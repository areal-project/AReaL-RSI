"""Session-affine Hermes processes preserve native global skill configuration."""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import tempfile
import weakref
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.adapters._identity_index import session_identity_map, string_identity_map
from areal_agent_runtime.adapters.hermes.runtime import HermesGatewayRuntimeAdapter
from areal_agent_runtime.contracts.runtime import (
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    RuntimeDescriptor,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    runtime_session_binding_digest,
)

MAX_SKILLS = 256
MAX_MANIFEST_BYTES = 16 * 1024 * 1024
MAX_FRONTMATTER_BYTES = 64 * 1024


def _skill_document(resource_id: str, content: Any) -> tuple[str, str]:
    text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False, allow_nan=False)
    if len(text.encode("utf-8")) > MAX_MANIFEST_BYTES:
        raise ValueError("Hermes skill exceeds 16 MiB")
    if not text.strip() or "\x00" in text:
        raise ValueError("Hermes skills require non-empty content without NUL")
    if text.startswith("---"):
        match = re.search(r"\n---\s*\n", text[3:])
        if match is None:
            raise ValueError("Hermes SKILL.md requires a closed YAML frontmatter")
        frontmatter = text[3 : match.start() + 3]
        if len(frontmatter.encode("utf-8")) > MAX_FRONTMATTER_BYTES:
            raise ValueError("Hermes skill frontmatter exceeds 64 KiB")
        try:
            if any(isinstance(token, (yaml.AliasToken, yaml.AnchorToken)) for token in yaml.scan(frontmatter)):
                raise ValueError("Hermes snapshot frontmatter does not support YAML aliases or anchors")
            metadata = yaml.safe_load(frontmatter)
        except (yaml.YAMLError, RecursionError) as exc:
            raise ValueError("Invalid Hermes skill frontmatter") from exc
        if not isinstance(metadata, dict):
            raise ValueError("Hermes skill frontmatter must be an object")
        name = metadata.get("name")
        description = metadata.get("description")
        if not isinstance(description, str) or not description.strip() or len(description) > 1024:
            raise ValueError("Hermes skill description must contain 1–1024 characters")
        # Hermes has no DSH/Claude invocation flags. Silently accepting them
        # would advertise restrictions the native skill loader does not enforce.
        if any(key in metadata for key in ("disable-model-invocation", "user-invocable", "allowed-tools")):
            raise ValueError("Hermes does not support invocation/tool permissions in skill frontmatter")
    else:
        slug = re.sub(r"[^a-z0-9-]+", "-", resource_id.lower()).strip("-") or "skill"
        name = (
            resource_id
            if len(resource_id) <= 64 and re.fullmatch(r"[a-z0-9][a-z0-9._-]*", resource_id)
            else (f"{slug[:47]}-{hashlib.sha256(resource_id.encode()).hexdigest()[:12]}")
        )
        text = f"---\nname: {name}\ndescription: {json.dumps('Runtime skill ' + resource_id)}\n---\n\n{text}"
    if not isinstance(name, str) or len(name) > 64 or re.fullmatch(r"[a-z0-9][a-z0-9._-]*", name) is None:
        raise ValueError("Hermes snapshot skill names must use native lowercase names and at most 64 characters")
    return name, text


def _write_manifest(directory: Path, spec: RuntimeSessionSpec | None, toolsets: tuple[str, ...] | None) -> Path:
    payload: dict[str, Any] = {"version": 1, "system": "", "skills": None, "toolsets": toolsets}
    if spec is not None:
        environment = spec.agent_environment.assert_integrity()
        if environment.tool_catalog or environment.tool_sources or environment.mcp_sources:
            raise ValueError(
                "Hermes runtime-owned mode accepts native tools via nativeToolsets/config; "
                "portable ToolSpec/ToolSource/MCP definitions are unsupported"
            )
        payload["system"] = "\n\n".join(
            resource.content
            if isinstance(resource.content, str)
            else json.dumps(resource.content, ensure_ascii=False, allow_nan=False)
            for resource in environment.system_prompts
        )
        if len(environment.skills) > MAX_SKILLS:
            raise ValueError("Hermes supports at most 256 skills per session")
        if environment.skills:
            payload["skills"] = []
            names: set[str] = set()
            for resource in environment.skills:
                name, document = _skill_document(resource.resource_id, resource.content)
                if name in names:
                    raise ValueError(f"Duplicate Hermes skill name: {name}")
                names.add(name)
                payload["skills"].append({"name": name, "document": document})
    encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    if len(encoded) > MAX_MANIFEST_BYTES:
        raise ValueError("Hermes native manifest exceeds 16 MiB")
    target = directory / "environment.json"
    target.touch(mode=0o600)
    target.write_bytes(encoded)
    return target


@dataclass(slots=True)
class _NativeSession:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    runtime: HermesGatewayRuntimeAdapter
    directory: tempfile.TemporaryDirectory[str]
    session_closed: bool = False
    runtime_closed: bool = False


class HermesNativeRuntimeAdapter:
    """One native Gateway per immutable session, with no cross-session globals."""

    def __init__(self, launch: dict[str, Any], descriptor: RuntimeDescriptor, toolsets: tuple[str, ...] | None) -> None:
        self._launch = launch
        self._descriptor = descriptor
        self._toolsets = toolsets
        self._sessions: dict[str, _NativeSession] = {}
        self._pending_cleanup: list[tuple[HermesGatewayRuntimeAdapter, tempfile.TemporaryDirectory[str]]] = []
        self._closed_refs = session_identity_map()
        self._session_bindings = string_identity_map()
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._closing = False
        self._close_lock = asyncio.Lock()
        self._execution_slots = asyncio.Semaphore(launch["max_concurrency"])

    @classmethod
    async def create(
        cls, *, native_toolsets: tuple[str, ...] | None = None, **launch: Any
    ) -> HermesNativeRuntimeAdapter:
        if native_toolsets is not None and (
            not native_toolsets
            or len(set(native_toolsets)) != len(native_toolsets)
            or any(
                not isinstance(name, str) or re.fullmatch(r"[A-Za-z0-9_-]+", name) is None for name in native_toolsets
            )
        ):
            raise ValueError("nativeToolsets must be a non-empty set of native Hermes toolset names")
        # Validate installed API compatibility by starting the actual native
        # entrypoint even before the first Application session is requested.
        with tempfile.TemporaryDirectory(prefix="areal-hermes-probe-") as root:
            manifest = _write_manifest(Path(root), None, native_toolsets)
            runtime = await cls._spawn(launch, manifest)
            try:
                descriptor = await runtime.describe()
                await runtime._peer.request("areal.native.info", {})
            finally:
                await runtime.close()
        return cls(launch, descriptor, native_toolsets)

    @staticmethod
    async def _spawn(launch: dict[str, Any], manifest: Path) -> HermesGatewayRuntimeAdapter:
        runtime = await HermesGatewayRuntimeAdapter.spawn_stdio(
            **launch, _raw_stdio=True, _native_manifest=str(manifest)
        )
        assert isinstance(runtime, HermesGatewayRuntimeAdapter)
        return runtime

    async def describe(self) -> RuntimeDescriptor:
        return self._descriptor

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        lock = self._locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Hermes runtime is closing")
            require_runtime_environment_identity(self._descriptor, spec.agent_environment)
            existing = self._sessions.get(spec.session_id)
            if existing is not None:
                if existing.session_closed or existing.runtime_closed:
                    raise RuntimeError("Hermes session is closing")
                require_same_runtime_session_spec(existing.spec, spec)
                return existing.ref
            digest = runtime_session_binding_digest(spec)
            previous = self._session_bindings.get(spec.session_id)
            if previous is not None and previous != digest:
                raise ValueError("Hermes closed session does not match the immutable RuntimeSessionSpec")
            if spec.metadata.get("hermesStoredSessionId") is not None:
                raise ValueError("Hermes native resume uses the immutable binding, not hermesStoredSessionId metadata")
            directory = tempfile.TemporaryDirectory(prefix="areal-hermes-session-")
            runtime: HermesGatewayRuntimeAdapter | None = None
            try:
                manifest = _write_manifest(Path(directory.name), spec, self._toolsets)
                runtime = await self._spawn(self._launch, manifest)
                runtime._execution_slots = self._execution_slots
                runtime._strict_resume = True
                await runtime._peer.request("areal.native.info", {})
                ref = await runtime.open_session(spec)
                self._session_bindings[spec.session_id] = digest
            except BaseException as exc:
                if runtime is not None:
                    try:
                        await runtime.close()
                    except BaseException as cleanup_error:
                        self._pending_cleanup.append((runtime, directory))
                        exc.add_note(f"Hermes startup cleanup requires retry: {type(cleanup_error).__name__}")
                        raise exc from None
                directory.cleanup()
                raise
            self._sessions[spec.session_id] = _NativeSession(spec, ref, runtime, directory)
            return ref

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Hermes runtime is closing")
        session = self._sessions.get(request.session_id)
        if session is None:
            raise LookupError("Hermes session is not open")
        return await session.runtime.execute(request)

    async def close_session(self, ref: RuntimeSessionRef) -> None:
        lock = self._locks.setdefault(ref.session_id, asyncio.Lock())
        async with lock:
            session = self._sessions.get(ref.session_id)
            if session is None:
                if self._closed_refs.get(ref.session_id) == ref:
                    return
                raise LookupError("Hermes session reference is not owned by this adapter")
            if session.ref != ref:
                raise ValueError("Hermes session reference does not match the open session")
            self._closed_refs[ref.session_id] = ref
            if not session.session_closed:
                await session.runtime.close_session(ref)
                session.session_closed = True
            if not session.runtime_closed:
                await session.runtime.close()
                session.runtime_closed = True
            await run_blocking_io(session.directory.cleanup)
            self._sessions.pop(ref.session_id, None)

    async def health(self) -> HealthStatus:
        if self._closing:
            return HealthStatus(status="unhealthy", details={"reason": "closed"})
        for session in tuple(self._sessions.values()):
            health = await session.runtime.health()
            if health.status != "healthy":
                return health
        return HealthStatus(status="healthy", details={"binding": "native-session-processes"})

    async def close(self) -> None:
        async with self._close_lock:
            self._closing = True
            # Wait for in-flight open_session calls before enumerating owners.
            for lock in tuple(self._locks.values()):
                async with lock:
                    pass
            failures: list[Exception] = []
            for runtime, directory in tuple(self._pending_cleanup):
                try:
                    await runtime.close()
                    directory.cleanup()
                    self._pending_cleanup.remove((runtime, directory))
                except Exception as exc:
                    failures.append(exc)
            for session in tuple(self._sessions.values()):
                try:
                    await self.close_session(session.ref)
                except Exception as exc:
                    failures.append(exc)
            if failures:
                raise ExceptionGroup("Hermes session cleanup failed", failures)
            for index in (self._closed_refs, self._session_bindings):
                try:
                    index.close()
                except Exception as exc:
                    failures.append(exc)
            if failures:
                raise ExceptionGroup("Hermes identity index cleanup failed", failures)
