"""Production OCR engine adapter backed by the Tesseract CLI."""

from __future__ import annotations

import asyncio
import csv
import os
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters.vision.ocr import (
    BoundingBox,
    OCRExtraction,
    OCRSpan,
)
from areal_agent_runtime.contracts.runtime import HealthStatus

_IMAGE_SUFFIXES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
    "image/tiff": ".tiff",
    "image/bmp": ".bmp",
}


@dataclass(frozen=True, slots=True)
class TesseractOCRConfig:
    executable: str = "tesseract"
    timeout_seconds: float = 30.0
    default_language: str | None = None


class TesseractOCREngine:
    """Run Tesseract out of process and normalize its TSV into OCRExtraction v1."""

    def __init__(self, config: TesseractOCRConfig | None = None) -> None:
        self._config = config or TesseractOCRConfig()

    async def recognize(
        self,
        image: bytes,
        *,
        media_type: str,
        language: str | None,
    ) -> OCRExtraction:
        suffix = _IMAGE_SUFFIXES.get(media_type)
        if suffix is None:
            raise ValueError(f"Tesseract OCR does not support {media_type}")
        descriptor, name = tempfile.mkstemp(prefix="areal_agent_runtime-ocr-", suffix=suffix)
        os.close(descriptor)
        source = Path(name)
        try:
            await asyncio.to_thread(source.write_bytes, image)
            command = [self._config.executable, str(source), "stdout"]
            selected_language = language or self._config.default_language
            if selected_language:
                command.extend(("-l", selected_language))
            command.append("tsv")
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                async with asyncio.timeout(self._config.timeout_seconds):
                    stdout, stderr = await process.communicate()
            except TimeoutError:
                process.kill()
                await process.wait()
                raise TimeoutError(
                    f"Tesseract OCR exceeded {self._config.timeout_seconds:g}s"
                ) from None
            if process.returncode != 0:
                detail = stderr.decode("utf-8", errors="replace").strip()
                raise RuntimeError(
                    f"Tesseract OCR failed with exit code {process.returncode}: {detail}"
                )
            return self.parse_tsv(
                stdout.decode("utf-8-sig", errors="strict"),
                language=selected_language,
            )
        finally:
            await asyncio.to_thread(source.unlink, missing_ok=True)

    async def health(self) -> HealthStatus:
        executable = await asyncio.to_thread(shutil.which, self._config.executable)
        if executable is None:
            return HealthStatus(
                status="unhealthy",
                details={
                    "reason": "tesseract_not_found",
                    "executable": self._config.executable,
                },
            )
        try:
            process = await asyncio.create_subprocess_exec(
                executable,
                "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            async with asyncio.timeout(5):
                output, _ = await process.communicate()
        except Exception as exc:
            return HealthStatus(
                status="unhealthy",
                details={"reason": str(exc) or type(exc).__name__},
            )
        first_line = output.decode("utf-8", errors="replace").splitlines()
        return HealthStatus(
            status="healthy" if process.returncode == 0 else "unhealthy",
            details={
                "executable": executable,
                "version": first_line[0] if first_line else "unknown",
            },
        )

    @staticmethod
    def parse_tsv(value: str, *, language: str | None = None) -> OCRExtraction:
        spans: list[OCRSpan] = []
        line_words: dict[tuple[int, int, int, int], list[str]] = {}
        for row in csv.DictReader(value.splitlines(), delimiter="\t"):
            text = str(row.get("text") or "").strip()
            if not text:
                continue
            try:
                confidence_raw = float(row.get("conf") or -1)
                left = float(row.get("left") or 0)
                top = float(row.get("top") or 0)
                width = float(row.get("width") or 0)
                height = float(row.get("height") or 0)
                page = int(row.get("page_num") or 1)
                key = (
                    page,
                    int(row.get("block_num") or 0),
                    int(row.get("par_num") or 0),
                    int(row.get("line_num") or 0),
                )
            except (TypeError, ValueError) as exc:
                raise ValueError("Tesseract returned malformed TSV") from exc
            confidence = max(0.0, min(1.0, confidence_raw / 100.0)) if confidence_raw >= 0 else None
            spans.append(
                OCRSpan(
                    text=text,
                    confidence=confidence,
                    box=BoundingBox(x=left, y=top, width=width, height=height),
                    page=max(1, page),
                )
            )
            line_words.setdefault(key, []).append(text)
        text = "\n".join(" ".join(words) for words in line_words.values())
        return OCRExtraction(
            text=text,
            spans=tuple(spans),
            detected_language=language,
            engine="tesseract",
            metadata={"format": "tsv", "wordCount": len(spans)},
        )


def create_engine(config: dict[str, JsonValue]) -> TesseractOCREngine:
    executable = config.get("executable")
    language = config.get("defaultLanguage")
    timeout = config.get("timeoutSeconds")
    if executable is not None and (not isinstance(executable, str) or not executable):
        raise ValueError("Tesseract executable must be a non-empty string")
    if language is not None and (not isinstance(language, str) or not language):
        raise ValueError("Tesseract defaultLanguage must be a non-empty string")
    if timeout is not None and (
        not isinstance(timeout, (int, float))
        or isinstance(timeout, bool)
        or timeout <= 0
    ):
        raise ValueError("Tesseract timeoutSeconds must be positive")
    return TesseractOCREngine(
        TesseractOCRConfig(
            executable=executable if isinstance(executable, str) else "tesseract",
            timeout_seconds=float(timeout) if isinstance(timeout, (int, float)) else 30.0,
            default_language=language if isinstance(language, str) else None,
        )
    )
