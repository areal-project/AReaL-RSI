"""Typed event builders which keep sequence and lineage adapter-neutral."""

from __future__ import annotations

from typing import Literal

from pydantic import JsonValue

from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.errors import ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.runtime import (
    ModelCallCompletedEventData,
    ModelCallFailedEventData,
    ModelCallStartedEventData,
    RawRuntimeEventData,
    RuntimeEvent,
    ToolLifecycleEventData,
    ToolRequestedEventData,
    normalize_token_usage,
)
from areal_agent_runtime.kernel.ids import new_id


class HarnessEventBuilder:
    def __init__(
        self,
        *,
        producer: str,
        runtime_instance_id: str,
        execution_id: str,
        agent_id: str,
        parent_agent_id: str | None = None,
    ) -> None:
        if not producer.strip() or producer != producer.strip():
            raise ValueError("producer must be a non-empty trimmed string")
        self._producer = producer
        self._runtime_instance_id = runtime_instance_id
        self._execution_id = execution_id
        self._agent_id = agent_id
        self._parent_agent_id = parent_agent_id
        self._sequence = 0

    def event(
        self,
        event_type: EventType,
        data: dict[str, JsonValue],
        *,
        ignorable: bool = False,
    ) -> RuntimeEvent:
        result = RuntimeEvent(
            runtime_instance_id=self._runtime_instance_id,
            runtime_sequence=self._sequence,
            execution_id=self._execution_id,
            agent_id=self._agent_id,
            parent_agent_id=self._parent_agent_id,
            type=event_type,
            data=data,
            ignorable=ignorable,
        )
        self._sequence += 1
        return result

    def message(
        self,
        content: tuple[ContentBlock, ...],
        *,
        model_call_id: str | None = None,
        message_id: str | None = None,
    ) -> RuntimeEvent:
        return self.event(
            EventType.MESSAGE_COMPLETED,
            {
                "content": [item.model_dump(mode="json", by_alias=True) for item in content],
                "messageId": message_id or new_id("msg"),
                "modelCallId": model_call_id,
                "role": "assistant",
            },
        )

    def usage(self, raw: object, *, model_call_id: str | None = None) -> RuntimeEvent:
        normalized = normalize_token_usage(
            raw,
            scope="model-call" if model_call_id is not None else "execution",
        )
        if normalized is None:
            raise ValueError("vendor usage contains no recognized token counters")
        return self.event(
            EventType.USAGE_UPDATED,
            {
                "modelCallId": model_call_id,
                "usage": normalized.model_dump(mode="json", by_alias=True),
            },
        )

    def model_started(
        self,
        *,
        provider: str,
        model: str,
        model_call_id: str | None = None,
        attempt: int = 1,
    ) -> RuntimeEvent:
        payload = ModelCallStartedEventData(
            model_call_id=model_call_id or new_id("mcall"),
            provider=provider,
            model=model,
            attempt=attempt,
        )
        return self.event(
            EventType.MODEL_CALL_STARTED,
            payload.model_dump(mode="json", by_alias=True),
        )

    def model_completed(
        self,
        *,
        model_call_id: str,
        provider: str,
        model: str,
        duration_seconds: float,
        finish_reason: str | None = None,
        provider_request_id: str | None = None,
        attempt: int = 1,
    ) -> RuntimeEvent:
        payload = ModelCallCompletedEventData(
            model_call_id=model_call_id,
            provider=provider,
            model=model,
            attempt=attempt,
            provider_request_id=provider_request_id,
            finish_reason=finish_reason,
            duration_seconds=duration_seconds,
        )
        return self.event(
            EventType.MODEL_CALL_COMPLETED,
            payload.model_dump(mode="json", by_alias=True),
        )

    def model_failed(
        self,
        *,
        model_call_id: str,
        provider: str,
        model: str,
        duration_seconds: float,
        error: ErrorInfo,
        attempt: int = 1,
    ) -> RuntimeEvent:
        payload = ModelCallFailedEventData(
            model_call_id=model_call_id,
            provider=provider,
            model=model,
            attempt=attempt,
            error=error,
            duration_seconds=duration_seconds,
        )
        return self.event(
            EventType.MODEL_CALL_FAILED,
            payload.model_dump(mode="json", by_alias=True),
        )

    def tool_requested(
        self,
        *,
        call_id: str,
        name: str,
        arguments: dict[str, JsonValue],
        model_call_id: str | None = None,
    ) -> RuntimeEvent:
        payload = ToolRequestedEventData(
            call_id=call_id,
            name=name,
            arguments=arguments,
            model_call_id=model_call_id,
        )
        return self.event(
            EventType.TOOL_REQUESTED,
            payload.model_dump(mode="json", by_alias=True),
        )

    def tool_terminal(
        self,
        *,
        call_id: str,
        name: str,
        model_call_id: str | None = None,
        content: tuple[ContentBlock, ...] = (),
        value: JsonValue = None,
        error: ErrorInfo | None = None,
        duration_seconds: float | None = None,
    ) -> RuntimeEvent:
        payload = ToolLifecycleEventData(
            call_id=call_id,
            name=name,
            model_call_id=model_call_id,
            content=content,
            value=value,
            error=error,
            duration_seconds=duration_seconds,
        )
        return self.event(
            EventType.TOOL_FAILED if error is not None else EventType.TOOL_COMPLETED,
            payload.model_dump(mode="json", by_alias=True),
        )

    def raw(
        self,
        vendor_event_type: str,
        payload: JsonValue,
        *,
        reason: Literal[
            "unknown-event", "unsupported-event", "canonicalization-failed"
        ] = "unsupported-event",
    ) -> RuntimeEvent:
        data = RawRuntimeEventData(
            producer=self._producer,
            vendor_event_type=vendor_event_type,
            runtime_instance_id=self._runtime_instance_id,
            runtime_sequence=self._sequence,
            reason=reason,
            payload=payload,
        )
        return self.event(
            EventType.RAW_EVENT_RECORDED,
            data.model_dump(mode="json", by_alias=True),
            ignorable=True,
        )

    def raw_ref(
        self,
        vendor_event_type: str,
        asset_id: str,
        *,
        reason: Literal[
            "unknown-event", "unsupported-event", "canonicalization-failed"
        ] = "unsupported-event",
    ) -> RuntimeEvent:
        data = RawRuntimeEventData(
            producer=self._producer,
            vendor_event_type=vendor_event_type,
            runtime_instance_id=self._runtime_instance_id,
            runtime_sequence=self._sequence,
            reason=reason,
            storage="asset-ref",
            asset_id=asset_id,
        )
        return self.event(
            EventType.RAW_EVENT_RECORDED,
            data.model_dump(mode="json", by_alias=True),
            ignorable=True,
        )
