"""Canonical multimodal content and durable asset references."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, JsonValue, StrictInt, field_validator

from areal_agent_runtime.contracts.base import (
    ContractModel,
    require_media_type,
    require_optional_trimmed,
    require_trimmed,
)


class AssetLocator(ContractModel):
    scheme: Literal["asset", "https", "s3", "oss", "file"] = "asset"
    value: str = Field(min_length=1)

    @field_validator("value")
    @classmethod
    def validate_value(cls, value: str) -> str:
        return require_trimmed(value, "Asset locator value")


class AssetRef(ContractModel):
    asset_id: str = Field(min_length=1)
    media_type: str = Field(min_length=1)
    size: StrictInt | None = Field(default=None, ge=0)
    sha256: str | None = Field(default=None, pattern=r"^[a-fA-F0-9]{64}$")
    locator: AssetLocator
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "assetId")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value)

    @field_validator("sha256")
    @classmethod
    def normalize_sha256(cls, value: str | None) -> str | None:
        return value.lower() if value is not None else None


class TextBlock(ContractModel):
    type: Literal["text"] = "text"
    text: str


class ReasoningBlock(ContractModel):
    type: Literal["reasoning"] = "reasoning"
    text: str
    visibility: Literal["private", "summary", "public"] = "private"


class ImageRefBlock(ContractModel):
    type: Literal["image_ref"] = "image_ref"
    asset_id: str = Field(min_length=1)
    media_type: str = Field(pattern=r"^image/")
    detail: Literal["auto", "low", "high", "original"] = "auto"
    alt: str | None = None

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "image assetId")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value, prefix="image")


class AudioRefBlock(ContractModel):
    type: Literal["audio_ref"] = "audio_ref"
    asset_id: str = Field(min_length=1)
    media_type: str = Field(pattern=r"^audio/")
    transcript: str | None = None

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "audio assetId")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value, prefix="audio")


class VideoRefBlock(ContractModel):
    type: Literal["video_ref"] = "video_ref"
    asset_id: str = Field(min_length=1)
    media_type: str = Field(pattern=r"^video/")
    poster_asset_id: str | None = None

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "video assetId")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value, prefix="video")

    @field_validator("poster_asset_id")
    @classmethod
    def validate_poster_asset_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "posterAssetId")


class FileRefBlock(ContractModel):
    type: Literal["file_ref"] = "file_ref"
    asset_id: str = Field(min_length=1)
    media_type: str = Field(min_length=1)
    filename: str | None = None

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "file assetId")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value)

    @field_validator("filename")
    @classmethod
    def validate_filename(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "filename")


class JsonBlock(ContractModel):
    type: Literal["json"] = "json"
    value: JsonValue
    schema_name: str | None = None

    @field_validator("schema_name")
    @classmethod
    def validate_schema_name(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "schemaName")


ContentBlock = Annotated[
    TextBlock | ReasoningBlock | ImageRefBlock | AudioRefBlock | VideoRefBlock | FileRefBlock | JsonBlock,
    Field(discriminator="type"),
]
