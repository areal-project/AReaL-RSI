"""Reference in-memory StateStore used by tests and local examples."""

from __future__ import annotations

import asyncio
import math
import time
from collections import defaultdict
from collections.abc import AsyncIterator
from dataclasses import dataclass

from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.product import RunSnapshot, RunStatus

TERMINAL_STATUSES = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}


def status_for_event(event: RunEvent, current: RunStatus) -> RunStatus:
    if event.type == EventType.INTERACTION_REQUIRED:
        return current if event.data.get("terminal") is True else RunStatus.WAITING
    if event.type == EventType.INTERACTION_RESOLVED:
        pending = event.data.get("pendingInteractions")
        has_pending = (
            isinstance(pending, int)
            and not isinstance(pending, bool)
            and pending > 0
        )
        return RunStatus.WAITING if has_pending else RunStatus.RUNNING
    return {
        EventType.RUN_QUEUED: RunStatus.QUEUED,
        EventType.RUN_STARTED: RunStatus.RUNNING,
        EventType.RUN_RESUMED: RunStatus.RUNNING,
        EventType.RUN_COMPLETED: RunStatus.COMPLETED,
        EventType.RUN_FAILED: RunStatus.FAILED,
        EventType.RUN_CANCELLED: RunStatus.CANCELLED,
    }.get(event.type, current)


def validate_state_commit(event: RunEvent, snapshot: RunSnapshot, current: RunSnapshot) -> None:
    """Enforce the canonical EventLog -> RunSnapshot state machine."""

    if snapshot.run_id != event.run_id or snapshot.session_id != event.session_id:
        raise ValueError("event and RunSnapshot identities do not match")
    if current.run_id != event.run_id or current.session_id != event.session_id:
        raise ValueError("event identity does not match the durable Run")
    if snapshot.profile != current.profile:
        raise ValueError("RunSnapshot profile is immutable")
    if snapshot.workspace_id != current.workspace_id:
        raise ValueError("RunSnapshot workspaceId is immutable")
    if snapshot.context != current.context:
        raise ValueError("RunSnapshot context is immutable")
    if event.type == EventType.ENVIRONMENT_CREATED:
        if (
            event.environment_id is None
            or snapshot.environment_id != event.environment_id
            or event.data.get("environmentId") != event.environment_id
        ):
            raise ValueError("environment.created must atomically project environmentId")
    elif snapshot.environment_id != current.environment_id:
        raise ValueError("RunSnapshot environmentId can only change with environment.created")
    expected_correlation = current.context.correlation_id or event.run_id
    if event.correlation_id != expected_correlation:
        raise ValueError("canonical event correlationId does not match the Run context")
    if (
        event.tenant_id != current.context.tenant_id
        or event.project_id != current.context.project_id
        or event.trace_id != current.context.trace_id
        or event.episode_id != current.context.episode_id
    ):
        raise ValueError("canonical event lineage does not match the Run context")
    if event.type != EventType.ENVIRONMENT_CREATED and event.environment_id != current.environment_id:
        raise ValueError("canonical event environmentId does not match the Run projection")
    if snapshot.last_sequence != event.sequence:
        raise ValueError("RunSnapshot last_sequence must equal the committed event sequence")

    # A fully applied commit.pending journal is replayed against its own
    # resulting snapshot. It is valid only when byte-for-byte idempotent.
    if current.last_sequence == event.sequence:
        if snapshot != current:
            raise ValueError("StateStore replay conflicts with the durable RunSnapshot")
        return
    if event.sequence != current.last_sequence + 1:
        raise ValueError("RunSnapshot/Event sequence does not follow the durable snapshot")
    if current.status in TERMINAL_STATUSES:
        raise ValueError(f"Run is already terminal: {current.status.value}")

    allowed_sources = {
        EventType.RUN_QUEUED: {RunStatus.QUEUED},
        EventType.RUN_STARTED: {RunStatus.QUEUED},
        EventType.RUN_RESUMED: {RunStatus.QUEUED, RunStatus.RUNNING, RunStatus.WAITING},
        EventType.INTERACTION_REQUIRED: {RunStatus.RUNNING, RunStatus.WAITING},
        EventType.INTERACTION_RESOLVED: {RunStatus.RUNNING, RunStatus.WAITING},
        EventType.RUN_COMPLETED: {RunStatus.RUNNING},
        EventType.RUN_FAILED: {RunStatus.QUEUED, RunStatus.RUNNING, RunStatus.WAITING},
        EventType.RUN_CANCELLED: {RunStatus.QUEUED, RunStatus.RUNNING, RunStatus.WAITING},
    }
    allowed = allowed_sources.get(event.type)
    if allowed is not None and current.status not in allowed:
        raise ValueError(
            f"{event.type.value} is invalid while Run status is {current.status.value}"
        )

    expected_status = status_for_event(event, current.status)
    if snapshot.status != expected_status:
        raise ValueError(
            f"{event.type.value} must commit Run status {expected_status.value}"
        )
    if event.type == EventType.RUN_QUEUED and event.sequence != 0:
        raise ValueError("run.queued must be the first canonical event")
    if event.type == EventType.RUN_FAILED:
        error = event.data.get("error")
        if not isinstance(error, dict) or snapshot.error != error:
            raise ValueError("run.failed must commit its canonical error payload")
    elif snapshot.error != current.error:
        raise ValueError("RunSnapshot error can only change with run.failed")


def _durable_copy(value):  # type: ignore[no-untyped-def]
    return type(value).model_validate(value.model_dump(mode="json", by_alias=True))


@dataclass(frozen=True, slots=True)
class _OutboxEntry:
    event_id: str
    sequence: int
    sink_ids: tuple[str, ...]


class InMemoryStateStore:
    def __init__(self) -> None:
        self._runs: dict[str, RunSnapshot] = {}
        self._events: dict[str, list[RunEvent]] = defaultdict(list)
        self._outbox: dict[str, list[_OutboxEntry]] = defaultdict(list)
        self._outbox_acks: dict[tuple[str, str], int] = {}
        self._environments: dict[str, AgentEnvironmentSnapshot] = {}
        self._run_leases: dict[str, tuple[str, float]] = {}
        self._condition = asyncio.Condition()

    async def create_run(self, snapshot: RunSnapshot) -> None:
        if snapshot.last_sequence != -1:
            raise ValueError("a new RunSnapshot must start at sequence -1")
        durable = _durable_copy(snapshot)
        async with self._condition:
            if snapshot.run_id in self._runs:
                raise ValueError(f"run already exists: {snapshot.run_id}")
            self._runs[snapshot.run_id] = durable
            self._condition.notify_all()

    async def save_run(self, snapshot: RunSnapshot) -> None:
        snapshot = _durable_copy(snapshot)
        async with self._condition:
            current = self._runs.get(snapshot.run_id)
            if current is None:
                raise KeyError(snapshot.run_id)
            expected = len(self._events.get(snapshot.run_id, ())) - 1
            if snapshot.last_sequence != expected:
                raise ValueError(
                    f"RunSnapshot sequence must match EventLog for {snapshot.run_id}: "
                    f"expected {expected}, got {snapshot.last_sequence}"
                )
            if snapshot != current:
                raise ValueError(
                    "save_run is an idempotent compatibility operation; "
                    "RunSnapshot changes must be committed with their canonical event"
                )
            self._condition.notify_all()

    async def get_run(self, run_id: str) -> RunSnapshot | None:
        self._validate_identity(run_id, "run_id")
        async with self._condition:
            snapshot = self._runs.get(run_id)
            return _durable_copy(snapshot) if snapshot is not None else None

    async def try_acquire_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool:
        self._validate_identity(run_id, "run_id")
        self._validate_lease_input(owner_id, ttl_seconds)
        async with self._condition:
            snapshot = self._runs.get(run_id)
            if snapshot is None:
                raise KeyError(run_id)
            if snapshot.status in TERMINAL_STATUSES:
                return False
            now = time.monotonic()
            existing = self._run_leases.get(run_id)
            if existing is not None and existing[0] != owner_id and existing[1] > now:
                return False
            self._run_leases[run_id] = (owner_id, now + ttl_seconds)
            self._condition.notify_all()
            return True

    async def renew_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool:
        self._validate_identity(run_id, "run_id")
        self._validate_lease_input(owner_id, ttl_seconds)
        async with self._condition:
            if run_id not in self._runs:
                raise KeyError(run_id)
            now = time.monotonic()
            existing = self._run_leases.get(run_id)
            if existing is None or existing[0] != owner_id or existing[1] <= now:
                return False
            self._run_leases[run_id] = (owner_id, now + ttl_seconds)
            self._condition.notify_all()
            return True

    async def release_run(self, run_id: str, owner_id: str) -> None:
        self._validate_identity(run_id, "run_id")
        self._validate_identity(owner_id, "run lease owner_id")
        async with self._condition:
            existing = self._run_leases.get(run_id)
            if existing is not None and existing[0] == owner_id:
                self._run_leases.pop(run_id, None)
                self._condition.notify_all()

    async def save_environment_snapshot(
        self,
        session_id: str,
        snapshot: AgentEnvironmentSnapshot,
    ) -> None:
        self._validate_identity(session_id, "session_id")
        snapshot.assert_integrity()
        durable = AgentEnvironmentSnapshot.model_validate(snapshot.model_dump(mode="json", by_alias=True))
        async with self._condition:
            existing = self._environments.get(session_id)
            if existing is not None and existing.digest != snapshot.digest:
                raise ValueError(f"agent environment is immutable for session: {session_id}")
            self._environments.setdefault(session_id, durable)
            self._condition.notify_all()

    async def get_environment_snapshot(self, session_id: str) -> AgentEnvironmentSnapshot | None:
        self._validate_identity(session_id, "session_id")
        snapshot = self._environments.get(session_id)
        if snapshot is None:
            return None
        return AgentEnvironmentSnapshot.model_validate(snapshot.model_dump(mode="json", by_alias=True))

    async def commit_event(
        self,
        event: RunEvent,
        snapshot: RunSnapshot,
        *,
        outbox_sinks: tuple[str, ...],
    ) -> None:
        durable_event = _durable_copy(event)
        durable_snapshot = _durable_copy(snapshot)
        sink_ids = self._validate_sink_ids(outbox_sinks)
        async with self._condition:
            current = self._runs.get(durable_event.run_id)
            if current is None:
                raise KeyError(durable_event.run_id)
            events = self._events[durable_event.run_id]
            if durable_event.sequence != len(events):
                raise ValueError(
                    f"non-contiguous event sequence for {durable_event.run_id}: "
                    f"expected {len(events)}, got {durable_event.sequence}"
                )
            if any(current.event_id == durable_event.event_id for current in events):
                raise ValueError(f"duplicate event id: {durable_event.event_id}")
            self._validate_commit(durable_event, durable_snapshot, current)
            events.append(durable_event)
            self._outbox[durable_event.run_id].append(
                _OutboxEntry(
                    event_id=durable_event.event_id,
                    sequence=durable_event.sequence,
                    sink_ids=sink_ids,
                )
            )
            self._runs[durable_event.run_id] = durable_snapshot
            self._condition.notify_all()

    async def append_event(self, event: RunEvent) -> None:
        """Compatibility helper; new code must use the atomic commit_event API."""

        current = await self.get_run(event.run_id)
        if current is None:
            raise KeyError(event.run_id)
        status = status_for_event(event, current.status)
        await self.commit_event(
            event,
            current.model_copy(update={"last_sequence": event.sequence, "status": status}),
            outbox_sinks=(),
        )

    async def latest_event_sequence(self, run_id: str) -> int:
        self._validate_identity(run_id, "run_id")
        async with self._condition:
            if run_id not in self._runs:
                raise KeyError(run_id)
            return len(self._events.get(run_id, ())) - 1

    async def list_run_ids(self) -> tuple[str, ...]:
        async with self._condition:
            return tuple(sorted(self._runs))

    async def pending_event_deliveries(
        self,
        run_id: str,
        sink_id: str,
        *,
        limit: int = 128,
    ) -> tuple[RunEvent, ...]:
        self._validate_identity(run_id, "run_id")
        self._validate_delivery_input(sink_id, limit)
        async with self._condition:
            if run_id not in self._runs:
                raise KeyError(run_id)
            acknowledged = self._outbox_acks.get((run_id, sink_id), -1)
            event_by_sequence = {event.sequence: event for event in self._events.get(run_id, ())}
            pending = [
                _durable_copy(event_by_sequence[entry.sequence])
                for entry in self._outbox.get(run_id, ())
                if entry.sequence > acknowledged and sink_id in entry.sink_ids
            ]
            return tuple(pending[:limit])

    async def acknowledge_event_delivery(
        self,
        run_id: str,
        sink_id: str,
        *,
        through_sequence: int,
    ) -> None:
        self._validate_identity(run_id, "run_id")
        self._validate_identity(sink_id, "sink_id")
        if (
            isinstance(through_sequence, bool)
            or not isinstance(through_sequence, int)
            or through_sequence < 0
        ):
            raise ValueError("through_sequence must be a non-negative integer")
        async with self._condition:
            if run_id not in self._runs:
                raise KeyError(run_id)
            current = self._outbox_acks.get((run_id, sink_id), -1)
            if through_sequence <= current:
                return
            pending = [
                entry.sequence
                for entry in self._outbox.get(run_id, ())
                if entry.sequence > current and sink_id in entry.sink_ids
            ]
            if not pending or through_sequence not in pending:
                raise ValueError(
                    f"outbox acknowledgement does not name a pending delivery for {sink_id}: {through_sequence}"
                )
            self._outbox_acks[(run_id, sink_id)] = through_sequence
            self._condition.notify_all()

    async def list_events(self, run_id: str) -> tuple[RunEvent, ...]:
        self._validate_identity(run_id, "run_id")
        async with self._condition:
            return tuple(_durable_copy(event) for event in self._events.get(run_id, ()))

    async def _event_stream(self, run_id: str, after: int | None) -> AsyncIterator[RunEvent]:
        self._validate_identity(run_id, "run_id")
        if after is not None and (
            isinstance(after, bool) or not isinstance(after, int) or after < -1
        ):
            raise ValueError("event cursor must be an integer of at least -1")
        cursor = 0 if after is None else after + 1
        while True:
            async with self._condition:
                while cursor >= len(self._events.get(run_id, ())) and not self._is_terminal(run_id):
                    await self._condition.wait()
                events = self._events.get(run_id, ())
                pending = tuple(_durable_copy(event) for event in events[cursor:])
                terminal = self._is_terminal(run_id)
            for event in pending:
                cursor = event.sequence + 1
                yield event
            if terminal and cursor >= len(self._events.get(run_id, ())):
                return

    def stream_events(self, run_id: str, after: int | None = None) -> AsyncIterator[RunEvent]:
        return self._event_stream(run_id, after)

    def _is_terminal(self, run_id: str) -> bool:
        snapshot = self._runs.get(run_id)
        return snapshot is not None and snapshot.status in TERMINAL_STATUSES

    @staticmethod
    def _validate_lease_input(owner_id: str, ttl_seconds: float) -> None:
        InMemoryStateStore._validate_identity(owner_id, "run lease owner_id")
        if (
            isinstance(ttl_seconds, bool)
            or not isinstance(ttl_seconds, (int, float))
            or not math.isfinite(ttl_seconds)
            or ttl_seconds <= 0
        ):
            raise ValueError("run lease ttl_seconds must be a finite positive number")

    @staticmethod
    def _validate_delivery_input(sink_id: str, limit: int) -> None:
        InMemoryStateStore._validate_identity(sink_id, "sink_id")
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            raise ValueError("delivery limit must be a positive integer")

    @staticmethod
    def _validate_identity(value: str, field: str) -> None:
        if not isinstance(value, str) or not value.strip() or value != value.strip():
            raise ValueError(f"{field} must be a non-empty trimmed string")

    @classmethod
    def _validate_sink_ids(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if not isinstance(values, tuple):
            raise TypeError("outbox_sinks must be a tuple")
        for value in values:
            cls._validate_identity(value, "outbox sink identity")
        if len(values) != len(set(values)):
            raise ValueError("outbox sink identities must not contain duplicates")
        return values

    @staticmethod
    def _validate_commit(event: RunEvent, snapshot: RunSnapshot, current: RunSnapshot) -> None:
        validate_state_commit(event, snapshot, current)

    @staticmethod
    def _status_for_event(event: RunEvent, current: RunStatus) -> RunStatus:
        return status_for_event(event, current)

    @staticmethod
    def _validate_status_transition(
        event: RunEvent,
        snapshot: RunSnapshot,
        current: RunSnapshot,
    ) -> None:
        validate_state_commit(event, snapshot, current)
