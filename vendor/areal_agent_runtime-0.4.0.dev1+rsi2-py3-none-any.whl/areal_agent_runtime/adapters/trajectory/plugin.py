"""Plugin packaging for HTTP multimodal trajectory reporting."""

from __future__ import annotations

import os
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.trajectory.http import (
    HttpTrajectoryEventSink,
    TrajectoryHttpClient,
    TrajectoryHttpConfig,
)
from areal_agent_runtime.contracts.ports import AssetStorePort, StateStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class HttpTrajectoryPlugin:
    manifest = PluginManifest(
        name="http-trajectory",
        version="1.0.0",
        implements=(PortKey.EVENT_SINK,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.trajectory.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("network.trajectory", "asset.read", "state.read"),
    )

    def __init__(self) -> None:
        self.sink: HttpTrajectoryEventSink | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        endpoint = _required_string(config.get("endpoint"), "endpoint")
        client = TrajectoryHttpClient(
            TrajectoryHttpConfig(
                endpoint=endpoint,
                token=_secret(config),
                headers=_string_map(config.get("headers")),
                timeout_seconds=_positive_number(config.get("timeoutSeconds"), 30.0),
            )
        )
        self.sink = HttpTrajectoryEventSink(
            cast(StateStorePort, context.require(PortKey.STATE_STORE)),
            client,
            asset_store=_optional_asset_store(context),
            best_effort=config.get("bestEffort") is not False,
            max_attempts=_positive_integer(config.get("maxAttempts"), 3),
        )
        context.provide(PortKey.EVENT_SINK, self.sink)

    async def start(self) -> None:
        if self.sink is None:
            raise RuntimeError("HTTP trajectory plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.sink is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.sink.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> HttpTrajectoryPlugin:
    return HttpTrajectoryPlugin()


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _secret(config: dict[str, JsonValue]) -> str | None:
    env_name = _optional_string(config.get("tokenEnv"))
    if env_name is not None:
        value = os.environ.get(env_name)
        if not value:
            raise ValueError(f"environment variable {env_name!r} is empty or missing")
        return value
    return _optional_string(config.get("token"))


def _required_string(value: JsonValue | None, name: str) -> str:
    parsed = _optional_string(value)
    if parsed is None:
        raise ValueError(f"http-trajectory requires config.{name}")
    return parsed


def _optional_string(value: JsonValue | None) -> str | None:
    return value if isinstance(value, str) and value else None


def _string_map(value: JsonValue | None) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(key): item for key, item in value.items() if isinstance(item, str)}


def _positive_number(value: JsonValue | None, default: float) -> float:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0 else default


def _positive_integer(value: JsonValue | None, default: int) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else default
