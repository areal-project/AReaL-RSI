"""Plugin SPI packaging for the Anthropic Messages Runtime Adapter."""

from __future__ import annotations

import math
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters._asset_io import DEFAULT_MAX_RUNTIME_ASSET_BYTES
from areal_agent_runtime.adapters.anthropic_messages.runtime import (
    AnthropicMessagesRuntimeAdapter,
    AnthropicRuntimeConfig,
)
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class AnthropicMessagesRuntimePlugin:
    manifest = PluginManifest(
        name="anthropic-messages-runtime",
        version="1.1.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.anthropic_messages.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("network.model", "asset.read"),
    )

    def __init__(self) -> None:
        self.runtime: AnthropicMessagesRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        self.runtime = AnthropicMessagesRuntimeAdapter(
            asset_store=_optional_asset_store(context),
            config=AnthropicRuntimeConfig(
                model=_string(config.get("model"), default="claude-sonnet-4-5", field_name="model"),
                max_tokens=_positive_int(config.get("maxTokens"), 8192, "maxTokens"),
                max_turns=_positive_int(config.get("maxTurns"), 50, "maxTurns"),
                max_retries=_non_negative_int(config.get("maxRetries"), 2, "maxRetries"),
                retry_backoff_seconds=_non_negative_float(
                    config.get("retryBackoffSeconds"),
                    0.25,
                    "retryBackoffSeconds",
                ),
                max_no_progress_rounds=_positive_int(
                    config.get("maxNoProgressRounds"),
                    3,
                    "maxNoProgressRounds",
                ),
                max_history_chars=_positive_int(
                    config.get("maxHistoryChars"),
                    400_000,
                    "maxHistoryChars",
                ),
                max_concurrency=_positive_int(
                    config.get("maxConcurrency"),
                    8,
                    "maxConcurrency",
                ),
                max_input_asset_bytes=_positive_int(
                    config.get("maxInputAssetBytes"),
                    DEFAULT_MAX_RUNTIME_ASSET_BYTES,
                    "maxInputAssetBytes",
                ),
                api_key=_optional_string(config.get("apiKey"), field_name="apiKey"),
                base_url=_optional_string(config.get("baseUrl"), field_name="baseUrl"),
                default_headers=_string_map(config.get("defaultHeaders")),
                history_root=_optional_string(config.get("historyRoot"), field_name="historyRoot"),
                max_final_answer_attempts=_non_negative_int(
                    config.get("maxFinalAnswerAttempts"), 1, "maxFinalAnswerAttempts",
                ),
                model_parameters=_model_parameters(config.get("modelParameters")),
            ),
        )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Anthropic Messages plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> AnthropicMessagesRuntimePlugin:
    return AnthropicMessagesRuntimePlugin()


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _string(
    value: JsonValue | None,
    *,
    default: str,
    field_name: str,
) -> str:
    if value is None:
        return default
    result = _optional_string(value, field_name=field_name)
    assert result is not None
    return result


def _optional_string(value: JsonValue | None, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"{field_name} must be a non-blank, trimmed string")
    return value


def _positive_int(value: JsonValue | None, default: int, field_name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _non_negative_int(value: JsonValue | None, default: int, field_name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer")
    return value


def _non_negative_float(value: JsonValue | None, default: float, field_name: str) -> float:
    if value is None:
        return default
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value < 0
    ):
        raise ValueError(f"{field_name} must be a finite non-negative number")
    return float(value)


def _string_map(value: JsonValue | None) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("defaultHeaders must be an object containing string values")
    result: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise ValueError("defaultHeaders must be an object containing string values")
        result[key] = item
    return result


def _model_parameters(value: JsonValue | None) -> dict[str, JsonValue]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("modelParameters must be an object")
    return value
