"""Plugin packaging for the local AssetStore and trajectory EventSink."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.adapters.storage.assets import FileSystemAssetStore
from areal_agent_runtime.adapters.storage.sqlite_state import SQLiteStateStore
from areal_agent_runtime.adapters.storage.state import FileSystemStateStore
from areal_agent_runtime.adapters.storage.trajectory import JsonlTrajectorySink
from areal_agent_runtime.contracts.ports import AssetStorePort, StateStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class LocalStoragePlugin:
    manifest = PluginManifest(
        name="local-storage",
        version="1.0.0",
        implements=(PortKey.STATE_STORE, PortKey.ASSET_STORE, PortKey.EVENT_SINK),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.storage.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("filesystem.read", "filesystem.write"),
    )

    def __init__(self) -> None:
        self.asset_store: AssetStorePort | None = None
        self.state_store: StateStorePort | None = None
        self.trajectory_sink: JsonlTrajectorySink | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        configured_root = config.get("root")
        root = Path(configured_root) if isinstance(configured_root, str) else Path(".areal-agent-runtime")
        # Only an explicit loader binding selects another authority. A combined
        # asset plugin can incidentally register a StateStore of its own; that
        # must never override storage.root/stateBackend. Other PluginContext
        # implementations without binding metadata retain the local default.
        bindings = getattr(context, "bindings", {})
        bound_state = bindings.get(PortKey.STATE_STORE) if isinstance(bindings, Mapping) else None
        self.state_store = (
            cast(StateStorePort, context.require(PortKey.STATE_STORE, owner=bound_state))
            if isinstance(bound_state, str)
            else await run_blocking_io(_state_store, root, config.get("stateBackend", "auto"))
        )
        self.asset_store = (
            cast(AssetStorePort, context.require(PortKey.ASSET_STORE))
            if context.providers(PortKey.ASSET_STORE)
            else FileSystemAssetStore(root / "assets")
        )
        self.trajectory_sink = JsonlTrajectorySink(root / "trajectories", asset_store=self.asset_store)
        context.provide(PortKey.STATE_STORE, self.state_store)
        context.provide(PortKey.ASSET_STORE, self.asset_store)
        context.provide(PortKey.EVENT_SINK, self.trajectory_sink)

    async def start(self) -> None:
        health = await self.health()
        if health.status == "unhealthy":
            raise RuntimeError("Local storage is not writable")

    async def health(self) -> HealthStatus:
        if self.trajectory_sink is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.trajectory_sink.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> LocalStoragePlugin:
    return LocalStoragePlugin()


def _state_store(root: Path, backend: JsonValue) -> StateStorePort:
    root = root.expanduser().resolve()
    legacy_root, sqlite_path = root / "state", root / "state.sqlite3"
    if backend == "auto":
        legacy_exists = legacy_root.exists() and any(legacy_root.iterdir())
        if legacy_exists and sqlite_path.exists():
            raise ValueError("Both file and SQLite state exist; select storage.config.stateBackend explicitly")
        backend = "file" if legacy_exists else "sqlite"
    if backend == "file":
        return FileSystemStateStore(legacy_root)
    elif backend == "sqlite":
        return SQLiteStateStore(root)
    else:
        raise ValueError("stateBackend must be auto, sqlite, or file")
