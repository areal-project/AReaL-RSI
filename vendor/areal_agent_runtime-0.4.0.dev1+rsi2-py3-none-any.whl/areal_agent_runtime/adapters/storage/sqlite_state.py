"""Transactional SQLite StateStore for one host and its local durable volume.

WAL permits concurrent readers and serializes writers across processes. Execution
leases retain the existing owner/TTL contract; they are not distributed fencing.
Each operation owns its connection and transaction through cancellation cleanup.
"""

from __future__ import annotations

import asyncio
import json
import math
import sqlite3
import time
import weakref
from collections.abc import AsyncIterator, Iterator
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.contracts.data import RetentionClass
from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import RunEvent
from areal_agent_runtime.contracts.product import RunSnapshot, RunStatus
from areal_agent_runtime.kernel.state import status_for_event, validate_state_commit

_TERMINAL = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}
_SCHEMA_VERSION = 1
_APPLICATION_ID = 0x41525453  # ARTS, distinguishes this store from another SQLite database.
_SCHEMA = (
    """CREATE TABLE runs (
        run_id TEXT PRIMARY KEY,
        snapshot_json TEXT NOT NULL,
        last_sequence INTEGER NOT NULL CHECK(last_sequence >= -1),
        status TEXT NOT NULL
    )""",
    """CREATE TABLE events (
        run_id TEXT NOT NULL REFERENCES runs(run_id),
        sequence INTEGER NOT NULL CHECK(sequence >= 0),
        event_id TEXT NOT NULL,
        event_json TEXT NOT NULL,
        PRIMARY KEY(run_id, sequence),
        UNIQUE(run_id, event_id)
    )""",
    """CREATE TABLE deliveries (
        run_id TEXT NOT NULL,
        sink_id TEXT NOT NULL,
        sequence INTEGER NOT NULL,
        PRIMARY KEY(run_id, sink_id, sequence),
        FOREIGN KEY(run_id, sequence) REFERENCES events(run_id, sequence)
    )""",
    """CREATE TABLE acknowledgements (
        run_id TEXT NOT NULL,
        sink_id TEXT NOT NULL,
        through_sequence INTEGER NOT NULL,
        PRIMARY KEY(run_id, sink_id),
        FOREIGN KEY(run_id, sink_id, through_sequence)
            REFERENCES deliveries(run_id, sink_id, sequence)
    )""",
    """CREATE TABLE leases (
        run_id TEXT PRIMARY KEY REFERENCES runs(run_id),
        owner_id TEXT NOT NULL,
        expires_at REAL NOT NULL
    )""",
    """CREATE TABLE sessions (
        session_id TEXT PRIMARY KEY,
        digest TEXT NOT NULL,
        snapshot_json TEXT NOT NULL
    )""",
)


def _identity(value: str, field: str) -> None:
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be a non-empty trimmed string")


def _positive_seconds(value: float, field: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{field} must be finite and positive")


def _positive_integer(value: int, field: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field} must be a positive integer")


def _encode(value: RunEvent | RunSnapshot | AgentEnvironmentSnapshot) -> str:
    # Serializing before the first await also isolates caller-owned nested data.
    return json.dumps(value.model_dump(mode="json", by_alias=True), ensure_ascii=False,
                      sort_keys=True, separators=(",", ":"), allow_nan=False)


def _decode(payload: str) -> Any:
    def reject_constant(value: str) -> None:
        raise ValueError(f"non-finite JSON number is not allowed: {value}")

    def unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON object key: {key}")
            result[key] = value
        return result

    return json.loads(payload, parse_constant=reject_constant, object_pairs_hook=unique_object)


class SQLiteStateStore:
    """Implement StateStorePort with indexed canonical events and atomic outbox.

    ``root`` is a directory containing ``state.sqlite3`` and SQLite's WAL files.
    Connections are short-lived, so no explicit shutdown method is required.
    A local disk or local container volume is required; network filesystems and
    multi-host shared databases are outside this backend's supported topology.
    Optional query pages, outbox batches and streams bound serialized event
    bytes by ``page_max_bytes`` (8 MiB by default), in addition to item limits.
    An oversized individual event/snapshot raises ValueError without truncation;
    a deployment retaining such records must explicitly raise that budget.
    Python model overhead is additional; this is not a process RSS limit.
    New event/snapshot records must fit the same budget before they are written,
    so acceptance cannot create facts this configuration cannot later deliver.
    Legacy ``list_events``/``list_run_ids`` remain explicit bulk operations.
    """

    def __init__(
        self,
        root: str | Path,
        *,
        busy_timeout_seconds: float = 30.0,
        poll_interval_seconds: float = 0.25,
        stream_batch_size: int = 128,
        page_max_bytes: int = 8 * 1024 * 1024,
    ) -> None:
        _positive_seconds(busy_timeout_seconds, "busy_timeout_seconds")
        _positive_seconds(poll_interval_seconds, "poll_interval_seconds")
        _positive_integer(stream_batch_size, "stream_batch_size")
        _positive_integer(page_max_bytes, "page_max_bytes")
        self._root = Path(root).expanduser().resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        self._database = self._root / "state.sqlite3"
        if self._database.is_symlink():
            raise ValueError("SQLite StateStore database must not be a symlink")
        self._busy_timeout = busy_timeout_seconds
        self._poll_interval = poll_interval_seconds
        self._batch_size = stream_batch_size
        self._page_max_bytes = page_max_bytes
        self._conditions: weakref.WeakValueDictionary[str, asyncio.Condition] = weakref.WeakValueDictionary()
        self._initialize_database()

    def _open_connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._database, timeout=self._busy_timeout, isolation_level=None)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA synchronous = FULL")
            return connection
        except BaseException:
            connection.close()
            raise

    def _initialize_database(self) -> None:
        connection = self._open_connection()
        try:
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version == _SCHEMA_VERSION:
                self._validate_database_identity(connection)
            elif version != 0:
                raise ValueError(f"Unsupported SQLite StateStore schema version: {version}")
            elif connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' LIMIT 1"
            ).fetchone():
                raise ValueError("SQLite StateStore will not initialize an unrecognized existing database")
            journal_mode = connection.execute("PRAGMA journal_mode").fetchone()[0]
            if journal_mode != "wal":
                journal_mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()[0]
            if journal_mode != "wal":
                raise RuntimeError("SQLite StateStore requires WAL journal mode")
            if version == _SCHEMA_VERSION:
                return
            connection.execute("BEGIN IMMEDIATE")
            # Another constructor can finish initialization while we wait for
            # the writer reservation. Recheck before creating any tables.
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version == 0:
                tables = connection.execute(
                    "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
                ).fetchall()
                if tables:
                    raise ValueError("SQLite StateStore will not initialize an unrecognized existing database")
                for statement in _SCHEMA:
                    connection.execute(statement)
                connection.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
                connection.execute(f"PRAGMA application_id = {_APPLICATION_ID}")
            elif version != _SCHEMA_VERSION:
                raise ValueError(f"Unsupported SQLite StateStore schema version: {version}")
            self._validate_database_identity(connection)
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _validate_database_identity(connection: sqlite3.Connection) -> None:
        application_id = connection.execute("PRAGMA application_id").fetchone()[0]
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        if application_id != _APPLICATION_ID or not {
            "runs", "events", "deliveries", "acknowledgements", "leases", "sessions",
        }.issubset(tables):
            raise ValueError("Unrecognized or incomplete SQLite StateStore database")

    @contextmanager
    def _transaction(self, *, write: bool = False) -> Iterator[sqlite3.Connection]:
        connection = self._open_connection()
        try:
            connection.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _read_run(connection: sqlite3.Connection, run_id: str, *, required: bool = False) -> RunSnapshot | None:
        row = connection.execute("SELECT * FROM runs WHERE run_id = ?", (run_id,)).fetchone()
        if row is None:
            if required:
                raise KeyError(run_id)
            return None
        snapshot = RunSnapshot.model_validate(_decode(row["snapshot_json"]))
        if (snapshot.run_id != run_id or snapshot.last_sequence != row["last_sequence"]
                or snapshot.status.value != row["status"]):
            raise ValueError(f"SQLite StateStore snapshot identity/revision mismatch: {run_id}")
        head = connection.execute("SELECT MAX(sequence) FROM events WHERE run_id = ?", (run_id,)).fetchone()[0]
        if snapshot.last_sequence != (-1 if head is None else head):
            raise ValueError(f"SQLite StateStore snapshot/EventLog revision mismatch: {run_id}")
        return snapshot

    @staticmethod
    def _read_event(row: sqlite3.Row, snapshot: RunSnapshot) -> RunEvent:
        event = RunEvent.model_validate(_decode(row["event_json"]))
        if (event.run_id != snapshot.run_id or event.session_id != snapshot.session_id
                or event.sequence != row["sequence"] or event.event_id != row["event_id"]
                or event.correlation_id != (snapshot.context.correlation_id or snapshot.run_id)
                or event.tenant_id != snapshot.context.tenant_id or event.project_id != snapshot.context.project_id
                or event.trace_id != snapshot.context.trace_id or event.episode_id != snapshot.context.episode_id):
            raise ValueError(f"SQLite StateStore event identity/lineage mismatch: {snapshot.run_id}")
        return event

    async def create_run(self, snapshot: RunSnapshot) -> None:
        encoded = _encode(snapshot)
        await run_blocking_io(self._create_run, encoded)
        await self._notify(snapshot.run_id)

    def _check_record_budget(self, encoded: str, record_type: str) -> None:
        size = len(encoded.encode("utf-8"))
        if size > self._page_max_bytes:
            raise ContractError(ErrorInfo(
                code="STATE_RECORD_TOO_LARGE", category=ErrorCategory.INVALID_REQUEST,
                message=f"{record_type} exceeds SQLite StateStore page_max_bytes",
                details={"recordType": record_type, "actualBytes": size, "maxBytes": self._page_max_bytes},
            ))

    def _create_run(self, encoded: str) -> None:
        self._check_record_budget(encoded, "RunSnapshot")
        snapshot = RunSnapshot.model_validate(_decode(encoded))
        if snapshot.last_sequence != -1:
            raise ValueError("a new RunSnapshot must start at sequence -1")
        with self._transaction(write=True) as connection:
            if self._read_run(connection, snapshot.run_id) is not None:
                raise ValueError(f"run already exists: {snapshot.run_id}")
            connection.execute("INSERT INTO runs VALUES (?, ?, ?, ?)",
                               (snapshot.run_id, encoded, snapshot.last_sequence, snapshot.status.value))

    async def save_run(self, snapshot: RunSnapshot) -> None:
        await run_blocking_io(self._save_run, _encode(snapshot))

    def _save_run(self, encoded: str) -> None:
        snapshot = RunSnapshot.model_validate(_decode(encoded))
        with self._transaction(write=True) as connection:
            current = self._read_run(connection, snapshot.run_id, required=True)
            if snapshot != current:
                raise ValueError("save_run is an idempotent compatibility operation; "
                                 "RunSnapshot changes must be committed with their canonical event")

    async def get_run(self, run_id: str) -> RunSnapshot | None:
        _identity(run_id, "run_id")
        return await run_blocking_io(self._get_run, run_id)

    def _get_run(self, run_id: str) -> RunSnapshot | None:
        with self._transaction() as connection:
            return self._read_run(connection, run_id)

    async def commit_event(self, event: RunEvent, snapshot: RunSnapshot, *, outbox_sinks: tuple[str, ...]) -> None:
        if not isinstance(outbox_sinks, tuple):
            raise TypeError("outbox_sinks must be a tuple")
        for sink_id in outbox_sinks:
            _identity(sink_id, "outbox sink identity")
        if len(outbox_sinks) != len(set(outbox_sinks)):
            raise ValueError("outbox sink identities must not contain duplicates")
        await run_blocking_io(self._commit_event, _encode(event), _encode(snapshot), outbox_sinks)
        await self._notify(event.run_id)

    def _commit_event(self, encoded_event: str, encoded_snapshot: str, outbox_sinks: tuple[str, ...]) -> None:
        # Validate final UTF-8 encodings before opening a write transaction.
        # Neither half of a rejected fact may change history, snapshot or outbox.
        self._check_record_budget(encoded_event, "RunEvent")
        self._check_record_budget(encoded_snapshot, "RunSnapshot")
        event = RunEvent.model_validate(_decode(encoded_event))
        snapshot = RunSnapshot.model_validate(_decode(encoded_snapshot))
        with self._transaction(write=True) as connection:
            current = self._read_run(connection, event.run_id, required=True)
            assert current is not None
            if event.sequence != current.last_sequence + 1:
                raise ValueError(f"non-contiguous event sequence for {event.run_id}: "
                                 f"expected {current.last_sequence + 1}, got {event.sequence}")
            if connection.execute("SELECT 1 FROM events WHERE run_id = ? AND event_id = ?",
                                  (event.run_id, event.event_id)).fetchone():
                raise ValueError(f"duplicate event id: {event.event_id}")
            validate_state_commit(event, snapshot, current)
            connection.execute("INSERT INTO events VALUES (?, ?, ?, ?)",
                               (event.run_id, event.sequence, event.event_id, encoded_event))
            connection.execute("UPDATE runs SET snapshot_json = ?, last_sequence = ?, status = ? WHERE run_id = ?",
                               (encoded_snapshot, event.sequence, snapshot.status.value, event.run_id))
            connection.executemany("INSERT INTO deliveries VALUES (?, ?, ?)",
                                   ((event.run_id, sink_id, event.sequence) for sink_id in outbox_sinks))

    async def append_event(self, event: RunEvent) -> None:
        """Compatibility helper; authoritative publishers use commit_event."""
        current = await self.get_run(event.run_id)
        if current is None:
            raise KeyError(event.run_id)
        await self.commit_event(event, current.model_copy(update={
            "last_sequence": event.sequence, "status": status_for_event(event, current.status),
        }), outbox_sinks=())

    async def latest_event_sequence(self, run_id: str) -> int:
        _identity(run_id, "run_id")
        snapshot = await self.get_run(run_id)
        if snapshot is None:
            raise KeyError(run_id)
        return snapshot.last_sequence

    async def list_run_ids(self) -> tuple[str, ...]:
        return await run_blocking_io(self._list_run_ids)

    def _list_run_ids(self) -> tuple[str, ...]:
        with self._transaction() as connection:
            return tuple(row[0] for row in connection.execute("SELECT run_id FROM runs ORDER BY run_id"))

    async def list_run_snapshots(
        self, *, after_run_id: str | None = None, limit: int = 128,
    ) -> tuple[RunSnapshot, ...]:
        if after_run_id is not None:
            _identity(after_run_id, "after_run_id")
        _positive_integer(limit, "snapshot page limit")
        return await run_blocking_io(self._list_run_snapshots, after_run_id, limit)

    def _list_run_snapshots(self, after_run_id: str | None, limit: int) -> tuple[RunSnapshot, ...]:
        with self._transaction() as connection:
            rows = connection.execute(
                """SELECT run_id, length(CAST(snapshot_json AS BLOB)) AS size
                   FROM runs WHERE run_id > ? ORDER BY run_id LIMIT ?""", (after_run_id or "", limit),
            )
            snapshots: list[RunSnapshot] = []
            used_bytes = 0
            for row in rows:
                size = row["size"]
                if size > self._page_max_bytes:
                    raise ValueError(f"RunSnapshot exceeds page_max_bytes: {row['run_id']}")
                if used_bytes + size > self._page_max_bytes:
                    break
                snapshot = self._read_run(connection, row["run_id"], required=True)
                assert snapshot is not None
                snapshots.append(snapshot)
                used_bytes += size
            return tuple(snapshots)

    async def list_event_page(self, run_id: str, *, after: int = -1, limit: int = 128) -> tuple[RunEvent, ...]:
        _identity(run_id, "run_id")
        if isinstance(after, bool) or not isinstance(after, int) or after < -1:
            raise ValueError("event cursor must be an integer of at least -1")
        _positive_integer(limit, "event page limit")
        return await run_blocking_io(self._list_event_page, run_id, after, limit)

    def _list_event_page(self, run_id: str, after: int, limit: int) -> tuple[RunEvent, ...]:
        with self._transaction() as connection:
            snapshot = self._read_bounded_run(connection, run_id)
            return () if snapshot is None else self._read_event_page(connection, snapshot, after + 1, limit)

    def _read_bounded_run(
        self, connection: sqlite3.Connection, run_id: str, *, required: bool = False,
    ) -> RunSnapshot | None:
        row = connection.execute("SELECT length(CAST(snapshot_json AS BLOB)) FROM runs WHERE run_id = ?",
                                 (run_id,)).fetchone()
        if row is not None and row[0] > self._page_max_bytes:
            raise ValueError(f"RunSnapshot exceeds page_max_bytes: {run_id}")
        return self._read_run(connection, run_id, required=required)

    def _read_event_page(
        self, connection: sqlite3.Connection, snapshot: RunSnapshot, cursor: int, limit: int,
    ) -> tuple[RunEvent, ...]:
        if cursor > snapshot.last_sequence:
            return ()
        # Read lengths first so an oversized record never enters Python as a
        # giant string/model. The transaction keeps these lengths and bodies
        # consistent even when another process writes or prunes concurrently.
        rows = connection.execute(
            """SELECT sequence, length(CAST(event_json AS BLOB)) AS size FROM events
               WHERE run_id = ? AND sequence >= ? ORDER BY sequence LIMIT ?""",
            (snapshot.run_id, cursor, limit),
        )
        events: list[RunEvent] = []
        used_bytes = 0
        for metadata in rows:
            if metadata["sequence"] != cursor + len(events):
                raise ValueError(
                    f"SQLite StateStore EventLog gap at sequence {cursor + len(events)}: {snapshot.run_id}"
                )
            size = metadata["size"]
            if size > self._page_max_bytes:
                raise ValueError(f"RunEvent exceeds page_max_bytes: {snapshot.run_id}@{metadata['sequence']}")
            if used_bytes + size > self._page_max_bytes:
                break
            row = connection.execute("SELECT * FROM events WHERE run_id = ? AND sequence = ?",
                                     (snapshot.run_id, metadata["sequence"])).fetchone()
            events.append(self._read_event(row, snapshot))
            used_bytes += size
        if not events:
            raise ValueError(f"SQLite StateStore EventLog gap at sequence {cursor}: {snapshot.run_id}")
        return tuple(events)

    async def list_events(self, run_id: str) -> tuple[RunEvent, ...]:
        _identity(run_id, "run_id")
        return await run_blocking_io(self._list_events, run_id)

    def _list_events(self, run_id: str) -> tuple[RunEvent, ...]:
        with self._transaction() as connection:
            snapshot = self._read_run(connection, run_id)
            if snapshot is None:
                return ()
            rows = connection.execute("SELECT * FROM events WHERE run_id = ? ORDER BY sequence", (run_id,))
            events = tuple(self._read_event(row, snapshot) for row in rows)
            if len(events) != snapshot.last_sequence + 1 or any(e.sequence != i for i, e in enumerate(events)):
                raise ValueError(f"SQLite StateStore EventLog sequences must be contiguous from zero: {run_id}")
            return events

    async def pending_event_deliveries(self, run_id: str, sink_id: str, *, limit: int = 128) -> tuple[RunEvent, ...]:
        _identity(run_id, "run_id")
        _identity(sink_id, "sink_id")
        _positive_integer(limit, "delivery limit")
        return await run_blocking_io(self._pending_deliveries, run_id, sink_id, limit)

    def _pending_deliveries(self, run_id: str, sink_id: str, limit: int) -> tuple[RunEvent, ...]:
        with self._transaction() as connection:
            snapshot = self._read_bounded_run(connection, run_id, required=True)
            assert snapshot is not None
            acknowledged = self._acknowledged(connection, run_id, sink_id)
            rows = connection.execute(
                """SELECT e.sequence, length(CAST(e.event_json AS BLOB)) AS size FROM deliveries d JOIN events e
                   ON e.run_id = d.run_id AND e.sequence = d.sequence
                   WHERE d.run_id = ? AND d.sink_id = ? AND d.sequence > ?
                   ORDER BY d.sequence LIMIT ?""", (run_id, sink_id, acknowledged, limit),
            )
            events: list[RunEvent] = []
            used_bytes = 0
            for metadata in rows:
                size = metadata["size"]
                if size > self._page_max_bytes:
                    raise ValueError(f"RunEvent exceeds page_max_bytes: {run_id}@{metadata['sequence']}")
                if used_bytes + size > self._page_max_bytes:
                    break
                row = connection.execute("SELECT * FROM events WHERE run_id = ? AND sequence = ?",
                                         (run_id, metadata["sequence"])).fetchone()
                events.append(self._read_event(row, snapshot))
                used_bytes += size
            return tuple(events)

    @staticmethod
    def _acknowledged(connection: sqlite3.Connection, run_id: str, sink_id: str) -> int:
        row = connection.execute("SELECT through_sequence FROM acknowledgements WHERE run_id = ? AND sink_id = ?",
                                 (run_id, sink_id)).fetchone()
        if row is None:
            return -1
        sequence = row[0]
        if not isinstance(sequence, int) or sequence < 0 or not connection.execute(
            "SELECT 1 FROM deliveries WHERE run_id = ? AND sink_id = ? AND sequence = ?",
            (run_id, sink_id, sequence),
        ).fetchone():
            raise ValueError(f"SQLite StateStore acknowledgement lacks a delivery: {sink_id}@{sequence}")
        return sequence

    async def acknowledge_event_delivery(self, run_id: str, sink_id: str, *, through_sequence: int) -> None:
        _identity(run_id, "run_id")
        _identity(sink_id, "sink_id")
        if isinstance(through_sequence, bool) or not isinstance(through_sequence, int) or through_sequence < 0:
            raise ValueError("through_sequence must be a non-negative integer")
        await run_blocking_io(self._acknowledge_delivery, run_id, sink_id, through_sequence)

    def _acknowledge_delivery(self, run_id: str, sink_id: str, sequence: int) -> None:
        with self._transaction(write=True) as connection:
            self._read_run(connection, run_id, required=True)
            current = self._acknowledged(connection, run_id, sink_id)
            if sequence > current:
                if not connection.execute("SELECT 1 FROM deliveries WHERE run_id = ? AND sink_id = ? AND sequence = ?",
                                          (run_id, sink_id, sequence)).fetchone():
                    raise ValueError(
                        f"outbox acknowledgement does not name a pending delivery for {sink_id}: {sequence}"
                    )
                connection.execute("""INSERT INTO acknowledgements VALUES (?, ?, ?)
                                   ON CONFLICT(run_id, sink_id)
                                   DO UPDATE SET through_sequence = excluded.through_sequence""",
                                   (run_id, sink_id, sequence))
                current = sequence
            # The FK and validation retain the latest ACK's delivery as a
            # witness. Older intents are redundant, including in v1 databases.
            connection.execute("DELETE FROM deliveries WHERE run_id = ? AND sink_id = ? AND sequence < ?",
                               (run_id, sink_id, current))

    async def prune_terminal_runs(
        self, before: datetime, limit: int = 128, dry_run: bool = True,
    ) -> tuple[str, ...]:
        """Explicitly remove at most ``limit`` eligible Runs, ordered by run_id.

        The default only previews IDs. Choose/archive a retention policy before
        calling with ``dry_run=False``: this permanently removes canonical Run
        snapshots, events and their completed outbox, without a restore promise.
        The last event must precede an aware ``before`` timestamp; active Runs,
        live leases, pending deliveries to *any* sink and any legal-hold event
        prevent deletion. Eligibility and deletion share one writer transaction.

        Sessions, assets and external sink files are untouched: their references
        and independent retention lifecycles cannot be inferred from a Run ID.
        Other retention classes are labels, not automatic TTL policies. SQLite
        reuses freed pages; this does not VACUUM or promise a smaller disk file.
        Scanning candidates may take time proportional to retained history.
        Cancellation waits for the transaction's commit/rollback before raising;
        a caller cancelled during deletion must re-query to learn the outcome.
        """
        if not isinstance(before, datetime) or before.tzinfo is None or before.utcoffset() is None:
            raise ValueError("before must be a timezone-aware datetime")
        _positive_integer(limit, "prune limit")
        if not isinstance(dry_run, bool):
            raise ValueError("dry_run must be a boolean")
        return await run_blocking_io(self._prune_terminal_runs, before, limit, dry_run)

    def _prune_terminal_runs(self, before: datetime, limit: int, dry_run: bool) -> tuple[str, ...]:
        with self._transaction(write=True) as connection:
            candidates = connection.execute(
                "SELECT run_id FROM runs WHERE status IN (?, ?, ?) ORDER BY run_id",
                (RunStatus.COMPLETED.value, RunStatus.FAILED.value, RunStatus.CANCELLED.value),
            )
            selected: list[str] = []
            for candidate in candidates:
                run_id = candidate["run_id"]
                snapshot = self._read_bounded_run(connection, run_id, required=True)
                assert snapshot is not None
                if snapshot.last_sequence < 0:
                    continue
                # Reuse the bounded decoder; corrupt/oversized facts fail closed.
                last = self._read_event_page(connection, snapshot, snapshot.last_sequence, 1)[0]
                if last.time >= before:
                    continue
                lease = connection.execute("SELECT owner_id, expires_at FROM leases WHERE run_id = ?",
                                           (run_id,)).fetchone()
                if lease is not None:
                    _identity(lease["owner_id"], "durable run lease owner_id")
                    expiry = lease["expires_at"]
                    if not isinstance(expiry, (int, float)) or not math.isfinite(expiry):
                        raise ValueError("SQLite StateStore lease expiry must be finite")
                    if expiry > time.time():
                        continue
                # Validate every ACK witness, including a sink no longer in
                # the current deployment, before interpreting its watermark.
                for ack in connection.execute("SELECT sink_id FROM acknowledgements WHERE run_id = ?", (run_id,)):
                    self._acknowledged(connection, run_id, ack["sink_id"])
                if connection.execute(
                    """SELECT 1 FROM deliveries d LEFT JOIN acknowledgements a
                       ON a.run_id = d.run_id AND a.sink_id = d.sink_id
                       WHERE d.run_id = ? AND (a.through_sequence IS NULL OR d.sequence > a.through_sequence)
                       LIMIT 1""", (run_id,),
                ).fetchone():
                    continue
                if connection.execute(
                    """SELECT 1 FROM events WHERE run_id = ?
                       AND json_extract(event_json, '$.governance.retention') = ? LIMIT 1""",
                    (run_id, RetentionClass.LEGAL_HOLD.value),
                ).fetchone():
                    continue
                selected.append(run_id)
                if len(selected) == limit:
                    break
            candidates.close()
            if not dry_run:
                # Delete only after finishing the scan, preserving stable scan
                # order and respecting the ACK -> intent -> event foreign keys.
                for run_id in selected:
                    for table in ("acknowledgements", "deliveries", "events", "leases", "runs"):
                        connection.execute(f"DELETE FROM {table} WHERE run_id = ?", (run_id,))
            return tuple(selected)

    async def save_environment_snapshot(self, session_id: str, snapshot: AgentEnvironmentSnapshot) -> None:
        _identity(session_id, "session_id")
        snapshot.assert_integrity()
        await run_blocking_io(self._save_environment, session_id, _encode(snapshot))

    def _save_environment(self, session_id: str, encoded: str) -> None:
        snapshot = AgentEnvironmentSnapshot.model_validate(_decode(encoded))
        snapshot.assert_integrity()
        with self._transaction(write=True) as connection:
            row = connection.execute(
                "SELECT digest, snapshot_json FROM sessions WHERE session_id = ?", (session_id,),
            ).fetchone()
            if row is not None:
                existing = self._decode_environment(row)
                if existing.digest != snapshot.digest:
                    raise ValueError(f"agent environment is immutable for session: {session_id}")
                return
            connection.execute("INSERT INTO sessions VALUES (?, ?, ?)", (session_id, snapshot.digest, encoded))

    @staticmethod
    def _decode_environment(row: sqlite3.Row) -> AgentEnvironmentSnapshot:
        snapshot = AgentEnvironmentSnapshot.model_validate(_decode(row["snapshot_json"]))
        snapshot.assert_integrity()
        if snapshot.digest != row["digest"]:
            raise ValueError("SQLite StateStore Session digest mismatch")
        return snapshot

    async def get_environment_snapshot(self, session_id: str) -> AgentEnvironmentSnapshot | None:
        _identity(session_id, "session_id")
        return await run_blocking_io(self._get_environment, session_id)

    def _get_environment(self, session_id: str) -> AgentEnvironmentSnapshot | None:
        with self._transaction() as connection:
            row = connection.execute(
                "SELECT digest, snapshot_json FROM sessions WHERE session_id = ?", (session_id,),
            ).fetchone()
            return self._decode_environment(row) if row is not None else None

    async def try_acquire_run(self, run_id: str, owner_id: str, *, ttl_seconds: float) -> bool:
        _identity(run_id, "run_id")
        _identity(owner_id, "run lease owner_id")
        _positive_seconds(ttl_seconds, "run lease ttl_seconds")
        return await run_blocking_io(self._lease, run_id, owner_id, ttl_seconds, False)

    async def renew_run(self, run_id: str, owner_id: str, *, ttl_seconds: float) -> bool:
        _identity(run_id, "run_id")
        _identity(owner_id, "run lease owner_id")
        _positive_seconds(ttl_seconds, "run lease ttl_seconds")
        return await run_blocking_io(self._lease, run_id, owner_id, ttl_seconds, True)

    def _lease(self, run_id: str, owner_id: str, ttl: float, renewing: bool) -> bool:
        with self._transaction(write=True) as connection:
            snapshot = self._read_run(connection, run_id, required=True)
            assert snapshot is not None
            now = time.time()
            row = connection.execute("SELECT owner_id, expires_at FROM leases WHERE run_id = ?", (run_id,)).fetchone()
            if row is not None:
                _identity(row["owner_id"], "durable run lease owner_id")
                if not isinstance(row["expires_at"], (int, float)) or not math.isfinite(row["expires_at"]):
                    raise ValueError("SQLite StateStore lease expiry must be finite")
            if renewing:
                if row is None or row["owner_id"] != owner_id or row["expires_at"] <= now:
                    return False
            elif snapshot.status in _TERMINAL or (
                row is not None and row["owner_id"] != owner_id and row["expires_at"] > now
            ):
                return False
            connection.execute("""INSERT INTO leases VALUES (?, ?, ?)
                               ON CONFLICT(run_id) DO UPDATE
                               SET owner_id = excluded.owner_id, expires_at = excluded.expires_at""",
                               (run_id, owner_id, now + ttl))
            return True

    async def release_run(self, run_id: str, owner_id: str) -> None:
        _identity(run_id, "run_id")
        _identity(owner_id, "run lease owner_id")
        await run_blocking_io(self._release_lease, run_id, owner_id)

    def _release_lease(self, run_id: str, owner_id: str) -> None:
        with self._transaction(write=True) as connection:
            connection.execute("DELETE FROM leases WHERE run_id = ? AND owner_id = ?", (run_id, owner_id))

    def stream_events(self, run_id: str, after: int | None = None) -> AsyncIterator[RunEvent]:
        return self._stream_events(run_id, after)

    async def _stream_events(self, run_id: str, after: int | None) -> AsyncIterator[RunEvent]:
        _identity(run_id, "run_id")
        if after is not None and (isinstance(after, bool) or not isinstance(after, int) or after < -1):
            raise ValueError("event cursor must be an integer of at least -1")
        cursor = 0 if after is None else after + 1
        condition = self._conditions.setdefault(run_id, asyncio.Condition())
        while True:
            events, terminal, last_sequence = await run_blocking_io(self._event_page, run_id, cursor)
            for event in events:
                cursor = event.sequence + 1
                yield event
            if terminal and cursor > last_sequence:
                return
            if events:
                continue
            async with condition:
                try:
                    async with asyncio.timeout(self._poll_interval):
                        await condition.wait()
                except TimeoutError:
                    pass

    def _event_page(self, run_id: str, cursor: int) -> tuple[tuple[RunEvent, ...], bool, int]:
        with self._transaction() as connection:
            snapshot = self._read_bounded_run(connection, run_id)
            if snapshot is None:
                return (), False, -1
            events = self._read_event_page(connection, snapshot, cursor, self._batch_size)
            return events, snapshot.status in _TERMINAL, snapshot.last_sequence

    async def _notify(self, run_id: str) -> None:
        condition = self._conditions.setdefault(run_id, asyncio.Condition())
        async with condition:
            condition.notify_all()
