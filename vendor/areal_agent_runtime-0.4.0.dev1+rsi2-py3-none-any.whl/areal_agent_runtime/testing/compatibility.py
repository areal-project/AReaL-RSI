"""Conservative JSON Schema compatibility checks used by release CI.

The checker proves that payloads accepted by a released schema are not made
invalid by a later schema for common JSON Schema constraints.  It is
deliberately conservative: an ambiguous structural rewrite is treated as a
release-review failure and should use a new protocol major version or an
explicit translator.
"""

from __future__ import annotations

import inspect
from typing import Any

_LOWER_BOUNDS = (
    "minimum",
    "exclusiveMinimum",
    "minLength",
    "minItems",
    "minProperties",
    "minContains",
)
_UPPER_BOUNDS = (
    "maximum",
    "exclusiveMaximum",
    "maxLength",
    "maxItems",
    "maxProperties",
    "maxContains",
)
_EXACT_CONSTRAINTS = ("pattern", "format")
_PRESENCE_CONSTRAINTS = (
    "not",
    "if",
    "then",
    "else",
    "contains",
    "propertyNames",
    "dependentSchemas",
)
_SIGNATURE_KEYS = frozenset(
    {
        "$ref",
        "type",
        "const",
        "enum",
        "default",
        "required",
        "properties",
        "additionalProperties",
        "unevaluatedProperties",
        "uniqueItems",
        "multipleOf",
        "dependentRequired",
        "readOnly",
        "writeOnly",
        "allOf",
        "anyOf",
        "oneOf",
        *_PRESENCE_CONSTRAINTS,
        *_LOWER_BOUNDS,
        *_UPPER_BOUNDS,
        *_EXACT_CONSTRAINTS,
    }
)
_NON_SCHEMA_ARRAYS = frozenset({"enum", "required", "examples"})
_SCHEMA_MAPS = frozenset(
    {"$defs", "definitions", "dependentSchemas", "patternProperties", "properties"}
)
_NON_SCHEMA_OBJECTS = frozenset({"dependentRequired", "discriminator"})


def schema_signature(schema: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Extract compatibility-relevant constraints keyed by JSON pointer."""

    result: dict[str, dict[str, Any]] = {}

    def visit(value: Any, pointer: str, parent_key: str | None = None) -> None:
        if isinstance(value, dict):
            if parent_key in _NON_SCHEMA_OBJECTS:
                return
            if parent_key in _SCHEMA_MAPS:
                for key, child in sorted(value.items()):
                    visit(child, _join_pointer(pointer, key))
                return
            node: dict[str, Any] = {}
            for key in sorted(_SIGNATURE_KEYS):
                if key not in value:
                    continue
                candidate = value[key]
                if key == "properties" and isinstance(candidate, dict):
                    node[key] = sorted(candidate)
                elif key in {"required", "enum"} and isinstance(candidate, list):
                    node[key] = candidate
                elif key in {"additionalProperties", "unevaluatedProperties"}:
                    node[key] = candidate if isinstance(candidate, bool) else "<schema>"
                elif key in {"allOf", "anyOf", "oneOf"} and isinstance(candidate, list):
                    node[key] = len(candidate)
                elif key in _PRESENCE_CONSTRAINTS:
                    node[key] = True
                else:
                    node[key] = candidate
            # Empty schemas are meaningful (they accept every JSON value).
            # Retaining their pointer lets the checker detect a later type,
            # enum or structural restriction at the same location.
            result[pointer or "/"] = node
            for key, child in sorted(value.items()):
                if key in {"title", "description", "default", "examples"}:
                    continue
                visit(child, _join_pointer(pointer, key), key)
            return
        if isinstance(value, list) and parent_key not in _NON_SCHEMA_ARRAYS:
            for index, child in enumerate(value):
                visit(child, _join_pointer(pointer, str(index)))

    visit(schema, "")
    return result


def compare_schema_signatures(
    baseline: dict[str, dict[str, Any]],
    current: dict[str, dict[str, Any]],
) -> tuple[str, ...]:
    """Return backward-input compatibility failures between two signatures."""

    issues: list[str] = []
    for pointer, old in baseline.items():
        new = current.get(pointer)
        if new is None:
            issues.append(f"{pointer}: released schema node was removed or structurally replaced")
            continue

        old_properties = set(old.get("properties", ()))
        new_properties = set(new.get("properties", ()))
        removed = sorted(old_properties - new_properties)
        if removed:
            issues.append(f"{pointer}: properties removed: {', '.join(removed)}")

        old_required = set(old.get("required", ()))
        new_required = set(new.get("required", ()))
        added_required = sorted(new_required - old_required)
        if added_required:
            issues.append(f"{pointer}: new required properties: {', '.join(added_required)}")

        old_types = _value_set(old.get("type"))
        new_types = _value_set(new.get("type"))
        if not old_types and new_types:
            issues.append(f"{pointer}: new type restriction added: {sorted(new_types)}")
        elif old_types and (not new_types or not old_types.issubset(new_types)):
            issues.append(f"{pointer}: type narrowed from {sorted(old_types)} to {sorted(new_types)}")

        old_ref = old.get("$ref")
        new_ref = new.get("$ref")
        if old_ref is None and new_ref is not None:
            issues.append(f"{pointer}: new $ref restriction added")
        elif old_ref is not None and new_ref != old_ref:
            issues.append(f"{pointer}: $ref changed")

        if "const" in old and new.get("const", object()) != old["const"]:
            issues.append(f"{pointer}: const changed")
        elif "const" not in old and "const" in new:
            issues.append(f"{pointer}: new const restriction added")

        old_enum = _json_values(old.get("enum"))
        new_enum = _json_values(new.get("enum"))
        if old_enum is not None:
            if new_enum is None or not old_enum.issubset(new_enum):
                issues.append(f"{pointer}: enum values were removed")
        elif new_enum is not None:
            issues.append(f"{pointer}: new enum restriction added")

        if "default" in old and new.get("default", object()) != old["default"]:
            issues.append(f"{pointer}: default changed")
        elif "default" not in old and "default" in new:
            issues.append(f"{pointer}: new default added")

        for key in _LOWER_BOUNDS:
            old_value = old.get(key)
            new_value = new.get(key)
            if old_value is None and new_value is not None and new_value > 0:
                issues.append(f"{pointer}: new {key} restriction added")
            elif old_value is not None and new_value is not None and new_value > old_value:
                issues.append(f"{pointer}: {key} became stricter")

        for key in _UPPER_BOUNDS:
            old_value = old.get(key)
            new_value = new.get(key)
            if old_value is None and new_value is not None:
                issues.append(f"{pointer}: new {key} restriction added")
            elif old_value is not None and new_value is not None and new_value < old_value:
                issues.append(f"{pointer}: {key} became stricter")

        for key in _EXACT_CONSTRAINTS:
            old_value = old.get(key)
            new_value = new.get(key)
            if old_value is None and new_value is not None:
                issues.append(f"{pointer}: new {key} restriction added")
            elif old_value is not None and new_value not in {None, old_value}:
                issues.append(f"{pointer}: {key} changed")

        old_multiple = old.get("multipleOf")
        new_multiple = new.get("multipleOf")
        if old_multiple is None and new_multiple is not None:
            issues.append(f"{pointer}: new multipleOf restriction added")
        elif old_multiple is not None and new_multiple != old_multiple:
            issues.append(f"{pointer}: multipleOf changed")

        old_additional = old.get("additionalProperties", True)
        new_additional = new.get("additionalProperties", True)
        if old_additional is True and new_additional is not True:
            issues.append(f"{pointer}: additionalProperties became restricted")
        elif old_additional == "<schema>" and new_additional != "<schema>":
            if new_additional is False:
                issues.append(f"{pointer}: additionalProperties schema became forbidden")
            elif new_additional is True:
                pass  # Removing an additional-property schema is a relaxation.

        old_unevaluated = old.get("unevaluatedProperties", True)
        new_unevaluated = new.get("unevaluatedProperties", True)
        if old_unevaluated is True and new_unevaluated is not True:
            issues.append(f"{pointer}: unevaluatedProperties became restricted")
        elif old_unevaluated == "<schema>" and new_unevaluated is False:
            issues.append(f"{pointer}: unevaluatedProperties schema became forbidden")

        if old.get("uniqueItems") is not True and new.get("uniqueItems") is True:
            issues.append(f"{pointer}: uniqueItems restriction added")

        old_all_of = int(old.get("allOf", 0))
        new_all_of = int(new.get("allOf", 0))
        if new_all_of > old_all_of:
            issues.append(f"{pointer}: allOf constraints were added")
        old_any_of = int(old.get("anyOf", 0))
        new_any_of = int(new.get("anyOf", 0))
        if old_any_of == 0 and new_any_of > 0:
            issues.append(f"{pointer}: new anyOf restriction added")
        elif old_any_of > 0 and new_any_of < old_any_of:
            issues.append(f"{pointer}: anyOf alternatives were removed")
        old_one_of = int(old.get("oneOf", 0))
        new_one_of = int(new.get("oneOf", 0))
        if old_one_of != new_one_of:
            issues.append(f"{pointer}: oneOf alternatives changed")

        for key in _PRESENCE_CONSTRAINTS:
            if key not in old and key in new:
                issues.append(f"{pointer}: new {key} constraint added")

        for key in ("dependentRequired", "readOnly", "writeOnly"):
            if key not in old and key in new:
                issues.append(f"{pointer}: new {key} constraint added")
            elif key in old and new.get(key) != old[key]:
                issues.append(f"{pointer}: {key} changed")

    return tuple(dict.fromkeys(issues))


def callable_signature(value: Any) -> dict[str, Any]:
    """Capture the call semantics that established Python users depend on."""

    parameters = []
    for parameter in inspect.signature(value).parameters.values():
        if parameter.name in {"self", "cls"}:
            continue
        required = parameter.default is inspect.Parameter.empty
        parameters.append(
            {
                "name": parameter.name,
                "kind": parameter.kind.name,
                "required": required,
                "default": None if required else repr(parameter.default),
            }
        )
    return {
        "async": inspect.iscoroutinefunction(value),
        "parameters": parameters,
    }


def compare_callable_signatures(
    baseline: dict[str, Any],
    current: dict[str, Any],
) -> tuple[str, ...]:
    """Return source-compatibility failures for one public Python callable."""

    issues: list[str] = []
    if baseline["async"] != current["async"]:
        issues.append("sync/async behavior changed")
    positions = {
        item["name"]: index for index, item in enumerate(current["parameters"])
    }
    previous = -1
    for old_parameter in baseline["parameters"]:
        name = old_parameter["name"]
        index = positions.get(name)
        if index is None:
            issues.append(f"parameter removed: {name}")
            continue
        candidate = current["parameters"][index]
        if index < previous:
            issues.append(f"parameter order changed: {name}")
        previous = index
        if candidate["kind"] != old_parameter["kind"]:
            issues.append(f"parameter kind changed: {name}")
        if not old_parameter["required"]:
            if candidate["required"]:
                issues.append(f"optional parameter became required: {name}")
            elif candidate["default"] != old_parameter["default"]:
                issues.append(f"parameter default changed: {name}")
    old_names = {item["name"] for item in baseline["parameters"]}
    for candidate in current["parameters"]:
        if candidate["name"] not in old_names and candidate["required"]:
            issues.append(f"new required parameter added: {candidate['name']}")
    positional_kinds = {"POSITIONAL_ONLY", "POSITIONAL_OR_KEYWORD"}
    old_positional = [
        item["name"]
        for item in baseline["parameters"]
        if item["kind"] in positional_kinds
    ]
    new_positional = [
        item["name"]
        for item in current["parameters"]
        if item["kind"] in positional_kinds
    ]
    if new_positional[: len(old_positional)] != old_positional:
        issues.append("a positional parameter was inserted, removed, or reordered")
    return tuple(dict.fromkeys(issues))


def _join_pointer(pointer: str, token: str) -> str:
    escaped = token.replace("~", "~0").replace("/", "~1")
    return f"{pointer}/{escaped}"


def _value_set(value: Any) -> set[str]:
    if isinstance(value, str):
        return {value}
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return set(value)
    return set()


def _json_values(value: Any) -> set[str] | None:
    if not isinstance(value, list):
        return None
    return {repr(item) for item in value}
