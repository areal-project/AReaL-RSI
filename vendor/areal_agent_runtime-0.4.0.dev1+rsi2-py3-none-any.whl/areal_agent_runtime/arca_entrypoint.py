"""Generic synchronous/async entrypoints for ARCA-style serverless platforms."""

from __future__ import annotations

import asyncio
import json
import math
import os
from pathlib import Path
from typing import Any

from areal_agent_runtime.bootstrap import BootstrapConfig, build_composition

CONFIG_ENV = "AREAL_AGENT_RUNTIME_CONFIG"
DEADLINE_MARGIN_ENV = "AREAL_AGENT_RUNTIME_DEADLINE_MARGIN_SECONDS"


async def async_handler(event: dict[str, object], context: object | None = None) -> dict[str, Any]:
    """Build one isolated composition and invoke it using the canonical ARCA Host."""

    config_path = os.environ.get(CONFIG_ENV)
    if not config_path:
        raise RuntimeError(f"{CONFIG_ENV} must point to a BootstrapConfig JSON file")
    raw = await asyncio.to_thread(
        lambda: Path(config_path).expanduser().read_text(encoding="utf-8")
    )
    config = BootstrapConfig.model_validate(json.loads(raw))
    if config.host.kind != "arca":
        raise ValueError("ARCA entrypoint requires host.kind='arca'")
    payload = _apply_invocation_context(event, context)
    if payload.get("wait") is False:
        raise ValueError(
            "The per-invocation ARCA entrypoint requires wait=true; "
            "a returned background run would be cancelled during invocation cleanup"
        )
    composition = await build_composition(config)
    try:
        return await composition.create_arca_host().invoke(payload)
    finally:
        await composition.close()


def handler(event: dict[str, object], context: object | None = None) -> dict[str, Any]:
    """Synchronous function entrypoint for platforms that do not own an event loop."""

    return asyncio.run(async_handler(event, context))


def _apply_invocation_context(event: dict[str, object], context: object | None) -> dict[str, object]:
    payload = dict(event)
    remaining = _remaining_seconds(context)
    configured = payload.get("timeoutSeconds")
    if remaining is not None:
        payload["timeoutSeconds"] = (
            min(float(configured), remaining)
            if isinstance(configured, (int, float)) and not isinstance(configured, bool) and configured > 0
            else remaining
        )
    request_id = _context_value(context, "request_id", "requestId", "aws_request_id")
    if request_id is not None:
        metadata = payload.get("metadata")
        if metadata is None or isinstance(metadata, dict):
            merged = dict(metadata or {})
            merged.setdefault("arcaRequestId", str(request_id))
            payload["metadata"] = merged
    return payload


def _remaining_seconds(context: object | None) -> float | None:
    if context is None:
        return None
    getter = getattr(context, "get_remaining_time_in_millis", None)
    if not callable(getter):
        getter = getattr(context, "getRemainingTimeInMillis", None)
    if not callable(getter):
        return None
    remaining_ms = getter()
    if (
        not isinstance(remaining_ms, (int, float))
        or isinstance(remaining_ms, bool)
        or not math.isfinite(remaining_ms)
        or remaining_ms <= 0
    ):
        return None
    try:
        margin = float(os.environ.get(DEADLINE_MARGIN_ENV, "1"))
        if not math.isfinite(margin) or margin < 0:
            margin = 1.0
    except ValueError:
        margin = 1.0
    return max(0.001, float(remaining_ms) / 1000.0 - max(0.0, margin))


def _context_value(context: object | None, *names: str) -> object | None:
    if context is None:
        return None
    for name in names:
        value = getattr(context, name, None)
        if value is not None:
            return value
    return None
