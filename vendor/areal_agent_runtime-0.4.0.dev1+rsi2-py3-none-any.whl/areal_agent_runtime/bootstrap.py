"""Configuration-driven composition root for local, ARCA and container Hosts."""

from __future__ import annotations

import asyncio
import hashlib
import importlib
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    StrictBool,
    StrictInt,
    field_validator,
    model_validator,
)

from areal_agent_runtime.adapters.storage.annotations import FileSystemAnnotationStore
from areal_agent_runtime.application import (
    ARealAgentRuntime,
    WorkflowProfile,
    default_profiles,
)
from areal_agent_runtime.application.agent_environment import AgentEnvironmentPolicy
from areal_agent_runtime.contracts.base import to_camel
from areal_agent_runtime.contracts.environment import AgentEnvironmentSpec
from areal_agent_runtime.contracts.ports import (
    AssetStorePort,
    EnvironmentPort,
    EventSinkPort,
    StateStorePort,
    ToolProviderPort,
)
from areal_agent_runtime.contracts.product import RuntimeSelection
from areal_agent_runtime.contracts.runtime import AgentRuntimePort, WorkspaceRef
from areal_agent_runtime.hosts import (
    ArcaServerlessConfig,
    ArcaServerlessHost,
    BuiltinResource,
    HostResourceBindings,
    LegacyPromptResolver,
    NativeHttpHostConfig,
    OpenAICompatibilityConfig,
    OpenAICompatibilityHost,
    ResourceBindingPolicy,
    RuntimeDataHttpConfig,
    RuntimeDataPermission,
    RuntimeDataPrincipal,
    StaticBearerDataAuthorizer,
    create_http_app,
    create_openai_http_app,
    mount_runtime_data_api,
)
from areal_agent_runtime.plugin_sdk import Plugin, PluginManager, PluginPermissionPolicy, PortKey

_BOOTSTRAP_MODEL_CONFIG = ConfigDict(
    extra="forbid",
    alias_generator=to_camel,
    populate_by_name=True,
    serialize_by_alias=True,
)


class RuntimeBootstrapConfig(BaseModel):
    model_config = _BOOTSTRAP_MODEL_CONFIG

    kind: Literal[
        "fake",
        "dsh",
        "claude-agent-sdk",
        "claude-code",
        "hermes",
        "anthropic",
        "codex-cli",
        "remote",
        "entrypoint",
    ]
    plugin_entrypoint: str | None = None
    selector: str = "primary"
    profile_binding: Literal["auto", "runtime-owned", "portable"] = "auto"
    config: dict[str, JsonValue] = Field(default_factory=dict)
    service_bindings: dict[PortKey, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_entrypoint(self) -> RuntimeBootstrapConfig:
        if not self.selector.strip() or self.selector != self.selector.strip():
            raise ValueError("runtime.selector must be a non-blank, trimmed string")
        if self.plugin_entrypoint is not None and (
            not self.plugin_entrypoint.strip() or self.plugin_entrypoint != self.plugin_entrypoint.strip()
        ):
            raise ValueError("runtime.plugin_entrypoint must be a non-blank, trimmed string")
        if self.kind == "entrypoint" and self.plugin_entrypoint is None:
            raise ValueError("runtime.plugin_entrypoint is required when kind='entrypoint'")
        if self.kind != "entrypoint" and self.plugin_entrypoint is not None:
            raise ValueError("runtime.plugin_entrypoint is only valid when kind='entrypoint'")
        return self


class RuntimeDataApiBootstrapConfig(BaseModel):
    """Opt-in remote Data API binding for the standard HTTP composition.

    The bearer token is read from an environment variable when the ASGI app is
    created and is never accepted inline in a checked-in composition file.
    More advanced deployments can mount the Data API with their own
    ``RuntimeDataAuthorizerPort`` instead.
    """

    model_config = _BOOTSTRAP_MODEL_CONFIG

    enabled: StrictBool = False
    auth_token_env: str | None = Field(default=None, pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")
    subject: str | None = None
    tenant_id: str | None = None
    project_id: str | None = None
    permissions: tuple[RuntimeDataPermission, ...] = (
        RuntimeDataPermission.READ,
        RuntimeDataPermission.READ_CONFIDENTIAL,
        RuntimeDataPermission.APPEND_ANNOTATION,
        RuntimeDataPermission.RESOLVE_ASSET,
    )
    max_page_size: StrictInt = Field(default=500, ge=1, le=1000)
    max_request_bytes: StrictInt = Field(default=256 * 1024, ge=1, le=16 * 1024 * 1024)
    max_asset_ttl_seconds: StrictInt = Field(default=3600, ge=1, le=24 * 60 * 60)

    @field_validator("subject", "tenant_id", "project_id")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        if value is not None and (not value.strip() or value != value.strip()):
            raise ValueError("Runtime Data API identities must be non-blank and trimmed")
        return value

    @model_validator(mode="after")
    def validate_authentication(self) -> RuntimeDataApiBootstrapConfig:
        if len(self.permissions) != len(set(self.permissions)):
            raise ValueError("host.dataApi.permissions must not contain duplicates")
        if self.project_id is not None and self.tenant_id is None:
            raise ValueError("host.dataApi.projectId requires tenantId")
        if not self.enabled:
            if any(value is not None for value in (self.auth_token_env, self.subject, self.tenant_id, self.project_id)):
                raise ValueError("host.dataApi identity/auth fields require enabled=true")
            return self
        if self.auth_token_env is None or self.subject is None:
            raise ValueError("enabled host.dataApi requires authTokenEnv and subject")
        permissions = set(self.permissions)
        if not permissions:
            raise ValueError("enabled host.dataApi requires at least one permission")
        if RuntimeDataPermission.ADMIN not in permissions and self.tenant_id is None:
            raise ValueError("non-admin host.dataApi requires tenantId")
        if (
            RuntimeDataPermission.ADMIN not in permissions
            and permissions.intersection(
                {
                    RuntimeDataPermission.READ_CONFIDENTIAL,
                    RuntimeDataPermission.READ_RESTRICTED,
                }
            )
            and RuntimeDataPermission.READ not in permissions
        ):
            raise ValueError("host.dataApi sensitive read permissions require data:read")
        return self


class HostBootstrapConfig(BaseModel):
    model_config = _BOOTSTRAP_MODEL_CONFIG

    kind: Literal["native", "openai", "arca"] = "native"
    default_model: str = "areal-agent-runtime"
    default_profile: str = "general.default"
    default_workspace_id: str = "default"
    default_workspace_mount: str | None = None
    default_timeout_seconds: float | None = Field(default=None, gt=0)
    default_runtime_selector: str | None = None
    mode_runtime_selectors: dict[str, str] = Field(default_factory=dict)
    mode_profiles: dict[str, str] = Field(
        default_factory=lambda: {"default": "general.default"}
    )
    max_request_bytes: int = Field(default=32 * 1024 * 1024, ge=1)
    max_inline_image_bytes: int = Field(default=16 * 1024 * 1024, ge=1)
    allowed_agent_ids: tuple[str, ...] = ()
    request_knowledge: RequestKnowledgeBootstrapConfig = Field(
        default_factory=lambda: RequestKnowledgeBootstrapConfig()
    )
    agent_environment: AgentEnvironmentSpec = Field(default_factory=AgentEnvironmentSpec)
    supported_agent_environment_extensions: tuple[str, ...] = ()
    resource_bindings: ResourceBindingsBootstrapConfig = Field(
        default_factory=lambda: ResourceBindingsBootstrapConfig()
    )
    data_api: RuntimeDataApiBootstrapConfig = Field(
        default_factory=RuntimeDataApiBootstrapConfig
    )

    @model_validator(mode="after")
    def validate_openai_routing(self) -> HostBootstrapConfig:
        if not self.mode_profiles or "default" not in self.mode_profiles:
            raise ValueError("host.modeProfiles must define the fallback mode 'default'")
        invalid_profiles = [
            mode for mode, profile in self.mode_profiles.items() if not mode.strip() or not profile.strip()
        ]
        if invalid_profiles:
            raise ValueError("host.modeProfiles keys and values must not be blank")
        invalid_selectors = [
            mode for mode, selector in self.mode_runtime_selectors.items() if not mode.strip() or not selector.strip()
        ]
        if invalid_selectors:
            raise ValueError("host.modeRuntimeSelectors keys and values must not be blank")
        unknown_modes = sorted(set(self.mode_runtime_selectors).difference(self.mode_profiles))
        if unknown_modes:
            raise ValueError("host.modeRuntimeSelectors references unknown mode(s): " + ", ".join(unknown_modes))
        if any(not agent_id.strip() for agent_id in self.allowed_agent_ids):
            raise ValueError("host.allowedAgentIds must contain non-empty values")
        if len(self.allowed_agent_ids) != len(set(self.allowed_agent_ids)):
            raise ValueError("host.allowedAgentIds must not contain duplicates")
        if self.kind == "arca" and self.data_api.enabled:
            raise ValueError("host.dataApi is available only for long-lived native/openai HTTP Hosts")
        return self


class BuiltinResourceBootstrapConfig(BaseModel):
    model_config = _BOOTSTRAP_MODEL_CONFIG

    content: JsonValue
    media_type: str = "text/plain"
    version: str = "1.0.0"


class ResourceBindingsBootstrapConfig(BaseModel):
    """Physical paths and network policy owned by the Host composition root."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    builtins: dict[str, BuiltinResourceBootstrapConfig] = Field(default_factory=dict)
    mounts: dict[str, str] = Field(default_factory=dict)
    max_bytes: int = Field(default=1024 * 1024, ge=1)
    allowed_uri_origins: tuple[str, ...] = ()
    allowed_mcp_http_origins: tuple[str, ...] = ()
    allow_insecure_loopback_http: bool = False
    allow_stdio_mcp: bool = False
    allowed_invocation_source_providers: tuple[str, ...] = ()
    allowed_invocation_tool_names: tuple[str, ...] = ()
    allowed_invocation_permissions: tuple[str, ...] = ()


class RequestKnowledgeBootstrapConfig(BaseModel):
    """Legacy request Prompt/Skill mounts projected into canonical contracts."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    enabled: bool = False
    prompt_roots: dict[str, str] = Field(
        default_factory=lambda: {"catalog": "/prompt-catalog", "user": "/user_prompts"}
    )
    skill_roots: dict[str, str] = Field(default_factory=lambda: {"catalog": "/skill-catalog", "user": "/user_skills"})
    max_prompt_bytes: int = Field(default=32 * 1024, ge=1)
    max_skill_bytes: int = Field(default=256 * 1024, ge=1)
    max_requested_skills: int = Field(default=20, ge=1)


class PluginBootstrapConfig(BaseModel):
    """Trusted in-process Plugin selected by the deployment composition root."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    entrypoint: str = Field(min_length=3)
    instance_name: str | None = Field(default=None, min_length=1)
    config: dict[str, JsonValue] = Field(default_factory=dict)
    service_bindings: dict[PortKey, str] = Field(default_factory=dict)
    enabled: bool = True

    @model_validator(mode="after")
    def validate_names(self) -> PluginBootstrapConfig:
        if not self.entrypoint.strip() or self.entrypoint != self.entrypoint.strip():
            raise ValueError("plugin entrypoint must be a non-blank, trimmed string")
        if self.instance_name is not None and (
            not self.instance_name.strip() or self.instance_name != self.instance_name.strip()
        ):
            raise ValueError("plugin instanceName must be a non-blank, trimmed string")
        if any(not owner.strip() or owner != owner.strip() for owner in self.service_bindings.values()):
            raise ValueError("plugin serviceBindings values must be non-blank, trimmed strings")
        return self


class AssetRouteBootstrapConfig(BaseModel):
    """Placement rules use framework identities, never tool-supplied metadata."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    backend: str = Field(min_length=1)
    run_id: str | None = None
    profile_id: str | None = None
    agent_id: str | None = None
    media_type: str | None = None


class AssetStorageBootstrapConfig(BaseModel):
    """Replace just AssetStore, optionally routing agents to named backends."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    backends: dict[str, PluginBootstrapConfig] = Field(min_length=1)
    default_backend: str | None = None
    rules: tuple[AssetRouteBootstrapConfig, ...] = ()
    legacy_backend: str | None = None

    @model_validator(mode="after")
    def validate_backends(self) -> AssetStorageBootstrapConfig:
        from areal_agent_runtime.adapters.storage import AssetRoutingRule

        for name, plugin in self.backends.items():
            AssetRoutingRule(backend=name)
            if not plugin.enabled:
                raise ValueError("asset backends cannot be disabled")
        default = self.default_backend
        if default is None:
            if len(self.backends) != 1:
                raise ValueError("assets.defaultBackend is required with multiple backends")
            default = next(iter(self.backends))
            self.default_backend = default
        if default not in self.backends or (
            self.legacy_backend is not None and self.legacy_backend not in self.backends
        ):
            raise ValueError("asset defaults must name a configured backend")
        for rule in self.rules:
            AssetRoutingRule(**rule.model_dump(by_alias=False))
            if rule.backend not in self.backends:
                raise ValueError("asset rules must name configured backends")
        return self


class ToolBindingBootstrapConfig(BaseModel):
    """Add ToolProvider tools to an existing profile without copying its definition."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    profile_id: str = Field(min_length=1)
    tool_names: tuple[str, ...] = Field(min_length=1)
    agent_id: str | None = None


class BootstrapConfig(BaseModel):
    model_config = _BOOTSTRAP_MODEL_CONFIG

    data_root: str = ".areal-agent-runtime"
    runtime: RuntimeBootstrapConfig | None = None
    runtimes: tuple[RuntimeBootstrapConfig, ...] = ()
    host: HostBootstrapConfig = Field(default_factory=HostBootstrapConfig)
    storage: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.storage.plugin:create_plugin"
        )
    )
    state: PluginBootstrapConfig | None = None
    max_active_runs: StrictInt = Field(default=16, ge=1)
    data_query_max_events: StrictInt = Field(default=10_000, ge=1)
    data_query_max_bytes: StrictInt = Field(default=16 * 1024 * 1024, ge=1)
    max_recovery_events: StrictInt = Field(default=100_000, ge=1)
    max_recovery_bytes: StrictInt = Field(default=64 * 1024 * 1024, ge=1)
    assets: AssetStorageBootstrapConfig | None = None
    event_sinks: tuple[str, ...] | None = None
    environment: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.environment.plugin:create_plugin"
        )
    )
    workspace_tools: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.workspace.plugin:create_plugin"
        )
    )
    domain_tools: PluginBootstrapConfig | None = None
    knowledge_tools: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.knowledge.plugin:create_plugin"
        )
    )
    plugins: tuple[PluginBootstrapConfig, ...] = ()
    include_default_profiles: bool = True
    profile_overrides: tuple[WorkflowProfile, ...] = ()
    tool_bindings: tuple[ToolBindingBootstrapConfig, ...] = ()
    allowed_plugin_permissions: tuple[str, ...] | None = None
    allowed_tool_permissions: tuple[str, ...] | None = None

    @model_validator(mode="after")
    def validate_runtimes(self) -> BootstrapConfig:
        if self.runtime is not None and self.runtimes:
            raise ValueError("configure either runtime or runtimes, not both")
        configured = self.configured_runtimes()
        if not configured:
            raise ValueError("at least one runtime must be configured")
        selectors = [runtime.selector for runtime in configured]
        if len(selectors) != len(set(selectors)):
            raise ValueError("runtime selectors must be unique")
        if not self.storage.enabled or not self.environment.enabled:
            raise ValueError("storage and environment infrastructure plugins cannot be disabled")
        if self.state is not None and not self.state.enabled:
            raise ValueError("state infrastructure plugin cannot be disabled")
        if self.event_sinks is not None and (
            len(set(self.event_sinks)) != len(self.event_sinks)
            or any(not name.strip() or name != name.strip() for name in self.event_sinks)
        ):
            raise ValueError("eventSinks must contain unique non-blank instance names")
        _validate_asset_consumer_bindings(self)
        _validate_state_consumer_bindings(self)
        override_ids = [profile.profile_id for profile in self.profile_overrides]
        if len(override_ids) != len(set(override_ids)):
            raise ValueError("profileOverrides must not repeat profileId values")
        return self

    def configured_runtimes(self) -> tuple[RuntimeBootstrapConfig, ...]:
        if self.runtimes:
            return self.runtimes
        return (self.runtime,) if self.runtime is not None else ()


def _validate_asset_consumer_bindings(config: BootstrapConfig) -> None:
    if config.assets is None:
        return

    def check(location: str, bindings: dict[PortKey, str]) -> None:
        selected = bindings.get(PortKey.ASSET_STORE)
        if selected is not None and selected != "assets._router":
            raise ValueError(
                f"{location}.serviceBindings for AssetStore must use assets._router when assets is configured; "
                "remove the override and use assets.rules to select backends"
            )

    consumers = [
        ("storage", config.storage), ("environment", config.environment),
        ("workspaceTools", config.workspace_tools),
    ]
    if config.state is not None:
        consumers.append(("state", config.state))
    if config.domain_tools is not None:
        consumers.append(("domainTools", config.domain_tools))
    if config.host.request_knowledge.enabled:
        consumers.append(("knowledgeTools", config.knowledge_tools))
    consumers.extend((f"plugins[{index}]", plugin) for index, plugin in enumerate(config.plugins))
    for location, plugin in consumers:
        if plugin.enabled:
            check(location, plugin.service_bindings)
    for index, runtime in enumerate(config.configured_runtimes()):
        check("runtime" if config.runtime is not None else f"runtimes[{index}]", runtime.service_bindings)


def _validate_state_consumer_bindings(config: BootstrapConfig) -> None:
    if config.state is None:
        return
    owner = config.state.instance_name or "state"
    consumers = [config.storage, config.environment, config.workspace_tools, *config.plugins]
    if config.domain_tools is not None:
        consumers.append(config.domain_tools)
    if config.host.request_knowledge.enabled:
        consumers.append(config.knowledge_tools)
    bindings = [plugin.service_bindings for plugin in consumers if plugin.enabled]
    bindings.extend(runtime.service_bindings for runtime in config.configured_runtimes())
    for binding in bindings:
        selected = binding.get(PortKey.STATE_STORE)
        if selected is not None and selected != owner:
            raise ValueError(f"StateStore consumers must use the configured state backend {owner!r}")


class RuntimeWireListenConfig(BaseModel):
    model_config = _BOOTSTRAP_MODEL_CONFIG

    host: str = "127.0.0.1"
    port: StrictInt = Field(default=9010, ge=1, le=65535)
    auth_token: str | None = None
    auth_token_env: str | None = Field(default=None, pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")
    tls_cert_file: str | None = None
    tls_key_file: str | None = None
    tls_client_ca_file: str | None = None
    tls_require_client_cert: StrictBool = False
    allow_insecure: StrictBool = False
    max_frame_bytes: StrictInt = Field(default=16 * 1024 * 1024, ge=1024)
    workspace_transfer: StrictBool = True
    workspace_root: str | None = None

    @field_validator(
        "host",
        "auth_token",
        "auth_token_env",
        "tls_cert_file",
        "tls_key_file",
        "tls_client_ca_file",
        "workspace_root",
    )
    @classmethod
    def validate_nonblank_strings(cls, value: str | None) -> str | None:
        if value is not None and (not value.strip() or value != value.strip()):
            raise ValueError("wire string fields must be non-blank and trimmed")
        return value

    @model_validator(mode="after")
    def validate_tls(self) -> RuntimeWireListenConfig:
        if self.auth_token is not None and self.auth_token_env is not None:
            raise ValueError("wire auth_token and auth_token_env are mutually exclusive")
        if (self.tls_cert_file is None) != (self.tls_key_file is None):
            raise ValueError("wire TLS certificate and key must be configured together")
        if self.tls_require_client_cert and self.tls_client_ca_file is None:
            raise ValueError("wire mTLS requires tls_client_ca_file")
        if self.tls_client_ca_file is not None and self.tls_cert_file is None:
            raise ValueError("wire client CA requires a TLS server certificate")
        return self


class RuntimeServiceBootstrapConfig(BaseModel):
    """Composition for deploying one Runtime Adapter behind Runtime Wire."""

    model_config = _BOOTSTRAP_MODEL_CONFIG

    data_root: str = ".areal-agent-runtime/service"
    storage: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.storage.plugin:create_plugin"
        )
    )
    runtime: RuntimeBootstrapConfig
    wire: RuntimeWireListenConfig = Field(default_factory=RuntimeWireListenConfig)
    allowed_plugin_permissions: tuple[str, ...] | None = None


@dataclass(slots=True)
class ARealAgentRuntimeComposition:
    application: ARealAgentRuntime
    asset_store: AssetStorePort
    plugins: PluginManager
    runtime_selector: str
    host_config: HostBootstrapConfig
    prompt_resolver: LegacyPromptResolver | None = None

    def get_service(self, key: PortKey, owner: str | None = None) -> object:
        """Resolve an extension service without exposing PluginManager internals."""

        return self.plugins.registry.get(key, owner)

    def create_http_app(self):
        if self.host_config.kind == "arca":
            raise ValueError("ARCA is an invocation Host; use create_arca_host() or areal_agent_runtime invoke-arca")
        if self.host_config.kind == "openai":
            host = OpenAICompatibilityHost(
                self.application,
                OpenAICompatibilityConfig(
                    default_runtime=RuntimeSelection(selector=self.runtime_selector),
                    default_workspace=WorkspaceRef(
                        workspace_id=self.host_config.default_workspace_id,
                        mount_hint=self.host_config.default_workspace_mount,
                    ),
                    mode_runtimes={
                        mode: RuntimeSelection(selector=selector)
                        for mode, selector in self.host_config.mode_runtime_selectors.items()
                    },
                    mode_profiles=self.host_config.mode_profiles,
                    default_profile=self.host_config.default_profile,
                    default_model=self.host_config.default_model,
                    allowed_profiles=tuple(dict.fromkeys(self.host_config.mode_profiles.values())),
                    allowed_runtime_selectors=tuple(
                        dict.fromkeys(
                            (
                                self.runtime_selector,
                                *self.host_config.mode_runtime_selectors.values(),
                            )
                        )
                    ),
                    allowed_models=(self.host_config.default_model,),
                    max_request_bytes=self.host_config.max_request_bytes,
                    max_inline_image_bytes=self.host_config.max_inline_image_bytes,
                ),
                asset_store=self.asset_store,
            )
            return self._mount_data_api(create_openai_http_app(host))
        return self._mount_data_api(
            create_http_app(
                self.application,
                asset_store=self.asset_store,
                config=NativeHttpHostConfig(max_request_bytes=self.host_config.max_request_bytes),
            )
        )

    def _mount_data_api(self, app):  # type: ignore[no-untyped-def]
        configured = self.host_config.data_api
        if not configured.enabled:
            return app
        assert configured.auth_token_env is not None
        assert configured.subject is not None
        principal = RuntimeDataPrincipal(
            subject=configured.subject,
            tenant_id=configured.tenant_id,
            project_id=configured.project_id,
            permissions=frozenset(configured.permissions),
        )
        authorizer = StaticBearerDataAuthorizer.from_environment(
            configured.auth_token_env,
            principal,
        )
        return mount_runtime_data_api(
            app,
            self.application.data,
            authorizer,
            config=RuntimeDataHttpConfig(
                max_page_size=configured.max_page_size,
                max_request_bytes=configured.max_request_bytes,
                max_asset_ttl_seconds=configured.max_asset_ttl_seconds,
            ),
        )

    def create_arca_host(self) -> ArcaServerlessHost:
        if self.host_config.kind != "arca":
            raise ValueError("host.kind must be 'arca' to create an ARCA invocation Host")
        return ArcaServerlessHost(
            self.application,
            ArcaServerlessConfig(
                default_profile=self.host_config.default_profile,
                default_runtime=RuntimeSelection(selector=self.runtime_selector),
                default_workspace=WorkspaceRef(
                    workspace_id=self.host_config.default_workspace_id,
                    mount_hint=self.host_config.default_workspace_mount,
                ),
                default_timeout_seconds=self.host_config.default_timeout_seconds,
            ),
        )

    async def close(self) -> None:
        errors: list[BaseException] = []
        try:
            await self.application.shutdown()
        except BaseException as exc:
            errors.append(exc)
        try:
            await self.plugins.stop_all()
        except BaseException as exc:
            errors.append(exc)
        _raise_cleanup_errors("ARealAgentRuntime composition failed to close cleanly", errors)


@dataclass(slots=True)
class RuntimeServiceComposition:
    runtime: AgentRuntimePort
    asset_store: AssetStorePort
    plugins: PluginManager
    config: RuntimeServiceBootstrapConfig

    async def close(self) -> None:
        await self.plugins.stop_all()


async def _load_asset_backends(manager: PluginManager, config: AssetStorageBootstrapConfig | None) -> str | None:
    if config is None:
        return None
    owners: dict[str, str] = {}
    for alias, backend_config in config.backends.items():
        plugin = _load_plugin(backend_config.entrypoint)
        _require_plugin_ports(plugin, (PortKey.ASSET_STORE,), f"asset backend {alias}")
        owner = backend_config.instance_name or f"assets.{alias}"
        await manager.load(
            plugin, backend_config.config, instance_name=owner,
            service_bindings=backend_config.service_bindings,
        )
        owners[alias] = owner
    assert config.default_backend is not None
    router = _load_plugin("areal_agent_runtime.adapters.storage.routing_plugin:create_plugin")
    owner = "assets._router"
    await manager.load(
        router,
        {
            "backends": dict(owners),
            "defaultBackend": config.default_backend,
            "rules": [rule.model_dump(mode="json", by_alias=True, exclude_none=True) for rule in config.rules],
            **({"legacyBackend": config.legacy_backend} if config.legacy_backend is not None else {}),
        },
        instance_name=owner,
    )
    return owner


async def build_composition(config: BootstrapConfig | dict[str, object]) -> ARealAgentRuntimeComposition:
    parsed = config if isinstance(config, BootstrapConfig) else BootstrapConfig.model_validate(config)
    root = await asyncio.to_thread(lambda: Path(parsed.data_root).expanduser().resolve())
    manager = PluginManager(
        permission_policy=PluginPermissionPolicy(
            allowed=(
                frozenset(parsed.allowed_plugin_permissions) if parsed.allowed_plugin_permissions is not None else None
            )
        )
    )
    storage = _load_plugin(parsed.storage.entrypoint)
    environment = _load_plugin(parsed.environment.entrypoint)
    _require_plugin_ports(
        storage,
        (PortKey.STATE_STORE, PortKey.ASSET_STORE),
        "storage",
    )
    _require_plugin_ports(environment, (PortKey.ENVIRONMENT,), "environment")
    workspace_tools = _load_plugin(parsed.workspace_tools.entrypoint) if parsed.workspace_tools.enabled else None
    domain_tools = (
        _load_plugin(parsed.domain_tools.entrypoint)
        if parsed.domain_tools is not None and parsed.domain_tools.enabled
        else None
    )
    if workspace_tools is not None:
        _require_plugin_ports(workspace_tools, (PortKey.TOOL_PROVIDER,), "workspace tools")
    if domain_tools is not None:
        _require_plugin_ports(domain_tools, (PortKey.TOOL_PROVIDER,), "domain tools")
    request_knowledge = parsed.host.request_knowledge
    knowledge_tools = (
        _load_plugin(parsed.knowledge_tools.entrypoint)
        if request_knowledge.enabled and parsed.knowledge_tools.enabled
        else None
    )
    if knowledge_tools is not None:
        _require_plugin_ports(knowledge_tools, (PortKey.TOOL_PROVIDER,), "knowledge tools")
    runtime_configs = parsed.configured_runtimes()
    runtime_plugins = tuple(
        (runtime_config, _runtime_plugin(runtime_config), f"runtime.{runtime_config.selector}")
        for runtime_config in runtime_configs
    )
    application: ARealAgentRuntime | None = None
    storage_owner = parsed.storage.instance_name or storage.manifest.name
    environment_owner = parsed.environment.instance_name or environment.manifest.name
    try:
        asset_owner = await _load_asset_backends(manager, parsed.assets)
        state_owner = storage_owner
        if parsed.state is not None:
            state_plugin = _load_plugin(parsed.state.entrypoint)
            _require_plugin_ports(state_plugin, (PortKey.STATE_STORE,), "state backend")
            state_owner = parsed.state.instance_name or "state"
            await manager.load(
                state_plugin, parsed.state.config, instance_name=state_owner,
                service_bindings={
                    **parsed.state.service_bindings,
                    **({PortKey.ASSET_STORE: asset_owner} if asset_owner is not None else {}),
                },
            )
        await manager.load(
            storage,
            {"root": str(root), **parsed.storage.config},
            instance_name=storage_owner,
            service_bindings={
                **parsed.storage.service_bindings,
                **({PortKey.ASSET_STORE: asset_owner} if asset_owner is not None else {}),
                **({PortKey.STATE_STORE: state_owner} if parsed.state is not None else {}),
            },
        )
        if asset_owner is not None and (
            manager.registry.get(PortKey.ASSET_STORE, storage_owner)
            is not manager.registry.get(PortKey.ASSET_STORE, asset_owner)
        ):
            raise ValueError(
                "storage must reuse the injected AssetStore when assets is configured; "
                "update the combined plugin to context.require(PortKey.ASSET_STORE), or use the default storage. "
                "Configure asset wrappers as assets.backends instead of bypassing the unified store"
            )
        asset_owner = asset_owner or storage_owner
        if parsed.state is not None and (
            manager.registry.get(PortKey.STATE_STORE, storage_owner)
            is not manager.registry.get(PortKey.STATE_STORE, state_owner)
        ):
            raise ValueError("storage must reuse context.require(PortKey.STATE_STORE) when state is configured")
        infrastructure_bindings = {
            PortKey.STATE_STORE: state_owner,
            PortKey.ASSET_STORE: asset_owner,
        }
        environment_config: dict[str, JsonValue] = {
            "root": str(root / "environment"),
            "allowExternalMounts": parsed.host.kind == "arca" or parsed.host.default_workspace_mount is not None,
            **parsed.environment.config,
        }
        configured_mount_roots = environment_config.get("allowedExternalMountRoots", [])
        if not isinstance(configured_mount_roots, list) or any(
            not isinstance(item, str) or not item or item != item.strip() for item in configured_mount_roots
        ):
            raise ValueError("environment.allowedExternalMountRoots must be a list of trimmed non-empty paths")
        if parsed.host.default_workspace_mount is not None:
            configured_mount_roots = [
                *configured_mount_roots,
                parsed.host.default_workspace_mount,
            ]
        environment_config["allowedExternalMountRoots"] = list(dict.fromkeys(configured_mount_roots))
        await manager.load(
            environment,
            environment_config,
            instance_name=environment_owner,
            service_bindings={
                **infrastructure_bindings,
                **parsed.environment.service_bindings,
            },
        )
        infrastructure_bindings[PortKey.ENVIRONMENT] = environment_owner
        for plugin_config in parsed.plugins:
            if plugin_config.enabled:
                await manager.load(
                    _load_plugin(plugin_config.entrypoint),
                    plugin_config.config,
                    instance_name=plugin_config.instance_name,
                    service_bindings={
                        **infrastructure_bindings,
                        **plugin_config.service_bindings,
                    },
                )
        if knowledge_tools is not None:
            knowledge_config = dict(parsed.knowledge_tools.config)
            if knowledge_tools.manifest.metadata.get(
                "areal.agent-runtime.bootstrap.requestKnowledgeDefaults"
            ) is True:
                knowledge_roots: dict[str, JsonValue] = dict(request_knowledge.skill_roots)
                knowledge_config = {
                    "roots": knowledge_roots,
                    "maxFileBytes": request_knowledge.max_skill_bytes,
                    "maxSelectedBundles": request_knowledge.max_requested_skills,
                    **knowledge_config,
                }
            await manager.load(
                knowledge_tools,
                knowledge_config,
                instance_name=parsed.knowledge_tools.instance_name,
                service_bindings={
                    **infrastructure_bindings,
                    **parsed.knowledge_tools.service_bindings,
                },
            )
        if workspace_tools is not None:
            await manager.load(
                workspace_tools,
                parsed.workspace_tools.config,
                instance_name=parsed.workspace_tools.instance_name,
                service_bindings={
                    **infrastructure_bindings,
                    **parsed.workspace_tools.service_bindings,
                },
            )
        if domain_tools is not None:
            assert parsed.domain_tools is not None
            await manager.load(
                domain_tools,
                parsed.domain_tools.config,
                instance_name=parsed.domain_tools.instance_name,
                service_bindings={
                    **infrastructure_bindings,
                    **parsed.domain_tools.service_bindings,
                },
            )
        for runtime_config, runtime_plugin, owner in runtime_plugins:
            await manager.load(
                runtime_plugin,
                _runtime_plugin_config(runtime_config, runtime_plugin, data_root=root),
                instance_name=owner,
                service_bindings={
                    **infrastructure_bindings,
                    **runtime_config.service_bindings,
                },
            )

        state = cast(StateStorePort, manager.registry.get(PortKey.STATE_STORE, state_owner))
        assets = cast(AssetStorePort, manager.registry.get(PortKey.ASSET_STORE, asset_owner))
        environment_port = cast(
            EnvironmentPort,
            manager.registry.get(PortKey.ENVIRONMENT, environment_owner),
        )
        runtimes: dict[str, AgentRuntimePort] = {
            runtime_config.selector: cast(
                AgentRuntimePort,
                manager.registry.get(PortKey.AGENT_RUNTIME, owner),
            )
            for runtime_config, _runtime_plugin_instance, owner in runtime_plugins
        }
        bindings: dict[str, Literal["runtime-owned", "portable"]] = {}
        for runtime_config in runtime_configs:
            binding = runtime_config.profile_binding
            if binding == "auto":
                descriptor = await runtimes[runtime_config.selector].describe()
                binding = "portable" if descriptor.capabilities.application_tool_bridge else "runtime-owned"
            bindings[runtime_config.selector] = binding
        configured_selectors = set(runtimes)
        default_selector = parsed.host.default_runtime_selector or runtime_configs[0].selector
        requested_selectors = {default_selector, *parsed.host.mode_runtime_selectors.values()}
        missing_selectors = sorted(requested_selectors - configured_selectors)
        if missing_selectors:
            raise ValueError("Host references unknown runtime selector(s): " + ", ".join(missing_selectors))
        tool_providers = {
            owner: cast(ToolProviderPort, manager.registry.get(PortKey.TOOL_PROVIDER, owner))
            for owner in manager.registry.providers(PortKey.TOOL_PROVIDER)
        }
        tool_owners = await _discover_tool_owners(tool_providers)
        profiles = default_profiles() if parsed.include_default_profiles else {}
        profile_bindings: dict[str, set[Literal["runtime-owned", "portable"]]] = {}
        for mode, profile_id in parsed.host.mode_profiles.items():
            selector = parsed.host.mode_runtime_selectors.get(mode, default_selector)
            profile_bindings.setdefault(profile_id, set()).add(bindings[selector])
        ambiguous = sorted(profile_id for profile_id, values in profile_bindings.items() if len(values) > 1)
        if ambiguous:
            raise ValueError(
                "one profile cannot be runtime-owned and portable at the same time: " + ", ".join(ambiguous)
            )
        profiles.update({profile.profile_id: profile for profile in parsed.profile_overrides})
        if not profiles:
            raise ValueError("composition has no release profiles")
        if parsed.host.kind == "arca" and parsed.host.default_profile not in profiles:
            raise ValueError(f"Host defaultProfile is not installed: {parsed.host.default_profile}")
        if parsed.host.kind == "openai":
            missing_profiles = sorted(set(parsed.host.mode_profiles.values()).difference(profiles))
            if missing_profiles:
                raise ValueError(
                    "OpenAI Host modeProfiles references unavailable profile(s): " + ", ".join(missing_profiles)
                )
        await _apply_tool_bindings(profiles, parsed.tool_bindings, tool_owners)
        sinks = {
            owner: cast(EventSinkPort, manager.registry.get(PortKey.EVENT_SINK, owner))
            for owner in manager.registry.providers(PortKey.EVENT_SINK)
        }
        if parsed.event_sinks is not None:
            missing_sinks = sorted(set(parsed.event_sinks).difference(sinks))
            if missing_sinks:
                raise ValueError("eventSinks reference unavailable instances: " + ", ".join(missing_sinks))
            sinks = {owner: sinks[owner] for owner in parsed.event_sinks}
        application = ARealAgentRuntime(
            runtimes=runtimes,
            profiles=profiles,
            state=state,
            max_active_runs=parsed.max_active_runs,
            data_query_max_events=parsed.data_query_max_events,
            data_query_max_bytes=parsed.data_query_max_bytes,
            max_recovery_events=parsed.max_recovery_events,
            max_recovery_bytes=parsed.max_recovery_bytes,
            sinks=sinks,
            tool_providers=tool_providers,
            tool_provider_versions={
                owner: manager.manifest(owner).version for owner in manager.registry.providers(PortKey.TOOL_PROVIDER)
            },
            allowed_tool_permissions=parsed.allowed_tool_permissions,
            resource_loader=HostResourceBindings(
                builtins={
                    name: BuiltinResource(
                        content=value.content,
                        media_type=value.media_type,
                        version=value.version,
                    )
                    for name, value in parsed.host.resource_bindings.builtins.items()
                },
                mounts={
                    name: path
                    for name, path in parsed.host.resource_bindings.mounts.items()
                },
                asset_store=assets,
                policy=ResourceBindingPolicy(
                    max_bytes=parsed.host.resource_bindings.max_bytes,
                    allowed_http_origins=parsed.host.resource_bindings.allowed_uri_origins,
                    allow_insecure_loopback_http=(parsed.host.resource_bindings.allow_insecure_loopback_http),
                ),
            ),
            agent_environment_policy=AgentEnvironmentPolicy(
                allow_stdio_mcp=parsed.host.resource_bindings.allow_stdio_mcp,
                allowed_mcp_http_origins=(parsed.host.resource_bindings.allowed_mcp_http_origins),
                allow_insecure_loopback_http=(parsed.host.resource_bindings.allow_insecure_loopback_http),
                allowed_invocation_source_providers=(parsed.host.resource_bindings.allowed_invocation_source_providers),
                allowed_invocation_tool_names=(parsed.host.resource_bindings.allowed_invocation_tool_names),
                allowed_invocation_permissions=(parsed.host.resource_bindings.allowed_invocation_permissions),
                supported_extensions=parsed.host.supported_agent_environment_extensions,
            ),
            base_agent_environment=parsed.host.agent_environment,
            environment=environment_port,
            annotation_store=FileSystemAnnotationStore(root / "annotations"),
            asset_store=assets,
        )
        await application.initialize()
        prompt_resolver = (
            LegacyPromptResolver(
                request_knowledge.prompt_roots,
                skill_roots=request_knowledge.skill_roots,
                max_bytes=request_knowledge.max_prompt_bytes,
                max_skill_bytes=request_knowledge.max_skill_bytes,
            )
            if request_knowledge.enabled
            else None
        )
        return ARealAgentRuntimeComposition(
            application=application,
            asset_store=assets,
            plugins=manager,
            runtime_selector=default_selector,
            host_config=parsed.host,
            prompt_resolver=prompt_resolver,
        )
    except BaseException as build_error:
        cleanup_errors: list[BaseException] = []
        if application is not None:
            try:
                await application.shutdown()
            except BaseException as exc:
                cleanup_errors.append(exc)
        try:
            await manager.stop_all()
        except BaseException as exc:
            cleanup_errors.append(exc)
        if cleanup_errors:
            raise BaseExceptionGroup(
                "composition build failed and cleanup also failed",
                [build_error, *cleanup_errors],
            ) from None
        raise


async def build_runtime_service(
    config: RuntimeServiceBootstrapConfig | dict[str, object],
) -> RuntimeServiceComposition:
    parsed = (
        config
        if isinstance(config, RuntimeServiceBootstrapConfig)
        else RuntimeServiceBootstrapConfig.model_validate(config)
    )
    root = await asyncio.to_thread(lambda: Path(parsed.data_root).expanduser().resolve())
    manager = PluginManager(
        permission_policy=PluginPermissionPolicy(
            allowed=(
                frozenset(parsed.allowed_plugin_permissions) if parsed.allowed_plugin_permissions is not None else None
            )
        )
    )
    if not parsed.storage.enabled:
        raise ValueError("runtime service storage infrastructure plugin cannot be disabled")
    storage = _load_plugin(parsed.storage.entrypoint)
    _require_plugin_ports(storage, (PortKey.ASSET_STORE,), "runtime service storage")
    runtime_plugin = _runtime_plugin(parsed.runtime)
    storage_owner = parsed.storage.instance_name or storage.manifest.name
    try:
        await manager.load(
            storage,
            {"root": str(root), **parsed.storage.config},
            instance_name=storage_owner,
            service_bindings=parsed.storage.service_bindings,
        )
        await manager.load(
            runtime_plugin,
            _runtime_plugin_config(parsed.runtime, runtime_plugin, data_root=root),
            service_bindings={
                PortKey.ASSET_STORE: storage_owner,
                **parsed.runtime.service_bindings,
            },
        )
        runtime = cast(
            AgentRuntimePort,
            manager.registry.get(PortKey.AGENT_RUNTIME, runtime_plugin.manifest.name),
        )
        assets = cast(
            AssetStorePort,
            manager.registry.get(PortKey.ASSET_STORE, storage_owner),
        )
        return RuntimeServiceComposition(
            runtime=runtime,
            asset_store=assets,
            plugins=manager,
            config=parsed,
        )
    except BaseException as build_error:
        try:
            await manager.stop_all()
        except BaseException as cleanup_error:
            raise BaseExceptionGroup(
                "runtime service build failed and cleanup also failed",
                [build_error, cleanup_error],
            ) from None
        raise


def _runtime_plugin_config(
    config: RuntimeBootstrapConfig, plugin: Plugin, *, data_root: Path | None = None,
) -> dict[str, JsonValue]:
    """Supply defaults only to plugins that explicitly declare their support."""
    values = _runtime_config_values(
        config,
        receives_profile_binding=plugin.manifest.metadata.get("areal.agent-runtime.bootstrap.profileBinding") is True,
    )
    if data_root is not None and plugin.manifest.metadata.get("areal.agent-runtime.bootstrap.historyRoot") is True:
        # Selectors are logical IDs, not filesystem paths. Keep each installed
        # runtime's durable history isolated even for selectors containing '/'.
        identity = hashlib.sha256(config.selector.encode("utf-8")).hexdigest()
        values.setdefault("historyRoot", str(data_root / "runtime-history" / identity))
    return values


def _runtime_config_values(
    config: RuntimeBootstrapConfig, *, receives_profile_binding: bool
) -> dict[str, JsonValue]:
    """Shared assembly semantics for real plugin loading and offline validation."""
    values = dict(config.config)
    if receives_profile_binding:
        nested = values.get("profileBinding")
        if nested is not None and nested != config.profile_binding:
            raise ValueError("runtime.config.profileBinding conflicts with runtime.profileBinding")
        values["profileBinding"] = config.profile_binding
    return values


def _runtime_plugin(config: RuntimeBootstrapConfig) -> Plugin:
    if config.kind == "entrypoint":
        assert config.plugin_entrypoint is not None
        return _load_runtime_plugin(config.plugin_entrypoint)
    entrypoints = {
        "fake": "areal_agent_runtime.adapters.fake.plugin:create_plugin",
        "dsh": "areal_agent_runtime.adapters.dsh.plugin:create_plugin",
        "claude-agent-sdk": "areal_agent_runtime.adapters.claude_sdk.plugin:create_plugin",
        "claude-code": "areal_agent_runtime.adapters.claude_code.plugin:create_plugin",
        "hermes": "areal_agent_runtime.adapters.hermes.plugin:create_plugin",
        "anthropic": "areal_agent_runtime.adapters.anthropic_messages.plugin:create_plugin",
        "codex-cli": "areal_agent_runtime.adapters.codex_cli.plugin:create_plugin",
        "remote": "areal_agent_runtime.adapters.remote.plugin:create_plugin",
    }
    return _load_runtime_plugin(entrypoints[config.kind])


def _load_runtime_plugin(entrypoint: str) -> Plugin:
    plugin = _load_plugin(entrypoint)
    if PortKey.AGENT_RUNTIME not in plugin.manifest.implements:
        raise TypeError(f"Runtime plugin does not provide {PortKey.AGENT_RUNTIME}: {entrypoint}")
    return plugin


def _load_plugin(entrypoint: str) -> Plugin:
    module_name, separator, attribute = entrypoint.partition(":")
    if not separator or not module_name or not attribute:
        raise ValueError("plugin_entrypoint must use the 'python.module:factory' form")
    module = importlib.import_module(module_name)
    factory = getattr(module, attribute, None)
    if not callable(factory):
        raise TypeError(f"Plugin factory is not callable: {entrypoint}")
    plugin = factory()
    if not isinstance(plugin, Plugin):
        raise TypeError(f"Plugin does not implement Plugin SPI v1: {entrypoint}")
    return plugin


def _require_plugin_ports(
    plugin: Plugin,
    required: tuple[PortKey, ...],
    role: str,
) -> None:
    missing = [port for port in required if port not in plugin.manifest.implements]
    if missing:
        names = ", ".join(str(port) for port in missing)
        raise TypeError(f"{role} plugin {plugin.manifest.name} does not provide: {names}")


async def _apply_tool_bindings(
    profiles: dict[str, WorkflowProfile],
    bindings: tuple[ToolBindingBootstrapConfig, ...],
    tools: dict[str, str],
) -> None:
    if not bindings:
        return

    for binding in bindings:
        profile = profiles.get(binding.profile_id)
        if profile is None:
            raise ValueError(f"tool binding references unknown profile: {binding.profile_id}")
        missing = sorted(set(binding.tool_names).difference(tools))
        if missing:
            raise ValueError(
                f"tool binding for {binding.profile_id} references unavailable tools: {', '.join(missing)}"
            )
        if binding.agent_id is None:
            profiles[binding.profile_id] = profile.model_copy(
                update={"tool_names": _ordered_union(profile.tool_names, binding.tool_names)}
            )
            continue

        graph = profile.agent_graph
        if graph is None:
            raise ValueError(
                f"tool binding for {binding.profile_id} specifies agent {binding.agent_id!r}, "
                "but the profile has no agent graph"
            )
        if binding.agent_id not in {agent.agent_id for agent in graph.agents}:
            raise ValueError(f"tool binding for {binding.profile_id} references unknown agent: {binding.agent_id}")
        agents = tuple(
            agent.model_copy(update={"tool_names": _ordered_union(agent.tool_names, binding.tool_names)})
            if agent.agent_id == binding.agent_id
            else agent
            for agent in graph.agents
        )
        profiles[binding.profile_id] = profile.model_copy(
            update={"agent_graph": graph.model_copy(update={"agents": agents})}
        )


async def _discover_tool_owners(providers: dict[str, ToolProviderPort]) -> dict[str, str]:
    tools: dict[str, str] = {}
    for provider_name in sorted(providers):
        for spec in await providers[provider_name].list_tools():
            previous = tools.get(spec.name)
            if previous is not None:
                raise ValueError(
                    f"duplicate tool {spec.name!r} from providers {previous!r} and {provider_name!r}"
                )
            tools[spec.name] = provider_name
    return tools


def _ordered_union(left: tuple[str, ...], right: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys((*left, *right)))


def _raise_cleanup_errors(message: str, errors: list[BaseException]) -> None:
    if not errors:
        return
    if len(errors) == 1:
        raise errors[0]
    raise BaseExceptionGroup(message, errors)
