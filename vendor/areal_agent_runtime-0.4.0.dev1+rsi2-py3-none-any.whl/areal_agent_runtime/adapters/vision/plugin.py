"""Plugin packaging for the canonical ``vision.ocr`` ToolProvider."""

from __future__ import annotations

import importlib
import inspect
from collections.abc import Callable
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.vision.ocr import OCREngine, OCRToolProvider
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey

OCREngineFactory = Callable[[dict[str, JsonValue]], OCREngine]


class VisionOCRPlugin:
    manifest = PluginManifest(
        name="vision-ocr",
        version="1.0.0",
        implements=(PortKey.TOOL_PROVIDER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.vision.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("asset.read", "vision.ocr"),
    )

    def __init__(self, engine: OCREngine | None = None) -> None:
        self._engine = engine
        self.provider: OCRToolProvider | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        asset_store = cast(AssetStorePort, context.require(PortKey.ASSET_STORE))
        engine = self._engine or _load_engine(config)
        self._engine = engine
        self.provider = OCRToolProvider(asset_store, engine)
        context.provide(PortKey.TOOL_PROVIDER, self.provider)

    async def start(self) -> None:
        if self.provider is None:
            raise RuntimeError("Vision OCR plugin is not configured")
        health = await self.provider.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "OCR engine is unhealthy"))

    async def health(self) -> HealthStatus:
        if self.provider is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.provider.health()

    async def stop(self) -> None:
        close = getattr(self._engine, "close", None)
        if callable(close):
            result = close()
            if inspect.isawaitable(result):
                await result


def create_plugin() -> VisionOCRPlugin:
    return VisionOCRPlugin()


def _load_engine(config: dict[str, JsonValue]) -> OCREngine:
    entrypoint = config.get("engineEntrypoint")
    if not isinstance(entrypoint, str) or not entrypoint:
        raise ValueError("vision-ocr requires config.engineEntrypoint")
    module_name, separator, attribute = entrypoint.partition(":")
    if not separator or not module_name or not attribute:
        raise ValueError("engineEntrypoint must use the 'python.module:factory' form")
    factory = getattr(importlib.import_module(module_name), attribute, None)
    if not callable(factory):
        raise TypeError(f"OCR engine factory is not callable: {entrypoint}")
    engine_config = config.get("engineConfig")
    parsed_config = engine_config if isinstance(engine_config, dict) else {}
    engine = cast(OCREngineFactory, factory)(parsed_config)
    if not isinstance(engine, OCREngine):
        raise TypeError(f"OCR engine does not implement OCREngine: {entrypoint}")
    return engine
