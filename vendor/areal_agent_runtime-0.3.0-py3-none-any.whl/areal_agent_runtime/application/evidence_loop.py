"""Opt-in no-progress protection for evidence-producing Application tools."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import stat
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path

from areal_agent_runtime.application.progress_guard import NoProgressReport, ToolProgress, ToolProgressGuard
from areal_agent_runtime.contracts.content import JsonBlock
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.runtime import ToolCall, ToolRepeatPolicy, ToolResult, ToolSpec

_IGNORED_PATH_NAMES = frozenset({".git", ".areal-agent-runtime", ".agent-harness-state", "node_modules"})
_INFRASTRUCTURE_CATEGORIES = frozenset(
    {
        ErrorCategory.AUTHENTICATION,
        ErrorCategory.RATE_LIMIT,
        ErrorCategory.TIMEOUT,
        ErrorCategory.CANCELLED,
        ErrorCategory.UNAVAILABLE,
        ErrorCategory.PROTOCOL,
        ErrorCategory.INTERNAL,
    }
)
_MAX_REQUIRED_FIXES = 8
_MAX_SNAPSHOT_ENTRIES = 100_000
_MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class _FileDigest:
    stat_key: tuple[int, int, int, int, int]
    digest: str


@dataclass(slots=True)
class _EvidenceEntry:
    result: ToolResult
    calls: int = 1


@dataclass(slots=True)
class _EvidenceState:
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    revision: int = 0
    snapshot: tuple[tuple[str, str], ...] | None = None
    digest_cache: dict[str, _FileDigest] = field(default_factory=dict)
    entries: dict[tuple[str, str, int], _EvidenceEntry] = field(default_factory=dict)
    progress: ToolProgressGuard | None = None


class EvidenceLoopGuard:
    """Enforce bounded repetition without coupling the Kernel to domain tools."""

    def __init__(self) -> None:
        self._states: dict[tuple[str, str, str | None], _EvidenceState] = {}

    async def invoke(
        self,
        call: ToolCall,
        spec: ToolSpec,
        operation: Callable[[], Awaitable[ToolResult]],
        *,
        max_stalled_actions: int | None = None,
    ) -> ToolResult:
        state_key = (call.run_id, call.workspace.workspace_id, call.workspace.mount_hint)
        state = self._states.get(state_key)
        guarded = spec.repeat_policy == ToolRepeatPolicy.CACHE_THEN_BLOCK
        if state is None and not guarded and max_stalled_actions is None:
            return await operation()
        if call.workspace.mount_hint is None and not guarded:
            return await operation()
        if state is None:
            state = self._states.setdefault(state_key, _EvidenceState())
        if max_stalled_actions is not None and state.progress is None:
            state.progress = ToolProgressGuard(max_stalled_actions)

        async with state.lock:
            await self._observe_workspace(state, call)
            revision_before = state.revision
            evidence_key = self._evidence_key(call, revision_before)
            if guarded:
                cached = self._cached_result(state, call, evidence_key)
                if cached is not None:
                    return cached

            result = await operation()
            await self._observe_workspace(state, call)
            if state.progress is not None:
                progress = state.progress.observe(
                    call,
                    result,
                    revision_before=revision_before,
                    revision_after=state.revision,
                )
                if progress.threshold_reached:
                    return self._no_progress_result(result, call, state.revision, progress)
            if not guarded:
                return result
            if state.revision != revision_before:
                return self._annotate(
                    result,
                    call.call_id,
                    state.revision,
                    "not_cached_workspace_changed",
                    call.name,
                )
            if self._is_retryable_infrastructure(result):
                return self._annotate(
                    result,
                    call.call_id,
                    state.revision,
                    "not_cached_infrastructure",
                    call.name,
                )
            annotated = self._annotate(result, call.call_id, state.revision, "executed", call.name)
            state.entries[evidence_key] = _EvidenceEntry(result=annotated)
            return annotated

    @staticmethod
    def _no_progress_result(
        result: ToolResult,
        call: ToolCall,
        revision: int,
        progress: ToolProgress,
    ) -> ToolResult:
        count = progress.stalled_count
        fingerprint = progress.fingerprint
        value = NoProgressReport(
            workspace_revision=revision,
            stalled_count=count,
            fingerprint=fingerprint,
            workspace_changed=progress.workspace_changed,
            previous_result=result.model_dump(mode="json", by_alias=True),
            next_action=(
                "Stop repeating the same action; inspect current evidence and make a materially different change."
            ),
        ).model_dump(mode="json", by_alias=True)
        return ToolResult(
            call_id=call.call_id,
            content=(JsonBlock(value=value, schema_name="areal.agent-runtime.no-progress/v1"),),
            value=value,
            error=ErrorInfo(
                code="TOOL_NO_PROGRESS",
                category=ErrorCategory.CONFLICT,
                message="The configured no-progress threshold was reached",
                details={
                    "tool": call.name,
                    "workspaceRevision": revision,
                    "stalledCount": count,
                    "fingerprint": fingerprint,
                    "workspaceChanged": progress.workspace_changed,
                },
            ),
        )

    def release_run(self, run_id: str) -> None:
        for key in tuple(self._states):
            if key[0] == run_id:
                self._states.pop(key, None)

    async def _observe_workspace(self, state: _EvidenceState, call: ToolCall) -> None:
        mount_hint = call.workspace.mount_hint
        if mount_hint is None:
            raise RuntimeError(
                f"Tool {call.name} uses an evidence repeat policy but workspace.mountHint is unavailable"
            )
        root = await asyncio.to_thread(_resolve_workspace, mount_hint)
        snapshot, cache = await asyncio.to_thread(self._snapshot, root, state.digest_cache)
        state.digest_cache = cache
        if state.snapshot is None:
            state.snapshot = snapshot
        elif snapshot != state.snapshot:
            state.snapshot = snapshot
            state.revision += 1

    @staticmethod
    def _snapshot(
        root: Path,
        previous: dict[str, _FileDigest],
    ) -> tuple[tuple[tuple[str, str], ...], dict[str, _FileDigest]]:
        snapshot: list[tuple[str, str]] = []
        cache: dict[str, _FileDigest] = {}
        entry_count = 0
        total_bytes = 0
        for directory, names, filenames in os.walk(root, topdown=True, followlinks=False):
            directory_path = Path(directory)
            safe_directories: list[str] = []
            for name in sorted(names):
                if name in _IGNORED_PATH_NAMES:
                    continue
                try:
                    metadata = (directory_path / name).stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.S_ISDIR(metadata.st_mode):
                    safe_directories.append(name)
            names[:] = safe_directories
            for name in sorted(filenames):
                if name in _IGNORED_PATH_NAMES:
                    continue
                path = directory_path / name
                try:
                    metadata = path.stat(follow_symlinks=False)
                    if not stat.S_ISREG(metadata.st_mode):
                        continue
                    entry_count += 1
                    total_bytes += metadata.st_size
                    if entry_count > _MAX_SNAPSHOT_ENTRIES:
                        raise ValueError(
                            f"Workspace evidence snapshot exceeds {_MAX_SNAPSHOT_ENTRIES} files"
                        )
                    if total_bytes > _MAX_SNAPSHOT_BYTES:
                        raise ValueError(
                            f"Workspace evidence snapshot exceeds {_MAX_SNAPSHOT_BYTES} bytes"
                        )
                    relative = path.relative_to(root)
                    stat_key = (
                        metadata.st_dev,
                        metadata.st_ino,
                        metadata.st_size,
                        metadata.st_mtime_ns,
                        metadata.st_ctime_ns,
                    )
                    canonical_name = relative.as_posix()
                    cached = previous.get(canonical_name)
                    digest = (
                        cached.digest
                        if cached is not None and cached.stat_key == stat_key
                        else _sha256(path, expected=stat_key)
                    )
                    entry = _FileDigest(stat_key=stat_key, digest=digest)
                    cache[canonical_name] = entry
                    snapshot.append((canonical_name, digest))
                except OSError:
                    continue
        return tuple(snapshot), cache

    @staticmethod
    def _evidence_key(call: ToolCall, revision: int) -> tuple[str, str, int]:
        canonical = json.dumps(
            call.arguments,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        return call.name, canonical, revision

    def _cached_result(
        self,
        state: _EvidenceState,
        call: ToolCall,
        key: tuple[str, str, int],
    ) -> ToolResult | None:
        entry = state.entries.get(key)
        if entry is None:
            return None
        entry.calls += 1
        if entry.calls >= 3:
            value = {
                "ok": False,
                "status": "loop_blocked",
                "actionRequired": True,
                "workspaceRevision": state.revision,
                "cacheStatus": "loop_blocked",
                "requiredFixes": self._required_fixes(entry.result),
                "nextAction": f"先修改 workspace，再重新运行 {call.name}",
            }
            return ToolResult(
                call_id=call.call_id,
                content=(JsonBlock(value=value, schema_name="areal.agent-runtime.evidence-loop/v1"),),
                value=value,
                error=ErrorInfo(
                    code="EVIDENCE_LOOP_BLOCKED",
                    category=ErrorCategory.CONFLICT,
                    message="同一 workspace revision 下禁止第三次重复证据调用",
                    details={"tool": call.name, "workspaceRevision": state.revision},
                ),
            )
        return self._annotate(entry.result, call.call_id, state.revision, "reused", call.name)

    def _annotate(
        self,
        result: ToolResult,
        call_id: str,
        revision: int,
        cache_status: str,
        tool_name: str,
    ) -> ToolResult:
        fixes = self._required_fixes(result)
        metadata = {
            "workspaceRevision": revision,
            "cacheStatus": cache_status,
            "requiredFixes": fixes,
            "nextAction": self._next_action(tool_name, result, fixes),
        }
        value = {**result.value, **metadata} if isinstance(result.value, dict) else result.value
        content = tuple(
            block.model_copy(update={"value": {**block.value, **metadata}})
            if isinstance(block, JsonBlock) and isinstance(block.value, dict)
            else block
            for block in result.content
        )
        return result.model_copy(update={"call_id": call_id, "content": content, "value": value})

    @staticmethod
    def _required_fixes(result: ToolResult) -> list[dict[str, str]]:
        if not isinstance(result.value, dict):
            return []
        candidates: list[object] = []
        for key in ("requiredFixes", "required_fixes", "diagnostics"):
            value = result.value.get(key)
            if isinstance(value, (list, tuple)):
                candidates.extend(value)
        fixes: list[dict[str, str]] = []
        seen: set[str] = set()
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            code = str(candidate.get("code") or "UNKNOWN")
            if code in seen:
                continue
            seen.add(code)
            detail = candidate.get("detail") or candidate.get("message") or ""
            fixes.append({"code": code, "detail": str(detail)[:1000]})
            if len(fixes) >= _MAX_REQUIRED_FIXES:
                break
        return fixes

    @staticmethod
    def _next_action(tool_name: str, result: ToolResult, fixes: list[dict[str, str]]) -> str:
        if result.error is None:
            return f"继续下一交付步骤；不要在未修改 workspace 时重复 {tool_name}"
        if fixes:
            return f"先修改 workspace 以修复 {fixes[0]['code']}，再重新运行 {tool_name}"
        return f"先修改 workspace，再重新运行 {tool_name}"

    @staticmethod
    def _is_retryable_infrastructure(result: ToolResult) -> bool:
        error = result.error
        if error is not None and (error.retryable or error.category in _INFRASTRUCTURE_CATEGORIES):
            return True
        if not isinstance(result.value, dict):
            return False
        diagnostics = result.value.get("diagnostics")
        return isinstance(diagnostics, (list, tuple)) and any(
            isinstance(item, dict)
            and (
                str(item.get("origin", "")).lower() == "infrastructure"
                or str(item.get("disposition", "")).lower() == "retry"
            )
            for item in diagnostics
        )


def _sha256(path: Path, *, expected: tuple[int, int, int, int, int]) -> str:
    digest = hashlib.sha256()
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as handle:
        metadata = os.fstat(handle.fileno())
        actual = (
            metadata.st_dev,
            metadata.st_ino,
            metadata.st_size,
            metadata.st_mtime_ns,
            metadata.st_ctime_ns,
        )
        if not stat.S_ISREG(metadata.st_mode) or actual != expected:
            raise OSError(f"Workspace file changed while opening: {path}")
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_workspace(mount_hint: str) -> Path:
    root = Path(mount_hint).expanduser().resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Workspace does not exist: {root}")
    return root


__all__ = ["EvidenceLoopGuard"]
