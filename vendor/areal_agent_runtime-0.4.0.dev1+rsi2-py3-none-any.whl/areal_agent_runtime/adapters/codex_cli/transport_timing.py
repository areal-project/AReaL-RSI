"""Extract transport timestamps without retaining native log contents."""

from __future__ import annotations

import re
from datetime import datetime

_ANSI = re.compile(r"\x1b\[[0-9;]*m")
_TIMESTAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z")
_RESPONSE = re.compile(r"url=\S*/responses(?:\?\S*)?(?:\s|$)")


def transport_event(line: str) -> tuple[str, float] | None:
    line = _ANSI.sub("", line)
    kind = None
    if "codex_http_client::custom_ca" in line and "model_client.stream_responses_api" in line:
        if "building HTTP client" in line or "using system root certificates" in line:
            kind = "start"
    elif "codex_http_client::client" in line and _RESPONSE.search(line):
        if "Request failed method=POST" in line:
            kind = "failed"
        elif "Request completed method=POST" in line:
            status = re.search(r"\bstatus=(\d+)", line)
            if status and (int(status[1]) >= 500 or int(status[1]) in {408, 429}):
                kind = "failed"
            elif status and 200 <= int(status[1]) < 300:
                kind = "recovered"
    stamp = _TIMESTAMP.search(line) if kind else None
    if stamp is None:
        return None
    return kind, datetime.fromisoformat(stamp[0].replace("Z", "+00:00")).timestamp()
