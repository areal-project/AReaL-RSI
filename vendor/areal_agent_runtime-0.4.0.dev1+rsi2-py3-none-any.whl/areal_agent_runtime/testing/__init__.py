"""Reusable compatibility test kit for third-party adapters."""

from areal_agent_runtime.testing.conformance import (
    RuntimeConformanceCase,
    RuntimeConformanceError,
    RuntimeConformanceReport,
    analyze_data_coverage,
    verify_runtime,
)
from areal_agent_runtime.testing.infrastructure import (
    InfrastructureConformanceError,
    InfrastructureConformanceReport,
    verify_asset_store,
    verify_environment,
    verify_event_sink,
    verify_state_store,
)

__all__ = [
    "InfrastructureConformanceError",
    "InfrastructureConformanceReport",
    "RuntimeConformanceCase",
    "RuntimeConformanceError",
    "RuntimeConformanceReport",
    "analyze_data_coverage",
    "verify_asset_store",
    "verify_environment",
    "verify_event_sink",
    "verify_runtime",
    "verify_state_store",
]
