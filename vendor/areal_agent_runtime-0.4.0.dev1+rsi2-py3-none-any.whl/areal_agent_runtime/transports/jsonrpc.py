"""Bidirectional JSON-RPC 2.0 over newline-delimited asyncio streams."""

from __future__ import annotations

import asyncio
import contextlib
import json
import math
from collections.abc import Awaitable, Callable
from typing import Any

JsonObject = dict[str, Any]
RequestHandler = Callable[[Any], Awaitable[Any]]
NotificationHandler = Callable[[Any], Awaitable[None]]
DEFAULT_MAX_FRAME_BYTES = 16 * 1024 * 1024


class JsonRpcProtocolError(RuntimeError):
    def __init__(self, code: int, message: str, data: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.data = data


class JsonRpcPeer:
    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        *,
        max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
    ) -> None:
        if isinstance(max_frame_bytes, bool) or not isinstance(max_frame_bytes, int) or max_frame_bytes < 1024:
            raise ValueError("max_frame_bytes must be an integer of at least 1024")
        self._reader = reader
        self._writer = writer
        self._max_frame_bytes = max_frame_bytes
        self._max_frame_bytes_after_send: int | None = None
        self._request_handlers: dict[str, RequestHandler] = {}
        self._notification_handlers: dict[str, NotificationHandler] = {}
        self._pending: dict[str, asyncio.Future[Any]] = {}
        self._write_lock = asyncio.Lock()
        self._counter = 0
        self._read_task: asyncio.Task[None] | None = None
        self._dispatch_task: asyncio.Task[None] | None = None
        self._incoming: asyncio.Queue[JsonObject] = asyncio.Queue(maxsize=1024)
        self._closed = False
        self._closed_event = asyncio.Event()

    def on_request(self, method: str, handler: RequestHandler) -> None:
        self._validate_handler(method, handler)
        self._request_handlers[method] = handler

    def on_notification(self, method: str, handler: NotificationHandler) -> None:
        self._validate_handler(method, handler)
        self._notification_handlers[method] = handler

    @property
    def max_frame_bytes(self) -> int:
        return self._max_frame_bytes

    @property
    def pending_request_count(self) -> int:
        """Expose cleanup state for health checks and transport tests."""

        return len(self._pending)

    def set_max_frame_bytes(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 1024:
            raise ValueError("max_frame_bytes must be an integer of at least 1024")
        self._max_frame_bytes = value

    def set_max_frame_bytes_after_next_send(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 1024:
            raise ValueError("max_frame_bytes must be an integer of at least 1024")
        self._max_frame_bytes_after_send = value

    async def start(self) -> None:
        if self._closed:
            raise JsonRpcProtocolError(-32000, "JSON-RPC peer is closed")
        if self._read_task is None:
            self._read_task = asyncio.create_task(self._read_loop(), name="areal_agent_runtime-jsonrpc-reader")
            self._dispatch_task = asyncio.create_task(
                self._dispatch_loop(),
                name="areal_agent_runtime-jsonrpc-dispatcher",
            )

    async def request(self, method: str, params: Any = None, *, timeout_seconds: float | None = None) -> Any:
        self._validate_method(method)
        if self._closed:
            raise JsonRpcProtocolError(-32000, "JSON-RPC peer is closed")
        if timeout_seconds is not None and (
            isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, (int, float))
            or not math.isfinite(timeout_seconds)
            or timeout_seconds <= 0
        ):
            raise ValueError("timeout_seconds must be a finite positive number when provided")
        self._counter += 1
        request_id = str(self._counter)
        future = asyncio.get_running_loop().create_future()
        self._pending[request_id] = future
        try:
            await self._send({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
            async with asyncio.timeout(timeout_seconds):
                return await future
        finally:
            self._pending.pop(request_id, None)
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                # A concurrent close may complete the Future while _send itself
                # fails. Retrieving the exception prevents an orphaned Future
                # without changing the exception already observed by awaiters.
                future.exception()

    async def notify(self, method: str, params: Any = None) -> None:
        self._validate_method(method)
        if self._closed:
            raise JsonRpcProtocolError(-32000, "JSON-RPC peer is closed")
        await self._send({"jsonrpc": "2.0", "method": method, "params": params})

    async def close(self) -> None:
        was_closed = self._closed
        self._closed = True
        self._closed_event.set()
        if not self._writer.is_closing():
            self._writer.close()
        with contextlib.suppress(Exception):
            await self._writer.wait_closed()
        for task in (self._read_task, self._dispatch_task):
            if task is not None and task is not asyncio.current_task() and not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        if not was_closed:
            error = JsonRpcProtocolError(-32000, "JSON-RPC peer closed")
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(error)

    async def wait_closed(self) -> None:
        await self._closed_event.wait()

    async def _send(self, frame: JsonObject) -> None:
        encoded = json.dumps(frame, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode() + b"\n"
        if len(encoded) > self._max_frame_bytes:
            raise JsonRpcProtocolError(
                -32020,
                f"JSON-RPC frame exceeds negotiated limit ({len(encoded)} > {self._max_frame_bytes} bytes)",
            )
        async with self._write_lock:
            self._writer.write(encoded)
            await self._writer.drain()
            if self._max_frame_bytes_after_send is not None:
                self._max_frame_bytes = self._max_frame_bytes_after_send
                self._max_frame_bytes_after_send = None

    async def _read_loop(self) -> None:
        failure = JsonRpcProtocolError(-32000, "JSON-RPC stream ended")
        try:
            while True:
                try:
                    line = await self._reader.readline()
                except ValueError as exc:
                    failure = JsonRpcProtocolError(
                        -32020,
                        "JSON-RPC frame exceeds stream reader limit",
                        str(exc),
                    )
                    break
                if not line:
                    break
                if len(line) > self._max_frame_bytes:
                    failure = JsonRpcProtocolError(
                        -32020,
                        f"JSON-RPC frame exceeds negotiated limit ({len(line)} > {self._max_frame_bytes} bytes)",
                    )
                    break
                try:
                    frame = json.loads(
                        line,
                        parse_constant=_reject_json_constant,
                        object_pairs_hook=_unique_json_object,
                    )
                except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
                    failure = JsonRpcProtocolError(-32700, "Invalid JSON-RPC JSON", str(exc))
                    break
                if not isinstance(frame, dict) or frame.get("jsonrpc") != "2.0":
                    failure = JsonRpcProtocolError(-32600, "Invalid JSON-RPC frame")
                    break
                if "method" in frame:
                    if (
                        not isinstance(frame.get("method"), str)
                        or not frame["method"].strip()
                        or frame["method"] != frame["method"].strip()
                        or "result" in frame
                        or "error" in frame
                        or ("id" in frame and not isinstance(frame["id"], (str, int)))
                        or isinstance(frame.get("id"), bool)
                        or (isinstance(frame.get("id"), str) and not frame["id"])
                    ):
                        failure = JsonRpcProtocolError(-32600, "Invalid JSON-RPC request")
                        break
                    await self._incoming.put(frame)
                elif "id" in frame:
                    if ("result" in frame) == ("error" in frame):
                        failure = JsonRpcProtocolError(-32600, "Invalid JSON-RPC response")
                        break
                    try:
                        self._dispatch_response(frame)
                    except (TypeError, ValueError) as exc:
                        failure = JsonRpcProtocolError(
                            -32600,
                            "Invalid JSON-RPC response",
                            str(exc),
                        )
                        break
                else:
                    failure = JsonRpcProtocolError(-32600, "Invalid JSON-RPC frame")
                    break
        except asyncio.CancelledError:
            raise
        except (ConnectionError, OSError) as exc:
            failure = JsonRpcProtocolError(-32000, "JSON-RPC connection failed", str(exc))
        finally:
            if not self._closed:
                self._closed = True
                self._closed_event.set()
                if not self._writer.is_closing():
                    self._writer.close()
                for future in self._pending.values():
                    if not future.done():
                        future.set_exception(failure)
            if (
                self._dispatch_task is not None
                and self._dispatch_task is not asyncio.current_task()
                and not self._dispatch_task.done()
            ):
                self._dispatch_task.cancel()

    async def _dispatch_loop(self) -> None:
        # A notification/request handler may close its own peer. Closing the
        # reader can cancel this task while close() is awaiting that reader;
        # do not then wait on an inbox which can never receive another frame.
        while not self._closed:
            frame = await self._incoming.get()
            try:
                await self._dispatch_incoming(frame)
            except asyncio.CancelledError:
                task = asyncio.current_task()
                if task is not None and task.cancelling():
                    raise
                # A handler raised CancelledError itself.  Treat it like any
                # other handler failure; otherwise the dispatcher exits while
                # the connection and caller remain open forever.
                if frame.get("id") is not None:
                    await self.close()
                    return
                continue
            except Exception:
                # Request errors are converted to JSON-RPC responses inside
                # _dispatch_incoming.  An exception escaping a request means its
                # response could not be delivered; close the peer so the caller
                # observes a transport failure instead of waiting forever.
                if frame.get("id") is not None:
                    await self.close()
                    return
                # Notification handlers are isolated so a bad optional observer
                # cannot stop later ordered messages.
                continue
            finally:
                self._incoming.task_done()

    async def _dispatch_incoming(self, frame: JsonObject) -> None:
        method = frame.get("method")
        if not isinstance(method, str):
            return
        request_id = frame.get("id")
        if request_id is None:
            handler = self._notification_handlers.get(method)
            if handler is not None:
                await handler(frame.get("params"))
            return
        handler = self._request_handlers.get(method)
        if handler is None:
            await self._send_error(request_id, -32601, f"Method not found: {method}")
            return
        try:
            result = await handler(frame.get("params"))
        except JsonRpcProtocolError as exc:
            await self._send_error(request_id, exc.code, str(exc), exc.data)
        except asyncio.CancelledError:
            task = asyncio.current_task()
            if task is not None and task.cancelling():
                raise
            await self._send_error(request_id, -32603, "Request handler was cancelled")
        except Exception as exc:
            await self._send_error(
                request_id,
                -32603,
                "Internal error",
                {"errorType": type(exc).__name__},
            )
        else:
            await self._send({"jsonrpc": "2.0", "id": request_id, "result": result})

    def _dispatch_response(self, frame: JsonObject) -> None:
        raw_request_id = frame.get("id")
        if not isinstance(raw_request_id, str) or not raw_request_id:
            raise ValueError("JSON-RPC response id must be a non-empty string")
        request_id = raw_request_id
        future = self._pending.get(request_id)
        if future is None:
            if self._pending:
                raise ValueError("JSON-RPC response id does not match a pending request")
            return
        if future.done():
            return
        if "error" in frame:
            error = frame.get("error")
            if isinstance(error, dict):
                code = error.get("code", -32603)
                if isinstance(code, bool) or not isinstance(code, int):
                    raise ValueError("JSON-RPC error code must be an integer")
                message = error.get("message", "JSON-RPC error")
                if not isinstance(message, str):
                    raise ValueError("JSON-RPC error message must be a string")
                future.set_exception(
                    JsonRpcProtocolError(
                        code,
                        message,
                        error.get("data"),
                    )
                )
            else:
                future.set_exception(JsonRpcProtocolError(-32603, "Malformed JSON-RPC error"))
            return
        future.set_result(frame.get("result"))

    async def _send_error(self, request_id: Any, code: int, message: str, data: Any = None) -> None:
        error: JsonObject = {"code": code, "message": message}
        if data is not None:
            error["data"] = data
        await self._send({"jsonrpc": "2.0", "id": request_id, "error": error})

    @staticmethod
    def _validate_method(method: str) -> None:
        if (
            not isinstance(method, str)
            or not method.strip()
            or method != method.strip()
        ):
            raise ValueError("JSON-RPC method must be a non-empty trimmed string")

    @classmethod
    def _validate_handler(cls, method: str, handler: object) -> None:
        cls._validate_method(method)
        if not callable(handler):
            raise TypeError("JSON-RPC handler must be callable")


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON number is not allowed: {value}")


def _unique_json_object(pairs: list[tuple[str, Any]]) -> JsonObject:
    result: JsonObject = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result
