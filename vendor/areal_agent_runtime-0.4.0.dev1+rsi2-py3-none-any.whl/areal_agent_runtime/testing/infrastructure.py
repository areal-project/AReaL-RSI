"""Bounded, black-box probes for third-party infrastructure Ports.

Factories return async context managers: the integrator owns setup and cleanup.
Use disposable storage. Reopen must construct a NEW provider on the SAME backend.
These probes are evidence about exercised behavior, not a production certification.
``timeout_seconds`` bounds the operation. Every factory exit, Environment.close
and stream close also gets a fresh ``cleanup_timeout_seconds`` window (default 1s),
including after the operation times out. Total elapsed time can include these
cleanup windows. Operation and cleanup errors are preserved together in a group.
"""

from __future__ import annotations

import asyncio
import hashlib
import math
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TypeVar
from uuid import uuid4

from pydantic import JsonValue

from areal_agent_runtime.contracts import (
    AgentEnvironmentSnapshot,
    EventType,
    PromptResolutionMode,
    RunEvent,
    RunSnapshot,
    RunStatus,
    WorkspaceRef,
)
from areal_agent_runtime.contracts.ports import EnvironmentRef, EnvironmentSpec, WorkspaceCheckpoint
from areal_agent_runtime.plugin_sdk import AssetStorePort, EnvironmentPort, EventSinkPort, StateStorePort

StateFactory = Callable[[], AbstractAsyncContextManager[StateStorePort]]
AssetFactory = Callable[[], AbstractAsyncContextManager[AssetStorePort]]
SinkFactory = Callable[[], AbstractAsyncContextManager[EventSinkPort]]
EnvironmentFactory = Callable[[], AbstractAsyncContextManager[EnvironmentPort]]
SinkInspector = Callable[[EventSinkPort, str], Awaitable[tuple[str, ...]]]
EnvironmentProbe = Callable[[EnvironmentPort, EnvironmentRef], Awaitable[None]]
ProviderT = TypeVar("ProviderT")


class InfrastructureConformanceError(AssertionError):
    """An exercised Port behavior contradicted its integration contract."""


@dataclass(frozen=True, slots=True)
class InfrastructureConformanceReport:
    port: str
    verified: tuple[str, ...]
    unverified: tuple[str, ...]


def _check(condition: bool, message: str) -> None:
    if not condition:
        raise InfrastructureConformanceError(message)


def _validate_timeout(seconds: float, name: str) -> None:
    if isinstance(seconds, bool) or not math.isfinite(seconds) or seconds <= 0:
        raise ValueError(f"{name} must be finite and positive")


@asynccontextmanager
async def _timeout(seconds: float, cleanup_seconds: float) -> AsyncIterator[None]:
    _validate_timeout(seconds, "timeout_seconds")
    _validate_timeout(cleanup_seconds, "cleanup_timeout_seconds")
    deadline = asyncio.timeout(seconds)
    try:
        async with deadline:
            yield
    except BaseExceptionGroup as exc:
        # asyncio.timeout converts only a direct CancelledError on Python 3.11/3.12.
        # Cleanup failures may group that cancellation with a second error. Preserve
        # both failures and identify the expired operation deadline explicitly.
        cancelled, other = exc.split(asyncio.CancelledError)
        if deadline.expired() and cancelled is not None:
            errors: list[BaseException] = [TimeoutError(f"operation exceeded timeout_seconds={seconds}")]
            if other is not None:
                errors.append(other)
            raise BaseExceptionGroup("Infrastructure operation and cleanup failed", errors) from None
        raise


@asynccontextmanager
async def _cleanup_scope(
    cleanup: Callable[[BaseException | None], Awaitable[object]],
    *,
    label: str,
    timeout_seconds: float,
) -> AsyncIterator[None]:
    operation_error: BaseException | None = None
    try:
        yield
    except BaseException as exc:
        operation_error = exc
    try:
        # A fresh deadline is essential after the operation's timeout has already
        # cancelled its task: an enclosing timeout will not cancel this await again.
        async with asyncio.timeout(timeout_seconds):
            await cleanup(operation_error)
    except BaseException as exc:
        if isinstance(exc, TimeoutError):
            exc = TimeoutError(f"{label} exceeded cleanup_timeout_seconds={timeout_seconds}")
        if operation_error is not None:
            raise BaseExceptionGroup(f"Operation and {label} failed", [operation_error, exc]) from None
        raise exc
    if operation_error is not None:
        raise operation_error.with_traceback(operation_error.__traceback__)


@asynccontextmanager
async def _provider(
    factory: Callable[[], AbstractAsyncContextManager[ProviderT]], cleanup_seconds: float,
) -> AsyncIterator[ProviderT]:
    context = factory()
    provider = await context.__aenter__()

    async def leave(error: BaseException | None) -> object:
        return await context.__aexit__(
            type(error) if error is not None else None, error,
            error.__traceback__ if error is not None else None,
        )

    async with _cleanup_scope(leave, label="factory.__aexit__", timeout_seconds=cleanup_seconds):
        # Context managers must not suppress a conformance error or cancellation.
        yield provider


async def _close_stream(stream: object) -> None:
    close = getattr(stream, "aclose", None)
    if callable(close):
        await close()


async def _reject(operation: Callable[[], Awaitable[object]], message: str, *, text: str = "") -> None:
    try:
        await operation()
    except ValueError as exc:
        _check(text in str(exc), f"{message}: expected ValueError containing {text!r}, got {exc!r}")
    else:
        raise InfrastructureConformanceError(message)


def _events(run_id: str, session_id: str) -> tuple[RunEvent, RunEvent]:
    events = [
        RunEvent(
            event_id=f"event_{uuid4().hex}", sequence=sequence, time=datetime.now(UTC),
            run_id=run_id, session_id=session_id, correlation_id=run_id, type=event_type, data={},
        )
        for sequence, event_type in enumerate((EventType.RUNTIME_STATUS, EventType.RUN_COMPLETED))
    ]
    return events[0], events[1]


async def _read_asset(store: AssetStorePort, asset_id: str, expected: bytes, cleanup_seconds: float) -> None:
    chunks: list[bytes] = []
    size = 0
    stream = store.open(asset_id)
    async with _cleanup_scope(
        lambda _: _close_stream(stream), label="asset stream.aclose", timeout_seconds=cleanup_seconds,
    ):
        async for chunk in stream:
            _check(isinstance(chunk, bytes), "open yielded a non-bytes chunk")
            size += len(chunk)
            _check(size <= len(expected) and len(chunks) < 256, "open exceeded the expected size/chunk bound")
            chunks.append(chunk)
        _check(b"".join(chunks) == expected, "open corrupted or lost bytes")


async def verify_state_store(
    factory: StateFactory,
    *,
    reopen: StateFactory | None = None,
    timeout_seconds: float = 10,
    cleanup_timeout_seconds: float = 1,
) -> InfrastructureConformanceReport:
    """Check history, projections, sink-specific outbox and lease ownership.

``reopen`` adds reconstruction of committed data and acknowledgement plus a
simultaneous second client lease race. It does not simulate process crashes or
distributed fencing; supply backend-specific tests for those claims. Factory and
stream cleanup have independent ``cleanup_timeout_seconds`` deadlines.
"""
    run_id, session_id = f"run_{uuid4().hex}", f"session_{uuid4().hex}"
    initial = RunSnapshot(run_id=run_id, session_id=session_id, profile="general.default",
                          status=RunStatus.RUNNING, last_sequence=-1)
    first, terminal = _events(run_id, session_id)
    running = initial.model_copy(update={"last_sequence": 0})
    completed = initial.model_copy(update={"last_sequence": 1, "status": RunStatus.COMPLETED})
    environment = AgentEnvironmentSnapshot.empty()
    async with _timeout(timeout_seconds, cleanup_timeout_seconds):
        async with _provider(factory, cleanup_timeout_seconds) as store:
            _check(await store.get_run(run_id) is None, "fresh run unexpectedly exists")
            await store.create_run(initial)
            await _reject(lambda: store.create_run(initial), "create_run accepted a duplicate run")
            _check(await store.get_run(run_id) == initial, "create_run lost the snapshot")
            _check(await store.latest_event_sequence(run_id) == -1, "new history must start at -1")
            await store.save_run(initial)
            await _reject(lambda: store.save_run(completed), "save_run changed history without a canonical event")
            await store.save_environment_snapshot(session_id, environment)
            _check(await store.get_environment_snapshot(session_id) == environment, "Session environment was lost")
            changed_environment = AgentEnvironmentSnapshot.create(
                spec_digest="a" * 64, prompt_resolution=PromptResolutionMode.FALLBACK,
            )
            await _reject(lambda: store.save_environment_snapshot(session_id, changed_environment),
                          "Session accepted a conflicting environment snapshot")

            await store.commit_event(first, running, outbox_sinks=("alpha", "beta"))
            _check(await store.get_run(run_id) == running, "commit_event lost the snapshot transition")
            await _reject(
                lambda: store.commit_event(first, running, outbox_sinks=("alpha",)),
                "commit_event accepted stale sequence", text="non-contiguous event sequence",
            )
            invalid = terminal.model_copy(update={"session_id": "wrong-session"})
            await _reject(lambda: store.commit_event(invalid, completed, outbox_sinks=("alpha",)),
                          "commit_event accepted mismatched Session identity")
            await _reject(lambda: store.commit_event(
                terminal, running.model_copy(update={"last_sequence": 1}), outbox_sinks=("alpha",)),
                "commit_event accepted a terminal event without the terminal snapshot transition")
            _check(await store.list_events(run_id) == (first,), "rejected commit changed canonical history")
            _check(await store.get_run(run_id) == running, "rejected commit changed snapshot")
            _check(await store.pending_event_deliveries(run_id, "alpha") == (first,),
                   "rejected commit changed outbox")
            await store.commit_event(terminal, completed, outbox_sinks=("alpha", "beta"))
            _check(await store.latest_event_sequence(run_id) == 1, "latest sequence disagrees with history")
            _check(await store.list_events(run_id) == (first, terminal), "canonical history was lost or reordered")
            _check(run_id in await store.list_run_ids(), "list_run_ids omitted committed run")
            stream = store.stream_events(run_id, after=0)
            async with _cleanup_scope(
                lambda _: _close_stream(stream), label="event stream.aclose", timeout_seconds=cleanup_timeout_seconds,
            ):
                streamed = []
                async for event in stream:
                    streamed.append(event)
                    _check(len(streamed) <= 1, "exclusive stream cursor repeated or leaked events")
                _check(tuple(streamed) == (terminal,), "stream cursor must be exclusive")
            _check(await store.pending_event_deliveries(run_id, "alpha", limit=1) == (first,),
                   "outbox limit/order was ignored")
            _check(await store.pending_event_deliveries(run_id, "unbound") == (), "outbox leaked to another sink")
            await store.acknowledge_event_delivery(run_id, "alpha", through_sequence=0)
            await store.acknowledge_event_delivery(run_id, "alpha", through_sequence=0)
            _check(await store.pending_event_deliveries(run_id, "alpha") == (terminal,), "ack did not advance")
            _check(await store.pending_event_deliveries(run_id, "beta") == (first, terminal),
                   "one sink's acknowledgement erased another sink's delivery")
            await _reject(lambda: store.acknowledge_event_delivery(run_id, "alpha", through_sequence=99),
                          "outbox accepted acknowledgement of nonexistent event")
            # Execution ownership concerns live Runs; terminal Runs are not executable.
            lease_run = run_id + "_lease"
            await store.create_run(initial.model_copy(update={"run_id": lease_run}))
            _check(await store.try_acquire_run(lease_run, "owner-a", ttl_seconds=60), "lease acquisition failed")
            _check(not await store.try_acquire_run(lease_run, "owner-b", ttl_seconds=60), "two owners acquired the run")
            _check(not await store.renew_run(lease_run, "owner-b", ttl_seconds=60), "wrong owner renewed the lease")
            await store.release_run(lease_run, "owner-b")
            _check(await store.renew_run(lease_run, "owner-a", ttl_seconds=60), "wrong owner released the lease")
            await store.release_run(lease_run, "owner-a")
            if reopen is not None:
                async with _provider(reopen, cleanup_timeout_seconds) as other:
                    claimed = await asyncio.gather(
                        store.try_acquire_run(lease_run, "owner-a", ttl_seconds=60),
                        other.try_acquire_run(lease_run, "owner-b", ttl_seconds=60),
                    )
                    _check(sum(claimed) == 1, "independent clients acquired the same lease")
                    await store.release_run(lease_run, "owner-a")
                    await other.release_run(lease_run, "owner-b")
        if reopen is not None:
            async with _provider(reopen, cleanup_timeout_seconds) as store:
                _check(await store.get_run(run_id) == completed, "reopen lost the committed snapshot")
                _check(await store.list_events(run_id) == (first, terminal), "reopen lost canonical history")
                _check(await store.get_environment_snapshot(session_id) == environment, "reopen lost Session input")
                _check(await store.pending_event_deliveries(run_id, "alpha") == (terminal,), "reopen lost durable ack")
                _check(await store.pending_event_deliveries(run_id, "beta") == (first, terminal), "reopen lost outbox")
    return InfrastructureConformanceReport(
        "StateStore", ("history/snapshot/outbox", "sequence-conflict", "exclusive-cursor", "lease-ownership")
        + (("reconstruction", "two-client-lease-race") if reopen else ()),
        ("crash-atomicity", "lease-expiry/fencing", "multi-process/distributed-concurrency")
        + (() if reopen else ("reconstruction", "two-client-lease-race")),
    )


async def _chunks() -> AsyncIterator[bytes]:
    yield b"asset "
    yield b"conformance"


async def verify_asset_store(
    factory: AssetFactory, *, reopen: AssetFactory | None = None, timeout_seconds: float = 10,
    cleanup_timeout_seconds: float = 1,
) -> InfrastructureConformanceReport:
    """Check immutable descriptor identity, byte integrity and optional reopen.

    Factory and stream cleanup each have a separate cleanup_timeout_seconds limit.
    """
    payload = b"asset conformance"
    metadata: dict[str, JsonValue] = {"probe": uuid4().hex}
    async with _timeout(timeout_seconds, cleanup_timeout_seconds):
        async with _provider(factory, cleanup_timeout_seconds) as store:
            ref = await store.put(_chunks(), media_type="text/plain", metadata=metadata)
            retry = await store.put(_chunks(), media_type="text/plain", metadata=metadata)
            _check(retry == ref, "identical bytes/type/metadata did not return the same immutable AssetRef")
            _check(ref.media_type == "text/plain" and ref.metadata == metadata, "put lost descriptor fields")
            _check(ref.size == len(payload) and ref.sha256 == hashlib.sha256(payload).hexdigest(),
                   "AssetRef size/digest does not match bytes")
            changed = await store.put(_chunks(), media_type="application/octet-stream", metadata=metadata)
            _check(changed.asset_id != ref.asset_id, "a new media type overwrote an immutable descriptor")
            changed_metadata = await store.put(_chunks(), media_type="text/plain", metadata={**metadata, "other": True})
            _check(changed_metadata.asset_id != ref.asset_id, "new metadata overwrote an immutable descriptor")
            _check(await store.get(ref.asset_id) == ref, "get did not preserve the original descriptor")
            await _read_asset(store, ref.asset_id, payload, cleanup_timeout_seconds)
            _check(await store.get(f"missing_{uuid4().hex}") is None, "get must return None for unknown asset")
            _check(bool(await store.resolve(ref.asset_id, ttl_seconds=30)), "resolve returned an empty locator")
        if reopen is not None:
            async with _provider(reopen, cleanup_timeout_seconds) as store:
                _check(await store.get(ref.asset_id) == ref, "reopen lost descriptor")
                await _read_asset(store, ref.asset_id, payload, cleanup_timeout_seconds)
                _check(await store.put(_chunks(), media_type="text/plain", metadata=metadata) == ref,
                       "retry after reopen changed asset identity")
    return InfrastructureConformanceReport(
        "AssetStore", ("descriptor-idempotency", "immutable-metadata", "byte-integrity")
        + (("reconstruction",) if reopen else ()),
        ("access-control/expiry", "size-limit/corruption/failure-injection", "multi-process-concurrency")
        + (() if reopen else ("reconstruction",)),
    )


async def verify_event_sink(
    factory: SinkFactory, *, inspect: SinkInspector | None = None,
    reopen: SinkFactory | None = None, timeout_seconds: float = 10,
    cleanup_timeout_seconds: float = 1,
) -> InfrastructureConformanceReport:
    """Replay canonical events. ``inspect`` returns persisted event IDs in order.

Without a backend read probe, only lifecycle acceptance is verified; a sink that
silently drops all events cannot be distinguished from a functioning sink.
Factory cleanup has an independent ``cleanup_timeout_seconds`` deadline.
"""
    run_id = f"run_{uuid4().hex}"
    events = _events(run_id, f"session_{uuid4().hex}")
    expected = tuple(event.event_id for event in events)
    async with _timeout(timeout_seconds, cleanup_timeout_seconds):
        async with _provider(factory, cleanup_timeout_seconds) as sink:
            _check((await sink.health()).status != "unhealthy", "sink is unhealthy")
            for event in (*events, *events):
                await sink.consume(event)
            await sink.flush(run_id)
            if inspect is not None:
                _check(await inspect(sink, run_id) == expected, "sink lost, duplicated or reordered delivered events")
        if reopen is not None:
            async with _provider(reopen, cleanup_timeout_seconds) as sink:
                if inspect is not None:
                    _check(await inspect(sink, run_id) == expected, "sink reopen lost previously flushed events")
                for event in events:
                    await sink.consume(event)
                await sink.flush(run_id)
                if inspect is not None:
                    _check(await inspect(sink, run_id) == expected, "sink replay after reopen lost deduplication")
    return InfrastructureConformanceReport(
        "EventSink", ("consume/flush/health",) + (("persisted-replay-deduplication",) if inspect else ())
        + (("reconstruction",) if inspect and reopen else ()),
        ("outage-retry", "governance/redaction", "multi-process-concurrency")
        + (() if inspect else ("persistence/deduplication",))
        + (() if inspect and reopen else ("reconstruction",)),
    )


async def verify_environment(
    factory: EnvironmentFactory, *, spec: EnvironmentSpec | None = None,
    probe: EnvironmentProbe | None = None, timeout_seconds: float = 10,
    cleanup_timeout_seconds: float = 1,
) -> InfrastructureConformanceReport:
    """Check base EnvironmentPort lifecycle. An optional probe owns its assertions.

The base Port has no restore/overlay API. Test those optional capabilities using
adapter-specific probes and interrupted Application workflows before advertising
them; this report never infers support merely from a method's presence.
Environment.close and factory cleanup each get a fresh cleanup_timeout_seconds
deadline, even when the operation has already timed out.
"""
    spec = spec or EnvironmentSpec(workspace=WorkspaceRef(workspace_id=f"workspace_{uuid4().hex}"))
    async with _timeout(timeout_seconds, cleanup_timeout_seconds):
        async with _provider(factory, cleanup_timeout_seconds) as environment:
            _check((await environment.health()).status != "unhealthy", "environment is unhealthy")
            ref = await environment.open(spec)
            async with _cleanup_scope(
                lambda _: environment.close(ref), label="Environment.close", timeout_seconds=cleanup_timeout_seconds,
            ):
                _check(isinstance(ref, EnvironmentRef), "open must return EnvironmentRef")
                _check(ref.workspace.workspace_id == spec.workspace.workspace_id, "open changed workspace identity")
                checkpoint = await environment.checkpoint(ref)
                _check(isinstance(checkpoint, WorkspaceCheckpoint), "checkpoint must return WorkspaceCheckpoint")
                _check(checkpoint.workspace_id == ref.workspace.workspace_id, "checkpoint escaped workspace")
                if probe is not None:
                    await probe(environment, ref)
            again = await environment.open(spec)
            async with _cleanup_scope(
                lambda _: environment.close(again), label="Environment.close", timeout_seconds=cleanup_timeout_seconds,
            ):
                pass
    return InfrastructureConformanceReport(
        "Environment", ("open/checkpoint/close/reopen",) + (("caller-probe",) if probe else ()),
        ("checkpoint-content/restore", "overlay-isolation/merge", "crash-recovery", "cross-process-locking"),
    )
