"""ARealAgentRuntime Plugin SPI packaging for the DSH Runtime Adapter."""

from __future__ import annotations

import math
import os
from typing import Literal, cast

from pydantic import JsonValue

from areal_agent_runtime.adapters._asset_io import DEFAULT_MAX_RUNTIME_ASSET_BYTES
from areal_agent_runtime.adapters.dsh.runtime import DSHRuntimeAdapter, DSHRuntimeConfig
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus, Modality
from areal_agent_runtime.plugin_sdk.contracts import (
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)


class DSHRuntimePlugin:
    manifest = PluginManifest(
        name="dsh-runtime",
        version="1.0.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.dsh.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("process.spawn", "workspace.read", "workspace.write", "network.model"),
    )

    def __init__(self) -> None:
        self.runtime: DSHRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        runtime_config = DSHRuntimeConfig(
            provider=_string(config.get("provider"), field_name="provider") or "deepseek-official",
            model=(
                _environment_string("AREAL_AGENT_RUNTIME_MODEL")
                or _string(config.get("model"), field_name="model")
                or "deepseek-v4-flash"
            ),
            reasoning_effort=_string(config.get("reasoningEffort"), field_name="reasoningEffort"),
            max_tokens=_optional_positive_integer(config.get("maxTokens"), field_name="maxTokens"),
            runtime_cwd=_string(config.get("runtimeCwd"), field_name="runtimeCwd"),
            dsh_bin=_string(config.get("dshBin"), field_name="dshBin"),
            profile=_string(config.get("profile"), field_name="profile") or "sdk",
            patches=_patches(config.get("patches")),
            dsh_home=_string(config.get("dshHome"), field_name="dshHome"),
            env=_string_map(config.get("env")),
            base_url=(
                _environment_string("AREAL_AGENT_RUNTIME_UPSTREAM_BASE_URL")
                or _string(config.get("baseUrl"), field_name="baseUrl")
            ),
            api_key=(
                _environment_string("AREAL_AGENT_RUNTIME_UPSTREAM_API_KEY")
                or _string(config.get("apiKey"), field_name="apiKey")
            ),
            input_modalities=_modalities(config.get("inputModalities")),
            max_concurrency=_positive_integer(
                config.get("maxConcurrency"),
                default=8,
                field_name="maxConcurrency",
            ),
            application_tool_bridge=_boolean(config.get("applicationToolBridge"), default=False),
            application_tool_bridge_transport=_bridge_transport(config.get("applicationToolBridgeTransport")),
            tool_bridge_ready_timeout_seconds=_positive_float(
                config.get("toolBridgeReadyTimeoutSeconds"),
                default=10.0,
                field_name="toolBridgeReadyTimeoutSeconds",
            ),
            tool_bridge_call_timeout_seconds=_positive_float(
                config.get("toolBridgeCallTimeoutSeconds"),
                default=120.0,
                field_name="toolBridgeCallTimeoutSeconds",
            ),
            tool_bridge_max_concurrency=_positive_integer(
                config.get("toolBridgeMaxConcurrency"),
                default=16,
                field_name="toolBridgeMaxConcurrency",
            ),
            max_input_asset_bytes=_positive_integer(
                config.get("maxInputAssetBytes"),
                default=DEFAULT_MAX_RUNTIME_ASSET_BYTES,
                field_name="maxInputAssetBytes",
            ),
        )
        self.runtime = DSHRuntimeAdapter(
            asset_store=_optional_asset_store(context),
            config=runtime_config,
        )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("DSH plugin is not configured")
        health = await self.runtime.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "DSH runtime unavailable"))

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> DSHRuntimePlugin:
    return DSHRuntimePlugin()


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _string(value: JsonValue | None, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"{field_name} must be a non-blank, trimmed string")
    return value


def _environment_string(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    if not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"environment variable {name} must be a non-blank, trimmed string")
    return value


def _optional_positive_integer(value: JsonValue | None, *, field_name: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _boolean(value: JsonValue | None, *, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise ValueError("applicationToolBridge must be a boolean")
    return value


def _positive_float(
    value: JsonValue | None,
    *,
    default: float,
    field_name: str,
) -> float:
    if value is None:
        return default
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise ValueError(f"{field_name} must be a finite positive number")
    return float(value)


def _positive_integer(value: JsonValue | None, *, default: int, field_name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _bridge_transport(value: JsonValue | None) -> Literal["mcp", "legacy-http"]:
    if value is None:
        return "mcp"
    if value not in {"mcp", "legacy-http"}:
        raise ValueError("applicationToolBridgeTransport must be 'mcp' or 'legacy-http'")
    return value


def _string_map(value: JsonValue | None) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("env must be an object containing string values")
    result: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or not isinstance(item, str):
            raise ValueError("env must be an object containing string values")
        result[key] = item
    return result


def _patches(value: JsonValue | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ValueError("patches must be a list of unique strings")
    result: list[str] = []
    for item in value:
        if not isinstance(item, str) or not item or item != item.strip() or "\x00" in item:
            raise ValueError("patches must contain non-blank, trimmed strings")
        result.append(item)
    if len(result) != len(set(result)):
        raise ValueError("patches must not contain duplicates")
    return tuple(result)


def _modalities(value: JsonValue | None) -> tuple[Modality, ...]:
    if value is None:
        return (Modality.TEXT,)
    if not isinstance(value, list) or not value:
        raise ValueError("inputModalities must be a non-empty list")
    if any(not isinstance(item, str) for item in value):
        raise ValueError("DSH inputModalities only supports canonical modality names")
    try:
        modalities = tuple(Modality(item) for item in value)
    except ValueError as exc:
        raise ValueError("DSH inputModalities only supports canonical modality names") from exc
    if len(modalities) != len(set(modalities)):
        raise ValueError("DSH inputModalities must not contain duplicates")
    unsupported = set(modalities).difference({Modality.TEXT, Modality.IMAGE})
    if Modality.TEXT not in modalities or unsupported:
        raise ValueError("DSH inputModalities must include text and currently only supports text/image")
    return modalities
