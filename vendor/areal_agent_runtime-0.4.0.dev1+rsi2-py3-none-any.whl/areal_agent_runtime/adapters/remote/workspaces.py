"""Snapshot-based workspace data plane for cross-container Runtime Wire sessions."""

from __future__ import annotations

import asyncio
import contextlib
import errno
import gzip
import hashlib
import os
import shutil
import stat
import tarfile
import tempfile
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import BinaryIO

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import RuntimeSessionSpec
from areal_agent_runtime.contracts.wire import WorkspaceSnapshot

_DEFAULT_MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
_DIRECTORY_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
_FILE_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)


@dataclass(slots=True)
class ClientWorkspaceState:
    root: Path
    synchronized_paths: frozenset[PurePosixPath]
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


@dataclass(slots=True)
class ServerWorkspaceState:
    root: Path
    synchronized_paths: frozenset[PurePosixPath]
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    discarded: bool = False


class RuntimeWireWorkspaceClient:
    """Create the initial snapshot and reconcile the final snapshot on the Host."""

    def __init__(
        self,
        store: AssetStorePort,
        *,
        max_files: int = 50_000,
        max_unpacked_bytes: int = 512 * 1024 * 1024,
        max_archive_bytes: int = _DEFAULT_MAX_ARCHIVE_BYTES,
    ) -> None:
        _validate_workspace_limits(max_files, max_unpacked_bytes, max_archive_bytes)
        self._store = store
        self._max_files = max_files
        self._max_unpacked_bytes = max_unpacked_bytes
        self._max_archive_bytes = max_archive_bytes

    async def export(
        self,
        spec: RuntimeSessionSpec,
    ) -> tuple[RuntimeSessionSpec, WorkspaceSnapshot, ClientWorkspaceState]:
        mount_hint = spec.workspace.mount_hint
        if not mount_hint:
            raise ValueError("Workspace snapshot transfer requires workspace.mountHint")
        root, is_valid = await run_blocking_io(_resolved_directory, mount_hint)
        if not is_valid:
            raise ValueError(f"Workspace mount is not a real directory: {root}")
        archive, paths = await _archive_async(
            root,
            self._max_files,
            self._max_unpacked_bytes,
            self._max_archive_bytes,
        )
        try:
            ref = await self._store.put(
                _file_chunks(archive),
                media_type="application/vnd.areal-agent-runtime.workspace+tar+gzip",
                metadata={
                    "kind": "runtime-wire-workspace",
                    "direction": "host-to-runtime",
                    "workspaceId": spec.workspace.workspace_id,
                },
            )
        finally:
            await run_blocking_io(archive.unlink, missing_ok=True)
        remote_spec = spec.model_copy(update={"workspace": spec.workspace.model_copy(update={"mount_hint": None})})
        return (
            remote_spec,
            WorkspaceSnapshot(asset_id=ref.asset_id),
            ClientWorkspaceState(root=root, synchronized_paths=frozenset(paths)),
        )

    async def export_update(
        self,
        state: ClientWorkspaceState,
        *,
        workspace_id: str,
    ) -> WorkspaceSnapshot:
        """Publish Host-side tool mutations before returning a ToolResult."""

        async with state.lock:
            archive, paths = await _archive_async(
                state.root,
                self._max_files,
                self._max_unpacked_bytes,
                self._max_archive_bytes,
            )
            try:
                ref = await self._store.put(
                    _file_chunks(archive),
                    media_type="application/vnd.areal-agent-runtime.workspace+tar+gzip",
                    metadata={
                        "kind": "runtime-wire-workspace",
                        "direction": "host-to-runtime-tool-result",
                        "workspaceId": workspace_id,
                    },
                )
            finally:
                await run_blocking_io(archive.unlink, missing_ok=True)
            state.synchronized_paths = frozenset(paths)
            return WorkspaceSnapshot(asset_id=ref.asset_id)

    async def import_snapshot(
        self,
        state: ClientWorkspaceState,
        asset_id: str,
    ) -> None:
        """Make Runtime-side mutations visible before an Application tool runs."""

        async with state.lock:
            archive: Path | None = None
            staging: Path | None = None
            try:
                archive = await _asset_to_temp(
                    self._store,
                    asset_id,
                    max_bytes=self._max_archive_bytes,
                )
                staging = Path(tempfile.mkdtemp(prefix=".areal-agent-runtime-wire-sync-", dir=state.root.parent))
                await run_blocking_io(
                    _extract,
                    archive,
                    staging,
                    self._max_files,
                    self._max_unpacked_bytes,
                )
                await run_blocking_io(
                    _reconcile_state, state, staging, self._max_files, self._max_unpacked_bytes,
                )
            finally:
                # One cancellation barrier owns both cleanup operations: a
                # cancellation during unlink must not skip staging disposal.
                await run_blocking_io(_cleanup_transfer, archive, staging)

    async def import_final(
        self,
        state: ClientWorkspaceState,
        asset_id: str,
    ) -> None:
        await self.import_snapshot(state, asset_id)


class RuntimeWireWorkspaceServer:
    """Materialize an isolated runtime workspace and publish its final snapshot."""

    def __init__(
        self,
        store: AssetStorePort,
        root: str | Path,
        *,
        max_files: int = 50_000,
        max_unpacked_bytes: int = 512 * 1024 * 1024,
        max_archive_bytes: int = _DEFAULT_MAX_ARCHIVE_BYTES,
    ) -> None:
        _validate_workspace_limits(max_files, max_unpacked_bytes, max_archive_bytes)
        self._store = store
        self._root = Path(root).expanduser().resolve()
        self._max_files = max_files
        self._max_unpacked_bytes = max_unpacked_bytes
        self._max_archive_bytes = max_archive_bytes
        self._root.mkdir(parents=True, exist_ok=True)

    async def import_initial(
        self,
        spec: RuntimeSessionSpec,
        asset_id: str,
    ) -> tuple[RuntimeSessionSpec, ServerWorkspaceState]:
        identity = hashlib.sha256(spec.session_id.encode("utf-8")).hexdigest()
        workspace = Path(
            tempfile.mkdtemp(
                prefix=f"{identity[:16]}-",
                dir=self._root,
            )
        )
        archive: Path | None = None
        try:
            try:
                archive = await _asset_to_temp(
                    self._store,
                    asset_id,
                    max_bytes=self._max_archive_bytes,
                )
                paths = await run_blocking_io(
                    _extract,
                    archive,
                    workspace,
                    self._max_files,
                    self._max_unpacked_bytes,
                )
            finally:
                await run_blocking_io(_cleanup_transfer, archive, None)
            runtime_spec = spec.model_copy(
                update={"workspace": spec.workspace.model_copy(update={"mount_hint": str(workspace)})}
            )
            return runtime_spec, ServerWorkspaceState(
                root=workspace,
                synchronized_paths=frozenset(paths),
            )
        except BaseException:
            # This includes cancellation during successful-import cleanup:
            # without a returned state no caller can own the new workspace.
            await run_blocking_io(shutil.rmtree, workspace, ignore_errors=True)
            raise

    async def export_current(
        self,
        state: ServerWorkspaceState,
        *,
        workspace_id: str,
    ) -> WorkspaceSnapshot:
        """Publish a non-destructive snapshot before an external tool call."""

        async with state.lock:
            self._require_active(state)
            snapshot, paths = await self._store_snapshot(
                state.root,
                workspace_id=workspace_id,
                direction="runtime-to-host-tool-request",
            )
            state.synchronized_paths = frozenset(paths)
            return snapshot

    async def import_update(
        self,
        state: ServerWorkspaceState,
        asset_id: str,
    ) -> None:
        """Apply Host-side tool mutations before resuming the Runtime loop."""

        async with state.lock:
            self._require_active(state)
            archive: Path | None = None
            staging: Path | None = None
            try:
                archive = await _asset_to_temp(
                    self._store,
                    asset_id,
                    max_bytes=self._max_archive_bytes,
                )
                staging = Path(tempfile.mkdtemp(prefix=".areal-agent-runtime-wire-tool-", dir=state.root.parent))
                await run_blocking_io(
                    _extract,
                    archive,
                    staging,
                    self._max_files,
                    self._max_unpacked_bytes,
                )
                await run_blocking_io(
                    _reconcile_state, state, staging, self._max_files, self._max_unpacked_bytes,
                )
            finally:
                # One cancellation barrier owns both cleanup operations: a
                # cancellation during unlink must not skip staging disposal.
                await run_blocking_io(_cleanup_transfer, archive, staging)

    async def export_final(
        self,
        state: ServerWorkspaceState,
        *,
        workspace_id: str,
    ) -> WorkspaceSnapshot:
        async with state.lock:
            self._require_active(state)
            snapshot, _paths = await self._store_snapshot(
                state.root,
                workspace_id=workspace_id,
                direction="runtime-to-host-final",
            )
            return snapshot

    async def discard(self, state: ServerWorkspaceState) -> None:
        async with state.lock:
            if state.discarded:
                return
            await run_blocking_io(_remove_workspace_root, state.root)
            state.discarded = True

    @staticmethod
    def _require_active(state: ServerWorkspaceState) -> None:
        if state.discarded:
            raise RuntimeError("Runtime Wire workspace state was already discarded")

    async def _store_snapshot(
        self,
        root: Path,
        *,
        workspace_id: str,
        direction: str,
    ) -> tuple[WorkspaceSnapshot, set[PurePosixPath]]:
        archive, paths = await _archive_async(
            root,
            self._max_files,
            self._max_unpacked_bytes,
            self._max_archive_bytes,
        )
        try:
            ref = await self._store.put(
                _file_chunks(archive),
                media_type="application/vnd.areal-agent-runtime.workspace+tar+gzip",
                metadata={
                    "kind": "runtime-wire-workspace",
                    "direction": direction,
                    "workspaceId": workspace_id,
                },
            )
        finally:
            await run_blocking_io(archive.unlink, missing_ok=True)
        return WorkspaceSnapshot(asset_id=ref.asset_id), paths


async def _archive_async(
    root: Path, max_files: int, max_unpacked_bytes: int, max_archive_bytes: int,
) -> tuple[Path, set[PurePosixPath]]:
    result: tuple[Path, set[PurePosixPath]] | None = None

    def acquire() -> tuple[Path, set[PurePosixPath]]:
        nonlocal result
        result = _archive(root, max_files, max_unpacked_bytes, max_archive_bytes)
        return result

    try:
        return await run_blocking_io(acquire)
    except BaseException:
        if result is not None:
            await run_blocking_io(result[0].unlink, missing_ok=True)
        raise


async def _open_file(path: Path) -> BinaryIO:
    handle: BinaryIO | None = None

    def acquire() -> BinaryIO:
        nonlocal handle
        handle = path.open("rb")
        return handle

    try:
        return await run_blocking_io(acquire)
    except BaseException:
        if handle is not None:
            await run_blocking_io(handle.close)
        raise


def _cleanup_transfer(archive: Path | None, staging: Path | None) -> None:
    try:
        if archive is not None:
            archive.unlink(missing_ok=True)
    finally:
        if staging is not None:
            shutil.rmtree(staging, ignore_errors=True)


def _workspace_paths(
    root: Path,
    max_files: int,
    max_unpacked_bytes: int = 512 * 1024 * 1024,
) -> set[PurePosixPath]:
    paths: set[PurePosixPath] = set()
    total_bytes = 0
    for _path, relative, metadata in _walk_workspace(root):
        paths.add(relative)
        if len(paths) > max_files:
            raise ValueError(f"Workspace exceeds {max_files} entries")
        if stat.S_ISREG(metadata.st_mode):
            total_bytes += metadata.st_size
            if total_bytes > max_unpacked_bytes:
                raise ValueError(f"Workspace exceeds {max_unpacked_bytes} unpacked bytes")
    return paths


def _archive(
    root: Path,
    max_files: int,
    max_unpacked_bytes: int,
    max_archive_bytes: int,
) -> tuple[Path, set[PurePosixPath]]:
    descriptor, name = tempfile.mkstemp(prefix="areal_agent_runtime-workspace-", suffix=".tar.gz")
    os.close(descriptor)
    target = Path(name)
    count = 0
    total_bytes = 0
    paths: set[PurePosixPath] = set()
    try:
        with (
            target.open("wb") as output,
            gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed,
            tarfile.open(fileobj=compressed, mode="w") as archive,
        ):
            for _path, relative, observed in _walk_workspace(root):
                count += 1
                if count > max_files:
                    raise ValueError(f"Workspace exceeds {max_files} entries")
                paths.add(relative)
                descriptor = _open_relative_entry(
                    root,
                    relative,
                    directory=stat.S_ISDIR(observed.st_mode),
                )
                try:
                    current = os.fstat(descriptor)
                    _require_matching_metadata(observed, current, relative)
                    if stat.S_ISDIR(current.st_mode):
                        archive.addfile(_tar_info(relative, current))
                        continue
                    total_bytes += current.st_size
                    if total_bytes > max_unpacked_bytes:
                        raise ValueError(f"Workspace exceeds {max_unpacked_bytes} unpacked bytes")
                    info = _tar_info(relative, current)
                    with os.fdopen(descriptor, "rb", closefd=False) as source:
                        archive.addfile(info, source)
                    _require_matching_metadata(current, os.fstat(descriptor), relative)
                finally:
                    os.close(descriptor)
        if target.stat().st_size > max_archive_bytes:
            raise ValueError(f"Workspace archive exceeds {max_archive_bytes} bytes")
        with target.open("rb") as handle:
            os.fsync(handle.fileno())
        return target, paths
    except BaseException:
        target.unlink(missing_ok=True)
        raise


def _walk_workspace(
    root: Path,
) -> Iterator[tuple[Path, PurePosixPath, os.stat_result]]:
    root_metadata = os.lstat(root)
    if stat.S_ISLNK(root_metadata.st_mode) or not stat.S_ISDIR(root_metadata.st_mode):
        raise ValueError(f"Workspace root must be a real directory: {root}")

    def raise_walk_error(error: OSError) -> None:
        raise error

    for directory, directory_names, file_names in os.walk(
        root,
        topdown=True,
        followlinks=False,
        onerror=raise_walk_error,
    ):
        parent = Path(directory)
        retained_directories: list[str] = []
        for name in sorted(directory_names):
            path = parent / name
            metadata = os.lstat(path)
            if stat.S_ISLNK(metadata.st_mode):
                continue
            if not stat.S_ISDIR(metadata.st_mode):
                raise ValueError(f"Unsupported workspace entry: {path.relative_to(root)}")
            retained_directories.append(name)
            yield path, PurePosixPath(path.relative_to(root).as_posix()), metadata
        directory_names[:] = retained_directories
        for name in sorted(file_names):
            path = parent / name
            metadata = os.lstat(path)
            if stat.S_ISLNK(metadata.st_mode):
                continue
            if not stat.S_ISREG(metadata.st_mode):
                raise ValueError(f"Unsupported workspace entry: {path.relative_to(root)}")
            yield path, PurePosixPath(path.relative_to(root).as_posix()), metadata
    _require_matching_metadata(root_metadata, os.lstat(root), PurePosixPath("."))


def _tar_info(relative: PurePosixPath, metadata: os.stat_result) -> tarfile.TarInfo:
    info = tarfile.TarInfo(relative.as_posix())
    info.mode = stat.S_IMODE(metadata.st_mode)
    info.mtime = int(metadata.st_mtime)
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    if stat.S_ISDIR(metadata.st_mode):
        info.type = tarfile.DIRTYPE
        info.size = 0
    else:
        info.type = tarfile.REGTYPE
        info.size = metadata.st_size
    return info


def _metadata_fingerprint(metadata: os.stat_result) -> tuple[int, int, int, int, int, int]:
    return (
        metadata.st_dev,
        metadata.st_ino,
        stat.S_IFMT(metadata.st_mode),
        metadata.st_size,
        metadata.st_mtime_ns,
        metadata.st_ctime_ns,
    )


def _require_matching_metadata(
    expected: os.stat_result,
    current: os.stat_result,
    relative: PurePosixPath,
) -> None:
    if _metadata_fingerprint(expected) != _metadata_fingerprint(current):
        raise ValueError(f"Workspace entry changed during snapshot: {relative}")


def _open_relative_entry(
    root: Path,
    relative: PurePosixPath,
    *,
    directory: bool,
) -> int:
    parent_descriptor = _open_parent_descriptor(root, relative, create=False)
    if parent_descriptor is None:
        raise ValueError(f"Workspace entry disappeared during snapshot: {relative}")
    try:
        return os.open(
            relative.name,
            _DIRECTORY_OPEN_FLAGS if directory else _FILE_OPEN_FLAGS,
            dir_fd=parent_descriptor,
        )
    finally:
        os.close(parent_descriptor)


def _extract(
    archive_path: Path,
    destination: Path,
    max_files: int,
    max_unpacked_bytes: int,
) -> set[PurePosixPath]:
    destination = destination.resolve(strict=True)
    count = 0
    unpacked_bytes = 0
    seen: set[PurePosixPath] = set()
    directory_modes: list[tuple[Path, int]] = []
    # Stream headers instead of getmembers(): a snapshot containing millions
    # of tiny entries is rejected after max_files + 1 headers without first
    # retaining attacker-controlled TarInfo objects for the entire archive.
    with tarfile.open(archive_path, "r|gz") as archive:
        for member in archive:
            count += 1
            if count > max_files:
                raise ValueError(f"Workspace snapshot exceeds {max_files} entries")
            canonical_name = member.name[:-1] if member.isdir() and member.name.endswith("/") else member.name
            relative = PurePosixPath(canonical_name)
            if (
                not canonical_name
                or "\\" in canonical_name
                or "\x00" in canonical_name
                or len(canonical_name.encode("utf-8")) > 4096
                or relative.is_absolute()
                or any(part in {"", ".", ".."} for part in relative.parts)
                or relative.as_posix() != canonical_name
            ):
                raise ValueError(f"Unsafe workspace snapshot path: {member.name}")
            if relative in seen:
                raise ValueError(f"Duplicate workspace snapshot path: {member.name}")
            seen.add(relative)
            if not member.isdir() and not member.isfile():
                raise ValueError(f"Unsupported workspace snapshot entry: {member.name}")
            if member.size < 0:
                raise ValueError(f"Invalid workspace snapshot entry size: {member.name}")
            if member.isdir() and member.size != 0:
                raise ValueError(f"Workspace snapshot directory has data: {member.name}")
            if member.isfile():
                unpacked_bytes += member.size
                if unpacked_bytes > max_unpacked_bytes:
                    raise ValueError(f"Workspace snapshot exceeds {max_unpacked_bytes} unpacked bytes")
            target = destination.joinpath(*relative.parts)
            if not target.resolve().is_relative_to(destination):
                raise ValueError(f"Workspace snapshot escapes destination: {member.name}")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                directory_modes.append((target, member.mode & 0o777))
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise ValueError(f"Workspace snapshot file is unreadable: {member.name}")
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(target, flags, 0o600)
            with source, os.fdopen(descriptor, "wb") as output:
                written = 0
                while chunk := source.read(1024 * 1024):
                    written += len(chunk)
                    if written > member.size:
                        raise ValueError(f"Workspace snapshot entry exceeds declared size: {member.name}")
                    output.write(chunk)
                if written != member.size:
                    raise ValueError(f"Workspace snapshot entry size mismatch: {member.name}")
            os.chmod(target, member.mode & 0o777)
    for directory, mode in sorted(
        directory_modes,
        key=lambda item: len(item[0].parts),
        reverse=True,
    ):
        os.chmod(directory, mode)
    return seen


def _reconcile(
    root: Path,
    synchronized_paths: frozenset[PurePosixPath],
    staging: Path,
    max_files: int,
    max_unpacked_bytes: int = 512 * 1024 * 1024,
) -> set[PurePosixPath]:
    final_paths = _workspace_paths(staging, max_files, max_unpacked_bytes)
    removed = sorted(
        synchronized_paths.difference(final_paths),
        key=lambda item: len(item.parts),
        reverse=True,
    )
    # Validate the complete mutation set before changing any path.  Otherwise
    # a symlink created on the receiving side after the previous snapshot can
    # redirect an incoming file outside the workspace, and an error halfway
    # through reconciliation can leave a partially applied snapshot.
    for relative in (*removed, *sorted(final_paths, key=lambda item: item.as_posix())):
        _assert_safe_reconcile_path(root, relative)
    for relative in removed:
        _remove_relative_entry(root, relative)
    directory_modes: list[tuple[PurePosixPath, int]] = []
    for relative in sorted(final_paths, key=lambda item: (len(item.parts), item.as_posix())):
        source = staging.joinpath(*relative.parts)
        source_metadata = os.lstat(source)
        if stat.S_ISDIR(source_metadata.st_mode):
            _ensure_relative_directory(root, relative)
            directory_modes.append((relative, source_metadata.st_mode))
        elif stat.S_ISREG(source_metadata.st_mode):
            _copy_relative_file_atomic(staging, root, relative, source_metadata)
        else:  # pragma: no cover - staging was scanned immediately above
            raise ValueError(f"Unsupported staged workspace entry: {relative}")
    for relative, mode in sorted(
        directory_modes,
        key=lambda item: len(item[0].parts),
        reverse=True,
    ):
        _chmod_relative_directory(root, relative, mode)
    return final_paths


def _assert_safe_reconcile_path(root: Path, relative: PurePosixPath) -> None:
    if relative.is_absolute() or not relative.parts or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError(f"Unsafe workspace reconciliation path: {relative}")
    root_metadata = os.lstat(root)
    if stat.S_ISLNK(root_metadata.st_mode) or not stat.S_ISDIR(root_metadata.st_mode):
        raise ValueError("Workspace reconciliation root must be a real directory")
    current = root
    for part in relative.parts[:-1]:
        current /= part
        if current.is_symlink():
            raise ValueError(f"Workspace reconciliation path contains a symbolic link: {relative}")


def _open_parent_descriptor(
    root: Path,
    relative: PurePosixPath,
    *,
    create: bool,
) -> int | None:
    try:
        descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
    except OSError as exc:
        raise ValueError("Workspace root cannot be opened safely") from exc
    try:
        for part in relative.parts[:-1]:
            try:
                next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
            except FileNotFoundError:
                if not create:
                    os.close(descriptor)
                    return None
                try:
                    os.mkdir(part, 0o755, dir_fd=descriptor)
                except FileExistsError:
                    pass
                next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
            except OSError as exc:
                raise ValueError(f"Workspace path contains a symbolic link or non-directory: {relative}") from exc
            os.close(descriptor)
            descriptor = next_descriptor
        return descriptor
    except BaseException:
        with contextlib.suppress(OSError):
            os.close(descriptor)
        raise


def _remove_relative_entry(root: Path, relative: PurePosixPath) -> None:
    parent_descriptor = _open_parent_descriptor(root, relative, create=False)
    if parent_descriptor is None:
        return
    try:
        try:
            metadata = os.stat(relative.name, dir_fd=parent_descriptor, follow_symlinks=False)
        except FileNotFoundError:
            return
        if stat.S_ISLNK(metadata.st_mode) or stat.S_ISREG(metadata.st_mode):
            os.unlink(relative.name, dir_fd=parent_descriptor)
            os.fsync(parent_descriptor)
        elif stat.S_ISDIR(metadata.st_mode):
            try:
                os.rmdir(relative.name, dir_fd=parent_descriptor)
            except OSError as exc:
                if exc.errno not in {errno.ENOTEMPTY, errno.EEXIST}:
                    raise
            else:
                os.fsync(parent_descriptor)
        else:
            raise ValueError(f"Unsupported workspace destination entry: {relative}")
    finally:
        os.close(parent_descriptor)


def _ensure_relative_directory(root: Path, relative: PurePosixPath) -> None:
    parent_descriptor = _open_parent_descriptor(root, relative, create=True)
    assert parent_descriptor is not None
    try:
        try:
            metadata = os.stat(relative.name, dir_fd=parent_descriptor, follow_symlinks=False)
        except FileNotFoundError:
            metadata = None
        if metadata is not None and (stat.S_ISLNK(metadata.st_mode) or stat.S_ISREG(metadata.st_mode)):
            os.unlink(relative.name, dir_fd=parent_descriptor)
            metadata = None
        elif metadata is not None and not stat.S_ISDIR(metadata.st_mode):
            raise ValueError(f"Unsupported workspace destination entry: {relative}")
        if metadata is None:
            os.mkdir(relative.name, 0o755, dir_fd=parent_descriptor)
            os.fsync(parent_descriptor)
        descriptor = os.open(relative.name, _DIRECTORY_OPEN_FLAGS, dir_fd=parent_descriptor)
        try:
            current_mode = stat.S_IMODE(os.fstat(descriptor).st_mode)
            os.fchmod(descriptor, (current_mode | 0o700) & 0o777)
        finally:
            os.close(descriptor)
    finally:
        os.close(parent_descriptor)


def _chmod_relative_directory(root: Path, relative: PurePosixPath, mode: int) -> None:
    parent_descriptor = _open_parent_descriptor(root, relative, create=False)
    if parent_descriptor is None:
        raise ValueError(f"Workspace directory disappeared during reconciliation: {relative}")
    try:
        descriptor = os.open(relative.name, _DIRECTORY_OPEN_FLAGS, dir_fd=parent_descriptor)
        try:
            os.fchmod(descriptor, mode & 0o777)
        finally:
            os.close(descriptor)
    finally:
        os.close(parent_descriptor)


def _copy_relative_file_atomic(
    source_root: Path,
    destination_root: Path,
    relative: PurePosixPath,
    observed_source: os.stat_result,
) -> None:
    source_descriptor = _open_relative_entry(source_root, relative, directory=False)
    destination_parent: int | None = None
    temporary_name = f".areal-agent-runtime-wire-{hashlib.sha256(os.urandom(32)).hexdigest()}"
    temporary_descriptor: int | None = None
    try:
        destination_parent = _open_parent_descriptor(destination_root, relative, create=True)
        assert destination_parent is not None
        current_source = os.fstat(source_descriptor)
        _require_matching_metadata(observed_source, current_source, relative)
        temporary_descriptor = os.open(
            temporary_name,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
            dir_fd=destination_parent,
        )
        written = 0
        while chunk := os.read(source_descriptor, 1024 * 1024):
            written += len(chunk)
            if written > current_source.st_size:
                raise ValueError(f"Staged workspace entry grew during reconciliation: {relative}")
            _write_all(temporary_descriptor, chunk)
        if written != current_source.st_size:
            raise ValueError(f"Staged workspace entry size changed: {relative}")
        _require_matching_metadata(current_source, os.fstat(source_descriptor), relative)
        os.fchmod(temporary_descriptor, stat.S_IMODE(current_source.st_mode) & 0o777)
        os.fsync(temporary_descriptor)
        try:
            target_metadata = os.stat(
                relative.name,
                dir_fd=destination_parent,
                follow_symlinks=False,
            )
        except FileNotFoundError:
            target_metadata = None
        if target_metadata is not None and stat.S_ISDIR(target_metadata.st_mode):
            shutil.rmtree(relative.name, dir_fd=destination_parent)
        elif target_metadata is not None and not (
            stat.S_ISREG(target_metadata.st_mode) or stat.S_ISLNK(target_metadata.st_mode)
        ):
            raise ValueError(f"Unsupported workspace destination entry: {relative}")
        os.replace(
            temporary_name,
            relative.name,
            src_dir_fd=destination_parent,
            dst_dir_fd=destination_parent,
        )
        temporary_name = ""
        os.fsync(destination_parent)
    finally:
        if temporary_descriptor is not None:
            os.close(temporary_descriptor)
        if temporary_name and destination_parent is not None:
            with contextlib.suppress(FileNotFoundError):
                os.unlink(temporary_name, dir_fd=destination_parent)
        if destination_parent is not None:
            os.close(destination_parent)
        os.close(source_descriptor)


def _reconcile_state(
    state: ClientWorkspaceState | ServerWorkspaceState,
    staging: Path,
    max_files: int,
    max_unpacked_bytes: int,
) -> None:
    state.synchronized_paths = frozenset(
        _reconcile(state.root, state.synchronized_paths, staging, max_files, max_unpacked_bytes)
    )


def _write_all(descriptor: int, chunk: bytes) -> None:
    view = memoryview(chunk)
    while view:
        count = os.write(descriptor, view)
        if count <= 0:  # pragma: no cover - regular file invariant
            raise OSError("Workspace reconciliation write made no progress")
        view = view[count:]


async def _asset_to_temp(
    store: AssetStorePort,
    asset_id: str,
    *,
    max_bytes: int,
) -> Path:
    descriptor, name = tempfile.mkstemp(prefix="areal_agent_runtime-workspace-import-", suffix=".tar.gz")
    target = Path(name)
    try:
        handle = os.fdopen(descriptor, "wb")
        written = 0
        try:
            async for chunk in store.open(asset_id):
                if not isinstance(chunk, bytes):
                    raise TypeError("AssetStorePort.open() must yield bytes")
                written += len(chunk)
                if written > max_bytes:
                    raise ValueError(f"Workspace archive exceeds {max_bytes} bytes")
                await run_blocking_io(handle.write, chunk)
        finally:
            await run_blocking_io(handle.close)
        return target
    except BaseException:
        await run_blocking_io(target.unlink, missing_ok=True)
        raise


async def _file_chunks(path: Path) -> AsyncIterator[bytes]:
    handle = await _open_file(path)
    try:
        while chunk := await run_blocking_io(handle.read, 1024 * 1024):
            yield chunk
    finally:
        await run_blocking_io(handle.close)


def _resolved_directory(value: str) -> tuple[Path, bool]:
    configured = Path(value).expanduser()
    root = configured.resolve(strict=True)
    return root, root.is_dir() and not configured.is_symlink()


def _validate_workspace_limits(
    max_files: int,
    max_unpacked_bytes: int,
    max_archive_bytes: int,
) -> None:
    if isinstance(max_files, bool) or not isinstance(max_files, int) or max_files < 1:
        raise ValueError("max_files must be a positive integer")
    if isinstance(max_unpacked_bytes, bool) or not isinstance(max_unpacked_bytes, int) or max_unpacked_bytes < 1:
        raise ValueError("max_unpacked_bytes must be a positive integer")
    if isinstance(max_archive_bytes, bool) or not isinstance(max_archive_bytes, int) or max_archive_bytes < 1:
        raise ValueError("max_archive_bytes must be a positive integer")


def _remove_workspace_root(root: Path) -> None:
    try:
        metadata = os.lstat(root)
    except FileNotFoundError:
        return
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        root.unlink(missing_ok=True)
        return
    shutil.rmtree(root)
