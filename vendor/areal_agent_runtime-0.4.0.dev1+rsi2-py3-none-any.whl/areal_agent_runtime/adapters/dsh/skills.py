"""Translate immutable portable skill resources into native DSH definitions.

This module deliberately does not follow resource locators or grant tool access.
The Host has already resolved the bytes and the Application owns the ToolSet.
"""

from __future__ import annotations

import copy
import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

import yaml
from pydantic import JsonValue

from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot, ResolvedResourceSnapshot
from areal_agent_runtime.contracts.tools import ToolExecution

SKILLS_FILE_ENV = "AREAL_AGENT_RUNTIME_DSH_SKILLS_FILE"
SKILLS_SHA256_ENV = "AREAL_AGENT_RUNTIME_DSH_SKILLS_SHA256"
MAX_SKILLS = 256
MAX_SKILLS_BYTES = 16 * 1024 * 1024
MAX_SKILL_FRONTMATTER_BYTES = 64 * 1024
MAX_SKILL_FRONTMATTER_DEPTH = 64
_SKILL_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_YAML12_INT = re.compile(r"^(?:[-+]?[0-9]+|0o[0-7]+|0x[0-9a-fA-F]+)$")
_YAML12_FLOAT = re.compile(
    r"^(?:[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+"
    r"|[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)"
    r"|[-+]?\.(?:inf|Inf|INF)|\.(?:nan|NaN|NAN))$"
)


class _FrontmatterError(ValueError):
    """Safe validation detail that does not quote user-supplied skill content."""


class _FrontmatterLoader(yaml.SafeLoader):
    """Parse DSH's YAML 1.2 Core scalars with bounded, alias-free composition."""

    def __init__(self, stream: str) -> None:
        super().__init__(stream)
        self._frontmatter_depth = 0

    def compose_node(self, parent: yaml.Node | None, index: Any) -> yaml.Node | None:
        # Reject before composing or expanding references. Unlike DSH's native
        # provider, this cross-process snapshot bridge does not support aliases.
        if self.check_event(yaml.AliasEvent):
            raise _FrontmatterError("skill frontmatter aliases are not supported")
        if self._frontmatter_depth >= MAX_SKILL_FRONTMATTER_DEPTH:
            raise _FrontmatterError("skill frontmatter exceeds the maximum nesting depth")
        self._frontmatter_depth += 1
        try:
            return super().compose_node(parent, index)
        finally:
            self._frontmatter_depth -= 1


_FrontmatterLoader.yaml_implicit_resolvers = copy.deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for _initial, _resolvers in _FrontmatterLoader.yaml_implicit_resolvers.items():
    _FrontmatterLoader.yaml_implicit_resolvers[_initial] = [
        (tag, pattern)
        for tag, pattern in _resolvers
        if tag not in {
            "tag:yaml.org,2002:bool", "tag:yaml.org,2002:timestamp",
            "tag:yaml.org,2002:int", "tag:yaml.org,2002:float",
            "tag:yaml.org,2002:merge", "tag:yaml.org,2002:value",
        }
    ]
_FrontmatterLoader.add_implicit_resolver(
    "tag:yaml.org,2002:bool", re.compile(r"^(?:true|True|TRUE|false|False|FALSE)$"), list("tTfF")
)
_FrontmatterLoader.add_implicit_resolver("tag:yaml.org,2002:int", _YAML12_INT, list("-+0123456789"))
_FrontmatterLoader.add_implicit_resolver("tag:yaml.org,2002:float", _YAML12_FLOAT, list("-+0123456789."))


def _core_bool(loader: _FrontmatterLoader, node: yaml.ScalarNode) -> bool:
    value = loader.construct_scalar(node)
    if value not in {"true", "True", "TRUE", "false", "False", "FALSE"}:
        raise _FrontmatterError("skill frontmatter requires YAML 1.2 Core booleans")
    return value.lower() == "true"


def _core_int(loader: _FrontmatterLoader, node: yaml.ScalarNode) -> int:
    value = loader.construct_scalar(node)
    if _YAML12_INT.fullmatch(value) is None:
        raise _FrontmatterError("skill frontmatter requires YAML 1.2 Core integers")
    if value.startswith("0o"):
        return int(value[2:], 8)
    if value.startswith("0x"):
        return int(value[2:], 16)
    return int(value, 10)


def _core_float(loader: _FrontmatterLoader, node: yaml.ScalarNode) -> float:
    value = loader.construct_scalar(node)
    if _YAML12_FLOAT.fullmatch(value) is None:
        raise _FrontmatterError("skill frontmatter requires YAML 1.2 Core floats")
    return float(value.lower().replace(".inf", "inf").replace(".nan", "nan"))


_FrontmatterLoader.add_constructor("tag:yaml.org,2002:bool", _core_bool)
_FrontmatterLoader.add_constructor("tag:yaml.org,2002:int", _core_int)
_FrontmatterLoader.add_constructor("tag:yaml.org,2002:float", _core_float)


def _unique_mapping(loader: _FrontmatterLoader, node: yaml.MappingNode) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=True)
        if not isinstance(key, str) or key in result:
            raise ValueError("skill frontmatter requires unique string keys")
        result[key] = loader.construct_object(value_node, deep=True)
    return result


_FrontmatterLoader.add_constructor("tag:yaml.org,2002:map", _unique_mapping)


@dataclass(frozen=True)
class NativeSkill:
    name: str
    description: str
    content: str
    model_invocable: bool = True
    user_invocable: bool = True
    when_to_use: str | None = None
    metadata: dict[str, JsonValue] | None = None

    def to_wire(self) -> dict[str, JsonValue]:
        result: dict[str, JsonValue] = {
            "name": self.name,
            "description": self.description,
            "content": self.content,
            "invocation": {
                "modelInvocable": self.model_invocable,
                "userInvocable": self.user_invocable,
            },
        }
        if self.when_to_use is not None:
            result["whenToUse"] = self.when_to_use
        if self.metadata is not None:
            result["metadata"] = self.metadata
        return result


def native_skill_payload(environment: AgentEnvironmentSnapshot) -> bytes:
    """Validate skill compatibility and authority before a vendor process starts."""

    environment.assert_integrity()
    if len(environment.skills) > MAX_SKILLS:
        raise ValueError(f"DSH supports at most {MAX_SKILLS} skills per Session")
    names: set[str] = set()
    authorized_loader = any(
        tool.name == "skill" and tool.execution == ToolExecution.RUNTIME for tool in environment.tools
    )
    payload = bytearray()
    encoder = json.JSONEncoder(ensure_ascii=False, allow_nan=False)

    def append(fragment: str) -> None:
        encoded = fragment.encode("utf-8")
        if len(payload) + len(encoded) > MAX_SKILLS_BYTES:
            raise ValueError(f"DSH skill manifest exceeds {MAX_SKILLS_BYTES} bytes")
        payload.extend(encoded)

    append("[")
    for index, resource in enumerate(environment.skills):
        skill = resolve_native_skill(resource)
        if skill.name in names:
            raise ValueError(f"DSH skills have duplicate native name: {skill.name}")
        names.add(skill.name)
        if skill.model_invocable and not authorized_loader:
            raise ValueError(
                "DSH model-invocable skills require an explicitly authorized runtime tool named 'skill'; "
                "register the DSH skill tool provider and bind 'skill' to this Agent profile"
            )
        if index:
            append(", ")
        for fragment in encoder.iterencode(skill.to_wire()):
            append(fragment)
    append("]")
    return bytes(payload)


def resolve_native_skill(resource: ResolvedResourceSnapshot) -> NativeSkill:
    """Preserve native SKILL.md metadata, or name a legacy text/JSON resource."""

    raw = resource.content
    text = raw if isinstance(raw, str) else json.dumps(raw, ensure_ascii=False, allow_nan=False)
    if len(text) > MAX_SKILLS_BYTES:
        raise ValueError(f"DSH skill {resource.resource_id} exceeds {MAX_SKILLS_BYTES} characters")
    if "\x00" in text:
        raise ValueError(f"DSH skill {resource.resource_id} must not contain NUL bytes")
    # Resource bytes are resolved by the Host. A logical locator is never a file
    # path, and a lone SKILL.md does not authorize reading its sibling resources.
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].rstrip("\r\n") != "---":
        return NativeSkill(
            name=_legacy_name(resource.resource_id),
            description=f"Instructions for skill resource {resource.resource_id}.",
            content=text,
        )
    closing = next((i for i in range(1, len(lines)) if lines[i].rstrip("\r\n") == "---"), None)
    if closing is None:
        raise ValueError(f"DSH skill {resource.resource_id} has unterminated YAML frontmatter")
    frontmatter = "".join(lines[1:closing])
    if len(frontmatter.encode("utf-8")) > MAX_SKILL_FRONTMATTER_BYTES:
        raise ValueError(
            f"DSH skill {resource.resource_id} frontmatter exceeds {MAX_SKILL_FRONTMATTER_BYTES} bytes"
        )
    try:
        fields = yaml.load(frontmatter, Loader=_FrontmatterLoader)
        if not isinstance(fields, dict):
            raise ValueError("frontmatter must be an object")
        # Reject YAML types that cannot cross the JSON bridge (including cycles,
        # non-finite floats and arbitrary tags). No metadata may grant authority.
        fields = json.loads(json.dumps(fields, allow_nan=False))
    except (yaml.YAMLError, TypeError, ValueError, RecursionError) as exc:
        detail = f": {exc}" if isinstance(exc, _FrontmatterError) else ""
        raise ValueError(f"DSH skill {resource.resource_id} has invalid YAML frontmatter{detail}") from exc
    name = fields.get("name")
    description = fields.get("description")
    if not isinstance(name, str) or _SKILL_NAME.fullmatch(name) is None:
        raise ValueError(f"DSH skill {resource.resource_id} requires a kebab-case frontmatter name")
    if not isinstance(description, str) or not description.strip():
        raise ValueError(f"DSH skill {resource.resource_id} requires a frontmatter description")
    for legacy in ("disableModelInvocation", "modelInvocable", "userInvocable"):
        if legacy in fields:
            raise ValueError(f"DSH skill {resource.resource_id} uses unsupported invocation field {legacy}")
    when_to_use = fields.get("whenToUse")
    metadata = fields.get("metadata")
    return NativeSkill(
        name=name,
        description=description,
        content="".join(lines[closing + 1 :]).strip(),
        model_invocable=not _frontmatter_bool(fields, "disable-model-invocation", False),
        user_invocable=_frontmatter_bool(fields, "user-invocable", True),
        when_to_use=when_to_use if isinstance(when_to_use, str) and when_to_use else None,
        metadata=metadata if isinstance(metadata, dict) else None,
    )


def _legacy_name(resource_id: str) -> str:
    if _SKILL_NAME.fullmatch(resource_id):
        return resource_id
    slug = re.sub(r"[^a-z0-9]+", "-", resource_id.lower()).strip("-")[:64].rstrip("-") or "skill"
    digest = hashlib.sha256(resource_id.encode("utf-8")).hexdigest()[:12]
    return f"{slug}-{digest}"


def _frontmatter_bool(fields: dict[str, Any], key: str, default: bool) -> bool:
    if key not in fields:
        return default
    value = fields[key]
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        if value.lower() in {"true", "yes", "on", "1"}:
            return True
        if value.lower() in {"false", "no", "off", "0"}:
            return False
    raise ValueError(f"DSH skill frontmatter field '{key}' must be a boolean")
