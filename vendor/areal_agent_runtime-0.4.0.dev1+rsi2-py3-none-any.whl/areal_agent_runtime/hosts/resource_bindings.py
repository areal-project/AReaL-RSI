"""Host-owned resolution of logical Agent environment resources."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import cast
from urllib.parse import SplitResult, urlsplit, urlunsplit

from pydantic import JsonValue

from areal_agent_runtime.contracts.base import require_media_type, require_trimmed
from areal_agent_runtime.contracts.environment import (
    ArtifactResourceSource,
    BuiltinResourceSource,
    InlineResourceSource,
    MountResourceSource,
    ResourceSource,
    UriResourceSource,
)
from areal_agent_runtime.contracts.ports import AssetStorePort, LoadedResource

_MOUNT_ID = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


@dataclass(frozen=True, slots=True)
class BuiltinResource:
    content: JsonValue
    media_type: str = "text/plain"
    version: str = "1.0.0"

    def __post_init__(self) -> None:
        require_media_type(self.media_type)
        require_trimmed(self.version, "builtin resource version")
        object.__setattr__(self, "content", _clone_json_value(self.content))


@dataclass(frozen=True, slots=True)
class ResourceBindingPolicy:
    max_bytes: int = 1024 * 1024
    allowed_http_origins: tuple[str, ...] = ()
    allow_insecure_loopback_http: bool = False

    def __post_init__(self) -> None:
        if isinstance(self.max_bytes, bool) or not isinstance(self.max_bytes, int) or self.max_bytes < 1:
            raise ValueError("resource max_bytes must be a positive integer")
        if not isinstance(self.allow_insecure_loopback_http, bool):
            raise TypeError("allow_insecure_loopback_http must be a boolean")
        if not isinstance(self.allowed_http_origins, tuple):
            raise TypeError("allowed_http_origins must be a tuple")
        normalized = tuple(
            _validate_allowed_origin(
                origin,
                allow_insecure_loopback_http=self.allow_insecure_loopback_http,
            )
            for origin in self.allowed_http_origins
        )
        if len(normalized) != len(set(normalized)):
            raise ValueError("allowed_http_origins must not contain duplicate origins")
        object.__setattr__(self, "allowed_http_origins", normalized)


class HostResourceBindings:
    """Map builtin/artifact/URI/logical mounts without leaking physical paths to Core."""

    def __init__(
        self,
        *,
        builtins: dict[str, BuiltinResource] | None = None,
        mounts: dict[str, str | Path] | None = None,
        asset_store: AssetStorePort | None = None,
        policy: ResourceBindingPolicy | None = None,
    ) -> None:
        self._builtins: dict[str, BuiltinResource] = {}
        for resource_id, builtin in (builtins or {}).items():
            # Reuse the public contract's identifier grammar at the Host
            # registration boundary, then clone nested content for isolation.
            BuiltinResourceSource(resource_id=resource_id)
            if not isinstance(builtin, BuiltinResource):
                raise TypeError("builtins values must be BuiltinResource instances")
            self._builtins[resource_id] = BuiltinResource(
                content=builtin.content,
                media_type=builtin.media_type,
                version=builtin.version,
            )
        self._mounts: dict[str, Path] = {}
        self._mount_identities: dict[str, tuple[int, int] | None] = {}
        for mount_id, configured_root in (mounts or {}).items():
            if not isinstance(mount_id, str) or _MOUNT_ID.fullmatch(mount_id) is None:
                raise ValueError(f"invalid logical mount id: {mount_id!r}")
            configured = Path(configured_root).expanduser()
            if configured.is_symlink():
                raise ValueError(f"logical mount root must not be a symbolic link: {mount_id}")
            try:
                root = configured.resolve(strict=False)
            except (OSError, TypeError) as exc:
                raise ValueError(f"logical mount root is unavailable: {mount_id}") from exc
            identity: tuple[int, int] | None = None
            if root.exists():
                metadata = os.lstat(root)
                if not stat.S_ISDIR(metadata.st_mode):
                    raise ValueError(f"logical mount root must be a real directory: {mount_id}")
                identity = (metadata.st_dev, metadata.st_ino)
            self._mounts[mount_id] = root
            self._mount_identities[mount_id] = identity
        self._assets = asset_store
        self._policy = policy or ResourceBindingPolicy()
        self._allowed_origins = frozenset(self._policy.allowed_http_origins)

    async def load(self, source: ResourceSource) -> LoadedResource:
        if isinstance(source, InlineResourceSource):
            return self._loaded(
                source,
                source.content,
                locator=f"inline://{source.resource_id}",
            )
        if isinstance(source, BuiltinResourceSource):
            try:
                builtin = self._builtins[source.resource_id]
            except KeyError as exc:
                raise LookupError(f"unknown builtin resource: {source.resource_id}") from exc
            effective = source.model_copy(
                update={
                    "media_type": builtin.media_type,
                    "version": source.version or builtin.version,
                }
            )
            return self._loaded(
                effective,
                builtin.content,
                locator=f"builtin://{source.resource_id}",
            )
        if isinstance(source, MountResourceSource):
            return await self._load_mount(source)
        if isinstance(source, ArtifactResourceSource):
            return await self._load_artifact(source)
        if isinstance(source, UriResourceSource):
            return await self._load_uri(source)
        raise TypeError(f"unsupported ResourceSource: {type(source).__name__}")

    async def _load_mount(self, source: MountResourceSource) -> LoadedResource:
        try:
            root = self._mounts[source.mount_id]
        except KeyError as exc:
            raise LookupError(f"unknown logical mount: {source.mount_id}") from exc
        try:
            raw = await asyncio.to_thread(
                self._read_mount_bounded,
                root,
                PurePosixPath(source.relative_path),
                self._mount_identities[source.mount_id],
            )
        except FileNotFoundError:
            raise
        except OSError as exc:
            raise PermissionError(f"resource cannot be opened safely in mount: {source.mount_id}") from exc
        return self._loaded_bytes(
            source,
            raw,
            locator=f"mount://{source.mount_id}/{source.relative_path}",
        )

    async def _load_artifact(self, source: ArtifactResourceSource) -> LoadedResource:
        if self._assets is None:
            raise RuntimeError("artifact ResourceSource requires AssetStorePort")
        ref = await self._assets.get(source.artifact_id)
        if ref is None:
            raise LookupError(f"artifact is unavailable: {source.artifact_id}")
        raw = await self._read_asset_bounded(source.artifact_id)
        effective = source.model_copy(
            update={
                "media_type": ref.media_type,
                "expected_sha256": source.expected_sha256 or ref.sha256,
            }
        )
        return self._loaded_bytes(
            effective,
            raw,
            locator=f"artifact://{source.artifact_id}",
        )

    async def _load_uri(self, source: UriResourceSource) -> LoadedResource:
        try:
            parsed = urlsplit(source.uri)
        except ValueError as exc:
            raise PermissionError("URI resource is malformed") from exc
        if (
            not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or any(character.isspace() for character in source.uri)
        ):
            raise PermissionError("URI resource is malformed or contains forbidden credentials, query, or fragment")
        try:
            _ = parsed.port
        except ValueError as exc:
            raise PermissionError("URI resource has an invalid port") from exc
        scheme = parsed.scheme.lower()
        hostname = (parsed.hostname or "").lower()
        if scheme != "https":
            loopback = scheme == "http" and hostname in {"127.0.0.1", "localhost", "::1"}
            if not (loopback and self._policy.allow_insecure_loopback_http):
                raise PermissionError("URI resources require HTTPS unless loopback HTTP is explicitly allowed")
        origin = _origin(parsed)
        if not self._allowed_origins or origin not in self._allowed_origins:
            raise PermissionError(f"URI resource origin is not allowed: {origin}")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover - optional dependency guard
            raise RuntimeError("Install areal-agent-runtime[integrations] to resolve URI resources") from exc
        async with httpx.AsyncClient(
            follow_redirects=False,
            trust_env=False,
            timeout=30,
        ) as client:
            async with client.stream("GET", source.uri) as response:
                if 300 <= response.status_code < 400:
                    raise PermissionError("URI resource redirects are not accepted")
                response.raise_for_status()
                declared_length = response.headers.get("content-length")
                expected_bytes: int | None = None
                if declared_length is not None:
                    if re.fullmatch(r"[0-9]+", declared_length) is None:
                        raise ValueError("resource Content-Length is invalid")
                    expected_bytes = int(declared_length)
                    if expected_bytes > self._policy.max_bytes:
                        raise ValueError("resource exceeds configured maxBytes")
                raw = bytearray()
                async for chunk in response.aiter_bytes():
                    if not isinstance(chunk, bytes):  # pragma: no cover - httpx invariant guard
                        raise TypeError("URI resource stream yielded a non-bytes chunk")
                    raw.extend(chunk)
                    if len(raw) > self._policy.max_bytes:
                        raise ValueError("resource exceeds configured maxBytes")
                if expected_bytes is not None and len(raw) != expected_bytes:
                    raise ValueError("resource body does not match Content-Length")
                media_type = response.headers.get("content-type", source.media_type).strip()
                require_media_type(media_type)
        effective = source.model_copy(update={"media_type": media_type})
        return self._loaded_bytes(
            effective,
            bytes(raw),
            locator=_redacted_uri(parsed),
        )

    async def _read_asset_bounded(self, asset_id: str) -> bytes:
        assert self._assets is not None
        payload = bytearray()
        async for chunk in self._assets.open(asset_id):
            if not isinstance(chunk, bytes):
                raise TypeError("AssetStorePort.open() must yield bytes")
            payload.extend(chunk)
            if len(payload) > self._policy.max_bytes:
                raise ValueError("resource exceeds configured maxBytes")
        return bytes(payload)

    def _read_mount_bounded(
        self,
        root: Path,
        relative: PurePosixPath,
        expected_root_identity: tuple[int, int] | None,
    ) -> bytes:
        """Open every path component without following symlinks, then read bounded bytes."""

        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
        file_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        descriptors: list[int] = []
        try:
            current = os.open(root, directory_flags)
            descriptors.append(current)
            root_details = os.fstat(current)
            if not stat.S_ISDIR(root_details.st_mode) or (
                expected_root_identity is not None
                and (root_details.st_dev, root_details.st_ino) != expected_root_identity
            ):
                raise PermissionError("logical mount root changed after registration")
            for index, part in enumerate(relative.parts):
                final = index == len(relative.parts) - 1
                current = os.open(
                    part,
                    file_flags if final else directory_flags,
                    dir_fd=current,
                )
                descriptors.append(current)
            details = os.fstat(current)
            if not stat.S_ISREG(details.st_mode):
                raise FileNotFoundError(relative.name)
            if details.st_size > self._policy.max_bytes:
                raise ValueError("resource exceeds configured maxBytes")
            raw = bytearray()
            while chunk := os.read(current, min(64 * 1024, self._policy.max_bytes + 1 - len(raw))):
                raw.extend(chunk)
                if len(raw) > self._policy.max_bytes:
                    raise ValueError("resource exceeds configured maxBytes")
            return bytes(raw)
        finally:
            for descriptor in reversed(descriptors):
                os.close(descriptor)

    def _loaded_bytes(
        self,
        source: ResourceSource,
        raw: bytes,
        *,
        locator: str,
    ) -> LoadedResource:
        if len(raw) > self._policy.max_bytes:
            raise ValueError("resource exceeds configured maxBytes")
        try:
            base_media_type = source.media_type.split(";", 1)[0].strip().lower()
            if base_media_type == "application/json" or base_media_type.endswith("+json"):
                content: JsonValue = json.loads(
                    raw,
                    object_pairs_hook=_strict_json_object,
                    parse_constant=_reject_json_constant,
                )
            else:
                content = raw.decode("utf-8")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError(f"resource content does not match mediaType={source.media_type}") from exc
        return self._loaded(source, content, locator=locator, raw=raw)

    def _loaded(
        self,
        source: ResourceSource,
        content: JsonValue,
        *,
        locator: str,
        raw: bytes | None = None,
    ) -> LoadedResource:
        isolated_content = _clone_json_value(content)
        encoded = raw if raw is not None else _canonical_bytes(isolated_content)
        if len(encoded) > self._policy.max_bytes:
            raise ValueError("resource exceeds configured maxBytes")
        digest = hashlib.sha256(encoded).hexdigest()
        if source.expected_sha256 is not None and digest.lower() != source.expected_sha256.lower():
            raise ValueError(f"resource digest mismatch: {source.resource_id}")
        return LoadedResource(
            content=isolated_content,
            media_type=source.media_type,
            sha256=digest,
            version=source.version,
            locator=locator,
        )


def _canonical_bytes(content: JsonValue) -> bytes:
    if isinstance(content, str):
        return content.encode("utf-8")
    return json.dumps(
        content,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _origin(parsed: SplitResult) -> str:
    if not parsed.scheme or not parsed.hostname:
        raise ValueError("HTTP origin must include scheme and host")
    host = parsed.hostname.lower()
    if ":" in host:
        host = f"[{host}]"
    port = f":{parsed.port}" if parsed.port is not None else ""
    return f"{parsed.scheme.lower()}://{host}{port}"


def _validate_allowed_origin(
    value: str,
    *,
    allow_insecure_loopback_http: bool,
) -> str:
    if not isinstance(value, str) or not value or any(character.isspace() for character in value):
        raise ValueError("HTTP origin must be a non-empty URL without whitespace")
    try:
        parsed = urlsplit(value)
    except ValueError as exc:
        raise ValueError("HTTP origin is malformed") from exc
    if (
        parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise ValueError("HTTP origin must not contain credentials, a path, query, or fragment")
    try:
        origin = _origin(parsed)
    except ValueError as exc:
        raise ValueError("HTTP origin has an invalid port") from exc
    if parsed.scheme == "https":
        return origin
    loopback = (parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}
    if parsed.scheme == "http" and loopback and allow_insecure_loopback_http:
        return origin
    raise ValueError("HTTP origins require HTTPS unless loopback HTTP is explicitly allowed")


def _redacted_uri(parsed: SplitResult) -> str:
    host = parsed.hostname or ""
    if ":" in host:
        host = f"[{host}]"
    port = f":{parsed.port}" if parsed.port is not None else ""
    return urlunsplit((parsed.scheme, f"{host}{port}", parsed.path, "", ""))


def _strict_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"resource JSON contains duplicate key: {key}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> object:
    raise ValueError(f"resource JSON contains invalid constant: {value}")


def _clone_json_value(
    value: JsonValue,
    *,
    _active: set[int] | None = None,
    _depth: int = 0,
) -> JsonValue:
    if _depth > 128:
        raise ValueError("resource JSON exceeds the maximum nesting depth")
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("resource JSON numbers must be finite")
        return value
    if not isinstance(value, (list, dict)):
        raise TypeError(f"resource content is not a JSON value: {type(value).__name__}")
    active = _active if _active is not None else set()
    identity = id(value)
    if identity in active:
        raise ValueError("resource JSON must not contain cycles")
    active.add(identity)
    try:
        if isinstance(value, list):
            return cast(
                JsonValue,
                [_clone_json_value(item, _active=active, _depth=_depth + 1) for item in value],
            )
        cloned: dict[str, JsonValue] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("resource JSON object keys must be strings")
            cloned[key] = _clone_json_value(item, _active=active, _depth=_depth + 1)
        return cast(JsonValue, cloned)
    finally:
        active.remove(identity)
