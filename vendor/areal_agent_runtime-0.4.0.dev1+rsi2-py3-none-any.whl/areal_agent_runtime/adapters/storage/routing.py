"""Route the existing AssetStore Port through deployment-owned backend rules."""

from __future__ import annotations

import base64
import binascii
import json
import re
from collections.abc import AsyncIterator, Callable, Mapping
from dataclasses import dataclass

from pydantic import JsonValue

from areal_agent_runtime.contracts.base import require_media_type, require_optional_trimmed
from areal_agent_runtime.contracts.content import AssetLocator, AssetRef
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.kernel.asset_context import get_asset_write_context

_BACKEND_NAME = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$")
_ROUTED_ID_PREFIX = "aroute_v1_"
_MAX_ROUTED_ID_BYTES = 16 * 1024


@dataclass(frozen=True, slots=True)
class AssetRoutingRule:
    """One trusted first-match rule; None fields match every value.

    ``media_type`` supports an exact MIME type or a major-type wildcard such
    as ``image/*``. Context fields are exact identities, never code, globs,
    endpoints or model-supplied metadata.
    """

    backend: str
    run_id: str | None = None
    profile_id: str | None = None
    agent_id: str | None = None
    media_type: str | None = None

    def __post_init__(self) -> None:
        _require_backend_name(self.backend)
        for name in ("run_id", "profile_id", "agent_id"):
            _require_context_identity(getattr(self, name), f"Asset routing {name}")
        if self.media_type is not None:
            require_media_type(self.media_type)
            if ";" in self.media_type or (
                "*" in self.media_type and not re.fullmatch(r"[a-zA-Z0-9.+-]+/\*", self.media_type)
            ):
                raise ValueError("Asset routing media_type must be an exact MIME type or major-type wildcard")

    def matches(self, context: Mapping[str, str | None], media_type: str) -> bool:
        if any(
            expected is not None and context.get(name) != expected
            for name in ("run_id", "profile_id", "agent_id")
            if (expected := getattr(self, name)) is not None
        ):
            return False
        if self.media_type is None:
            return True
        actual = media_type.split(";", 1)[0].strip().lower()
        expected_media = self.media_type.lower()
        return (actual.startswith(expected_media[:-1]) if expected_media.endswith("/*") else actual == expected_media)


class RoutingAssetStore:
    """One AssetStore for all consumers, with stable backend-qualified IDs.

    Backends and rules are trusted deployment configuration. Only the supplied
    framework context provider can select a rule; ``put`` metadata never does.
    Bindings must keep their names across restart. Reading an issued ID ignores
    current write rules, allowing another agent to read a referenced asset.
    Identical puts are idempotent within the same routing context and rule set.

    Stable framework context becomes protected ``metadata.arealRuntime``
    provenance before writing. Callers cannot override these fields. The
    default backend also keeps pre-router, unqualified asset IDs readable;
    ``legacy_backend`` can pin that compatibility route separately.
    """

    def __init__(
        self,
        backends: Mapping[str, AssetStorePort],
        *,
        default_backend: str,
        rules: tuple[AssetRoutingRule, ...] = (),
        context_provider: Callable[[], Mapping[str, str | None] | None] | None = None,
        legacy_backend: str | None = None,
    ) -> None:
        self._backends = dict(backends)
        if not self._backends:
            raise ValueError("Asset routing requires at least one backend")
        for name, backend in self._backends.items():
            _require_backend_name(name)
            if not isinstance(backend, AssetStorePort):
                raise TypeError(f"Asset backend {name!r} must implement AssetStorePort")
        if default_backend not in self._backends:
            raise ValueError("Asset default_backend must name a configured backend")
        if legacy_backend is not None and legacy_backend not in self._backends:
            raise ValueError("Asset legacy_backend must name a configured backend")
        if not isinstance(rules, tuple) or any(not isinstance(rule, AssetRoutingRule) for rule in rules):
            raise TypeError("Asset rules must be a tuple of AssetRoutingRule values")
        if any(rule.backend not in self._backends for rule in rules):
            raise ValueError("Asset routing rules must name configured backends")
        if context_provider is not None and not callable(context_provider):
            raise TypeError("Asset context_provider must be callable")
        self._default_backend = default_backend
        self._legacy_backend = legacy_backend or default_backend
        self._rules = rules
        self._context_provider = context_provider or get_asset_write_context

    async def put(
        self,
        chunks: AsyncIterator[bytes],
        *,
        media_type: str,
        metadata: dict[str, JsonValue] | None = None,
    ) -> AssetRef:
        require_media_type(media_type)
        context = self._context_provider()
        if context is not None and not isinstance(context, Mapping):
            raise TypeError("Asset routing context must be a mapping")
        context = dict(context or {})
        for name in ("run_id", "profile_id", "agent_id"):
            _require_context_identity(context.get(name), f"Asset context {name}")
        provenance: dict[str, JsonValue] = {
            name: context[name] for name in ("run_id", "profile_id", "agent_id") if context.get(name) is not None
        }
        stored_metadata = dict(metadata or {})
        if provenance:
            stored_metadata["arealRuntime"] = provenance
        backend_name = next(
            (rule.backend for rule in self._rules if rule.matches(context, media_type)),
            self._default_backend,
        )
        ref = await self._backends[backend_name].put(chunks, media_type=media_type, metadata=stored_metadata)
        if not isinstance(ref, AssetRef) or ref.media_type != media_type or ref.metadata != stored_metadata:
            raise ValueError(f"Asset backend {backend_name!r} returned an inconsistent descriptor")
        ref = AssetRef.model_validate(ref)
        return self._qualified_ref(backend_name, ref)

    async def get(self, asset_id: str) -> AssetRef | None:
        route = self._read_route(asset_id)
        if route is None:
            return None
        backend_name, local_id, qualified = route
        ref = await self._backends[backend_name].get(local_id)
        if ref is None:
            return None
        if not isinstance(ref, AssetRef) or ref.asset_id != local_id:
            raise ValueError(f"Asset backend {backend_name!r} returned a descriptor for another asset")
        ref = AssetRef.model_validate(ref)
        return self._qualified_ref(backend_name, ref) if qualified else ref

    async def open(self, asset_id: str) -> AsyncIterator[bytes]:
        route = self._read_route(asset_id)
        if route is None:
            raise FileNotFoundError(f"Unknown routed asset: {asset_id}")
        backend_name, local_id, _qualified = route
        stream = self._backends[backend_name].open(local_id)
        try:
            async for chunk in stream:
                if not isinstance(chunk, bytes):
                    raise TypeError("AssetStore.open() must yield bytes")
                yield chunk
        finally:
            close = getattr(stream, "aclose", None)
            if callable(close):
                await close()

    async def resolve(self, asset_id: str, *, ttl_seconds: int = 300) -> str:
        if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int) or ttl_seconds < 1:
            raise ValueError("ttl_seconds must be a positive integer")
        route = self._read_route(asset_id)
        if route is None:
            raise FileNotFoundError(f"Unknown routed asset: {asset_id}")
        backend_name, local_id, _qualified = route
        locator = await self._backends[backend_name].resolve(local_id, ttl_seconds=ttl_seconds)
        return f"asset://{asset_id}" if locator == f"asset://{local_id}" else locator

    @staticmethod
    def _qualified_ref(backend_name: str, ref: AssetRef) -> AssetRef:
        payload = json.dumps([backend_name, ref.asset_id], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(payload) > _MAX_ROUTED_ID_BYTES:
            raise ValueError("Asset backend returned an assetId too large for routing")
        encoded = base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")
        asset_id = f"{_ROUTED_ID_PREFIX}{encoded}"
        return ref.model_copy(update={"asset_id": asset_id, "locator": AssetLocator(value=asset_id)})

    def _read_route(self, asset_id: str) -> tuple[str, str, bool] | None:
        if not isinstance(asset_id, str) or not asset_id or asset_id != asset_id.strip():
            raise ValueError("assetId must be a trimmed non-empty string")
        if not asset_id.startswith(_ROUTED_ID_PREFIX):
            return (self._legacy_backend, asset_id, False) if self._legacy_backend is not None else None
        encoded = asset_id[len(_ROUTED_ID_PREFIX):]
        if len(encoded) > (_MAX_ROUTED_ID_BYTES + 2) // 3 * 4 or not re.fullmatch(r"[A-Za-z0-9_-]+", encoded):
            raise ValueError("Malformed routed assetId")
        try:
            payload = base64.b64decode(encoded + "=" * (-len(encoded) % 4), altchars=b"-_", validate=True)
            route = json.loads(payload)
        except (binascii.Error, UnicodeError, ValueError, RecursionError) as exc:
            raise ValueError("Malformed routed assetId") from exc
        if (
            not isinstance(route, list) or len(route) != 2
            or any(not isinstance(value, str) or not value or value != value.strip() for value in route)
        ):
            raise ValueError("Malformed routed assetId")
        backend_name, local_id = route
        _require_backend_name(backend_name)
        require_optional_trimmed(local_id, "Asset routing local assetId")
        canonical = base64.urlsafe_b64encode(
            json.dumps(route, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        ).decode("ascii").rstrip("=")
        if canonical != encoded:
            raise ValueError("Non-canonical routed assetId")
        if backend_name not in self._backends:
            raise FileNotFoundError(f"Asset backend is no longer configured: {backend_name}")
        return backend_name, local_id, True


def _require_backend_name(value: str) -> None:
    if not isinstance(value, str) or _BACKEND_NAME.fullmatch(value) is None:
        raise ValueError("Asset backend names must be 1-64 letters, digits, dots, dashes or underscores")


def _require_context_identity(value: object, name: str) -> None:
    if value is not None and not isinstance(value, str):
        raise TypeError(f"{name} must be a string or None")
    require_optional_trimmed(value, name)
