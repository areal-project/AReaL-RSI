"""Public protocol version identifiers."""

from typing import Literal

ProductApiVersion = Literal["areal.agent-runtime.product/v1"]
RuntimeApiVersion = Literal["areal.agent-runtime.runtime/v1"]
EventApiVersion = Literal["areal.agent-runtime.event/v1"]
PluginApiVersion = Literal["areal.agent-runtime.plugin/v1"]
RuntimeWireApiVersion = Literal["areal.agent-runtime.runtime-wire/v1"]
DataApiVersion = Literal["areal.agent-runtime.data/v1"]

PRODUCT_API_VERSION: ProductApiVersion = "areal.agent-runtime.product/v1"
RUNTIME_API_VERSION: RuntimeApiVersion = "areal.agent-runtime.runtime/v1"
EVENT_API_VERSION: EventApiVersion = "areal.agent-runtime.event/v1"
PLUGIN_API_VERSION: PluginApiVersion = "areal.agent-runtime.plugin/v1"
RUNTIME_WIRE_API_VERSION: RuntimeWireApiVersion = "areal.agent-runtime.runtime-wire/v1"
DATA_API_VERSION: DataApiVersion = "areal.agent-runtime.data/v1"
