"""ARealAgentRuntime Plugin SPI packaging for the Claude Agent SDK adapter."""

from __future__ import annotations

import math
import re
from typing import Any, Literal, cast

from pydantic import JsonValue

from areal_agent_runtime.adapters._asset_io import DEFAULT_MAX_RUNTIME_ASSET_BYTES
from areal_agent_runtime.adapters.claude_sdk.runtime import ClaudeAgentSDKRuntimeAdapter
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import (
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)


class ClaudeAgentSDKRuntimePlugin:
    runtime_class = ClaudeAgentSDKRuntimeAdapter
    manifest = PluginManifest(
        name="claude-agent-sdk-runtime",
        version="1.1.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.claude_sdk.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("process.spawn", "workspace.read", "workspace.write", "network.model"),
        metadata={"areal.agent-runtime.bootstrap.profileBinding": True},
    )

    def __init__(self) -> None:
        self.runtime: ClaudeAgentSDKRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        options = _options(config)
        binding = config.get("profileBinding", "auto")
        if not isinstance(binding, str) or binding not in {"auto", "portable", "runtime-owned"}:
            raise ValueError("profileBinding must be auto, runtime-owned or portable")
        bridge = _boolean(config.get("applicationToolBridge"), default=binding == "portable")
        if binding == "auto":
            binding = "portable" if bridge else "runtime-owned"
        self.runtime = self.runtime_class(
            asset_store=_optional_asset_store(context),
            base_options=options,
            application_tool_bridge=bridge,
            tool_policy_mode=cast(Literal["portable", "runtime-owned"], binding),
            max_concurrency=_positive_integer(
                config.get("maxConcurrency"),
                default=8,
                field_name="maxConcurrency",
            ),
            max_input_asset_bytes=_positive_integer(
                config.get("maxInputAssetBytes"),
                default=DEFAULT_MAX_RUNTIME_ASSET_BYTES,
                field_name="maxInputAssetBytes",
            ),
            tool_bridge_call_timeout_seconds=_positive_float(
                config.get("toolBridgeCallTimeoutSeconds"),
                default=120.0,
                field_name="toolBridgeCallTimeoutSeconds",
            ),
            tool_bridge_max_concurrency=_positive_integer(
                config.get("toolBridgeMaxConcurrency"),
                default=16,
                field_name="toolBridgeMaxConcurrency",
            ),
        )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Claude Agent SDK plugin is not configured")
        health = await self.runtime.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "Claude Agent SDK unavailable"))

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> ClaudeAgentSDKRuntimePlugin:
    return ClaudeAgentSDKRuntimePlugin()


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _options(config: dict[str, JsonValue]) -> object:
    try:
        from claude_agent_sdk import ClaudeAgentOptions
    except ImportError as exc:  # pragma: no cover - optional dependency failure
        raise RuntimeError("Install areal-agent-runtime[claude] to load this plugin") from exc

    kwargs: dict[str, Any] = {}
    thinking = config.get("thinking")
    if thinking is not None:
        if not isinstance(thinking, dict) or set(thinking).difference({"type", "budget_tokens", "display"}):
            raise ValueError("thinking must be a native SDK thinking configuration")
        mode = thinking.get("type")
        if not isinstance(mode, str) or mode not in {"disabled", "adaptive", "enabled"}:
            raise ValueError("thinking.type must be disabled, adaptive or enabled")
        if mode == "enabled":
            budget = thinking.get("budget_tokens")
            if isinstance(budget, bool) or not isinstance(budget, int) or budget < 1:
                raise ValueError("enabled thinking requires positive integer budget_tokens")
        elif "budget_tokens" in thinking:
            raise ValueError("thinking.budget_tokens requires type enabled")
        display = thinking.get("display")
        if "display" in thinking and (not isinstance(display, str) or display not in {"summarized", "omitted"}):
            raise ValueError("thinking.display must be summarized or omitted")
        if mode == "disabled" and "display" in thinking:
            raise ValueError("disabled thinking does not accept display")
        kwargs["thinking"] = dict(thinking)
    for source, target in {"cliPath": "cli_path", "model": "model"}.items():
        value = config.get(source)
        if value is not None:
            if not isinstance(value, str) or not value or value != value.strip() or "\0" in value:
                raise ValueError(f"{source} must be a non-blank, trimmed string")
            kwargs[target] = value
    tools = config.get("tools")
    if tools is not None:
        if tools == "default":
            kwargs["tools"] = {"type": "preset", "preset": "claude_code"}
        elif isinstance(tools, list) and all(isinstance(item, str) and item and item == item.strip() for item in tools):
            kwargs["tools"] = tools
        else:
            raise ValueError("tools must be 'default' or a list of native tool names")
    plugins = config.get("plugins")
    if plugins is not None:
        if not isinstance(plugins, list) or any(
            not isinstance(item, str) or not item or item != item.strip() or "\0" in item for item in plugins
        ):
            raise ValueError("plugins must be a list of local plugin directory paths")
        kwargs["plugins"] = [{"type": "local", "path": path} for path in plugins]
    permission_mode = config.get("permissionMode")
    if permission_mode is not None:
        if permission_mode not in {
            "default",
            "acceptEdits",
            "plan",
            "bypassPermissions",
            "dontAsk",
            "auto",
        }:
            raise ValueError("permissionMode is not supported by the Claude Agent SDK adapter")
        kwargs["permission_mode"] = permission_mode
    settings = config.get("settings")
    if settings is not None:
        if (
            not isinstance(settings, str)
            or not settings
            or settings != settings.strip()
            or "\x00" in settings
        ):
            raise ValueError("settings must be a non-blank, trimmed string")
        kwargs["settings"] = settings
    max_turns = config.get("maxTurns")
    if max_turns is not None:
        kwargs["max_turns"] = _positive_integer(
            max_turns,
            default=1,
            field_name="maxTurns",
        )
    max_budget = config.get("maxBudgetUsd")
    if max_budget is not None:
        kwargs["max_budget_usd"] = _positive_float(
            max_budget,
            default=1.0,
            field_name="maxBudgetUsd",
        )
    effort = config.get("effort")
    if effort is not None:
        if effort not in {"low", "medium", "high", "xhigh", "max"}:
            raise ValueError("effort is not supported by the Claude Agent SDK adapter")
        kwargs["effort"] = effort
    string_lists: dict[str, list[str]] = {}
    for source, target in {
        "allowedTools": "allowed_tools",
        "disallowedTools": "disallowed_tools",
        "settingSources": "setting_sources",
        "skills": "skills",
    }.items():
        value = config.get(source)
        if value is None:
            continue
        if source == "skills" and value == "all":
            kwargs[target] = "all"
            continue
        if not isinstance(value, list) or any(
            not isinstance(item, str)
            or not item
            or item != item.strip()
            or "\x00" in item
            for item in value
        ):
            raise ValueError(f"{source} must be a list of non-blank, trimmed strings")
        if len(value) != len(set(value)):
            raise ValueError(f"{source} must not contain duplicates")
        string_lists[source] = [cast(str, item) for item in value]
        kwargs[target] = string_lists[source]
    allowed = set(string_lists.get("allowedTools", ()))
    disallowed = set(string_lists.get("disallowedTools", ()))
    overlap = sorted(allowed.intersection(disallowed))
    if overlap:
        raise ValueError("allowedTools and disallowedTools overlap: " + ", ".join(overlap))
    env = config.get("env")
    if env is not None:
        if not isinstance(env, dict):
            raise ValueError("env must be an object containing string values")
        normalized_env: dict[str, str] = {}
        for key, item in env.items():
            if not isinstance(key, str) or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) is None:
                raise ValueError("env keys must be portable environment variable names")
            if not isinstance(item, str) or "\x00" in item:
                raise ValueError("env values must be strings without NUL bytes")
            normalized_env[key] = item
        kwargs["env"] = normalized_env
    return ClaudeAgentOptions(**kwargs)


def _boolean(value: JsonValue | None, *, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise ValueError("applicationToolBridge must be a boolean")
    return value


def _positive_float(
    value: JsonValue | None,
    *,
    default: float,
    field_name: str,
) -> float:
    if value is None:
        return default
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise ValueError(f"{field_name} must be a positive number")
    return float(value)


def _positive_integer(
    value: JsonValue | None,
    *,
    default: int,
    field_name: str,
) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value
