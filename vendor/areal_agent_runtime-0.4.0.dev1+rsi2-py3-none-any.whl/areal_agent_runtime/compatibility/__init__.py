"""Compatibility projections kept outside the canonical domain contracts."""

from areal_agent_runtime.compatibility.v1 import (
    DATA_AWARE_RUNTIME_CLIENT_NAME,
    LEGACY_RUNTIME_CLIENT_NAME,
    dump_event_api_v1,
    dump_product_run_snapshot_v1,
    dump_runtime_descriptor_v1,
    dump_runtime_event_v1,
    runtime_client_supports_data_v1,
)

__all__ = [
    "DATA_AWARE_RUNTIME_CLIENT_NAME",
    "LEGACY_RUNTIME_CLIENT_NAME",
    "dump_event_api_v1",
    "dump_product_run_snapshot_v1",
    "dump_runtime_descriptor_v1",
    "dump_runtime_event_v1",
    "runtime_client_supports_data_v1",
]
