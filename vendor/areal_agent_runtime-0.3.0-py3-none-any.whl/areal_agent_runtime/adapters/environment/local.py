"""Mounted/local workspace EnvironmentPort reference implementation."""

from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import math
import os
import shutil
import stat
import tarfile
import tempfile
import weakref
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from areal_agent_runtime.contracts.ports import (
    EnvironmentRef,
    EnvironmentSpec,
    WorkspaceCheckpoint,
)
from areal_agent_runtime.contracts.runtime import HealthStatus, WorkspaceRef
from areal_agent_runtime.kernel.ids import new_id

_DIRECTORY_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
_FILE_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)


@dataclass(frozen=True, slots=True)
class _WorkspaceEntry:
    relative: PurePosixPath
    metadata: os.stat_result


@dataclass(frozen=True, slots=True)
class _WorkspaceScan:
    root_metadata: os.stat_result
    entries: tuple[_WorkspaceEntry, ...]


class LocalEnvironmentAdapter:
    def __init__(
        self,
        root: str | Path,
        *,
        allow_external_mounts: bool = False,
        allowed_external_mount_roots: tuple[str | Path, ...] = (),
        lease_timeout_seconds: float = 30.0,
        max_workspace_entries: int = 100_000,
        max_workspace_bytes: int = 2 * 1024 * 1024 * 1024,
    ) -> None:
        self._root = Path(root).expanduser().resolve()
        self._workspaces = self._root / "workspaces"
        self._checkpoints = self._root / "checkpoints"
        self._leases = self._root / "leases"
        self._overlays_root = self._root / "overlays"
        self._allow_external_mounts = allow_external_mounts
        self._allowed_external_mount_roots = tuple(
            Path(path).expanduser().resolve() for path in allowed_external_mount_roots
        )
        if not isinstance(allow_external_mounts, bool):
            raise ValueError("allow_external_mounts must be a boolean")
        if (
            isinstance(lease_timeout_seconds, bool)
            or not isinstance(lease_timeout_seconds, (int, float))
            or not math.isfinite(lease_timeout_seconds)
            or lease_timeout_seconds <= 0
        ):
            raise ValueError("lease_timeout_seconds must be a finite positive number")
        self._lease_timeout_seconds = lease_timeout_seconds
        for name, value in (
            ("max_workspace_entries", max_workspace_entries),
            ("max_workspace_bytes", max_workspace_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        self._max_workspace_entries = max_workspace_entries
        self._max_workspace_bytes = max_workspace_bytes
        self._environments: dict[str, EnvironmentRef] = {}
        self._workspace_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._environment_locks: dict[str, asyncio.Lock] = {}
        self._operation_locks: dict[str, asyncio.Lock] = {}
        self._lease_handles: dict[str, int] = {}
        self._overlay_namespaces: dict[str, Path] = {}
        self._overlay_views: dict[tuple[str, str], tuple[WorkspaceRef, dict[str, str]]] = {}
        self._merged_overlay_views: set[tuple[str, str]] = set()
        self._max_baseline_bytes = max(
            1024 * 1024,
            min(128 * 1024 * 1024, max_workspace_entries * 1024),
        )
        self._workspaces.mkdir(parents=True, exist_ok=True)
        self._checkpoints.mkdir(parents=True, exist_ok=True)
        self._leases.mkdir(parents=True, exist_ok=True)
        self._overlays_root.mkdir(parents=True, exist_ok=True)

    async def open(self, spec: EnvironmentSpec) -> EnvironmentRef:
        mount = self._resolve_mount(spec.workspace)
        lock = self._workspace_locks.setdefault(str(mount), asyncio.Lock())
        await lock.acquire()
        lease_handle: int | None = None
        try:
            lease_handle = await self._acquire_file_lease(mount)
            await asyncio.to_thread(mount.mkdir, parents=True, exist_ok=True)
            environment = EnvironmentRef(
                environment_id=new_id("environment"),
                workspace=spec.workspace.model_copy(update={"mount_hint": str(mount)}),
            )
            self._environments[environment.environment_id] = environment
            self._environment_locks[environment.environment_id] = lock
            self._operation_locks[environment.environment_id] = asyncio.Lock()
            self._lease_handles[environment.environment_id] = lease_handle
            run_id = spec.metadata.get("runId")
            if run_id is not None and (not isinstance(run_id, str) or not run_id or run_id != run_id.strip()):
                raise ValueError("Environment metadata runId must be a trimmed non-empty string")
            overlay_identity = (
                f"run:{run_id}\x00workspace:{environment.workspace.workspace_id}\x00mount:{mount}"
                if isinstance(run_id, str) and run_id
                else (
                    f"environment:{environment.environment_id}"
                    f"\x00workspace:{environment.workspace.workspace_id}\x00mount:{mount}"
                )
            )
            namespace = hashlib.sha256(overlay_identity.encode("utf-8")).hexdigest()
            overlay_namespace = self._overlays_root / namespace
            if overlay_namespace in self._overlay_namespaces.values():
                raise RuntimeError("An active Environment already owns this overlay namespace")
            self._overlay_namespaces[environment.environment_id] = overlay_namespace
            return environment
        except BaseException:
            if "environment" in locals():
                self._environments.pop(environment.environment_id, None)
                self._environment_locks.pop(environment.environment_id, None)
                self._operation_locks.pop(environment.environment_id, None)
                self._lease_handles.pop(environment.environment_id, None)
                self._overlay_namespaces.pop(environment.environment_id, None)
            if lease_handle is not None:
                self._release_file_lease(lease_handle)
            lock.release()
            raise

    async def checkpoint(self, environment: EnvironmentRef) -> WorkspaceCheckpoint:
        lock = self._get_operation_lock(environment.environment_id)
        async with lock:
            current = self._require_environment(environment)
            assert current.workspace.mount_hint is not None
            workspace = Path(current.workspace.mount_hint)
            checkpoint_id = new_id("checkpoint")
            target = self._checkpoints / f"{checkpoint_id}.tar.gz"
            try:
                await asyncio.to_thread(self._archive, workspace, target)
                digest = await asyncio.to_thread(self._sha256, target)
            except BaseException:
                await asyncio.to_thread(target.unlink, missing_ok=True)
                raise
            return WorkspaceCheckpoint(
                checkpoint_id=checkpoint_id,
                workspace_id=current.workspace.workspace_id,
                digest=digest,
                locator=target.as_uri(),
            )

    async def open_workspace_view(self, environment: EnvironmentRef, agent_id: str) -> WorkspaceRef:
        """Create one copy-on-start overlay inside an existing EnvironmentLease."""

        self._validate_agent_id(agent_id)
        lock = self._get_operation_lock(environment.environment_id)
        async with lock:
            current = self._require_environment(environment)
            assert current.workspace.mount_hint is not None
            key = (environment.environment_id, agent_id)
            existing = self._overlay_views.get(key)
            if existing is not None:
                return existing[0]
            source = Path(current.workspace.mount_hint)
            target, baseline_path = self._overlay_paths(environment.environment_id, agent_id)
            if key in self._merged_overlay_views:
                await asyncio.to_thread(self._remove_overlay_files, target, baseline_path)
                self._merged_overlay_views.remove(key)
            baseline = await asyncio.to_thread(
                self._load_or_create_overlay,
                source,
                target,
                baseline_path,
            )
            view = WorkspaceRef(
                workspace_id=f"{current.workspace.workspace_id}@overlay:{agent_id}",
                mount_hint=str(target),
            )
            self._overlay_views[key] = (view, baseline)
            return view

    async def merge_workspace_views(
        self,
        environment: EnvironmentRef,
        agent_ids: tuple[str, ...],
    ) -> None:
        """Merge explicitly named overlays, rejecting divergent file writes."""

        self._validate_agent_ids(agent_ids)
        lock = self._get_operation_lock(environment.environment_id)
        async with lock:
            current = self._require_environment(environment)
            await asyncio.to_thread(self._merge_workspace_views, current, agent_ids)

    async def close(self, environment: EnvironmentRef) -> None:
        await self._close(environment, preserve_overlays=False)

    async def close_for_recovery(self, environment: EnvironmentRef) -> None:
        """Release leases while retaining durable overlay views for Run recovery."""

        await self._close(environment, preserve_overlays=True)

    async def _close(self, environment: EnvironmentRef, *, preserve_overlays: bool) -> None:
        operation_lock = self._operation_locks.get(environment.environment_id)
        if operation_lock is None:
            return
        async with operation_lock:
            if self._environments.get(environment.environment_id) is None:
                return
            self._require_environment(environment)
            self._environments.pop(environment.environment_id, None)
            overlay_keys = [key for key in self._overlay_views if key[0] == environment.environment_id]
            for key in overlay_keys:
                self._overlay_views.pop(key, None)
            merged_keys = {key for key in self._merged_overlay_views if key[0] == environment.environment_id}
            self._merged_overlay_views.difference_update(merged_keys)
            overlay_root = self._overlay_namespaces.pop(environment.environment_id, None)
            try:
                if not preserve_overlays and overlay_root is not None and overlay_root.exists():
                    await asyncio.to_thread(shutil.rmtree, overlay_root)
            finally:
                # Cleanup failure must never strand the cross-process lease or the
                # in-process workspace mutex.  Callers may still observe the
                # overlay deletion error, but another Run can safely make progress.
                lease_handle = self._lease_handles.pop(environment.environment_id, None)
                try:
                    if lease_handle is not None:
                        self._release_file_lease(lease_handle)
                finally:
                    lock = self._environment_locks.pop(environment.environment_id, None)
                    if lock is not None and lock.locked():
                        lock.release()
                    self._operation_locks.pop(environment.environment_id, None)

    def _get_operation_lock(self, environment_id: str) -> asyncio.Lock:
        try:
            return self._operation_locks[environment_id]
        except KeyError as exc:
            raise ValueError(f"Environment is not open: {environment_id}") from exc

    def _require_environment(self, environment: EnvironmentRef) -> EnvironmentRef:
        current = self._environments.get(environment.environment_id)
        if current is None or not current.workspace.mount_hint:
            raise ValueError(f"Environment is not open: {environment.environment_id}")
        if current != environment:
            raise ValueError(f"Environment handle does not match the active lease: {environment.environment_id}")
        return current

    @staticmethod
    def _validate_agent_id(agent_id: str) -> None:
        if not isinstance(agent_id, str) or not agent_id or agent_id != agent_id.strip():
            raise ValueError("agentId must be a trimmed non-empty string")

    @classmethod
    def _validate_agent_ids(cls, agent_ids: tuple[str, ...]) -> None:
        if not isinstance(agent_ids, tuple):
            raise TypeError("agent_ids must be a tuple")
        for agent_id in agent_ids:
            cls._validate_agent_id(agent_id)
        if len(agent_ids) != len(set(agent_ids)):
            raise ValueError("agent_ids must not contain duplicates")

    async def health(self) -> HealthStatus:
        writable = self._root.exists() and os.access(self._root, os.W_OK)
        return HealthStatus(
            status="healthy" if writable else "unhealthy",
            details={"root": str(self._root), "writable": writable},
        )

    def _resolve_mount(self, workspace: WorkspaceRef) -> Path:
        if workspace.mount_hint:
            requested = Path(workspace.mount_hint).expanduser().resolve()
            allowed = requested.is_relative_to(self._workspaces) or any(
                requested == root or requested.is_relative_to(root) for root in self._allowed_external_mount_roots
            )
            if not self._allow_external_mounts and not allowed:
                raise PermissionError("External workspace mountHint is not allowed")
            return requested
        safe = hashlib.sha256(workspace.workspace_id.encode("utf-8")).hexdigest()
        return self._workspaces / safe

    async def _acquire_file_lease(self, mount: Path) -> int:
        identity = hashlib.sha256(str(mount).encode("utf-8")).hexdigest()
        path = self._leases / f"{identity}.lock"
        handle = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            async with asyncio.timeout(self._lease_timeout_seconds):
                while True:
                    try:
                        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        return handle
                    except BlockingIOError:
                        await asyncio.sleep(0.05)
        except BaseException:
            os.close(handle)
            raise

    @staticmethod
    def _release_file_lease(handle: int) -> None:
        try:
            fcntl.flock(handle, fcntl.LOCK_UN)
        finally:
            os.close(handle)

    def _archive(self, workspace: Path, target: Path) -> None:
        scan = self._workspace_entries(workspace)
        descriptor, temporary_name = tempfile.mkstemp(prefix="checkpoint-", dir=target.parent)
        os.close(descriptor)
        temporary = Path(temporary_name)
        root_descriptor: int | None = None
        try:
            root_descriptor = self._open_workspace_root(workspace, scan.root_metadata)
            with tarfile.open(temporary, "w:gz") as archive:
                for entry in scan.entries:
                    entry_descriptor = self._open_workspace_entry(root_descriptor, entry)
                    try:
                        current = os.fstat(entry_descriptor)
                        info = self._tar_info(entry.relative, current)
                        if stat.S_ISDIR(current.st_mode):
                            archive.addfile(info)
                        else:
                            with os.fdopen(entry_descriptor, "rb", closefd=False) as source:
                                archive.addfile(info, source)
                            self._require_stable_entry(
                                entry_descriptor,
                                current,
                                entry.relative,
                            )
                    finally:
                        os.close(entry_descriptor)
            with temporary.open("rb") as handle:
                os.fsync(handle.fileno())
            os.replace(temporary, target)
            directory = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
        finally:
            if root_descriptor is not None:
                os.close(root_descriptor)

    def _copy_tree(self, source: Path, target: Path) -> None:
        scan = self._workspace_entries(source)
        target.mkdir(parents=True, exist_ok=False, mode=0o700)
        root_descriptor = self._open_workspace_root(source, scan.root_metadata)
        directory_modes: list[tuple[Path, int]] = []
        try:
            for entry in scan.entries:
                destination = target.joinpath(*entry.relative.parts)
                source_descriptor = self._open_workspace_entry(root_descriptor, entry)
                try:
                    current = os.fstat(source_descriptor)
                    if stat.S_ISDIR(current.st_mode):
                        destination.mkdir(parents=True, exist_ok=True)
                        directory_modes.append((destination, stat.S_IMODE(current.st_mode) & 0o777))
                        continue
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    output_descriptor = os.open(
                        destination,
                        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                        0o600,
                    )
                    try:
                        with (
                            os.fdopen(source_descriptor, "rb", closefd=False) as input_handle,
                            os.fdopen(output_descriptor, "wb", closefd=False) as output_handle,
                        ):
                            shutil.copyfileobj(input_handle, output_handle, length=1024 * 1024)
                            output_handle.flush()
                            os.fsync(output_handle.fileno())
                        self._require_stable_entry(
                            source_descriptor,
                            current,
                            entry.relative,
                        )
                        os.fchmod(output_descriptor, stat.S_IMODE(current.st_mode) & 0o777)
                    finally:
                        os.close(output_descriptor)
                finally:
                    os.close(source_descriptor)
            for directory, mode in sorted(
                directory_modes,
                key=lambda item: len(item[0].parts),
                reverse=True,
            ):
                os.chmod(directory, mode)
        finally:
            os.close(root_descriptor)

    def _merge_workspace_views(self, environment: EnvironmentRef, agent_ids: tuple[str, ...]) -> None:
        base = Path(environment.workspace.mount_hint or "")
        # before digest, after digest, source root, agent id, source size
        changes: dict[str, tuple[str | None, str | None, Path | None, str, int]] = {}
        registrations: list[tuple[tuple[str, str], WorkspaceRef]] = []
        for agent_id in agent_ids:
            key = (environment.environment_id, agent_id)
            registered = self._overlay_views.get(key)
            if registered is None:
                target, baseline_path = self._overlay_paths(environment.environment_id, agent_id)
                try:
                    baseline = self._read_baseline(baseline_path)
                except (OSError, ValueError, json.JSONDecodeError) as exc:
                    raise ValueError(f"Overlay is not recoverable for agent: {agent_id}") from exc
                if not target.is_dir() or target.is_symlink():
                    raise ValueError(f"Overlay is not recoverable for agent: {agent_id}")
                view = WorkspaceRef(
                    workspace_id=f"{environment.workspace.workspace_id}@overlay:{agent_id}",
                    mount_hint=str(target),
                )
                registered = (view, baseline)
                self._overlay_views[key] = registered
            view, baseline = registered
            overlay = Path(view.mount_hint or "")
            overlay_scan = self._workspace_entries(overlay)
            current = self._hash_workspace_scan(overlay, overlay_scan)
            sizes = {
                entry.relative.as_posix(): entry.metadata.st_size
                for entry in overlay_scan.entries
                if stat.S_ISREG(entry.metadata.st_mode)
            }
            for relative in sorted(set(baseline).union(current)):
                before = baseline.get(relative)
                after = current.get(relative)
                if before == after:
                    continue
                previous = changes.get(relative)
                if previous is not None and (previous[0] != before or previous[1] != after):
                    raise RuntimeError(f"Overlay merge conflict for {relative}: {previous[3]} and {agent_id}")
                source_root = overlay if after is not None else None
                changes[relative] = (
                    before,
                    after,
                    source_root,
                    agent_id,
                    sizes.get(relative, 0),
                )
            registrations.append((key, view))

        base_scan = self._workspace_entries(base)
        base_hashes = self._hash_workspace_scan(base, base_scan)
        self._validate_projected_workspace(base_scan, base_hashes, changes)
        for relative, (before, after, source_root, agent_id, _source_size) in sorted(changes.items()):
            relative_path = PurePosixPath(relative)
            observed = self._relative_digest(base, relative_path)
            if observed == after:
                continue
            if observed != before:
                raise RuntimeError(f"Base workspace changed after overlay fork for {relative}: {agent_id}")
            if after is None:
                self._delete_relative_file(base, relative_path, expected_digest=before)
            else:
                assert source_root is not None
                self._copy_relative_atomic(
                    source_root,
                    base,
                    relative_path,
                    expected_source_digest=after,
                    expected_destination_digest=before,
                )
        # Keep durable overlay files until Environment close. This makes a
        # process-level retry after a partially applied merge idempotent and
        # avoids turning post-commit garbage collection failure into data loss.
        for key, _view in registrations:
            self._overlay_views.pop(key, None)
            self._merged_overlay_views.add(key)

    def _overlay_paths(self, environment_id: str, agent_id: str) -> tuple[Path, Path]:
        try:
            namespace = self._overlay_namespaces[environment_id]
        except KeyError as exc:
            raise ValueError(f"Environment is not open: {environment_id}") from exc
        safe_agent = hashlib.sha256(agent_id.encode("utf-8")).hexdigest()
        return namespace / safe_agent, namespace / f"{safe_agent}.baseline.json"

    def _load_or_create_overlay(
        self,
        source: Path,
        target: Path,
        baseline_path: Path,
    ) -> dict[str, str]:
        if target.is_dir() and not target.is_symlink() and baseline_path.is_file() and not baseline_path.is_symlink():
            baseline = self._read_baseline(baseline_path)
            self._tree_hashes(target)
            return baseline
        if target.exists() or target.is_symlink() or baseline_path.exists() or baseline_path.is_symlink():
            self._remove_overlay_files(target, baseline_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.parent / f".{target.name}.{new_id('overlay')}"
        try:
            self._copy_tree(source, temporary)
            baseline = self._tree_hashes(temporary)
            os.replace(temporary, target)
            try:
                self._write_baseline(baseline_path, baseline)
            except BaseException:
                shutil.rmtree(target, ignore_errors=True)
                raise
            return baseline
        except BaseException:
            if temporary.exists():
                shutil.rmtree(temporary, ignore_errors=True)
            raise

    @staticmethod
    def _write_baseline(path: Path, baseline: dict[str, str]) -> None:
        descriptor, temporary_name = tempfile.mkstemp(prefix="baseline-", dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(
                    baseline,
                    handle,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise

    def _read_baseline(self, path: Path) -> dict[str, str]:
        descriptor = os.open(path, _FILE_OPEN_FLAGS)
        try:
            details = os.fstat(descriptor)
            if not stat.S_ISREG(details.st_mode) or details.st_size > self._max_baseline_bytes:
                raise ValueError("overlay baseline is invalid or exceeds its size limit")
            raw = bytearray()
            while chunk := os.read(
                descriptor,
                min(64 * 1024, self._max_baseline_bytes + 1 - len(raw)),
            ):
                raw.extend(chunk)
                if len(raw) > self._max_baseline_bytes:
                    raise ValueError("overlay baseline exceeds its size limit")
        finally:
            os.close(descriptor)
        payload = json.loads(
            raw,
            object_pairs_hook=self._strict_object,
            parse_constant=self._reject_json_constant,
        )
        if (
            not isinstance(payload, dict)
            or any(
                not isinstance(key, str)
                or not key
                or "\\" in key
                or "\x00" in key
                or not PurePosixPath(key).parts
                or PurePosixPath(key).is_absolute()
                or ".." in PurePosixPath(key).parts
                or PurePosixPath(key).as_posix() != key
                or not isinstance(value, str)
                or len(value) != 64
                or any(character not in "0123456789abcdef" for character in value)
                for key, value in payload.items()
            )
            or len(payload) > self._max_workspace_entries
        ):
            raise ValueError("overlay baseline is invalid")
        return payload

    @staticmethod
    def _strict_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"overlay baseline contains duplicate key: {key}")
            result[key] = value
        return result

    @staticmethod
    def _reject_json_constant(value: str) -> object:
        raise ValueError(f"overlay baseline contains invalid JSON constant: {value}")

    @staticmethod
    def _remove_overlay_files(target: Path, baseline_path: Path) -> None:
        if target.is_symlink():
            target.unlink()
        elif target.exists():
            shutil.rmtree(target)
        baseline_path.unlink(missing_ok=True)

    def _tree_hashes(self, root: Path) -> dict[str, str]:
        scan = self._workspace_entries(root)
        return self._hash_workspace_scan(root, scan)

    def _workspace_entries(self, root: Path) -> _WorkspaceScan:
        try:
            root_metadata = os.lstat(root)
        except OSError as exc:
            raise ValueError(f"Workspace root cannot be inspected: {root}") from exc
        if stat.S_ISLNK(root_metadata.st_mode) or not stat.S_ISDIR(root_metadata.st_mode):
            raise ValueError(f"Workspace root must be a real directory: {root}")
        entries: list[_WorkspaceEntry] = []
        entry_count = 0
        total_bytes = 0

        def raise_walk_error(error: OSError) -> None:
            raise error

        for directory, names, filenames in os.walk(
            root,
            topdown=True,
            followlinks=False,
            onerror=raise_walk_error,
        ):
            directory_path = Path(directory)
            safe_directories: list[str] = []
            for name in sorted(names):
                path = directory_path / name
                metadata = os.lstat(path)
                entry_count += 1
                if entry_count > self._max_workspace_entries:
                    raise ValueError(f"Workspace exceeds max_workspace_entries={self._max_workspace_entries}")
                if stat.S_ISLNK(metadata.st_mode):
                    continue
                if not stat.S_ISDIR(metadata.st_mode):
                    raise ValueError(f"Unsupported workspace entry: {path.relative_to(root)}")
                safe_directories.append(name)
                entries.append(
                    _WorkspaceEntry(
                        relative=PurePosixPath(path.relative_to(root).as_posix()),
                        metadata=metadata,
                    )
                )
            names[:] = safe_directories
            for name in sorted(filenames):
                path = directory_path / name
                metadata = os.lstat(path)
                entry_count += 1
                if entry_count > self._max_workspace_entries:
                    raise ValueError(f"Workspace exceeds max_workspace_entries={self._max_workspace_entries}")
                if stat.S_ISLNK(metadata.st_mode):
                    continue
                if not stat.S_ISREG(metadata.st_mode):
                    raise ValueError(f"Unsupported workspace entry: {path.relative_to(root)}")
                total_bytes += metadata.st_size
                if total_bytes > self._max_workspace_bytes:
                    raise ValueError(f"Workspace exceeds max_workspace_bytes={self._max_workspace_bytes}")
                entries.append(
                    _WorkspaceEntry(
                        relative=PurePosixPath(path.relative_to(root).as_posix()),
                        metadata=metadata,
                    )
                )
        current_root = os.lstat(root)
        self._require_matching_metadata(root_metadata, current_root, PurePosixPath("."))
        return _WorkspaceScan(
            root_metadata=root_metadata,
            entries=tuple(sorted(entries, key=lambda entry: entry.relative.as_posix())),
        )

    @staticmethod
    def _sha256(path: Path) -> str:
        descriptor = os.open(path, _FILE_OPEN_FLAGS)
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise ValueError(f"Checkpoint is not a regular file: {path}")
            digest = LocalEnvironmentAdapter._sha256_descriptor(descriptor)
            LocalEnvironmentAdapter._require_stable_entry(
                descriptor,
                before,
                PurePosixPath(path.name),
            )
            return digest
        finally:
            os.close(descriptor)

    @staticmethod
    def _sha256_descriptor(descriptor: int) -> str:
        digest = hashlib.sha256()
        os.lseek(descriptor, 0, os.SEEK_SET)
        while chunk := os.read(descriptor, 1024 * 1024):
            digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _metadata_fingerprint(metadata: os.stat_result) -> tuple[int, int, int, int, int, int]:
        return (
            metadata.st_dev,
            metadata.st_ino,
            stat.S_IFMT(metadata.st_mode),
            metadata.st_size,
            metadata.st_mtime_ns,
            metadata.st_ctime_ns,
        )

    @classmethod
    def _require_matching_metadata(
        cls,
        expected: os.stat_result,
        current: os.stat_result,
        relative: PurePosixPath,
    ) -> None:
        if cls._metadata_fingerprint(expected) != cls._metadata_fingerprint(current):
            raise ValueError(f"Workspace entry changed during snapshot: {relative}")

    @classmethod
    def _require_stable_entry(
        cls,
        descriptor: int,
        expected: os.stat_result,
        relative: PurePosixPath,
    ) -> None:
        cls._require_matching_metadata(expected, os.fstat(descriptor), relative)

    @classmethod
    def _open_workspace_root(cls, root: Path, expected: os.stat_result) -> int:
        descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
        try:
            current = os.fstat(descriptor)
            if not stat.S_ISDIR(current.st_mode):
                raise ValueError(f"Workspace root must be a real directory: {root}")
            cls._require_matching_metadata(expected, current, PurePosixPath("."))
            return descriptor
        except BaseException:
            os.close(descriptor)
            raise

    @classmethod
    def _open_workspace_entry(cls, root_descriptor: int, entry: _WorkspaceEntry) -> int:
        descriptor = os.dup(root_descriptor)
        try:
            for index, part in enumerate(entry.relative.parts):
                is_final = index == len(entry.relative.parts) - 1
                flags = _FILE_OPEN_FLAGS if is_final and stat.S_ISREG(entry.metadata.st_mode) else _DIRECTORY_OPEN_FLAGS
                next_descriptor = os.open(part, flags, dir_fd=descriptor)
                os.close(descriptor)
                descriptor = next_descriptor
            cls._require_matching_metadata(
                entry.metadata,
                os.fstat(descriptor),
                entry.relative,
            )
            return descriptor
        except BaseException:
            os.close(descriptor)
            raise

    @staticmethod
    def _tar_info(relative: PurePosixPath, metadata: os.stat_result) -> tarfile.TarInfo:
        info = tarfile.TarInfo(relative.as_posix())
        info.mode = stat.S_IMODE(metadata.st_mode) & 0o777
        info.mtime = int(metadata.st_mtime)
        info.uid = 0
        info.gid = 0
        info.uname = ""
        info.gname = ""
        if stat.S_ISDIR(metadata.st_mode):
            info.type = tarfile.DIRTYPE
            info.size = 0
        else:
            info.type = tarfile.REGTYPE
            info.size = metadata.st_size
        return info

    def _hash_workspace_scan(self, root: Path, scan: _WorkspaceScan) -> dict[str, str]:
        hashes: dict[str, str] = {}
        root_descriptor = self._open_workspace_root(root, scan.root_metadata)
        try:
            for entry in scan.entries:
                if not stat.S_ISREG(entry.metadata.st_mode):
                    continue
                descriptor = self._open_workspace_entry(root_descriptor, entry)
                try:
                    before = os.fstat(descriptor)
                    hashes[entry.relative.as_posix()] = self._sha256_descriptor(descriptor)
                    self._require_stable_entry(descriptor, before, entry.relative)
                finally:
                    os.close(descriptor)
        finally:
            os.close(root_descriptor)
        return hashes

    def _validate_projected_workspace(
        self,
        base_scan: _WorkspaceScan,
        base_hashes: dict[str, str],
        changes: dict[str, tuple[str | None, str | None, Path | None, str, int]],
    ) -> None:
        directories = {entry.relative.as_posix() for entry in base_scan.entries if stat.S_ISDIR(entry.metadata.st_mode)}
        file_sizes = {
            entry.relative.as_posix(): entry.metadata.st_size
            for entry in base_scan.entries
            if stat.S_ISREG(entry.metadata.st_mode)
        }
        if set(file_sizes) != set(base_hashes):
            raise RuntimeError("Base workspace changed while preparing overlay merge")
        for relative, (_before, after, _source, _agent, source_size) in changes.items():
            if after is None:
                file_sizes.pop(relative, None)
            else:
                file_sizes[relative] = source_size
        for relative in tuple(file_sizes):
            if relative in directories:
                raise RuntimeError(f"Overlay merge would replace a directory with a file: {relative}")
            path = PurePosixPath(relative)
            for index in range(1, len(path.parts)):
                parent = PurePosixPath(*path.parts[:index]).as_posix()
                if parent in file_sizes:
                    raise RuntimeError(f"Overlay merge has a file/directory conflict: {relative}")
                directories.add(parent)
        entry_count = len(directories) + len(file_sizes)
        if entry_count > self._max_workspace_entries:
            raise ValueError(f"Workspace exceeds max_workspace_entries={self._max_workspace_entries}")
        total_bytes = sum(file_sizes.values())
        if total_bytes > self._max_workspace_bytes:
            raise ValueError(f"Workspace exceeds max_workspace_bytes={self._max_workspace_bytes}")

    @staticmethod
    def _open_parent_descriptor(
        root: Path,
        relative: PurePosixPath,
        *,
        create: bool,
    ) -> int | None:
        try:
            descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
        except OSError as exc:
            raise RuntimeError(f"Workspace root cannot be opened safely: {root}") from exc
        try:
            for part in relative.parts[:-1]:
                try:
                    next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
                except FileNotFoundError:
                    if not create:
                        os.close(descriptor)
                        return None
                    try:
                        os.mkdir(part, 0o755, dir_fd=descriptor)
                    except FileExistsError:
                        pass
                    next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
                except OSError as exc:
                    raise RuntimeError(
                        f"Overlay merge path contains a symbolic link or non-directory: {relative}"
                    ) from exc
                os.close(descriptor)
                descriptor = next_descriptor
            return descriptor
        except BaseException:
            try:
                os.close(descriptor)
            except OSError:
                pass
            raise

    @classmethod
    def _relative_digest(cls, root: Path, relative: PurePosixPath) -> str | None:
        parent_descriptor = cls._open_parent_descriptor(root, relative, create=False)
        if parent_descriptor is None:
            return None
        try:
            try:
                descriptor = os.open(relative.name, _FILE_OPEN_FLAGS, dir_fd=parent_descriptor)
            except FileNotFoundError:
                return None
            except OSError as exc:
                raise RuntimeError(f"Overlay merge target is not a safe regular file: {relative}") from exc
            try:
                before = os.fstat(descriptor)
                if not stat.S_ISREG(before.st_mode):
                    raise RuntimeError(f"Overlay merge target is not a regular file: {relative}")
                digest = cls._sha256_descriptor(descriptor)
                cls._require_stable_entry(descriptor, before, relative)
                return digest
            finally:
                os.close(descriptor)
        finally:
            os.close(parent_descriptor)

    @classmethod
    def _delete_relative_file(
        cls,
        root: Path,
        relative: PurePosixPath,
        *,
        expected_digest: str | None,
    ) -> None:
        observed = cls._relative_digest(root, relative)
        if observed is None:
            return
        if observed != expected_digest:
            raise RuntimeError(f"Base workspace changed during overlay merge: {relative}")
        parent_descriptor = cls._open_parent_descriptor(root, relative, create=False)
        if parent_descriptor is None:
            return
        try:
            os.unlink(relative.name, dir_fd=parent_descriptor)
            os.fsync(parent_descriptor)
        finally:
            os.close(parent_descriptor)

    @classmethod
    def _copy_relative_atomic(
        cls,
        source_root: Path,
        destination_root: Path,
        relative: PurePosixPath,
        *,
        expected_source_digest: str,
        expected_destination_digest: str | None,
    ) -> None:
        source_parent = cls._open_parent_descriptor(source_root, relative, create=False)
        if source_parent is None:
            raise RuntimeError(f"Overlay source disappeared during merge: {relative}")
        source_descriptor: int | None = None
        destination_parent: int | None = None
        temporary_name: str | None = None
        temporary_descriptor: int | None = None
        try:
            try:
                source_descriptor = os.open(relative.name, _FILE_OPEN_FLAGS, dir_fd=source_parent)
            except OSError as exc:
                raise RuntimeError(f"Overlay source cannot be opened safely: {relative}") from exc
            source_before = os.fstat(source_descriptor)
            if not stat.S_ISREG(source_before.st_mode):
                raise RuntimeError(f"Overlay source is not a regular file: {relative}")
            destination_parent = cls._open_parent_descriptor(
                destination_root,
                relative,
                create=True,
            )
            assert destination_parent is not None
            temporary_name = f".areal-agent-runtime-merge-{new_id('file')}"
            temporary_descriptor = os.open(
                temporary_name,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
                dir_fd=destination_parent,
            )
            digest = hashlib.sha256()
            os.lseek(source_descriptor, 0, os.SEEK_SET)
            while chunk := os.read(source_descriptor, 1024 * 1024):
                digest.update(chunk)
                view = memoryview(chunk)
                while view:
                    written = os.write(temporary_descriptor, view)
                    view = view[written:]
            cls._require_stable_entry(source_descriptor, source_before, relative)
            if digest.hexdigest() != expected_source_digest:
                raise RuntimeError(f"Overlay source changed during merge: {relative}")
            os.fchmod(temporary_descriptor, stat.S_IMODE(source_before.st_mode) & 0o777)
            os.fsync(temporary_descriptor)
            observed = cls._relative_digest(destination_root, relative)
            if observed == expected_source_digest:
                return
            if observed != expected_destination_digest:
                raise RuntimeError(f"Base workspace changed during overlay merge: {relative}")
            os.replace(
                temporary_name,
                relative.name,
                src_dir_fd=destination_parent,
                dst_dir_fd=destination_parent,
            )
            temporary_name = None
            os.fsync(destination_parent)
        finally:
            if temporary_descriptor is not None:
                os.close(temporary_descriptor)
            if temporary_name is not None and destination_parent is not None:
                try:
                    os.unlink(temporary_name, dir_fd=destination_parent)
                except FileNotFoundError:
                    pass
            if destination_parent is not None:
                os.close(destination_parent)
            if source_descriptor is not None:
                os.close(source_descriptor)
            os.close(source_parent)
