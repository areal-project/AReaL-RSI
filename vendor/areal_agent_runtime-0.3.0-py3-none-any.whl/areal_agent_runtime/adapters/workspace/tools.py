"""Application-owned workspace tools for runtimes without native file tools."""

from __future__ import annotations

import asyncio
import contextlib
import math
import os
import secrets
import signal
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from pydantic import Field, ValidationError, model_validator

from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import TextBlock
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.runtime import HealthStatus, ToolCall, ToolExecution, ToolResult, ToolSpec

WORKSPACE_TOOL_NAMES = (
    "workspace.read",
    "workspace.write",
    "workspace.edit",
    "workspace.list",
    "workspace.search",
    "workspace.run",
)
_DIRECTORY_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
_FILE_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
_UNSET = object()


@dataclass(frozen=True, slots=True)
class WorkspaceToolConfig:
    max_read_bytes: int = 1024 * 1024
    max_write_bytes: int = 8 * 1024 * 1024
    max_output_chars: int = 64 * 1024
    max_results: int = 500
    max_scan_entries: int = 20_000
    max_scan_depth: int = 64
    command_timeout_seconds: float = 120.0
    allowed_commands: tuple[str, ...] = (
        "node",
        "npm",
        "npx",
        "pnpm",
        "python",
        "python3",
        "uv",
    )

    def __post_init__(self) -> None:
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 1
            for value in (
                self.max_read_bytes,
                self.max_write_bytes,
                self.max_output_chars,
                self.max_results,
                self.max_scan_entries,
                self.max_scan_depth,
            )
        ):
            raise ValueError("workspace limits must be positive integers")
        if (
            isinstance(self.command_timeout_seconds, bool)
            or not isinstance(self.command_timeout_seconds, (int, float))
            or not math.isfinite(self.command_timeout_seconds)
            or self.command_timeout_seconds <= 0
        ):
            raise ValueError("command_timeout_seconds must be finite and positive")
        if (
            not isinstance(self.allowed_commands, tuple)
            or not self.allowed_commands
            or any(
                not isinstance(item, str)
                or not item.strip()
                or item != item.strip()
                or Path(item).name != item
                or "\x00" in item
                for item in self.allowed_commands
            )
            or len(self.allowed_commands) != len(set(self.allowed_commands))
        ):
            raise ValueError("allowed_commands must contain unique non-empty strings")


class _PathArguments(ContractModel):
    path: str = Field(min_length=1, max_length=4096)


class _WriteArguments(_PathArguments):
    content: str


class _EditArguments(_PathArguments):
    old_text: str = Field(min_length=1)
    new_text: str
    expected_replacements: int = Field(default=1, ge=1)


class _ListArguments(ContractModel):
    path: str = Field(default=".", min_length=1, max_length=4096)
    pattern: str = Field(default="**/*", min_length=1, max_length=512)


class _SearchArguments(ContractModel):
    query: str = Field(min_length=1, max_length=4096)
    path: str = Field(default=".", min_length=1, max_length=4096)
    case_sensitive: bool = True


class _RunArguments(ContractModel):
    argv: tuple[str, ...] = Field(min_length=1, max_length=256)
    cwd: str = Field(default=".", min_length=1, max_length=4096)

    @model_validator(mode="after")
    def validate_argv(self) -> _RunArguments:
        if any(not item or "\x00" in item for item in self.argv):
            raise ValueError("argv entries must be non-empty strings without NUL bytes")
        if sum(len(item.encode("utf-8")) for item in self.argv) > 128 * 1024:
            raise ValueError("argv exceeds 131072 UTF-8 bytes")
        return self


@dataclass(frozen=True, slots=True)
class _ScannedEntry:
    path: PurePosixPath
    is_directory: bool
    size: int | None


class _WorkspaceConflict(RuntimeError):
    pass


class _WorkspaceLimit(ValueError):
    pass


class LocalWorkspaceToolProvider:
    """Small, bounded file/command surface resolved from each ToolCall workspace."""

    def __init__(self, config: WorkspaceToolConfig | None = None) -> None:
        self._config = config or WorkspaceToolConfig()

    async def list_tools(self) -> tuple[ToolSpec, ...]:
        path_property = {
            "type": "string",
            "minLength": 1,
            "maxLength": 4096,
            "description": "Workspace-relative path",
        }
        return (
            ToolSpec(
                name="workspace.read",
                description="Read one UTF-8 text file inside the selected workspace.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path"],
                    "properties": {"path": path_property},
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.read",),
            ),
            ToolSpec(
                name="workspace.write",
                description="Atomically write one UTF-8 text file inside the selected workspace.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path", "content"],
                    "properties": {
                        "path": path_property,
                        "content": {"type": "string"},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.write",),
            ),
            ToolSpec(
                name="workspace.edit",
                description="Replace an exact text occurrence in a workspace file.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["path", "oldText", "newText"],
                    "properties": {
                        "path": path_property,
                        "oldText": {"type": "string", "minLength": 1},
                        "newText": {"type": "string"},
                        "expectedReplacements": {"type": "integer", "minimum": 1, "default": 1},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.write",),
            ),
            ToolSpec(
                name="workspace.list",
                description="List bounded workspace entries matching a relative glob.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "path": {"type": "string", "minLength": 1, "maxLength": 4096, "default": "."},
                        "pattern": {"type": "string", "minLength": 1, "maxLength": 512, "default": "**/*"},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.read",),
            ),
            ToolSpec(
                name="workspace.search",
                description="Search literal text in bounded UTF-8 workspace files.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["query"],
                    "properties": {
                        "query": {"type": "string", "minLength": 1, "maxLength": 4096},
                        "path": {"type": "string", "minLength": 1, "maxLength": 4096, "default": "."},
                        "caseSensitive": {"type": "boolean", "default": True},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.read",),
            ),
            ToolSpec(
                name="workspace.run",
                description="Run an allowlisted executable without a shell in the workspace.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["argv"],
                    "properties": {
                        "argv": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 256,
                            "items": {"type": "string", "minLength": 1},
                        },
                        "cwd": {"type": "string", "minLength": 1, "maxLength": 4096, "default": "."},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("workspace.execute",),
            ),
        )

    async def invoke(self, call: ToolCall) -> ToolResult:
        try:
            if call.name == "workspace.read":
                return await self._read(call)
            if call.name == "workspace.write":
                return await self._write(call)
            if call.name == "workspace.edit":
                return await self._edit(call)
            if call.name == "workspace.list":
                return await self._list(call)
            if call.name == "workspace.search":
                return await self._search(call)
            if call.name == "workspace.run":
                return await self._run(call)
            return self._error(call, "WORKSPACE_TOOL_NOT_FOUND", ErrorCategory.NOT_FOUND, call.name)
        except ValidationError as exc:
            return self._error(call, "WORKSPACE_ARGUMENTS_INVALID", ErrorCategory.INVALID_REQUEST, str(exc))
        except _WorkspaceConflict as exc:
            return self._error(call, "WORKSPACE_WRITE_CONFLICT", ErrorCategory.CONFLICT, str(exc))
        except _WorkspaceLimit as exc:
            return self._error(call, "WORKSPACE_LIMIT_EXCEEDED", ErrorCategory.INVALID_REQUEST, str(exc))
        except (ValueError, PermissionError) as exc:
            return self._error(call, "WORKSPACE_PATH_INVALID", ErrorCategory.PERMISSION, str(exc))
        except FileNotFoundError as exc:
            return self._error(call, "WORKSPACE_PATH_NOT_FOUND", ErrorCategory.NOT_FOUND, str(exc))
        except Exception as exc:
            return self._error(
                call,
                "WORKSPACE_TOOL_FAILED",
                ErrorCategory.INTERNAL,
                str(exc) or type(exc).__name__,
            )

    async def health(self) -> HealthStatus:
        return HealthStatus(
            status="healthy",
            details={"allowedCommands": list(self._config.allowed_commands)},
        )

    async def _read(self, call: ToolCall) -> ToolResult:
        arguments = _PathArguments.model_validate(call.arguments)
        workspace = self._workspace(call)
        relative = self._relative_path(arguments.path, allow_current=False)
        payload, _observed = await asyncio.to_thread(
            self._read_relative,
            workspace,
            relative,
            self._config.max_read_bytes,
        )
        try:
            content = payload.decode("utf-8")
        except UnicodeError as exc:
            return self._error(
                call,
                "WORKSPACE_TEXT_ENCODING_INVALID",
                ErrorCategory.INVALID_REQUEST,
                f"File is not UTF-8 text: {arguments.path}: {exc}",
            )
        return ToolResult(
            call_id=call.call_id,
            content=(TextBlock(text=content),),
            value={"path": arguments.path, "content": content},
        )

    async def _write(self, call: ToolCall) -> ToolResult:
        arguments = _WriteArguments.model_validate(call.arguments)
        payload = arguments.content.encode("utf-8")
        if len(payload) > self._config.max_write_bytes:
            raise _WorkspaceLimit(
                f"Write exceeds {self._config.max_write_bytes} bytes: {arguments.path}"
            )
        workspace = self._workspace(call)
        relative = self._relative_path(arguments.path, allow_current=False)
        await asyncio.to_thread(self._write_relative_atomic, workspace, relative, payload)
        return ToolResult(
            call_id=call.call_id,
            value={"path": arguments.path, "bytes": len(payload)},
        )

    async def _edit(self, call: ToolCall) -> ToolResult:
        arguments = _EditArguments.model_validate(call.arguments)
        workspace = self._workspace(call)
        relative = self._relative_path(arguments.path, allow_current=False)
        payload, observed = await asyncio.to_thread(
            self._read_relative,
            workspace,
            relative,
            self._config.max_read_bytes,
        )
        try:
            content = payload.decode("utf-8")
        except UnicodeError as exc:
            return self._error(
                call,
                "WORKSPACE_TEXT_ENCODING_INVALID",
                ErrorCategory.INVALID_REQUEST,
                f"File is not UTF-8 text: {arguments.path}: {exc}",
            )
        occurrences = content.count(arguments.old_text)
        if occurrences != arguments.expected_replacements:
            return self._error(
                call,
                "WORKSPACE_EDIT_CONFLICT",
                ErrorCategory.CONFLICT,
                f"Expected {arguments.expected_replacements} replacement(s), found {occurrences}",
            )
        updated = content.replace(arguments.old_text, arguments.new_text)
        updated_payload = updated.encode("utf-8")
        if len(updated_payload) > self._config.max_write_bytes:
            raise _WorkspaceLimit(
                f"Edited file exceeds {self._config.max_write_bytes} bytes: {arguments.path}"
            )
        await asyncio.to_thread(
            self._write_relative_atomic,
            workspace,
            relative,
            updated_payload,
            observed,
        )
        return ToolResult(
            call_id=call.call_id,
            value={"path": arguments.path, "replacements": occurrences},
        )

    async def _list(self, call: ToolCall) -> ToolResult:
        arguments = _ListArguments.model_validate(call.arguments)
        workspace = self._workspace(call)
        root = self._relative_path(arguments.path, allow_current=True)
        self._validate_pattern(arguments.pattern)
        entries, scan_truncated = await asyncio.to_thread(self._scan_entries, workspace, root)
        values: list[dict[str, object]] = []
        matched_more = False
        for entry in entries:
            relative_to_root = entry.path.relative_to(root) if root.parts else entry.path
            if not self._matches_pattern(relative_to_root, arguments.pattern):
                continue
            if len(values) >= self._config.max_results:
                matched_more = True
                break
            values.append(
                {
                    "path": entry.path.as_posix(),
                    "type": "directory" if entry.is_directory else "file",
                    "size": entry.size,
                }
            )
        return ToolResult(
            call_id=call.call_id,
            value={"entries": values, "truncated": scan_truncated or matched_more},
        )

    async def _search(self, call: ToolCall) -> ToolResult:
        arguments = _SearchArguments.model_validate(call.arguments)
        workspace = self._workspace(call)
        root = self._relative_path(arguments.path, allow_current=True)
        query = arguments.query if arguments.case_sensitive else arguments.query.casefold()
        matches: list[dict[str, object]] = []
        entries, scan_truncated = await asyncio.to_thread(self._scan_entries, workspace, root)
        result_truncated = scan_truncated
        for entry in entries:
            if len(matches) >= self._config.max_results:
                result_truncated = True
                break
            if entry.is_directory or entry.size is None or entry.size > self._config.max_read_bytes:
                continue
            try:
                payload, _observed = await asyncio.to_thread(
                    self._read_relative,
                    workspace,
                    entry.path,
                    self._config.max_read_bytes,
                )
                content = payload.decode("utf-8")
            except (FileNotFoundError, PermissionError, UnicodeError, _WorkspaceLimit):
                continue
            for line_number, line in enumerate(content.splitlines(), start=1):
                candidate = line if arguments.case_sensitive else line.casefold()
                if query in candidate:
                    matches.append(
                        {
                            "path": entry.path.as_posix(),
                            "line": line_number,
                            "text": line[:500],
                        }
                    )
                    if len(matches) >= self._config.max_results:
                        result_truncated = True
                        break
        return ToolResult(
            call_id=call.call_id,
            value={"matches": matches, "truncated": result_truncated},
        )

    async def _run(self, call: ToolCall) -> ToolResult:
        arguments = _RunArguments.model_validate(call.arguments)
        executable = Path(arguments.argv[0]).name
        if arguments.argv[0] != executable or executable not in self._config.allowed_commands:
            return self._error(
                call,
                "WORKSPACE_COMMAND_DENIED",
                ErrorCategory.PERMISSION,
                f"Executable is not allowlisted: {arguments.argv[0]}",
            )
        workspace = self._workspace(call)
        cwd_relative = self._relative_path(arguments.cwd, allow_current=True)
        cwd_descriptor = await asyncio.to_thread(self._open_directory_descriptor, workspace, cwd_relative)
        try:
            # ``subprocess`` has no descriptor-based cwd API. Anchor and verify
            # every component with O_NOFOLLOW first, then pass the corresponding
            # lexical path while this Agent holds its workspace view lock.
            cwd_path = workspace.joinpath(*cwd_relative.parts)
            if not self._same_entry_state(os.fstat(cwd_descriptor), os.stat(cwd_path)):
                raise _WorkspaceConflict(f"Workspace command directory changed before execution: {cwd_relative}")
            process = await asyncio.create_subprocess_exec(
                *arguments.argv,
                cwd=cwd_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,
            )
        finally:
            os.close(cwd_descriptor)
        assert process.stdout is not None and process.stderr is not None
        output_limit = self._config.max_output_chars * 4
        stdout_task = asyncio.create_task(self._read_bounded(process.stdout, output_limit))
        stderr_task = asyncio.create_task(self._read_bounded(process.stderr, output_limit))
        timed_out = False
        try:
            async with asyncio.timeout(self._config.command_timeout_seconds):
                await process.wait()
        except TimeoutError:
            timed_out = True
            self._kill_process_group(process)
            await process.wait()
        except BaseException:
            self._kill_process_group(process)
            await process.wait()
            await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)
            raise
        stdout, stderr = await asyncio.gather(stdout_task, stderr_task)
        stdout_text = stdout.decode("utf-8", errors="replace")[-self._config.max_output_chars :]
        stderr_text = stderr.decode("utf-8", errors="replace")[-self._config.max_output_chars :]
        value = {
            "argv": list(arguments.argv),
            "exitCode": -1 if timed_out else process.returncode,
            "stdout": stdout_text,
            "stderr": stderr_text,
        }
        if timed_out:
            return ToolResult(
                call_id=call.call_id,
                content=(TextBlock(text=stdout_text + stderr_text),),
                value=value,
                error=ErrorInfo(
                    code="WORKSPACE_COMMAND_TIMEOUT",
                    category=ErrorCategory.TIMEOUT,
                    message=f"Command exceeded {self._config.command_timeout_seconds} seconds",
                ),
            )
        if process.returncode != 0:
            return ToolResult(
                call_id=call.call_id,
                content=(TextBlock(text=stdout_text + stderr_text),),
                value=value,
                error=ErrorInfo(
                    code="WORKSPACE_COMMAND_FAILED",
                    category=ErrorCategory.INVALID_REQUEST,
                    message=f"Command exited with status {process.returncode}",
                ),
            )
        return ToolResult(
            call_id=call.call_id,
            content=(TextBlock(text=stdout_text),),
            value=value,
        )

    def _workspace(self, call: ToolCall) -> Path:
        if not call.workspace.mount_hint:
            raise ValueError("Workspace tools require workspace.mountHint")
        workspace = Path(call.workspace.mount_hint).expanduser().resolve()
        if not workspace.is_dir():
            raise FileNotFoundError(f"Workspace does not exist: {workspace}")
        return workspace

    @staticmethod
    def _relative_path(value: str, *, allow_current: bool) -> PurePosixPath:
        candidate = PurePosixPath(value)
        if (
            candidate.is_absolute()
            or ".." in candidate.parts
            or "\x00" in value
            or (not allow_current and not candidate.parts)
        ):
            raise PermissionError(f"Path must stay inside the workspace: {value}")
        return candidate

    @staticmethod
    def _open_parent_descriptor(root: Path, relative: PurePosixPath, *, create: bool) -> int:
        try:
            descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
        except OSError as exc:
            raise PermissionError(f"Workspace root cannot be opened safely: {root}") from exc
        try:
            for part in relative.parts[:-1]:
                try:
                    next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
                except FileNotFoundError:
                    if not create:
                        raise
                    try:
                        os.mkdir(part, 0o755, dir_fd=descriptor)
                    except FileExistsError:
                        pass
                    next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
                except OSError as exc:
                    raise PermissionError(
                        f"Workspace path contains a symbolic link or non-directory: {relative}"
                    ) from exc
                os.close(descriptor)
                descriptor = next_descriptor
            return descriptor
        except BaseException:
            with contextlib.suppress(OSError):
                os.close(descriptor)
            raise

    @staticmethod
    def _open_directory_descriptor(root: Path, relative: PurePosixPath) -> int:
        try:
            descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
        except OSError as exc:
            raise PermissionError(f"Workspace root cannot be opened safely: {root}") from exc
        try:
            for part in relative.parts:
                try:
                    next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=descriptor)
                except FileNotFoundError:
                    raise
                except OSError as exc:
                    raise PermissionError(
                        f"Workspace directory contains a symbolic link or is not a directory: {relative}"
                    ) from exc
                os.close(descriptor)
                descriptor = next_descriptor
            return descriptor
        except BaseException:
            with contextlib.suppress(OSError):
                os.close(descriptor)
            raise

    @classmethod
    def _read_relative(
        cls,
        root: Path,
        relative: PurePosixPath,
        limit: int,
    ) -> tuple[bytes, os.stat_result]:
        parent_descriptor = cls._open_parent_descriptor(root, relative, create=False)
        descriptor: int | None = None
        try:
            try:
                descriptor = os.open(relative.name, _FILE_OPEN_FLAGS, dir_fd=parent_descriptor)
            except FileNotFoundError:
                raise
            except OSError as exc:
                raise PermissionError(f"Workspace file cannot be opened safely: {relative}") from exc
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise PermissionError(f"Workspace path is not a regular file: {relative}")
            if before.st_size > limit:
                raise _WorkspaceLimit(f"File exceeds {limit} bytes: {relative}")
            payload = bytearray()
            while chunk := os.read(descriptor, min(1024 * 1024, limit + 1)):
                payload.extend(chunk)
                if len(payload) > limit:
                    raise _WorkspaceLimit(f"File exceeds {limit} bytes: {relative}")
            after = os.fstat(descriptor)
            if len(payload) != before.st_size or not cls._same_entry_state(before, after):
                raise _WorkspaceConflict(f"Workspace file changed while reading: {relative}")
            return bytes(payload), before
        finally:
            if descriptor is not None:
                os.close(descriptor)
            os.close(parent_descriptor)

    @classmethod
    def _write_relative_atomic(
        cls,
        root: Path,
        relative: PurePosixPath,
        payload: bytes,
        expected: os.stat_result | None | object = _UNSET,
    ) -> None:
        parent_descriptor = cls._open_parent_descriptor(root, relative, create=True)
        temporary_name = f".areal-agent-runtime-write-{secrets.token_hex(16)}"
        temporary_descriptor: int | None = None
        try:
            observed = cls._entry_metadata(parent_descriptor, relative.name)
            cls._require_regular_destination(observed, relative)
            if expected is not _UNSET and not cls._same_optional_entry_state(expected, observed):
                raise _WorkspaceConflict(f"Workspace file changed before edit commit: {relative}")
            mode = stat.S_IMODE(observed.st_mode) & 0o777 if observed is not None else 0o644
            temporary_descriptor = os.open(
                temporary_name,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
                dir_fd=parent_descriptor,
            )
            view = memoryview(payload)
            while view:
                written = os.write(temporary_descriptor, view)
                if written <= 0:
                    raise OSError("Workspace write made no progress")
                view = view[written:]
            os.fchmod(temporary_descriptor, mode)
            os.fsync(temporary_descriptor)
            current = cls._entry_metadata(parent_descriptor, relative.name)
            cls._require_regular_destination(current, relative)
            if not cls._same_optional_entry_state(observed, current):
                raise _WorkspaceConflict(f"Workspace file changed during write: {relative}")
            os.replace(
                temporary_name,
                relative.name,
                src_dir_fd=parent_descriptor,
                dst_dir_fd=parent_descriptor,
            )
            temporary_name = ""
            os.fsync(parent_descriptor)
        finally:
            if temporary_descriptor is not None:
                os.close(temporary_descriptor)
            if temporary_name:
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(temporary_name, dir_fd=parent_descriptor)
            os.close(parent_descriptor)

    @staticmethod
    def _entry_metadata(parent_descriptor: int, name: str) -> os.stat_result | None:
        try:
            return os.stat(name, dir_fd=parent_descriptor, follow_symlinks=False)
        except FileNotFoundError:
            return None

    @staticmethod
    def _require_regular_destination(metadata: os.stat_result | None, relative: PurePosixPath) -> None:
        if metadata is not None and not stat.S_ISREG(metadata.st_mode):
            raise PermissionError(f"Workspace destination is not a regular file: {relative}")

    @staticmethod
    def _same_entry_state(before: os.stat_result, after: os.stat_result) -> bool:
        return (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_size,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) == (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        )

    @classmethod
    def _same_optional_entry_state(
        cls,
        before: os.stat_result | None | object,
        after: os.stat_result | None,
    ) -> bool:
        if before is None or after is None:
            return before is after
        if before is _UNSET or not isinstance(before, os.stat_result):
            return False
        return cls._same_entry_state(before, after)

    def _scan_entries(
        self,
        root: Path,
        base: PurePosixPath,
    ) -> tuple[tuple[_ScannedEntry, ...], bool]:
        descriptor = self._open_directory_descriptor(root, base)
        entries: list[_ScannedEntry] = []
        scanned = 0
        truncated = False

        def walk(directory_descriptor: int, prefix: PurePosixPath, depth: int) -> None:
            nonlocal scanned, truncated
            with os.scandir(directory_descriptor) as iterator:
                children = sorted(iterator, key=lambda item: item.name)
            for child in children:
                if scanned >= self._config.max_scan_entries:
                    truncated = True
                    return
                scanned += 1
                try:
                    metadata = child.stat(follow_symlinks=False)
                except FileNotFoundError:
                    continue
                relative = prefix / child.name
                if stat.S_ISREG(metadata.st_mode):
                    entries.append(_ScannedEntry(path=relative, is_directory=False, size=metadata.st_size))
                    continue
                if not stat.S_ISDIR(metadata.st_mode):
                    continue
                entries.append(_ScannedEntry(path=relative, is_directory=True, size=None))
                if depth >= self._config.max_scan_depth:
                    truncated = True
                    continue
                try:
                    child_descriptor = os.open(
                        child.name,
                        _DIRECTORY_OPEN_FLAGS,
                        dir_fd=directory_descriptor,
                    )
                except (FileNotFoundError, NotADirectoryError):
                    continue
                except OSError as exc:
                    raise PermissionError(f"Workspace directory cannot be scanned safely: {relative}") from exc
                try:
                    walk(child_descriptor, relative, depth + 1)
                finally:
                    os.close(child_descriptor)
                if truncated and scanned >= self._config.max_scan_entries:
                    return

        try:
            walk(descriptor, base, 1)
        finally:
            os.close(descriptor)
        return tuple(entries), truncated

    @staticmethod
    def _matches_pattern(relative: PurePosixPath, pattern: str) -> bool:
        if pattern in {"**", "**/*"}:
            return True
        if "/" not in pattern and len(relative.parts) != 1:
            return False
        return relative.match(pattern)

    @staticmethod
    async def _read_bounded(stream: asyncio.StreamReader, limit: int) -> bytes:
        retained = bytearray()
        while chunk := await stream.read(8192):
            retained.extend(chunk)
            if len(retained) > limit:
                del retained[: len(retained) - limit]
        return bytes(retained)

    @staticmethod
    def _kill_process_group(process: asyncio.subprocess.Process) -> None:
        if process.returncode is not None:
            return
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except (AttributeError, ProcessLookupError):
            with contextlib.suppress(ProcessLookupError):
                process.kill()

    @staticmethod
    def _validate_pattern(pattern: str) -> None:
        candidate = PurePosixPath(pattern)
        if candidate.is_absolute() or ".." in candidate.parts or "\x00" in pattern:
            raise PermissionError(f"Glob must stay inside the workspace: {pattern}")

    @staticmethod
    def _error(call: ToolCall, code: str, category: ErrorCategory, message: str) -> ToolResult:
        return ToolResult(
            call_id=call.call_id,
            error=ErrorInfo(code=code, category=category, message=message),
        )
