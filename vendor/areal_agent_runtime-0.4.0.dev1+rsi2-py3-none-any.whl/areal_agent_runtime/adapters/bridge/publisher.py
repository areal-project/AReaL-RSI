"""ARealAgentRuntime artifact publication adapter for Bridge-like services."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Protocol

from areal_agent_runtime.contracts.ports import ArtifactPublishReceipt, ArtifactRef
from areal_agent_runtime.contracts.runtime import HealthStatus


class BridgeClient(Protocol):
    async def publish(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    async def health(self) -> HealthStatus: ...


@dataclass(frozen=True, slots=True)
class BridgePublisherConfig:
    endpoint: str
    token: str | None = field(default=None, repr=False)
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = 60.0

    def __post_init__(self) -> None:
        if not isinstance(self.endpoint, str) or not self.endpoint:
            raise ValueError("Bridge endpoint must not be empty")
        if (
            isinstance(self.timeout_seconds, bool)
            or not isinstance(self.timeout_seconds, (int, float))
            or not math.isfinite(self.timeout_seconds)
            or self.timeout_seconds <= 0
        ):
            raise ValueError("Bridge timeout_seconds must be positive and finite")
        if self.token is not None and (not isinstance(self.token, str) or not self.token):
            raise ValueError("Bridge token must be a non-empty string when provided")
        if not isinstance(self.headers, dict) or any(
            not isinstance(key, str) or not key or not isinstance(value, str)
            for key, value in self.headers.items()
        ):
            raise ValueError("Bridge headers must contain non-empty string keys and string values")


class BridgeHttpClient:
    def __init__(self, config: BridgePublisherConfig) -> None:
        self._config = config

    async def publish(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover - optional dependency guard
            raise RuntimeError("Install areal-agent-runtime[integrations] to use Bridge HTTP") from exc
        headers = {"content-type": "application/json", **self._config.headers}
        idempotency_key = payload.get("idempotencyKey")
        if isinstance(idempotency_key, str) and idempotency_key:
            headers = {key: value for key, value in headers.items() if key.lower() != "idempotency-key"}
            headers["idempotency-key"] = idempotency_key
        if self._config.token:
            headers["authorization"] = f"Bearer {self._config.token}"
        async with httpx.AsyncClient(
            timeout=self._config.timeout_seconds,
            follow_redirects=False,
            trust_env=False,
        ) as client:
            response = await client.post(self._config.endpoint, json=payload, headers=headers)
            response.raise_for_status()
            value = response.json()
        if not isinstance(value, dict):
            raise ValueError("Bridge response must be a JSON object")
        return value

    async def health(self) -> HealthStatus:
        return HealthStatus(status="healthy", details={"configured": bool(self._config.endpoint)})


class BridgeArtifactPublisher:
    def __init__(self, client: BridgeClient, *, publisher_name: str = "bridge") -> None:
        self._client = client
        self._publisher_name = publisher_name

    async def publish(self, artifact: ArtifactRef) -> ArtifactPublishReceipt:
        idempotency_key = artifact.metadata.get("idempotencyKey")
        if idempotency_key is not None and (not isinstance(idempotency_key, str) or not idempotency_key):
            raise ValueError("Artifact metadata idempotencyKey must be a non-empty string")
        payload = {
            "schemaVersion": "areal.agent-runtime.artifact-publish/v1",
            "artifact": artifact.model_dump(mode="json", by_alias=True),
        }
        if idempotency_key is not None:
            payload["idempotencyKey"] = idempotency_key
        response = await self._client.publish(payload)
        response_artifact_id = response.get("artifactId") or response.get("artifact_id")
        response_version = response.get("version")
        response_idempotency_key = response.get("idempotencyKey") or response.get("idempotency_key")
        if response_artifact_id is not None and str(response_artifact_id) != artifact.artifact_id:
            raise ValueError("Bridge response artifactId does not match the publication request")
        if response_version is not None and str(response_version) != artifact.version:
            raise ValueError("Bridge response version does not match the publication request")
        if response_idempotency_key is not None and response_idempotency_key != idempotency_key:
            raise ValueError("Bridge response idempotencyKey does not match the publication request")
        locator = response.get("locator") or response.get("url") or response.get("html_url")
        checksum = response.get("checksum") or response.get("sha256") or response.get("md5")
        known = {
            "locator",
            "url",
            "html_url",
            "checksum",
            "sha256",
            "md5",
            "artifactId",
            "artifact_id",
            "version",
            "idempotencyKey",
            "idempotency_key",
        }
        metadata = {str(key): _jsonable(value) for key, value in response.items() if key not in known}
        return ArtifactPublishReceipt(
            publisher=self._publisher_name,
            artifact_id=artifact.artifact_id,
            version=artifact.version,
            locator=str(locator) if locator is not None else None,
            checksum=str(checksum) if checksum is not None else None,
            metadata=metadata,
        )

    async def health(self) -> HealthStatus:
        return await self._client.health()


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return str(value)
