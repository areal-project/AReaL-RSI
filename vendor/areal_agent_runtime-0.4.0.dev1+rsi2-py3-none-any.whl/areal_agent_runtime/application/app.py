"""Application service orchestrating Hosts, profiles and interchangeable runtimes."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import math
import sys
import weakref
from collections import OrderedDict
from collections.abc import AsyncIterator, Coroutine, Mapping
from typing import Any

from pydantic import JsonValue, TypeAdapter, ValidationError

from areal_agent_runtime.application.agent_environment import (
    AgentEnvironmentPolicy,
    AgentEnvironmentResolver,
    InlineResourceLoader,
)
from areal_agent_runtime.application.data_plane import RuntimeDataClient
from areal_agent_runtime.application.orchestration import (
    AgentScheduler,
    ApplicationOrchestrator,
    RuntimeGraphSnapshot,
    WorkspaceView,
    plan_proposal_instruction,
    restore_runtime_graph,
)
from areal_agent_runtime.application.profiles import WorkflowProfile
from areal_agent_runtime.application.tool_gateway import ToolGateway
from areal_agent_runtime.application.workflow import (
    AgentGraph,
    AgentInputMode,
    MultiAgentOwnership,
    WorkflowAgent,
    WorkspaceAccess,
)
from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    TextBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.environment import (
    AgentEnvironmentLayer,
    AgentEnvironmentSnapshot,
    AgentEnvironmentSpec,
)
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import (
    EnvironmentCreatedEventData,
    EventType,
    RunEvent,
)
from areal_agent_runtime.contracts.ports import (
    AnnotationStorePort,
    AssetStorePort,
    EnvironmentPort,
    EnvironmentRef,
    EnvironmentSpec,
    EventSinkPort,
    ResourceLoaderPort,
    StateStorePort,
    ToolProviderPort,
    WorkspaceCheckpoint,
)
from areal_agent_runtime.contracts.product import (
    CancelRunCommand,
    RunRef,
    RunSnapshot,
    RunStatus,
    StartRunCommand,
    SteerRunCommand,
    SubmitInteractionCommand,
)
from areal_agent_runtime.contracts.runtime import (
    AgentRef,
    AgentRuntimePort,
    CancelReason,
    ChildEventProjection,
    ExecutionChannel,
    ExecutionPolicy,
    ExecutionRequest,
    InteractionRequest,
    InteractionResponse,
    Modality,
    RawRuntimeEventData,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolCall,
    ToolExecution,
    ToolResult,
    ToolSpec,
)
from areal_agent_runtime.kernel.asset_context import asset_write_context, get_asset_write_context
from areal_agent_runtime.kernel.data import (
    CanonicalDataPolicy,
    RuntimeEventLineageValidator,
    canonicalize_runtime_usage,
)
from areal_agent_runtime.kernel.events import EventPublisher
from areal_agent_runtime.kernel.ids import new_id
from areal_agent_runtime.kernel.state_queries import iter_events, iter_run_snapshots

logger = logging.getLogger(__name__)
_DIAGNOSTIC_RUN_LIMIT = 128
_DIAGNOSTIC_ENTRY_LIMIT = 16
_DIAGNOSTIC_TEXT_LIMIT = 2048
_RECOVERY_SCAN_BATCH = 128
_GRAPH_RECOVERY_EVENTS = frozenset({
    EventType.RUNTIME_GRAPH_SNAPSHOTTED, EventType.AGENT_SCHEDULED, EventType.AGENT_STARTED,
    EventType.AGENT_COMPLETED, EventType.AGENT_FAILED, EventType.AGENT_CANCELLED,
    EventType.EXECUTION_COMPLETED, EventType.EXECUTION_FAILED, EventType.ORCHESTRATOR_DECIDED,
})


class ARealAgentRuntime:
    def __init__(
        self,
        *,
        runtimes: dict[str, AgentRuntimePort],
        profiles: dict[str, WorkflowProfile],
        state: StateStorePort,
        sinks: Mapping[str, EventSinkPort] | tuple[EventSinkPort, ...] = (),
        tool_providers: dict[str, ToolProviderPort] | None = None,
        tool_provider_versions: dict[str, str] | None = None,
        allowed_tool_permissions: tuple[str, ...] | None = None,
        resource_loader: ResourceLoaderPort | None = None,
        agent_environment_policy: AgentEnvironmentPolicy | None = None,
        base_agent_environment: AgentEnvironmentSpec | None = None,
        environment: EnvironmentPort | None = None,
        annotation_store: AnnotationStorePort | None = None,
        asset_store: AssetStorePort | None = None,
        run_lease_ttl_seconds: float = 30.0,
        max_active_runs: int = 16,
        data_query_max_events: int = 10_000,
        data_query_max_bytes: int = 16 * 1024 * 1024,
        max_recovery_events: int = 100_000,
        max_recovery_bytes: int = 64 * 1024 * 1024,
    ) -> None:
        if (
            isinstance(run_lease_ttl_seconds, bool)
            or not isinstance(run_lease_ttl_seconds, (int, float))
            or not math.isfinite(run_lease_ttl_seconds)
            or run_lease_ttl_seconds <= 0
        ):
            raise ValueError("run_lease_ttl_seconds must be a finite positive number")
        if isinstance(max_active_runs, bool) or not isinstance(max_active_runs, int) or max_active_runs <= 0:
            raise ValueError("max_active_runs must be a positive integer")
        for name, value in (("max_recovery_events", max_recovery_events), ("max_recovery_bytes", max_recovery_bytes)):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        self._runtimes = dict(runtimes)
        self._profiles = dict(profiles)
        self._state = state
        self._data_policy = CanonicalDataPolicy()
        self._events = EventPublisher(state, sinks, data_policy=self._data_policy)
        self._tools = ToolGateway(
            tool_providers,
            provider_versions=tool_provider_versions,
            allowed_permissions=allowed_tool_permissions,
        )
        self._agent_environments = AgentEnvironmentResolver(
            resource_loader or InlineResourceLoader(),
            self._tools,
            policy=agent_environment_policy,
        )
        self._base_agent_environment = base_agent_environment or AgentEnvironmentSpec()
        self._environment = environment
        self.data = RuntimeDataClient(
            state,
            annotations=annotation_store,
            assets=asset_store,
            max_materialized_events=data_query_max_events,
            max_materialized_bytes=data_query_max_bytes,
        )
        self._worker_id = new_id("worker")
        self._run_lease_ttl_seconds = run_lease_ttl_seconds
        self._max_active_runs = max_active_runs
        self._max_recovery_events = max_recovery_events
        self._max_recovery_bytes = max_recovery_bytes
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._recovery_task: asyncio.Task[None] | None = None
        self._recovery_scan: AsyncIterator[RunSnapshot] | None = None
        self._recovery_wakeup = asyncio.Event()
        # Execution ownership must still be revalidated before control/commit.
        self._owned_runs: set[str] = set()
        # A task can finish between a caller obtaining its RunRef and calling
        # wait(). Keep a normalized failure after the live Task is removed so
        # that this race can never turn an infrastructure failure into a stale
        # QUEUED/RUNNING response.
        self._task_failures: OrderedDict[str, ErrorInfo] = OrderedDict()
        # Post-terminal cleanup (outbox retry / execution-lease release) cannot
        # be represented by another canonical event because terminal-last is a
        # protocol invariant. Retain and log those failures instead of silently
        # suppressing them. Environment close is handled before a success
        # terminal and therefore does not normally land here.
        self._cleanup_failures: OrderedDict[str, list[str]] = OrderedDict()
        # A task cancellation is not always a Product-level cancellation.  A
        # graceful process shutdown or a lost execution lease must leave the
        # durable Run recoverable; only cancel_run() is caller intent to make it
        # terminal.  Keep those causes explicit instead of inferring them from
        # asyncio.CancelledError.
        self._recoverable_interruptions: set[str] = set()
        self._graceful_interruptions: set[str] = set()
        self._explicit_cancellations: set[str] = set()
        self._cancellation_reasons: dict[str, str] = {}
        self._channels: dict[str, dict[str, ExecutionChannel]] = {}
        self._interaction_channels: dict[tuple[str, str], tuple[str, ExecutionChannel]] = {}
        self._responded_interactions: set[tuple[str, str]] = set()
        self._environment_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._lifecycle_lock = asyncio.Lock()
        self._initialized = False
        self._closing = False
        self._closed = False

    async def initialize(self) -> None:
        async with self._lifecycle_lock:
            self._ensure_accepting_runs()
            if self._initialized:
                return
            await self._tools.initialize()
            await self._events.recover()
            await self._restore_incomplete_runs()
            self._initialized = True
            self._recovery_task = asyncio.create_task(
                self._coordinate_recovery(), name="areal_agent_runtime:recovery-coordinator",
            )

    async def _restore_incomplete_runs(self) -> bool:
        """Scan a bounded window under the admission lock; return whether it ended.

        The iterator retains at most one backend page, never a backlog of Run
        IDs or sleeping tasks for foreign owners. Continue its cursor before
        revisiting earlier leases so a busy prefix cannot starve later work.
        """

        terminal = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}
        if self._recovery_scan is None:
            self._recovery_scan = iter_run_snapshots(self._state, batch_size=_RECOVERY_SCAN_BATCH)
        for _ in range(_RECOVERY_SCAN_BATCH):
            if len(self._tasks) >= self._max_active_runs:
                return False
            try:
                snapshot = await anext(self._recovery_scan)
            except StopAsyncIteration:
                self._recovery_scan = None
                return True
            run_id = snapshot.run_id
            if run_id in self._tasks or run_id in self._task_failures:
                continue
            if snapshot.status in terminal or snapshot.last_sequence < 0:
                # create_run precedes the first authoritative invocation event.
                # Do not race its creator for a Run that was not accepted yet.
                continue
            if not await self._state.try_acquire_run(
                run_id, self._worker_id, ttl_seconds=self._run_lease_ttl_seconds,
            ):
                continue
            self._owned_runs.add(run_id)
            self._start_run_task(
                run_id,
                self._execute_run(
                    run_id=run_id,
                    session_id=snapshot.session_id,
                    command=None,
                    recovering=True,
                ),
                name=f"areal_agent_runtime:recover:{run_id}",
            )
        return False

    async def _coordinate_recovery(self) -> None:
        interval = min(1.0, self._run_lease_ttl_seconds / 3)
        while True:
            self._recovery_wakeup.clear()
            try:
                async with self._lifecycle_lock:
                    if self._closing or self._closed:
                        return
                    exhausted = await self._restore_incomplete_runs()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._recovery_scan = None
                self._record_cleanup_failure("recovery-coordinator", "Run recovery scan", exc)
                exhausted = True
            if exhausted or len(self._tasks) >= self._max_active_runs:
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self._recovery_wakeup.wait(), timeout=interval)
            else:
                # Release the admission lock between pages, including stores
                # whose asynchronous methods complete without yielding.
                await asyncio.sleep(0)

    async def start_run(self, command: StartRunCommand) -> RunRef:
        async with self._lifecycle_lock:
            self._ensure_accepting_runs()
            return await self._start_run(command)

    async def _start_run(self, command: StartRunCommand) -> RunRef:
        if len(self._tasks) >= self._max_active_runs:
            raise ContractError(ErrorInfo(
                code="RUN_CAPACITY_EXCEEDED", category=ErrorCategory.RATE_LIMIT,
                message="This worker has reached max_active_runs; retry when a Run finishes",
                retryable=True, details={"maxActiveRuns": self._max_active_runs},
            ))
        if command.profile not in self._profiles:
            raise self._error("PROFILE_NOT_FOUND", ErrorCategory.NOT_FOUND, f"Unknown profile: {command.profile}")
        if command.runtime.selector not in self._runtimes:
            raise self._error(
                "RUNTIME_NOT_FOUND", ErrorCategory.NOT_FOUND, f"Unknown runtime: {command.runtime.selector}"
            )
        profile = self._profiles[command.profile]
        if profile.agent_graph is not None:
            missing_runtimes = sorted(
                {
                    agent.runtime_selector
                    for agent in profile.agent_graph.agents
                    if agent.runtime_selector is not None and agent.runtime_selector not in self._runtimes
                }
            )
            if missing_runtimes:
                raise self._error(
                    "RUNTIME_NOT_FOUND",
                    ErrorCategory.NOT_FOUND,
                    f"Unknown graph runtime(s): {', '.join(missing_runtimes)}",
                )
        run_id = new_id("run")
        session_id = command.session_id or new_id("ses")
        snapshot = RunSnapshot(
            run_id=run_id,
            session_id=session_id,
            profile=command.profile,
            workspace_id=command.workspace.workspace_id,
            context=command.context,
            status=RunStatus.QUEUED,
            last_sequence=-1,
        )
        await self._state.create_run(snapshot)
        if not await self._state.try_acquire_run(
            run_id, self._worker_id, ttl_seconds=self._run_lease_ttl_seconds,
        ):
            raise self._error("RUN_NOT_OWNED", ErrorCategory.CONFLICT, f"Cannot acquire new Run: {run_id}")
        self._owned_runs.add(run_id)
        try:
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                event_type=EventType.RUN_QUEUED,
                data={
                    "profile": command.profile,
                    "runtime": command.runtime.selector,
                    "request": command.model_copy(update={"session_id": session_id}).model_dump(
                        mode="json",
                        by_alias=True,
                    ),
                },
            )
        except BaseException as start_error:
            # A caller disconnect or ambiguous backend error is not a Product
            # cancellation. The queue event may already have accepted the Run.
            # Reconcile before releasing this lifecycle lock; otherwise this
            # initialized process leaves accepted work stranded until restart.
            reconciliation = asyncio.create_task(
                self._reconcile_run_acceptance(run_id, session_id),
                name=f"areal_agent_runtime:acceptance:{run_id}",
            )
            while not reconciliation.done():
                try:
                    await asyncio.shield(reconciliation)
                except asyncio.CancelledError:
                    continue
                except BaseException:
                    break
            try:
                reconciliation.result()
            except BaseException as recovery_error:
                start_error.add_note(
                    f"Run acceptance reconciliation also failed: {self._format_failure(recovery_error)}"
                )
                self._record_cleanup_failure(run_id, "Run acceptance reconciliation", recovery_error)
            raise
        self._start_run_task(
            run_id,
            self._execute_run(run_id=run_id, session_id=session_id, command=command),
            name=f"areal_agent_runtime:{run_id}",
        )
        return RunRef(
            run_id=run_id,
            session_id=session_id,
            status=RunStatus.QUEUED,
            events_url=f"/v1/runs/{run_id}/events",
        )

    async def _reconcile_run_acceptance(self, run_id: str, session_id: str) -> None:
        try:
            snapshot = await self._state.get_run(run_id)
            if snapshot is not None and snapshot.last_sequence >= 0:
                self._start_run_task(
                    run_id,
                    self._execute_run(run_id=run_id, session_id=session_id, command=None, recovering=True),
                    name=f"areal_agent_runtime:accepted:{run_id}",
                )
        finally:
            if run_id not in self._tasks:
                self._owned_runs.discard(run_id)
                await self._state.release_run(run_id, self._worker_id)

    async def get_run(self, run_id: str) -> RunSnapshot:
        snapshot = await self._state.get_run(run_id)
        if snapshot is None:
            raise self._error("RUN_NOT_FOUND", ErrorCategory.NOT_FOUND, f"Unknown run: {run_id}")
        return snapshot

    def list_profiles(self) -> tuple[WorkflowProfile, ...]:
        return tuple(self._profiles[name] for name in sorted(self._profiles))

    async def list_runtimes(self) -> tuple[object, ...]:
        return tuple(await asyncio.gather(*(self._runtimes[name].describe() for name in sorted(self._runtimes))))

    @property
    def cleanup_failures(self) -> dict[str, tuple[str, ...]]:
        """Return a defensive snapshot of non-canonical cleanup diagnostics."""

        return {run_id: tuple(failures) for run_id, failures in self._cleanup_failures.items()}

    @property
    def delivery_failures(self) -> dict[tuple[str, str], str]:
        """Current outbox failures by (run_id, sink_id); retries remain automatic.

        An empty mapping does not certify delivery: work may still be queued.
        Successful Run completion describes execution, not external ingestion.
        """

        return self._events.delivery_failures

    def stream_events(self, run_id: str, after: int | None = None) -> AsyncIterator[RunEvent]:
        async def checked_stream() -> AsyncIterator[RunEvent]:
            # StateStore streams intentionally wait for cross-process writers.
            # Without this Product boundary check, a typo in a run id would
            # therefore wait forever instead of producing RUN_NOT_FOUND.
            await self.get_run(run_id)
            async for event in self._state.stream_events(run_id, after):
                yield event

        return checked_stream()

    async def submit_interaction(self, command: SubmitInteractionCommand) -> None:
        key = (command.run_id, command.interaction_id)
        target = self._interaction_channels.get(key)
        if target is None:
            # Do not forward an arbitrary interactionId merely because the Run
            # happens to have one active channel. Runtime interaction requests
            # are capabilities with an explicit correlation identity.
            raise self._error(
                "INTERACTION_NOT_ACTIVE",
                ErrorCategory.CONFLICT,
                f"Interaction is not accepting a response: {command.interaction_id}",
            )
        if command.execution_id is not None and target[0] != command.execution_id:
            raise self._error(
                "INTERACTION_EXECUTION_MISMATCH",
                ErrorCategory.CONFLICT,
                f"Interaction {command.interaction_id} does not belong to execution {command.execution_id}",
            )
        channel = target[1]
        await self._require_run_ownership(command.run_id)
        if key in self._responded_interactions:
            raise self._error(
                "INTERACTION_RESPONSE_ALREADY_SUBMITTED",
                ErrorCategory.CONFLICT,
                f"Interaction response was already submitted: {command.interaction_id}",
            )
        # Reserve before crossing the Runtime boundary so concurrent callers
        # cannot submit two responses. Keep the live mapping until the Runtime
        # emits interaction.resolved; respond() merely acknowledges receipt.
        self._responded_interactions.add(key)
        try:
            await channel.respond(InteractionResponse(interaction_id=command.interaction_id, response=command.response))
        except BaseException:
            self._responded_interactions.discard(key)
            raise

    async def steer_run(self, command: SteerRunCommand) -> None:
        channel = self._require_channel(command.run_id, command.execution_id)
        await self._require_run_ownership(command.run_id)
        await channel.steer(command.input)

    async def _renew_run_ownership(self, run_id: str) -> bool:
        if run_id not in self._owned_runs:
            return False
        try:
            renewed = await self._state.renew_run(
                run_id, self._worker_id, ttl_seconds=self._run_lease_ttl_seconds,
            )
        except Exception as exc:
            self._record_cleanup_failure(run_id, "execution ownership check", exc)
            renewed = False
        if not renewed:
            self._owned_runs.discard(run_id)
            self._recoverable_interruptions.add(run_id)
            task = self._tasks.get(run_id)
            if task is not None and task is not asyncio.current_task():
                task.cancel()
        return renewed

    async def _require_run_ownership(self, run_id: str) -> None:
        if await self._renew_run_ownership(run_id):
            return
        raise self._error(
            "RUN_NOT_OWNED",
            ErrorCategory.CONFLICT,
            f"Run is active on another owner and cannot be controlled locally: {run_id}",
        )

    async def cancel_run(self, command: CancelRunCommand) -> None:
        snapshot = await self.get_run(command.run_id)
        if snapshot.status in {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}:
            return
        try:
            await self._require_run_ownership(command.run_id)
        except ContractError:
            if (await self.get_run(command.run_id)).status in {
                RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED,
            }:
                return
            raise
        channels = tuple(self._channels.get(command.run_id, {}).values())
        # Establish Application-owned cancellation before a runtime hard-close
        # can race a failed terminal event back into the canonical Run state.
        # Runtime cancellation still runs for resource/process cleanup.
        task = self._tasks.get(command.run_id)
        if task is None:
            raise self._error(
                "RUN_NOT_OWNED",
                ErrorCategory.CONFLICT,
                f"Run is active on another owner and cannot be cancelled locally: {command.run_id}",
            )
        if command.run_id not in self._explicit_cancellations:
            self._explicit_cancellations.add(command.run_id)
            self._cancellation_reasons[command.run_id] = command.reason
            self._recoverable_interruptions.discard(command.run_id)
            self._graceful_interruptions.discard(command.run_id)
            task.cancel()
        if channels:
            cancellation_results = await asyncio.gather(
                *(channel.cancel(CancelReason(message=command.reason)) for channel in channels),
                return_exceptions=True,
            )
            for cancellation_result in cancellation_results:
                if isinstance(cancellation_result, BaseException):
                    self._record_cleanup_failure(
                        command.run_id,
                        "runtime execution cancellation",
                        cancellation_result,
                    )
        # A Task can be cancelled before its coroutine executes even one line;
        # in that case _execute_run has no opportunity to publish the product
        # terminal event.  Join cleanup, then close that race explicitly.
        await asyncio.gather(task, return_exceptions=True)
        if command.run_id in self._owned_runs:
            # Cancellation before _execute_run's first step leaves the initial
            # lease with start_run. Only that actual owner may commit fallback.
            try:
                await self._require_run_ownership(command.run_id)
                await self._publish_run_cancelled_if_active(
                    command.run_id, snapshot.session_id, command.reason,
                )
            finally:
                self._owned_runs.discard(command.run_id)
                await self._state.release_run(command.run_id, self._worker_id)

    async def wait(self, run_id: str) -> RunSnapshot:
        task = self._tasks.get(run_id)
        # Restored work may be awaiting a bounded local slot or a foreign lease.
        # Preserve wait's blocking behavior without allocating a task per Run
        # during initialization. A caller may cancel this wait independently.
        while task is None and self._recovery_task is not None and not self._recovery_task.done():
            snapshot = await self.get_run(run_id)
            if snapshot.status in {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}:
                self._task_failures.pop(run_id, None)
                return snapshot
            if run_id in self._task_failures:
                raise ContractError(self._task_failures[run_id])
            await asyncio.sleep(min(0.1, self._run_lease_ttl_seconds / 3))
            task = self._tasks.get(run_id)
        observed_failure: BaseException | None = None
        if task is not None:
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError:
                if not task.cancelled():
                    raise
            except Exception as exc:
                observed_failure = exc
        snapshot = await self.get_run(run_id)
        if snapshot.status in {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}:
            # Canonical state wins once a terminal commit exists. Operational
            # cleanup failures remain available through cleanup_failures.
            self._task_failures.pop(run_id, None)
            return snapshot
        failure = self._task_failures.get(run_id)
        if failure is None and observed_failure is not None:
            failure = self._task_failure_info(run_id, observed_failure)
        if failure is not None:
            raise ContractError(failure)
        if task is None:
            raise ContractError(ErrorInfo(
                code="RUN_NOT_ACTIVE", category=ErrorCategory.UNAVAILABLE,
                message=f"Run is not terminal and has no local execution task: {run_id}",
                retryable=True, details={"runId": run_id, "status": snapshot.status.value},
            ))
        return snapshot

    async def shutdown(self) -> None:
        shutdown_errors: list[BaseException] = []
        async with self._lifecycle_lock:
            if self._closed:
                return
            self._closing = True
            try:
                if self._recovery_task is not None:
                    self._recovery_task.cancel()
                    await asyncio.gather(self._recovery_task, return_exceptions=True)
                    self._recovery_task = None
                if self._recovery_scan is not None:
                    await self._recovery_scan.aclose()
                    self._recovery_scan = None
                active = tuple((run_id, task) for run_id, task in self._tasks.items() if not task.done())
                for run_id, task in active:
                    if run_id not in self._explicit_cancellations:
                        self._recoverable_interruptions.add(run_id)
                        self._graceful_interruptions.add(run_id)
                    task.cancel()
                if active:
                    results = await asyncio.gather(*(task for _, task in active), return_exceptions=True)
                    shutdown_errors.extend(
                        result
                        for result in results
                        if isinstance(result, BaseException) and not isinstance(result, asyncio.CancelledError)
                    )
            finally:
                # Tasks cancelled before their coroutine starts do not execute
                # _execute_run's finally block, but start_run already leased
                # their queued Run. Leave the facts recoverable and free it.
                for run_id in tuple(self._owned_runs):
                    try:
                        await self._state.release_run(run_id, self._worker_id)
                    except BaseException as exc:
                        shutdown_errors.append(exc)
                    finally:
                        self._owned_runs.discard(run_id)
                try:
                    await self._events.aclose()
                except BaseException as exc:
                    shutdown_errors.append(exc)
                self._closed = True
                self._closing = False
        if shutdown_errors:
            if len(shutdown_errors) == 1:
                raise shutdown_errors[0]
            raise BaseExceptionGroup("Application shutdown cleanup failed", shutdown_errors)

    def _start_run_task(
        self,
        run_id: str,
        coroutine: Coroutine[Any, Any, None],
        *,
        name: str,
    ) -> None:
        task = asyncio.create_task(coroutine, name=name)
        self._tasks[run_id] = task

        def forget(finished: asyncio.Task[None]) -> None:
            if self._tasks.get(run_id) is finished:
                self._tasks.pop(run_id, None)
            if not finished.cancelled():
                failure = finished.exception()
                if failure is not None:
                    info = self._task_failure_info(run_id, failure)
                    self._task_failures[run_id] = info
                    self._task_failures.move_to_end(run_id)
                    while len(self._task_failures) > _DIAGNOSTIC_RUN_LIMIT:
                        self._task_failures.popitem(last=False)
                    logger.error(
                        "ARealAgentRuntime Run task failed outside its canonical terminal transition: %s: %s",
                        run_id,
                        info.message,
                        exc_info=(type(failure), failure, failure.__traceback__),
                    )
            self._recoverable_interruptions.discard(run_id)
            self._graceful_interruptions.discard(run_id)
            self._explicit_cancellations.discard(run_id)
            self._cancellation_reasons.pop(run_id, None)
            self._recovery_wakeup.set()

        task.add_done_callback(forget)

    async def _execute_run(
        self,
        *,
        run_id: str,
        session_id: str,
        command: StartRunCommand | None,
        resuming: bool = False,
        recovering: bool = False,
    ) -> None:
        owner_task = asyncio.current_task()
        lease_lost = asyncio.Event()

        async def renew_execution_lease() -> None:
            while True:
                await asyncio.sleep(self._run_lease_ttl_seconds / 3)
                try:
                    renewed = await self._state.renew_run(
                        run_id,
                        self._worker_id,
                        ttl_seconds=self._run_lease_ttl_seconds,
                    )
                except Exception:
                    renewed = False
                if renewed:
                    continue
                lease_lost.set()
                self._owned_runs.discard(run_id)
                self._recoverable_interruptions.add(run_id)
                if owner_task is not None:
                    owner_task.cancel()
                return

        lease_task: asyncio.Task[None] | None = None
        environment_ref: EnvironmentRef | None = None
        try:
            # Admission may already own a lease. Include revalidation in the
            # same cleanup boundary so a backend error here cannot strand the
            # Run in _owned_runs after its local Task is forgotten.
            claimed = await self._state.try_acquire_run(
                run_id, self._worker_id, ttl_seconds=self._run_lease_ttl_seconds,
            )
            if not claimed:
                self._owned_runs.discard(run_id)
                return
            self._owned_runs.add(run_id)
            lease_task = asyncio.create_task(
                renew_execution_lease(), name=f"areal_agent_runtime:lease:{run_id}",
            )
            snapshot = await self.get_run(run_id)
            if snapshot.status in {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}:
                return
            if command is None:
                # Validate recovery inputs only after acquiring the lease. A
                # follower with a different release cannot terminate live work.
                raw_request: JsonValue = None
                async for queued in iter_events(self._state, run_id):
                    if queued.type == EventType.RUN_QUEUED:
                        raw_request = queued.data.get("request")
                        break
                try:
                    command = StartRunCommand.model_validate(raw_request)
                    if command.profile not in self._profiles:
                        raise ValueError(f"profile is no longer installed: {command.profile}")
                    if command.runtime.selector not in self._runtimes:
                        raise ValueError(f"runtime is no longer installed: {command.runtime.selector}")
                except (ValidationError, ValueError, TypeError) as exc:
                    raise self._error(
                        "RUN_RECOVERY_INPUT_UNAVAILABLE", ErrorCategory.CONFLICT,
                        str(exc) or "Run invocation is not recoverable",
                    ) from exc
                del queued, raw_request
                resuming = snapshot.status != RunStatus.QUEUED
                if resuming:
                    command = command.model_copy(update={"session_id": session_id, "resume_session": True})
            profile = self._profiles[command.profile]
            if self._environment is not None:
                environment_ref = await self._environment.open(
                    EnvironmentSpec(
                        workspace=command.workspace,
                        metadata={
                            **command.metadata,
                            "runId": run_id,
                            "sessionId": session_id,
                        },
                    )
                )
                if (
                    environment_ref.workspace.workspace_id
                    != command.workspace.workspace_id
                ):
                    raise self._error(
                        "ENVIRONMENT_WORKSPACE_IDENTITY_MISMATCH",
                        ErrorCategory.PROTOCOL,
                        "Environment changed the logical workspaceId: "
                        f"{command.workspace.workspace_id} -> "
                        f"{environment_ref.workspace.workspace_id}",
                    )
                command = command.model_copy(update={"workspace": environment_ref.workspace})
                await self._events.publish(
                    run_id=run_id,
                    session_id=session_id,
                    environment_id=environment_ref.environment_id,
                    event_type=EventType.ENVIRONMENT_CREATED,
                    data=EnvironmentCreatedEventData(
                        environment_id=environment_ref.environment_id,
                        workspace_id=environment_ref.workspace.workspace_id,
                        mount_hint=environment_ref.workspace.mount_hint,
                    ).model_dump(mode="json", by_alias=True),
                )
            default_descriptor = await self._runtimes[command.runtime.selector].describe()
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                event_type=EventType.RUN_RESUMED if resuming else EventType.RUN_STARTED,
                data={
                    "runtime": default_descriptor.model_dump(mode="json", by_alias=True),
                    "input": [block.model_dump(mode="json", by_alias=True) for block in command.input],
                    "knowledge": [item.model_dump(mode="json", by_alias=True) for item in command.knowledge],
                    "instructionCount": len(command.instructions),
                    "workspace": command.workspace.model_dump(mode="json", by_alias=True),
                    "metadata": command.metadata,
                    "resumed": resuming,
                },
                snapshot_status=RunStatus.RUNNING,
            )
            if profile.agent_graph is None:
                output = await self._execute_agent(
                    run_id=run_id,
                    product_session_id=session_id,
                    runtime_session_id=session_id,
                    command=command,
                    agent=AgentRef(agent_id="agent_root", role=profile.role),
                    input=command.input,
                    system=profile.system,
                    runtime_selector=command.runtime.selector,
                    required_modalities=profile.required_input_modalities,
                    required_features=profile.required_features,
                    max_stalled_actions=profile.max_stalled_actions,
                    tool_names=profile.tool_names,
                    release_environment=profile.agent_environment,
                    emit_agent_lifecycle=False,
                    workspace_access=None,
                    environment_ref=environment_ref,
                )
            elif profile.agent_graph.ownership == MultiAgentOwnership.RUNTIME_NATIVE:
                native_command = command.model_copy(
                    update={
                        "metadata": {
                            **command.metadata,
                            "multiAgentOwnership": MultiAgentOwnership.RUNTIME_NATIVE.value,
                            "agentGraph": profile.agent_graph.model_dump(mode="json", by_alias=True),
                        }
                    }
                )
                output = await self._execute_agent(
                    run_id=run_id,
                    product_session_id=session_id,
                    runtime_session_id=session_id,
                    command=native_command,
                    agent=AgentRef(agent_id="agent_root", role=profile.role),
                    input=command.input,
                    system=profile.system,
                    runtime_selector=command.runtime.selector,
                    required_modalities=profile.required_input_modalities,
                    required_features=self._ordered_union(
                        profile.required_features,
                        ("native_graph_execution",),
                    ),
                    max_stalled_actions=profile.max_stalled_actions,
                    tool_names=profile.tool_names,
                    release_environment=profile.agent_environment,
                    emit_agent_lifecycle=False,
                    workspace_access=None,
                    environment_ref=environment_ref,
                )
            else:
                output = await self._execute_graph(
                    run_id=run_id,
                    session_id=session_id,
                    command=command,
                    profile=profile,
                    graph=profile.agent_graph,
                    environment_ref=environment_ref,
                )
            if self._environment is not None and environment_ref is not None:
                checkpoint = await self._checkpoint_environment(environment_ref)
                await self._require_run_ownership(run_id)
                await self._events.publish(
                    run_id=run_id,
                    session_id=session_id,
                    event_type=EventType.WORKSPACE_CHECKPOINTED,
                    data=checkpoint.model_dump(mode="json", by_alias=True),
                )
                # Environment ownership is part of a successful Run boundary.
                # Close it before committing run.completed so a failed close can
                # still produce the one canonical run.failed terminal instead of
                # leaking a lease behind an irrevocable success state.
                await self._environment.close(environment_ref)
                environment_ref = None
            await self._require_run_ownership(run_id)
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                event_type=EventType.RUN_COMPLETED,
                data={"output": [block.model_dump(mode="json", by_alias=True) for block in output]},
                snapshot_status=RunStatus.COMPLETED,
            )
        except asyncio.CancelledError as cancellation:
            recoverable = run_id in self._recoverable_interruptions or lease_lost.is_set()
            cleanup_errors: list[BaseException] = []
            if (
                (run_id in self._graceful_interruptions or not recoverable)
                and self._environment is not None
                and environment_ref is not None
            ):
                try:
                    await self._require_run_ownership(run_id)
                    checkpoint = await self._checkpoint_environment(environment_ref)
                    await self._require_run_ownership(run_id)
                    await self._events.publish(
                        run_id=run_id,
                        session_id=session_id,
                        event_type=EventType.WORKSPACE_CHECKPOINTED,
                        data={
                            **checkpoint.model_dump(mode="json", by_alias=True),
                            "boundary": (
                                "graceful_shutdown" if run_id in self._graceful_interruptions else "run_cancelled"
                            ),
                        },
                    )
                except BaseException as exc:
                    cleanup_errors.append(exc)
            if self._environment is not None and environment_ref is not None:
                try:
                    close_environment = self._environment.close
                    if recoverable:
                        recoverable_close = getattr(self._environment, "close_for_recovery", None)
                        if callable(recoverable_close):
                            close_environment = recoverable_close
                    await close_environment(environment_ref)
                    environment_ref = None
                except BaseException as exc:
                    cleanup_errors.append(exc)
            # Cleanup may await beyond a lease expiry. Recheck after it; the
            # value captured on entering this handler is no longer evidence.
            recoverable = recoverable or run_id in self._recoverable_interruptions or lease_lost.is_set()
            if not recoverable and not await self._renew_run_ownership(run_id):
                recoverable = True
            if not recoverable:
                await self._publish_run_cancelled_if_active(
                    run_id,
                    session_id,
                    self._cancellation_reasons.get(run_id, "cancelled"),
                    cleanup_errors=tuple(self._format_failure(error) for error in cleanup_errors),
                )
            for cleanup_error in cleanup_errors:
                cancellation.add_note(
                    f"run interruption cleanup also failed: {type(cleanup_error).__name__}: {cleanup_error}"
                )
                self._record_cleanup_failure(run_id, "environment interruption cleanup", cleanup_error)
            if cleanup_errors and recoverable:
                if len(cleanup_errors) == 1:
                    raise cleanup_errors[0] from cancellation
                raise BaseExceptionGroup(
                    "recoverable Run interruption cleanup failed", cleanup_errors
                ) from cancellation
            raise
        except Exception as exc:
            cleanup_errors: list[BaseException] = []
            if self._environment is not None and environment_ref is not None:
                # Failed executions can have valuable partial outputs too.
                # Capture them before an Environment adapter tears down its
                # workspace, preserving the primary failure if capture fails.
                try:
                    await self._require_run_ownership(run_id)
                    checkpoint = await self._checkpoint_environment(environment_ref)
                    await self._require_run_ownership(run_id)
                    await self._events.publish(
                        run_id=run_id,
                        session_id=session_id,
                        event_type=EventType.WORKSPACE_CHECKPOINTED,
                        data={**checkpoint.model_dump(mode="json", by_alias=True), "boundary": "run_failed"},
                    )
                except BaseException as checkpoint_error:
                    cleanup_errors.append(checkpoint_error)
                try:
                    close_environment = self._environment.close
                    if run_id in self._recoverable_interruptions:
                        recoverable_close = getattr(self._environment, "close_for_recovery", None)
                        if callable(recoverable_close):
                            close_environment = recoverable_close
                    await close_environment(environment_ref)
                    environment_ref = None
                except BaseException as cleanup_error:
                    cleanup_errors.append(cleanup_error)
            info = (
                exc.info
                if isinstance(exc, ContractError)
                else ErrorInfo(
                    code="APPLICATION_RUN_FAILED",
                    category=ErrorCategory.INTERNAL,
                    message=str(exc) or type(exc).__name__,
                )
            )
            if cleanup_errors:
                for cleanup_error in cleanup_errors:
                    exc.add_note(f"run failure cleanup also failed: {type(cleanup_error).__name__}: {cleanup_error}")
                info = info.model_copy(
                    update={
                        "details": {
                            **info.details,
                            "cleanupErrors": [self._format_failure(error) for error in cleanup_errors],
                        }
                    }
                )
            error_payload = info.model_dump(mode="json", by_alias=True)
            if await self._renew_run_ownership(run_id):
                if run_id in self._explicit_cancellations:
                    # A Product cancellation can interrupt the projection or
                    # cleanup of an earlier error. That execution error remains
                    # durable, while the explicit command owns the Run outcome.
                    await self._publish_run_cancelled_if_active(
                        run_id, session_id, self._cancellation_reasons.get(run_id, "cancelled"),
                        cleanup_errors=tuple(self._format_failure(error) for error in cleanup_errors),
                    )
                else:
                    await self._events.publish(
                        run_id=run_id,
                        session_id=session_id,
                        event_type=EventType.RUN_FAILED,
                        data={"error": error_payload},
                        snapshot_status=RunStatus.FAILED,
                        snapshot_error=error_payload,
                    )
        finally:
            if lease_task is not None:
                lease_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await lease_task
            try:
                self._tools.release_run(run_id)
            except BaseException as exc:
                self._record_cleanup_failure(run_id, "tool evidence cleanup", exc)
            self._channels.pop(run_id, None)
            stale_interactions = [key for key in self._interaction_channels if key[0] == run_id]
            for key in stale_interactions:
                self._interaction_channels.pop(key, None)
                self._responded_interactions.discard(key)
            if self._environment is not None and environment_ref is not None:
                try:
                    close_environment = self._environment.close
                    if run_id in self._recoverable_interruptions:
                        recoverable_close = getattr(self._environment, "close_for_recovery", None)
                        if callable(recoverable_close):
                            close_environment = recoverable_close
                    await close_environment(environment_ref)
                except BaseException as exc:
                    self._record_cleanup_failure(run_id, "environment final cleanup", exc)
            try:
                await self._events.flush(run_id)
            except BaseException as exc:
                self._record_cleanup_failure(run_id, "event outbox flush", exc)
            try:
                await self._state.release_run(run_id, self._worker_id)
            except BaseException as exc:
                self._record_cleanup_failure(run_id, "execution lease release", exc)
            finally:
                self._owned_runs.discard(run_id)

    async def _checkpoint_environment(self, environment: EnvironmentRef) -> WorkspaceCheckpoint:
        assert self._environment is not None
        checkpoint = await self._environment.checkpoint(environment)
        if checkpoint.workspace_id != environment.workspace.workspace_id:
            raise self._error(
                "ENVIRONMENT_CHECKPOINT_IDENTITY_MISMATCH",
                ErrorCategory.PROTOCOL,
                "Environment checkpoint changed the logical workspaceId: "
                f"{environment.workspace.workspace_id} -> {checkpoint.workspace_id}",
            )
        return checkpoint

    async def _completed_execution(
        self, run_id: str, agent: AgentRef, *, dag_attempt: bool,
    ) -> tuple[RunEvent, tuple[ContentBlock, ...]] | None:
        """Reuse the latest committed execution across a Run-finalization crash.

        The execution terminal is committed only after the complete Runtime
        stream has passed validation. Its messages already contain the output;
        a missing final Run checkpoint must not repeat model/tool side effects.
        A later attempt or a failed execution never reuses an earlier success.
        """

        latest: RunEvent | None = None
        current_schedule: RunEvent | None = None
        async for event in iter_events(self._state, run_id):
            if event.agent_id != agent.agent_id or event.parent_agent_id != agent.parent_agent_id:
                continue
            if event.execution_id is not None:
                latest = event
            if event.type == EventType.AGENT_SCHEDULED:
                current_schedule = event
        if latest is None:
            return None
        started: RunEvent | None = None
        terminal: RunEvent | None = None
        prior_schedule: RunEvent | None = None
        failed = False
        output_blocks: list[ContentBlock] = []
        async for event in iter_events(self._state, run_id):
            if event.agent_id != agent.agent_id or event.parent_agent_id != agent.parent_agent_id:
                continue
            if started is None and event.type == EventType.AGENT_SCHEDULED:
                prior_schedule = event
            if event.execution_id != latest.execution_id:
                continue
            if started is None and event.type == EventType.EXECUTION_STARTED:
                started = event
            if terminal is None and event.type == EventType.EXECUTION_COMPLETED:
                terminal = event
            if event.type in {EventType.EXECUTION_FAILED, EventType.AGENT_FAILED, EventType.AGENT_CANCELLED}:
                failed = True
            if (terminal is None and event.type == EventType.MESSAGE_COMPLETED
                    and event.agent_attempt_id == latest.agent_attempt_id
                    and event.session_id == latest.session_id):
                output_blocks.extend(self._message_content(event))
        if started is None or terminal is None or failed or (
            terminal.agent_attempt_id is None or terminal.agent_attempt_id != started.agent_attempt_id
            or terminal.session_id != started.session_id
            or latest.agent_attempt_id != terminal.agent_attempt_id
            or latest.session_id != terminal.session_id or started.sequence >= terminal.sequence
        ):
            return None
        if dag_attempt:
            scheduled_attempt = prior_schedule.data.get("attempt") if prior_schedule is not None else None
            if (
                not isinstance(scheduled_attempt, int) or isinstance(scheduled_attempt, bool)
                or scheduled_attempt < 1 or current_schedule is None
                or current_schedule.data.get("attempt") != scheduled_attempt
            ):
                # Recovery refunds the interrupted attempt. A business retry
                # advances it and must not reuse a prior attempt's execution.
                return None
        return terminal, tuple(output_blocks)

    async def _execute_graph(
        self,
        *,
        run_id: str,
        session_id: str,
        command: StartRunCommand,
        profile: WorkflowProfile,
        graph: AgentGraph,
        environment_ref: EnvironmentRef | None,
    ) -> tuple[ContentBlock, ...]:
        async def execute_node(
            node: WorkflowAgent,
            outputs: Mapping[str, tuple[ContentBlock, ...]],
            workspace_view: WorkspaceView,
        ) -> tuple[ContentBlock, ...]:
            workspace_view = await self._materialize_workspace_view(
                environment_ref,
                node,
                workspace_view,
            )
            node_input = self._compose_agent_input(command.input, node, dict(outputs))
            selector = node.runtime_selector or command.runtime.selector
            node_command = command.model_copy(
                update={
                    "workspace": workspace_view.workspace,
                    "metadata": {
                        **command.metadata,
                        "workspaceView": workspace_view.model_dump(mode="json", by_alias=True),
                        "multiAgentOwnership": graph.ownership.value,
                        "parallelGroupId": workspace_view.parallel_group_id,
                        "runtimeSubagentsAllowed": node.allow_runtime_subagents,
                    },
                }
            )
            planner_contract = (
                (plan_proposal_instruction(graph.dynamic_policy),)
                if graph.dynamic_policy is not None
                and node.agent_id == graph.dynamic_policy.planner_agent_id
                else ()
            )
            return await self._execute_agent(
                run_id=run_id,
                product_session_id=session_id,
                runtime_session_id=f"{session_id}:{node.agent_id}",
                command=node_command,
                agent=AgentRef(
                    agent_id=node.agent_id,
                    parent_agent_id=graph.coordinator_agent_id,
                    role=node.role,
                ),
                input=node_input,
                system=(*profile.system, *node.system, *planner_contract),
                runtime_selector=selector,
                required_modalities=self._ordered_union(
                    profile.required_input_modalities,
                    node.required_input_modalities,
                ),
                required_features=self._ordered_union(
                    self._ordered_union(profile.required_features, node.required_features),
                    ("native_multi_agent",) if node.allow_runtime_subagents else (),
                ),
                max_stalled_actions=profile.max_stalled_actions,
                tool_names=self._ordered_union(profile.tool_names, node.tool_names),
                release_environment=self._merge_environment_layer(
                    profile.agent_environment,
                    node.agent_environment,
                ),
                emit_agent_lifecycle=True,
                workspace_access=node.workspace_access,
                lifecycle_data={
                    "dependsOn": list(node.depends_on),
                    "parallelGroupId": workspace_view.parallel_group_id,
                    "workspaceView": workspace_view.model_dump(mode="json", by_alias=True),
                    "multiAgentOwnership": graph.ownership.value,
                    "runtimeSubagentsAllowed": node.allow_runtime_subagents,
                },
                environment_ref=environment_ref,
            )

        async def emit_scheduler_event(
            event_type: EventType,
            data: dict[str, object],
            agent_id: str | None,
            parent_agent_id: str | None,
        ) -> None:
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                agent_id=agent_id,
                parent_agent_id=(
                    parent_agent_id
                    if parent_agent_id is not None
                    else graph.coordinator_agent_id
                    if agent_id is not None
                    else None
                ),
                event_type=event_type,
                data=data,
            )

        persisted = await self._restore_graph_state(run_id)
        orchestrator: ApplicationOrchestrator | None = None
        effective_graph = persisted.graph if persisted is not None else graph
        if effective_graph.dynamic_policy is not None and (persisted is None or not persisted.decisions):
            descriptors = {selector: await runtime.describe() for selector, runtime in self._runtimes.items()}
            orchestrator = ApplicationOrchestrator(
                policy=effective_graph.dynamic_policy,
                agent_profiles={
                    item.agent_profile_id: item for item in profile.agent_profiles
                },
                runtime_capabilities={
                    selector: descriptor.capabilities for selector, descriptor in descriptors.items()
                },
                session_tool_names=await self._tools.catalog_names(),
                default_runtime_selector=command.runtime.selector,
            )
        scheduler = AgentScheduler(
            run_id=run_id,
            workspace=command.workspace,
            data_policy=self._data_policy,
            execute_agent=execute_node,
            emit=emit_scheduler_event,
            interruption_is_recoverable=lambda: run_id in self._recoverable_interruptions,
        )
        try:
            return await scheduler.execute(graph, resume=persisted, orchestrator=orchestrator)
        except asyncio.CancelledError:
            if run_id in self._graceful_interruptions:
                await scheduler.checkpoint_for_recovery()
            raise

    async def _publish_run_cancelled_if_active(
        self,
        run_id: str,
        session_id: str,
        reason: str,
        *,
        cleanup_errors: tuple[str, ...] = (),
    ) -> None:
        snapshot = await self._state.get_run(run_id)
        if snapshot is None or snapshot.status in {
            RunStatus.COMPLETED,
            RunStatus.FAILED,
            RunStatus.CANCELLED,
        }:
            return
        try:
            data: dict[str, JsonValue] = {"reason": reason}
            if cleanup_errors:
                data["cleanupErrors"] = list(cleanup_errors)
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                event_type=EventType.RUN_CANCELLED,
                data=data,
                snapshot_status=RunStatus.CANCELLED,
            )
        except ValueError:
            # Another terminal transition may win after the read above.  The
            # StateStore enforces first-terminal-wins; only suppress that
            # expected race, never an unrelated commit failure.
            current = await self._state.get_run(run_id)
            if current is None or current.status not in {
                RunStatus.COMPLETED,
                RunStatus.FAILED,
                RunStatus.CANCELLED,
            }:
                raise

    async def _restore_graph_state(self, run_id: str) -> RuntimeGraphSnapshot | None:
        # Legacy completion-order reconstruction needs older graph snapshots.
        # Preserve that evidence, while excluding unrelated model/tool history
        # and enforcing an explicit serialized budget before materialization.
        events: list[RunEvent] = []
        serialized_bytes = 0
        async for event in iter_events(self._state, run_id):
            if event.type not in _GRAPH_RECOVERY_EVENTS:
                continue
            serialized_bytes += len(event.model_dump_json().encode("utf-8"))
            if len(events) >= self._max_recovery_events or serialized_bytes > self._max_recovery_bytes:
                raise ContractError(ErrorInfo(
                    code="RECOVERY_HISTORY_LIMIT_EXCEEDED", category=ErrorCategory.UNAVAILABLE,
                    message="Graph recovery history exceeds its configured event or serialized-byte budget",
                    retryable=True, details={
                        "runId": run_id, "maxRecoveryEvents": self._max_recovery_events,
                        "maxRecoveryBytes": self._max_recovery_bytes,
                    },
                ))
            events.append(event)
        return restore_runtime_graph(tuple(events))

    @staticmethod
    def _format_failure(error: BaseException) -> str:
        return f"{type(error).__name__}: {error or type(error).__name__}"

    @staticmethod
    def _task_failure_info(run_id: str, error: BaseException) -> ErrorInfo:
        if isinstance(error, ContractError):
            info = error.info
            return info.model_copy(update={
                "code": info.code[:_DIAGNOSTIC_TEXT_LIMIT],
                "message": info.message[:_DIAGNOSTIC_TEXT_LIMIT],
                "cause": info.cause[:_DIAGNOSTIC_TEXT_LIMIT] if info.cause is not None else None,
                "details": info.details if len(info.model_dump_json()) <= _DIAGNOSTIC_TEXT_LIMIT else {
                    "runId": run_id, "diagnosticsTruncated": True,
                },
            })
        return ErrorInfo(
            code="APPLICATION_TASK_FAILED",
            category=ErrorCategory.INTERNAL,
            message=(str(error) or type(error).__name__)[:_DIAGNOSTIC_TEXT_LIMIT],
            retryable=True,
            details={"runId": run_id, "exceptionType": type(error).__name__},
        )

    def _record_cleanup_failure(self, run_id: str, stage: str, error: BaseException) -> None:
        detail = f"{stage}: {self._format_failure(error)}"[:_DIAGNOSTIC_TEXT_LIMIT]
        failures = self._cleanup_failures.setdefault(run_id, [])
        self._cleanup_failures.move_to_end(run_id)
        if detail not in failures:
            failures.append(detail)
            del failures[:-_DIAGNOSTIC_ENTRY_LIMIT]
        while len(self._cleanup_failures) > _DIAGNOSTIC_RUN_LIMIT:
            self._cleanup_failures.popitem(last=False)
        logger.error(
            "ARealAgentRuntime Run cleanup failed (%s, %s): %s",
            run_id,
            stage,
            error or type(error).__name__,
            exc_info=(type(error), error, error.__traceback__),
        )

    async def _materialize_workspace_view(
        self,
        environment_ref: EnvironmentRef | None,
        agent: WorkflowAgent,
        view: WorkspaceView,
    ) -> WorkspaceView:
        if agent.merge_overlays:
            merge = getattr(self._environment, "merge_workspace_views", None)
            if environment_ref is None or not callable(merge):
                raise self._error(
                    "WORKSPACE_OVERLAY_MERGE_UNAVAILABLE",
                    ErrorCategory.INVALID_REQUEST,
                    f"Agent {agent.agent_id} requires overlay merge support from the Environment Adapter",
                )
            await merge(environment_ref, agent.merge_overlays)
        if agent.workspace_access != WorkspaceAccess.OVERLAY:
            return view
        open_view = getattr(self._environment, "open_workspace_view", None)
        if environment_ref is None or not callable(open_view):
            raise self._error(
                "WORKSPACE_OVERLAY_UNAVAILABLE",
                ErrorCategory.INVALID_REQUEST,
                f"Agent {agent.agent_id} requires an isolated overlay WorkspaceView",
            )
        workspace = await open_view(environment_ref, agent.agent_id)
        return view.model_copy(update={"workspace": workspace})

    async def _execute_agent(
        self,
        *,
        run_id: str,
        product_session_id: str,
        runtime_session_id: str,
        command: StartRunCommand,
        agent: AgentRef,
        input: tuple[ContentBlock, ...],
        system: tuple[ContentBlock, ...],
        runtime_selector: str,
        required_modalities: tuple[Modality, ...],
        required_features: tuple[str, ...],
        max_stalled_actions: int | None,
        tool_names: tuple[str, ...],
        release_environment: AgentEnvironmentLayer,
        emit_agent_lifecycle: bool,
        workspace_access: WorkspaceAccess | None,
        lifecycle_data: dict[str, object] | None = None,
        environment_ref: EnvironmentRef | None = None,
    ) -> tuple[ContentBlock, ...]:
        # Scope is installed by Application, so Harness and tool adapters only
        # call AssetStore.put; concurrent agents cannot select each other's route.
        with asset_write_context(run_id=run_id, profile_id=command.profile, agent_id=agent.agent_id):
            return await self._execute_agent_in_context(
                run_id=run_id,
                product_session_id=product_session_id,
                runtime_session_id=runtime_session_id,
                command=command,
                agent=agent,
                input=input,
                system=system,
                runtime_selector=runtime_selector,
                required_modalities=required_modalities,
                required_features=required_features,
                max_stalled_actions=max_stalled_actions,
                tool_names=tool_names,
                release_environment=release_environment,
                emit_agent_lifecycle=emit_agent_lifecycle,
                workspace_access=workspace_access,
                lifecycle_data=lifecycle_data,
                environment_ref=environment_ref,
            )

    async def _execute_agent_in_context(
        self,
        *,
        run_id: str,
        product_session_id: str,
        runtime_session_id: str,
        command: StartRunCommand,
        agent: AgentRef,
        input: tuple[ContentBlock, ...],
        system: tuple[ContentBlock, ...],
        runtime_selector: str,
        required_modalities: tuple[Modality, ...],
        required_features: tuple[str, ...],
        max_stalled_actions: int | None,
        tool_names: tuple[str, ...],
        release_environment: AgentEnvironmentLayer,
        emit_agent_lifecycle: bool,
        workspace_access: WorkspaceAccess | None,
        lifecycle_data: dict[str, object] | None = None,
        environment_ref: EnvironmentRef | None = None,
    ) -> tuple[ContentBlock, ...]:
        runtime = self._runtimes[runtime_selector]
        runtime_session: RuntimeSessionRef | None = None
        channel: ExecutionChannel | None = None
        execution_id = new_id("exe")
        agent_attempt_id = new_id("aat")
        agent_environment_id: str | None = None
        agent_started = False
        runtime_execution_started = False
        runtime_execution_start_seen = False
        execution_terminal_published = False
        event_runtime_instance_id: str | None = None

        async def publish_agent_completion(result: tuple[ContentBlock, ...]) -> None:
            data: dict[str, JsonValue] = {
                "output": [block.model_dump(mode="json", by_alias=True) for block in result],
            }
            try:
                await self._events.publish(
                    run_id=run_id, session_id=product_session_id,
                    execution_id=execution_id, agent_attempt_id=agent_attempt_id,
                    agent_environment_id=agent_environment_id, agent_id=agent.agent_id,
                    parent_agent_id=agent.parent_agent_id, event_type=EventType.AGENT_COMPLETED,
                    data=data,
                )
            except Exception as commit_error:
                # An accepted completion followed by a failed acknowledgement
                # is already successful work. Verify the full governed fact
                # before allowing the Scheduler to count a failure and retry.
                expected_data, _ = self._data_policy.protect(EventType.AGENT_COMPLETED, data)
                confirmed = False
                try:
                    async for event in iter_events(self._state, run_id):
                        if (
                            event.type == EventType.AGENT_COMPLETED and event.run_id == run_id
                            and event.session_id == product_session_id and event.execution_id == execution_id
                            and event.agent_attempt_id == agent_attempt_id
                            and event.agent_environment_id == agent_environment_id
                            and event.agent_id == agent.agent_id and event.parent_agent_id == agent.parent_agent_id
                            and event.data == expected_data
                        ):
                            confirmed = True
                            break
                except Exception as read_error:
                    commit_error.add_note(f"Agent completion reconciliation failed: {self._format_failure(read_error)}")
                    raise commit_error from read_error
                if not confirmed:
                    raise
                self._record_cleanup_failure(run_id, "confirmed Agent completion acknowledgement", commit_error)

        async def publish_application_execution_failure(reason: str, info: ErrorInfo | None = None) -> None:
            nonlocal execution_terminal_published, runtime_execution_started
            if execution_terminal_published:
                return
            # Cancellation or an ambiguous backend response can arrive after
            # the commit succeeded but before the await updated local flags.
            # The durable terminal wins; never manufacture a second terminal
            # for that same execution/attempt while projecting the Run error.
            async for event in iter_events(self._state, run_id):
                if not (
                    event.run_id == run_id and event.execution_id == execution_id
                    and event.session_id == product_session_id and event.agent_attempt_id == agent_attempt_id
                    and event.agent_id == agent.agent_id and event.parent_agent_id == agent.parent_agent_id
                ):
                    continue
                if event.type in {EventType.EXECUTION_COMPLETED, EventType.EXECUTION_FAILED}:
                    execution_terminal_published = True
                    return
                if event.type == EventType.EXECUTION_STARTED:
                    runtime_execution_started = True
            if not runtime_execution_started:
                return
            data: dict[str, JsonValue] = {"reason": reason}
            if info is not None:
                data["error"] = info.model_dump(mode="json", by_alias=True)
            await self._events.publish(
                run_id=run_id,
                session_id=product_session_id,
                execution_id=execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=agent.agent_id,
                parent_agent_id=agent.parent_agent_id,
                event_type=EventType.EXECUTION_FAILED,
                data=data,
            )
            execution_terminal_published = True

        try:
            descriptor = await runtime.describe()
            environment_snapshot = await self._resolve_agent_environment(
                runtime_session_id=runtime_session_id,
                command=command,
                descriptor=descriptor,
                release_system=system,
                release_tool_names=tool_names,
                release_environment=release_environment,
                release_id=f"{command.profile}:{agent.agent_id}",
            )
            agent_environment_id = environment_snapshot.snapshot_id
            tools = environment_snapshot.tools
            self._validate_workspace_tool_permissions(agent, workspace_access, tools)
            self._validate_capabilities(
                input,
                required_modalities,
                required_features,
                descriptor.capabilities,
                tools,
            )
            use_command_runtime_options = runtime_selector == command.runtime.selector
            session_spec = RuntimeSessionSpec(
                session_id=runtime_session_id,
                workspace=command.workspace,
                model=command.runtime.model if use_command_runtime_options else None,
                provider=command.runtime.provider if use_command_runtime_options else None,
                # sessionId is identity, not proof that vendor state exists.
                # Hosts which interpret an incoming legacy id as a resume
                # request set resume_session explicitly.
                resume=bool(command.resume_session),
                agent_environment=environment_snapshot,
                metadata={**command.metadata, "workflowAgentId": agent.agent_id},
            )
            if command.resume_session:
                recovered = await self._completed_execution(run_id, agent, dag_attempt=emit_agent_lifecycle)
                if recovered is not None:
                    terminal, recovered_output = recovered
                    if terminal.agent_environment_id != agent_environment_id:
                        raise self._error(
                            "RECOVERED_EXECUTION_ENVIRONMENT_MISMATCH", ErrorCategory.CONFLICT,
                            "Completed execution differs from the immutable AgentEnvironment binding",
                        )
                    assert terminal.execution_id is not None and terminal.agent_attempt_id is not None
                    execution_id = terminal.execution_id
                    agent_attempt_id = terminal.agent_attempt_id
                    agent_started = runtime_execution_started = execution_terminal_published = True
                    # The model/tool execution is already durable. Reconnect
                    # only to settle Session resources, then finish the same
                    # Application attempt without starting another execution.
                    runtime_session = await runtime.open_session(session_spec)
                    await runtime.close_session(runtime_session)
                    runtime_session = None
                    await self._require_run_ownership(run_id)
                    if emit_agent_lifecycle:
                        await publish_agent_completion(recovered_output)
                    return recovered_output
            await self._events.publish(
                run_id=run_id,
                session_id=product_session_id,
                execution_id=execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=agent.agent_id,
                parent_agent_id=agent.parent_agent_id,
                event_type=EventType.AGENT_ENVIRONMENT_RESOLVED,
                data=environment_snapshot.trajectory_manifest(),
            )
            if emit_agent_lifecycle:
                await self._events.publish(
                    run_id=run_id,
                    session_id=product_session_id,
                    execution_id=execution_id,
                    agent_attempt_id=agent_attempt_id,
                    agent_environment_id=agent_environment_id,
                    agent_id=agent.agent_id,
                    parent_agent_id=agent.parent_agent_id,
                    event_type=EventType.AGENT_STARTED,
                    data={
                        "role": agent.role,
                        "runtime": descriptor.model_dump(mode="json", by_alias=True),
                        **(lifecycle_data or {}),
                    },
                )
                agent_started = True

            runtime_session = await runtime.open_session(session_spec)
            request = ExecutionRequest(
                run_id=run_id,
                execution_id=execution_id,
                session_id=runtime_session_id,
                agent=agent,
                input=input,
                agent_environment=environment_snapshot,
                workspace=command.workspace,
                knowledge=command.knowledge,
                policy=ExecutionPolicy(
                    required_capabilities=required_features,
                    max_stalled_actions=max_stalled_actions,
                ),
                metadata={**command.metadata, "workflowAgentId": agent.agent_id},
            )
            channel = await runtime.execute(request)
            self._channels.setdefault(run_id, {})[execution_id] = channel
            terminal_event: RuntimeEvent | None = None
            expected_runtime_sequence = 0
            output: list[ContentBlock] = []
            selected_tools = {tool.name: tool for tool in tools}
            terminal_tool_committed = False
            terminal_interaction_committed = False
            runtime_data_lineage = RuntimeEventLineageValidator()
            known_runtime_children: set[str] = set()
            terminal_runtime_children: set[str] = set()
            allow_runtime_children = bool(
                {"native_multi_agent", "native_graph_execution"}.intersection(required_features)
            )
            async for event in channel.events():
                if event.execution_id != execution_id:
                    raise self._error(
                        "RUNTIME_EXECUTION_CORRELATION_MISMATCH",
                        ErrorCategory.PROTOCOL,
                        f"Runtime emitted {event.execution_id} for execution {execution_id}",
                    )
                if event_runtime_instance_id is None:
                    event_runtime_instance_id = event.runtime_instance_id
                elif event.runtime_instance_id != event_runtime_instance_id:
                    raise self._error(
                        "RUNTIME_INSTANCE_CORRELATION_MISMATCH",
                        ErrorCategory.PROTOCOL,
                        f"Runtime instance changed within execution {execution_id}: "
                        f"{event_runtime_instance_id} -> {event.runtime_instance_id}",
                    )
                if event.runtime_sequence != expected_runtime_sequence:
                    raise self._error(
                        "RUNTIME_SEQUENCE_INVALID",
                        ErrorCategory.PROTOCOL,
                        f"Runtime sequence must be contiguous from zero; expected "
                        f"{expected_runtime_sequence}, received {event.runtime_sequence}",
                    )
                expected_runtime_sequence += 1
                if event.runtime_sequence == 0 and event.type != EventType.EXECUTION_STARTED:
                    raise self._error(
                        "RUNTIME_EXECUTION_START_INVALID",
                        ErrorCategory.PROTOCOL,
                        "Runtime sequence zero must be execution.started",
                    )
                if event.type == EventType.EXECUTION_STARTED:
                    if runtime_execution_start_seen:
                        raise self._error(
                            "RUNTIME_EXECUTION_START_INVALID",
                            ErrorCategory.PROTOCOL,
                            "Runtime emitted execution.started more than once",
                        )
                    runtime_execution_start_seen = True
                self._validate_runtime_event_lineage(
                    event=event,
                    execution_agent=agent,
                    execution_id=execution_id,
                    capabilities=descriptor.capabilities,
                    allow_runtime_children=allow_runtime_children,
                    expected_group_id=(lifecycle_data or {}).get("parallelGroupId"),
                    known_children=known_runtime_children,
                    terminal_children=terminal_runtime_children,
                )
                if terminal_event is not None:
                    raise self._error(
                        "RUNTIME_TERMINAL_EVENT_INVALID",
                        ErrorCategory.PROTOCOL,
                        "Runtime emitted an event after its terminal event",
                    )
                if event.type == EventType.USAGE_UPDATED:
                    original_usage = event.data
                    assert isinstance(original_usage, dict)
                    canonical_usage, was_legacy = canonicalize_runtime_usage(
                        original_usage
                    )
                    if was_legacy:
                        await self._events.publish(
                            run_id=run_id,
                            session_id=product_session_id,
                            execution_id=event.execution_id,
                            agent_attempt_id=agent_attempt_id,
                            agent_environment_id=agent_environment_id,
                            agent_id=event.agent_id,
                            parent_agent_id=event.parent_agent_id,
                            event_type=EventType.RAW_EVENT_RECORDED,
                            data=RawRuntimeEventData(
                                producer=descriptor.name,
                                vendor_event_type=EventType.USAGE_UPDATED.value,
                                runtime_instance_id=event.runtime_instance_id,
                                runtime_sequence=event.runtime_sequence,
                                reason="unsupported-event",
                                payload=original_usage,
                            ).model_dump(mode="json", by_alias=True),
                            ignorable=True,
                        )
                    if canonical_usage is None:
                        continue
                    event = event.model_copy(update={"data": canonical_usage})
                try:
                    runtime_data_lineage.observe(event)
                except ValueError as exc:
                    raise self._error(
                        "RUNTIME_DATA_LINEAGE_INVALID",
                        ErrorCategory.PROTOCOL,
                        str(exc),
                    ) from exc
                # Forward-compatible vendor events remain explicit facts. The
                # v1 EventType enum cannot carry their name, so persist a typed
                # raw envelope instead of silently deleting them.
                if not isinstance(event.type, EventType):
                    await self._events.publish(
                        run_id=run_id,
                        session_id=product_session_id,
                        execution_id=event.execution_id,
                        agent_attempt_id=agent_attempt_id,
                        agent_environment_id=agent_environment_id,
                        agent_id=event.agent_id,
                        parent_agent_id=event.parent_agent_id,
                        event_type=EventType.RAW_EVENT_RECORDED,
                        data=RawRuntimeEventData(
                            producer=descriptor.name,
                            vendor_event_type=event.type,
                            runtime_instance_id=event.runtime_instance_id,
                            runtime_sequence=event.runtime_sequence,
                            reason="unknown-event",
                            payload=event.data,
                        ).model_dump(mode="json", by_alias=True),
                        ignorable=True,
                    )
                    continue
                if event.type in {
                    EventType.EXECUTION_COMPLETED,
                    EventType.EXECUTION_FAILED,
                }:
                    try:
                        runtime_data_lineage.finish()
                    except ValueError as exc:
                        raise self._error(
                            "RUNTIME_DATA_LINEAGE_INVALID",
                            ErrorCategory.PROTOCOL,
                            str(exc),
                        ) from exc
                    terminal_event = event
                    continue
                if (terminal_tool_committed or terminal_interaction_committed) and event.type not in {
                    EventType.USAGE_UPDATED,
                }:
                    if event.type == EventType.TOOL_REQUESTED:
                        await self._reject_after_terminal_tool(channel, event)
                    continue
                interaction = self._interaction_request(event)
                interaction_key: tuple[str, str] | None = None
                interaction_reservation: tuple[str, ExecutionChannel] | None = None
                interaction_was_responded = False
                if interaction is not None and not interaction.terminal:
                    interaction_key = (run_id, interaction.interaction_id)
                    if interaction_key in self._interaction_channels:
                        raise self._error(
                            "RUNTIME_INTERACTION_ID_CONFLICT",
                            ErrorCategory.PROTOCOL,
                            f"Runtime reused active interactionId {interaction.interaction_id!r}",
                        )
                    interaction_reservation = (execution_id, channel)
                    # Publish only after the response route exists. StateStore
                    # readers can observe a committed event immediately, before
                    # EventSink delivery or this coroutine gets another turn.
                    self._interaction_channels[interaction_key] = interaction_reservation
                try:
                    if interaction is not None and interaction.commit_barrier:
                        await self._commit_interaction_barrier(
                            run_id=run_id,
                            session_id=product_session_id,
                            execution_id=execution_id,
                            agent_attempt_id=agent_attempt_id,
                            agent_environment_id=agent_environment_id,
                            agent=agent,
                            interaction=interaction,
                            environment_ref=environment_ref,
                        )
                    canonical_data = event.data
                    snapshot_status = (
                        RunStatus.WAITING if interaction is not None and not interaction.terminal else None
                    )
                    if event.type == EventType.INTERACTION_RESOLVED:
                        interaction_id = event.data.get("interactionId")
                        assert isinstance(interaction_id, str)
                        interaction_key = (run_id, interaction_id)
                        interaction_reservation = self._interaction_channels.get(interaction_key)
                        if (
                            interaction_reservation is None
                            or interaction_reservation[0] != execution_id
                            or interaction_reservation[1] is not channel
                        ):
                            raise self._error(
                                "RUNTIME_INTERACTION_RESOLUTION_INVALID",
                                ErrorCategory.PROTOCOL,
                                "Runtime resolved an interaction that is not active on this execution: "
                                f"{interaction_id}",
                            )
                        interaction_was_responded = interaction_key in self._responded_interactions
                        self._interaction_channels.pop(interaction_key, None)
                        self._responded_interactions.discard(interaction_key)
                        pending_interactions = sum(
                            1
                            for candidate_run_id, _candidate_interaction_id in self._interaction_channels
                            if candidate_run_id == run_id
                        )
                        canonical_data = {
                            **event.data,
                            "pendingInteractions": pending_interactions,
                        }
                        snapshot_status = RunStatus.WAITING if pending_interactions else RunStatus.RUNNING
                    canonical = await self._events.publish(
                        run_id=run_id,
                        session_id=product_session_id,
                        execution_id=event.execution_id,
                        agent_attempt_id=agent_attempt_id,
                        agent_environment_id=agent_environment_id,
                        agent_id=event.agent_id,
                        parent_agent_id=event.parent_agent_id,
                        event_type=event.type,
                        data=canonical_data,
                        ignorable=event.ignorable,
                        snapshot_status=snapshot_status,
                    )
                    if event.type == EventType.EXECUTION_STARTED:
                        runtime_execution_started = True
                except BaseException:
                    if interaction_key is not None and interaction_reservation is not None:
                        if event.type == EventType.INTERACTION_RESOLVED:
                            self._interaction_channels[interaction_key] = interaction_reservation
                            if interaction_was_responded:
                                self._responded_interactions.add(interaction_key)
                        elif self._interaction_channels.get(interaction_key) is interaction_reservation:
                            self._interaction_channels.pop(interaction_key, None)
                    raise
                if interaction is not None and interaction.terminal:
                    terminal_interaction_committed = True
                if event.type == EventType.TOOL_REQUESTED:
                    terminal_tool_committed = (
                        await self._handle_tool_request(
                            run_id=run_id,
                            session_id=product_session_id,
                            channel=channel,
                            event=event,
                            request=request,
                            selected_tools=selected_tools,
                            agent_attempt_id=agent_attempt_id,
                            agent_environment_id=agent_environment_id,
                            causation_id=canonical.event_id,
                            environment_ref=environment_ref,
                        )
                        or terminal_tool_committed
                    )
                # Native child messages remain canonical observations. Only
                # the execution owner decides what becomes its DAG output.
                if event.type == EventType.MESSAGE_COMPLETED and event.agent_id == agent.agent_id:
                    output.extend(self._message_content(event))

            if terminal_event is None:
                raise self._error(
                    "RUNTIME_TERMINAL_EVENT_INVALID",
                    ErrorCategory.PROTOCOL,
                    f"Runtime {descriptor.name} ended without exactly one terminal event",
                )
            if descriptor.capabilities.child_event_projection == ChildEventProjection.FULL:
                unterminated_children = sorted(known_runtime_children.difference(terminal_runtime_children))
                if unterminated_children:
                    raise self._error(
                        "RUNTIME_CHILD_AGENT_TERMINAL_MISSING",
                        ErrorCategory.PROTOCOL,
                        "Runtime ended execution while child agents were still active: "
                        + ", ".join(unterminated_children),
                    )
            await self._events.publish(
                run_id=run_id,
                session_id=product_session_id,
                execution_id=terminal_event.execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=terminal_event.agent_id,
                parent_agent_id=terminal_event.parent_agent_id,
                event_type=terminal_event.type,
                data=terminal_event.data,
                ignorable=terminal_event.ignorable,
            )
            execution_terminal_published = True
            if terminal_event.type == EventType.EXECUTION_FAILED:
                raise self._error(
                    "RUNTIME_EXECUTION_FAILED",
                    ErrorCategory.INTERNAL,
                    f"Runtime {descriptor.name} reported a failed execution",
                )
        except asyncio.CancelledError as cancellation:
            if run_id not in self._recoverable_interruptions:
                try:
                    await publish_application_execution_failure("application_execution_cancelled")
                except BaseException as projection_error:
                    cancellation.add_note(
                        "execution cancellation projection also failed: "
                        f"{type(projection_error).__name__}: {projection_error}"
                    )
                    self._record_cleanup_failure(run_id, "execution cancellation projection", projection_error)
            if emit_agent_lifecycle and agent_started and run_id not in self._recoverable_interruptions:
                await self._events.publish(
                    run_id=run_id,
                    session_id=product_session_id,
                    execution_id=execution_id,
                    agent_attempt_id=agent_attempt_id,
                    agent_environment_id=agent_environment_id,
                    agent_id=agent.agent_id,
                    parent_agent_id=agent.parent_agent_id,
                    event_type=EventType.AGENT_CANCELLED,
                    data={"reason": "run_cancelled"},
                )
            raise
        except Exception as exc:
            info = (
                exc.info
                if isinstance(exc, ContractError)
                else ErrorInfo(
                    code="AGENT_EXECUTION_FAILED",
                    category=ErrorCategory.INTERNAL,
                    message=str(exc) or type(exc).__name__,
                )
            )
            projection_errors: list[BaseException] = []
            try:
                await publish_application_execution_failure("application_rejected_runtime_execution", info)
            except BaseException as projection_error:
                projection_errors.append(projection_error)
            if emit_agent_lifecycle and agent_started:
                try:
                    await self._events.publish(
                        run_id=run_id,
                        session_id=product_session_id,
                        execution_id=execution_id,
                        agent_attempt_id=agent_attempt_id,
                        agent_environment_id=agent_environment_id,
                        agent_id=agent.agent_id,
                        parent_agent_id=agent.parent_agent_id,
                        event_type=EventType.AGENT_FAILED,
                        data={"error": info.model_dump(mode="json", by_alias=True)},
                    )
                except BaseException as projection_error:
                    projection_errors.append(projection_error)
            for projection_error in projection_errors:
                exc.add_note(
                    f"execution failure projection also failed: {type(projection_error).__name__}: {projection_error}"
                )
            raise
        finally:
            self._channels.get(run_id, {}).pop(execution_id, None)
            stale_interactions = [
                key
                for key, (target_execution_id, _) in self._interaction_channels.items()
                if key[0] == run_id and target_execution_id == execution_id
            ]
            for key in stale_interactions:
                self._interaction_channels.pop(key, None)
                self._responded_interactions.discard(key)
            active_error = sys.exception()
            cleanup_errors: list[BaseException] = []
            if channel is not None:
                try:
                    await channel.close()
                except BaseException as exc:
                    cleanup_errors.append(exc)
            if runtime_session is not None:
                try:
                    await runtime.close_session(runtime_session)
                except BaseException as exc:
                    cleanup_errors.append(exc)
            if cleanup_errors:
                if active_error is not None:
                    for cleanup_error in cleanup_errors:
                        active_error.add_note(
                            f"execution cleanup also failed: {type(cleanup_error).__name__}: {cleanup_error}"
                        )
                elif len(cleanup_errors) == 1:
                    raise cleanup_errors[0]
                else:
                    raise BaseExceptionGroup("execution channel/session cleanup failed", cleanup_errors)

        result = tuple(output)
        if emit_agent_lifecycle:
            await publish_agent_completion(result)
        return result

    async def _resolve_agent_environment(
        self,
        *,
        runtime_session_id: str,
        command: StartRunCommand,
        descriptor: RuntimeDescriptor,
        release_system: tuple[ContentBlock, ...],
        release_tool_names: tuple[str, ...],
        release_environment: AgentEnvironmentLayer,
        release_id: str,
    ) -> AgentEnvironmentSnapshot:
        lock = self._environment_locks.setdefault(runtime_session_id, asyncio.Lock())
        async with lock:
            existing = await self._state.get_environment_snapshot(runtime_session_id)
            if existing is not None:
                await self._agent_environments.validate_persisted(
                    existing,
                    runtime=descriptor,
                )
                return existing
            snapshot: AgentEnvironmentSnapshot = await self._agent_environments.resolve(
                self._compose_agent_environment(command),
                runtime=descriptor,
                release_system=release_system,
                release_tool_names=release_tool_names,
                release_environment=release_environment,
                release_id=release_id,
                release_version=self._profiles[command.profile].version,
                invocation_instructions=command.instructions,
            )
            await self._state.save_environment_snapshot(runtime_session_id, snapshot)
            return snapshot

    def _compose_agent_environment(self, command: StartRunCommand) -> AgentEnvironmentSpec:
        base = self._base_agent_environment
        requested = command.agent_environment or AgentEnvironmentSpec(prompt_resolution=base.prompt_resolution)
        reserved_layers = {
            "builtin": requested.builtin,
            "releaseProfile": requested.release_profile,
            "hostMount": requested.host_mount,
        }
        supplied_reserved = [name for name, layer in reserved_layers.items() if layer != AgentEnvironmentLayer()]
        if supplied_reserved:
            raise self._error(
                "AGENT_ENVIRONMENT_LAYER_FORBIDDEN",
                ErrorCategory.INVALID_REQUEST,
                "Run requests may only add Invocation resources; Host-owned layers were supplied: "
                + ", ".join(supplied_reserved),
            )
        return AgentEnvironmentSpec(
            prompt_resolution=requested.prompt_resolution,
            builtin=base.builtin,
            release_profile=base.release_profile,
            host_mount=base.host_mount,
            invocation=self._merge_environment_layer(base.invocation, requested.invocation),
            extensions=tuple({item.key: item for item in (*base.extensions, *requested.extensions)}.values()),
        )

    @staticmethod
    def _merge_environment_layer(
        left: AgentEnvironmentLayer,
        right: AgentEnvironmentLayer,
    ) -> AgentEnvironmentLayer:
        return AgentEnvironmentLayer(
            system_prompts=(*left.system_prompts, *right.system_prompts),
            skills=(*left.skills, *right.skills),
            tool_sources=(*left.tool_sources, *right.tool_sources),
            mcp_sources=(*left.mcp_sources, *right.mcp_sources),
        )

    def _validate_capabilities(
        self,
        input: tuple[ContentBlock, ...],
        required_input_modalities: tuple[Modality, ...],
        required_features: tuple[str, ...],
        capabilities: RuntimeCapabilities,
        tools: tuple[ToolSpec, ...],
    ) -> None:
        required_modalities = set(required_input_modalities)
        for block in input:
            if isinstance(block, ImageRefBlock):
                required_modalities.add(Modality.IMAGE)
            elif isinstance(block, AudioRefBlock):
                required_modalities.add(Modality.AUDIO)
            elif isinstance(block, VideoRefBlock):
                required_modalities.add(Modality.VIDEO)
            elif isinstance(block, FileRefBlock):
                required_modalities.add(Modality.FILE)
        missing_modalities = required_modalities.difference(capabilities.input_modalities)
        missing_features = [feature for feature in required_features if not bool(getattr(capabilities, feature, False))]
        if tools and not capabilities.tool_calling and "tool_calling" not in missing_features:
            missing_features.append("tool_calling")
        if any(tool.execution in {ToolExecution.APPLICATION, ToolExecution.REMOTE} for tool in tools):
            if not capabilities.application_tool_bridge and "application_tool_bridge" not in missing_features:
                missing_features.append("application_tool_bridge")
        if missing_modalities or missing_features:
            missing = sorted([modality.value for modality in missing_modalities] + missing_features)
            raise self._error(
                "RUNTIME_CAPABILITY_MISSING",
                ErrorCategory.INVALID_REQUEST,
                f"Runtime is missing required capabilities: {', '.join(missing)}",
            )

    def _validate_runtime_event_lineage(
        self,
        *,
        event: RuntimeEvent,
        execution_agent: AgentRef,
        execution_id: str,
        capabilities: RuntimeCapabilities,
        allow_runtime_children: bool,
        expected_group_id: object,
        known_children: set[str],
        terminal_children: set[str],
    ) -> None:
        root_agent_id = execution_agent.agent_id
        if event.agent_id == root_agent_id:
            if event.parent_agent_id != execution_agent.parent_agent_id:
                raise self._error(
                    "RUNTIME_AGENT_LINEAGE_INVALID",
                    ErrorCategory.PROTOCOL,
                    f"Runtime changed the parent of execution agent {root_agent_id}",
                )
            return

        if not allow_runtime_children or not capabilities.native_multi_agent:
            raise self._error(
                "RUNTIME_CHILD_AGENT_NOT_AUTHORIZED",
                ErrorCategory.PROTOCOL,
                f"Runtime emitted child agent {event.agent_id} without workflow authorization",
            )
        if event.type in {
            EventType.EXECUTION_STARTED,
            EventType.EXECUTION_COMPLETED,
            EventType.EXECUTION_FAILED,
        }:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                "Execution boundary events must belong to the Application-owned execution agent",
            )
        if event.agent_id == event.parent_agent_id:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime child agent {event.agent_id} cannot parent itself",
            )
        if event.parent_agent_id != root_agent_id and event.parent_agent_id not in known_children:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime child agent {event.agent_id} has an unknown parent: {event.parent_agent_id}",
            )
        if event.parent_agent_id in terminal_children:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime child agent {event.agent_id} emitted under terminal parent {event.parent_agent_id}",
            )
        if not isinstance(event.data, dict) or event.data.get("parentExecutionId") != execution_id:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime child agent {event.agent_id} is missing its canonical parentExecutionId",
            )
        projected_group_id = event.data.get("groupId")
        if isinstance(expected_group_id, str) and expected_group_id:
            if projected_group_id != expected_group_id:
                raise self._error(
                    "RUNTIME_AGENT_LINEAGE_INVALID",
                    ErrorCategory.PROTOCOL,
                    f"Runtime child agent {event.agent_id} escaped parallel group {expected_group_id}",
                )
        elif projected_group_id is not None and (not isinstance(projected_group_id, str) or not projected_group_id):
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime child agent {event.agent_id} emitted an invalid groupId",
            )

        if event.agent_id in terminal_children:
            raise self._error(
                "RUNTIME_AGENT_LINEAGE_INVALID",
                ErrorCategory.PROTOCOL,
                f"Runtime emitted an event after child agent {event.agent_id} became terminal",
            )
        if capabilities.child_event_projection == ChildEventProjection.FULL:
            if event.type == EventType.AGENT_STARTED:
                if event.agent_id in known_children:
                    raise self._error(
                        "RUNTIME_AGENT_LINEAGE_INVALID",
                        ErrorCategory.PROTOCOL,
                        f"Runtime started child agent {event.agent_id} more than once",
                    )
            elif event.agent_id not in known_children:
                event_type = event.type.value if isinstance(event.type, EventType) else event.type
                raise self._error(
                    "RUNTIME_AGENT_LINEAGE_INVALID",
                    ErrorCategory.PROTOCOL,
                    f"Runtime emitted {event_type} before starting child agent {event.agent_id}",
                )
        if event.type == EventType.AGENT_STARTED:
            known_children.add(event.agent_id)
        if event.type in {
            EventType.AGENT_COMPLETED,
            EventType.AGENT_FAILED,
            EventType.AGENT_CANCELLED,
        }:
            terminal_children.add(event.agent_id)

    async def _handle_tool_request(
        self,
        *,
        run_id: str,
        session_id: str,
        channel: ExecutionChannel,
        event: RuntimeEvent,
        request: ExecutionRequest,
        selected_tools: dict[str, ToolSpec],
        agent_attempt_id: str,
        agent_environment_id: str,
        causation_id: str,
        environment_ref: EnvironmentRef | None,
    ) -> bool:
        if not isinstance(event.data, dict):
            return False
        data = event.data
        name = data.get("name")
        declared_execution = data.get("execution")
        spec = selected_tools.get(name) if isinstance(name, str) else None
        normalized_execution = (
            ToolExecution(declared_execution) if isinstance(declared_execution, (str, ToolExecution)) else None
        )
        if spec is not None and normalized_execution is not None and normalized_execution != spec.execution:
            raise self._error(
                "RUNTIME_TOOL_EXECUTION_MISMATCH",
                ErrorCategory.PROTOCOL,
                f"Runtime declared {normalized_execution.value} execution for {name}, "
                f"but the selected ToolSpec requires {spec.execution.value}",
            )
        application_owned = spec is not None and spec.execution in {
            ToolExecution.APPLICATION,
            ToolExecution.REMOTE,
        }
        explicitly_external = normalized_execution in {
            ToolExecution.APPLICATION,
            ToolExecution.REMOTE,
        }
        if not application_owned and not explicitly_external:
            return False

        call_id = data.get("callId")
        arguments = data.get("arguments")
        raw_arguments = data.get("rawArguments")
        if not isinstance(call_id, str) or not call_id or not isinstance(name, str) or not name:
            raise self._error(
                "RUNTIME_TOOL_CALL_INVALID",
                ErrorCategory.PROTOCOL,
                "Runtime emitted an external tool request without callId or name",
            )

        committed = await self._committed_tool_result(
            run_id=run_id,
            agent_id=event.agent_id,
            call_id=call_id,
            name=name,
            arguments=arguments if isinstance(arguments, dict) else None,
            raw_arguments=raw_arguments if isinstance(raw_arguments, str) else None,
        )
        if committed is not None:
            await channel.send_tool_result(committed)
            return committed.error is None and spec is not None and spec.terminal_on_success

        if spec is None:
            result = ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="TOOL_NOT_AUTHORIZED",
                    category=ErrorCategory.PERMISSION,
                    message=f"Tool was not selected by the workflow: {name}",
                ),
            )
        elif not isinstance(arguments, dict):
            result = ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="TOOL_ARGUMENTS_INVALID",
                    category=ErrorCategory.INVALID_REQUEST,
                    message=f"Tool arguments must be an object: {name}",
                ),
            )
        else:
            try:
                call = ToolCall(
                    call_id=call_id,
                    run_id=request.run_id,
                    session_id=request.session_id,
                    execution_id=event.execution_id,
                    agent_id=event.agent_id,
                    name=name,
                    arguments=arguments,
                    workspace=request.workspace,
                    agent_environment=request.agent_environment,
                    knowledge=request.knowledge,
                    metadata=request.metadata,
                )
            except ValidationError as exc:
                raise self._error(
                    "RUNTIME_TOOL_CALL_INVALID",
                    ErrorCategory.PROTOCOL,
                    str(exc),
                ) from exc
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                execution_id=event.execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=event.agent_id,
                parent_agent_id=event.parent_agent_id,
                event_type=EventType.TOOL_STARTED,
                data={
                    "callId": call.call_id,
                    "name": call.name,
                    "arguments": call.arguments,
                    "modelCallId": data.get("modelCallId"),
                },
                causation_id=causation_id,
            )
            # Native child tools carry their own agent identity, while the
            # containing Runtime execution keeps the parent's asset scope.
            context = get_asset_write_context()
            with asset_write_context(
                run_id=run_id,
                profile_id=context.get("profile_id"),
                agent_id=event.agent_id,
            ):
                result = await self._tools.invoke(
                    call,
                    max_stalled_actions=request.policy.max_stalled_actions,
                )

        # An invoked Application-owned tool with mutation permissions may have
        # changed the shared workspace even when it reports an error. Persist
        # that observable state before the Runtime receives the ToolResult;
        # otherwise resumed model history can get ahead of durable workspace
        # state. This replaces the legacy per-tool workspace WAL barrier.
        if (
            spec is not None
            and self._tool_requires_workspace_checkpoint(spec)
            and self._environment is not None
            and environment_ref is not None
            and request.workspace.workspace_id == environment_ref.workspace.workspace_id
        ):
            checkpoint = await self._checkpoint_environment(environment_ref)
            checkpoint_data = checkpoint.model_dump(mode="json", by_alias=True)
            checkpoint_data.update(
                {
                    "boundary": "application_tool_result",
                    "callId": call_id,
                    "toolName": name,
                }
            )
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                execution_id=event.execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=event.agent_id,
                parent_agent_id=event.parent_agent_id,
                event_type=EventType.WORKSPACE_CHECKPOINTED,
                data=checkpoint_data,
                causation_id=causation_id,
            )

        result_data = result.model_dump(mode="json", by_alias=True)
        result_data.update(
            {
                "name": name,
                "arguments": arguments if isinstance(arguments, dict) else None,
                "rawArguments": raw_arguments if isinstance(raw_arguments, str) else None,
                "modelCallId": data.get("modelCallId"),
            }
        )
        await self._events.publish(
            run_id=run_id,
            session_id=session_id,
            execution_id=event.execution_id,
            agent_attempt_id=agent_attempt_id,
            agent_environment_id=agent_environment_id,
            agent_id=event.agent_id,
            parent_agent_id=event.parent_agent_id,
            event_type=EventType.TOOL_FAILED if result.error is not None else EventType.TOOL_COMPLETED,
            data=result_data,
            causation_id=causation_id,
        )
        # The canonical ToolResult is committed before handing it back to the
        # Runtime. If the process dies in that narrow window, a repeated callId
        # is replayed from StateStore instead of invoking the provider again.
        await channel.send_tool_result(result)
        return result.error is None and spec is not None and spec.terminal_on_success

    async def _committed_tool_result(
        self,
        *,
        run_id: str,
        agent_id: str,
        call_id: str,
        name: str,
        arguments: dict[str, JsonValue] | None,
        raw_arguments: str | None,
    ) -> ToolResult | None:
        latest: RunEvent | None = None
        async for previous in iter_events(self._state, run_id):
            if (
                previous.type not in {EventType.TOOL_COMPLETED, EventType.TOOL_FAILED}
                or previous.agent_id != agent_id
                or not isinstance(previous.data, dict)
                or previous.data.get("callId") != call_id
            ):
                continue
            latest = previous
        if latest is not None:
            recorded_name = latest.data.get("name")
            recorded_arguments = latest.data.get("arguments")
            recorded_raw_arguments = latest.data.get("rawArguments")
            if recorded_name is not None and recorded_name != name:
                raise self._error(
                    "RUNTIME_TOOL_CALL_ID_CONFLICT",
                    ErrorCategory.PROTOCOL,
                    f"Runtime reused callId {call_id!r} for a different tool",
                )
            if recorded_arguments != arguments or recorded_raw_arguments != raw_arguments:
                raise self._error(
                    "RUNTIME_TOOL_CALL_ID_CONFLICT",
                    ErrorCategory.PROTOCOL,
                    f"Runtime reused callId {call_id!r} with different arguments",
                )
            try:
                return ToolResult.model_validate(
                    {
                        "callId": latest.data.get("callId"),
                        "content": latest.data.get("content", []),
                        "value": latest.data.get("value"),
                        "error": latest.data.get("error"),
                    }
                )
            except ValidationError as exc:
                raise self._error(
                    "DURABLE_TOOL_RESULT_INVALID",
                    ErrorCategory.INTERNAL,
                    f"Committed ToolResult {call_id!r} is invalid: {exc}",
                ) from exc
        return None

    @staticmethod
    def _tool_requires_workspace_checkpoint(spec: ToolSpec) -> bool:
        return bool({"workspace.write", "workspace.execute"}.intersection(spec.permissions))

    def _validate_workspace_tool_permissions(
        self,
        agent: AgentRef,
        workspace_access: WorkspaceAccess | None,
        tools: tuple[ToolSpec, ...],
    ) -> None:
        if workspace_access is not WorkspaceAccess.READ:
            return
        denied = sorted(
            tool.name for tool in tools if {"workspace.write", "workspace.execute"}.intersection(tool.permissions)
        )
        if denied:
            raise self._error(
                "WORKSPACE_ACCESS_VIOLATION",
                ErrorCategory.PERMISSION,
                f"Read-only Agent {agent.agent_id} cannot use workspace-mutating tools: " + ", ".join(denied),
            )

    @staticmethod
    async def _reject_after_terminal_tool(channel: ExecutionChannel, event: RuntimeEvent) -> None:
        if not isinstance(event.data, dict):
            return
        call_id = event.data.get("callId")
        if not isinstance(call_id, str) or not call_id:
            return
        await channel.send_tool_result(
            ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="EXECUTION_ALREADY_COMMITTED",
                    category=ErrorCategory.CONFLICT,
                    message="A terminal tool has already committed this execution",
                ),
            )
        )

    @staticmethod
    def _compose_agent_input(
        original: tuple[ContentBlock, ...],
        agent: WorkflowAgent,
        outputs: dict[str, tuple[ContentBlock, ...]],
    ) -> tuple[ContentBlock, ...]:
        content: list[ContentBlock] = []
        if agent.input_mode in {AgentInputMode.ORIGINAL, AgentInputMode.ORIGINAL_AND_DEPENDENCIES}:
            content.extend(original)
        if agent.input_mode in {AgentInputMode.DEPENDENCIES, AgentInputMode.ORIGINAL_AND_DEPENDENCIES}:
            for dependency in agent.depends_on:
                content.append(TextBlock(text=f"Upstream result from {dependency}:"))
                content.extend(outputs[dependency])
        if not content:
            content.append(TextBlock(text="No upstream content was produced; inspect the shared workspace."))
        return tuple(content)

    @staticmethod
    def _ordered_union(*groups: tuple[object, ...]) -> tuple[object, ...]:
        return tuple(dict.fromkeys(item for group in groups for item in group))

    def _message_content(self, event: RuntimeEvent | RunEvent) -> tuple[ContentBlock, ...]:
        if not isinstance(event.data, dict) or not isinstance(event.data.get("content"), list):
            return ()
        try:
            return TypeAdapter(tuple[ContentBlock, ...]).validate_python(event.data["content"])
        except ValidationError as exc:
            raise self._error(
                "RUNTIME_MESSAGE_CONTENT_INVALID",
                ErrorCategory.PROTOCOL,
                str(exc),
            ) from exc

    @staticmethod
    def _interaction_request(event: RuntimeEvent) -> InteractionRequest | None:
        if event.type != EventType.INTERACTION_REQUIRED:
            return None
        try:
            return InteractionRequest.model_validate(event.data)
        except ValidationError as exc:
            raise ARealAgentRuntime._error(
                "RUNTIME_INTERACTION_INVALID",
                ErrorCategory.PROTOCOL,
                str(exc),
            ) from exc

    async def _commit_interaction_barrier(
        self,
        *,
        run_id: str,
        session_id: str,
        execution_id: str,
        agent_attempt_id: str,
        agent_environment_id: str,
        agent: AgentRef,
        interaction: InteractionRequest,
        environment_ref: EnvironmentRef | None,
    ) -> None:
        checkpoint_data: object = None
        if self._environment is not None and environment_ref is not None:
            checkpoint = await self._checkpoint_environment(environment_ref)
            checkpoint_data = checkpoint.model_dump(mode="json", by_alias=True)
            await self._events.publish(
                run_id=run_id,
                session_id=session_id,
                execution_id=execution_id,
                agent_attempt_id=agent_attempt_id,
                agent_environment_id=agent_environment_id,
                agent_id=agent.agent_id,
                parent_agent_id=agent.parent_agent_id,
                event_type=EventType.WORKSPACE_CHECKPOINTED,
                data=checkpoint_data,
            )
        await self._events.publish(
            run_id=run_id,
            session_id=session_id,
            execution_id=execution_id,
            agent_attempt_id=agent_attempt_id,
            agent_environment_id=agent_environment_id,
            agent_id=agent.agent_id,
            parent_agent_id=agent.parent_agent_id,
            event_type=EventType.SESSION_COMMITTED,
            data={
                "interactionId": interaction.interaction_id,
                "workspaceCheckpoint": checkpoint_data,
            },
        )

    def _require_channel(self, run_id: str, execution_id: str | None = None) -> ExecutionChannel:
        channels = self._channels.get(run_id, {})
        if execution_id is not None:
            channel = channels.get(execution_id)
            if channel is None:
                raise self._error(
                    "EXECUTION_NOT_ACTIVE",
                    ErrorCategory.CONFLICT,
                    f"Execution is not accepting input: {execution_id}",
                )
            return channel
        if not channels:
            raise self._error("RUN_NOT_ACTIVE", ErrorCategory.CONFLICT, f"Run is not accepting input: {run_id}")
        if len(channels) > 1:
            raise self._error(
                "RUN_TARGET_AMBIGUOUS",
                ErrorCategory.CONFLICT,
                "More than one agent is active; provide executionId",
            )
        return next(iter(channels.values()))

    def _ensure_accepting_runs(self) -> None:
        if self._closing or self._closed:
            raise self._error(
                "APPLICATION_CLOSED",
                ErrorCategory.CONFLICT,
                "Application is shutting down and cannot accept new runs",
            )

    @staticmethod
    def _error(code: str, category: ErrorCategory, message: str) -> ContractError:
        return ContractError(ErrorInfo(code=code, category=category, message=message))
