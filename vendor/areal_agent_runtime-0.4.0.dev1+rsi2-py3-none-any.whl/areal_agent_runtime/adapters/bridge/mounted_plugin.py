"""Plugin entrypoint for the legacy mounted-output Bridge protocol."""

from __future__ import annotations

from pathlib import Path
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.bridge.mounted import (
    MountedOutputArtifactPublisher,
    MountedOutputPublisherConfig,
)
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import (
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)


class MountedOutputBridgePlugin:
    manifest = PluginManifest(
        name="bridge-mounted-output",
        version="1.0.0",
        implements=(PortKey.ARTIFACT_PUBLISHER,),
        entrypoints=PluginEntrypoints(
            local="areal_agent_runtime.adapters.bridge.mounted_plugin:create_plugin"
        ),
        config_schema="mounted.config.schema.json",
        permissions=("filesystem.write.output", "asset.read"),
    )

    def __init__(self) -> None:
        self.publisher: MountedOutputArtifactPublisher | None = None

    async def configure(
        self,
        context: PluginContext,
        config: dict[str, JsonValue],
    ) -> None:
        assets = cast(AssetStorePort, context.require(PortKey.ASSET_STORE))
        output_root = config.get("outputRoot")
        self.publisher = MountedOutputArtifactPublisher(
            assets,
            MountedOutputPublisherConfig(
                output_root=Path(output_root) if isinstance(output_root, str) else Path("/output"),
                create_root=config.get("createRoot") is True,
            ),
        )
        context.provide(PortKey.ARTIFACT_PUBLISHER, self.publisher)

    async def start(self) -> None:
        if self.publisher is None:
            raise RuntimeError("Mounted Bridge plugin is not configured")
        health = await self.publisher.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "Bridge output is unavailable"))

    async def health(self) -> HealthStatus:
        if self.publisher is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.publisher.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> MountedOutputBridgePlugin:
    return MountedOutputBridgePlugin()
