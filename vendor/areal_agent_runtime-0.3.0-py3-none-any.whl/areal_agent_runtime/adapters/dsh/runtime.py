"""Translate the ARealAgentRuntime Runtime Port to the official DeepSeek Harness SDK.

Only this module knows DSH's Python objects and event vocabulary.  The public
Application and Kernel depend exclusively on ``areal_agent_runtime.contracts``.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import json
import math
import re
import tempfile
import weakref
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable, Mapping
from dataclasses import dataclass, field, replace
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from types import MappingProxyType
from typing import Any, Literal, Protocol
from urllib.parse import urlsplit

from pydantic import BaseModel

from areal_agent_runtime.adapters._asset_io import (
    DEFAULT_MAX_RUNTIME_ASSET_BYTES,
    MAX_RUNTIME_ASSET_BYTES,
    read_asset_bytes,
)
from areal_agent_runtime.adapters.dsh.skills import SKILLS_FILE_ENV, SKILLS_SHA256_ENV, native_skill_payload
from areal_agent_runtime.adapters.dsh.tool_bridge import (
    BRIDGE_PROTOCOL_VERSION,
    DSHApplicationToolBridge,
    DSHBridgeTool,
)
from areal_agent_runtime.adapters.mcp.gateway import (
    APPLICATION_TOOL_MCP_PROTOCOL,
    ApplicationToolExecution,
    ApplicationToolMcpGateway,
)
from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    JsonBlock,
    ReasoningBlock,
    TextBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.data import (
    DataCoverage,
    DetailCoverage,
    MessageCoverage,
    RawEventCoverage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ChildEventProjection,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolExecution,
    ToolResult,
    normalize_token_usage,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
)
from areal_agent_runtime.kernel.ids import new_id

_END = object()
_FAILED_DSH_REASONS = frozenset({"aborted", "disposed", "error", "interrupted"})
_ENVIRONMENT_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_NATIVE_SUBAGENTS_ENV = "AREAL_AGENT_RUNTIME_ALLOW_NATIVE_SUBAGENTS"
_ALLOWED_TOOLS_ENV = "AREAL_AGENT_RUNTIME_DSH_ALLOWED_TOOL_NAMES"
_SYSTEM_PROMPT_ENV = "AREAL_AGENT_RUNTIME_DSH_SYSTEM_PROMPT"
_SESSION_BINDING_ENV = "AREAL_AGENT_RUNTIME_DSH_SESSION_BINDING"
_SESSION_EXTENSION = "areal.agent-runtime.dsh-session/v1"
_PUBLIC_ANSWER_PROMPT = (
    "Provide the final answer to the original task as ordinary public answer text, not a thinking block. "
    "Do not reveal private reasoning. Preserve the requested output format (including bare JSON when requested). "
    "Use the results and completed tool operations already in this session. Do not call tools or repeat work."
)
_NATIVE_DELEGATION_TOOL_NAMES = frozenset(
    {
        "interrupt_agent",
        "list_agents",
        "send_message",
        "subagent",
        "subagent_fork",
        "workflow",
    }
)


class DSHNotification(Protocol):
    method: str
    payload: dict[str, Any]


class DSHRunResult(Protocol):
    final_response: str
    finish_reason: str | None


class DSHSessionBackend(Protocol):
    def run(
        self,
        input: list[dict[str, Any]],
        *,
        on_notification: Callable[[DSHNotification], None] | None = None,
    ) -> DSHRunResult: ...

    def close(self) -> None: ...


DSHBackendFactory = Callable[[RuntimeSessionSpec, "DSHRuntimeConfig"], DSHSessionBackend]


class _ApplicationToolGateway(Protocol):
    """Lifecycle subset shared by the standard MCP and legacy DSH gateways."""

    def bind(self, session_id: str, execution: ApplicationToolExecution) -> None: ...

    def unbind(self, session_id: str, execution: ApplicationToolExecution) -> None: ...


@dataclass(frozen=True, slots=True)
class DSHRuntimeConfig:
    provider: str = "deepseek-official"
    model: str = "deepseek-v4-flash"
    reasoning_effort: str | None = None
    max_tokens: int | None = None
    runtime_cwd: str | None = None
    dsh_bin: str | None = None
    profile: str = "sdk"
    patches: tuple[str, ...] = ()
    dsh_home: str | None = None
    env: Mapping[str, str] = field(default_factory=dict, repr=False)
    base_url: str | None = None
    api_key: str | None = field(default=None, repr=False)
    input_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    max_concurrency: int = 8
    application_tool_bridge: bool = False
    application_tool_bridge_transport: Literal["mcp", "legacy-http"] = "mcp"
    tool_bridge_ready_timeout_seconds: float = 10.0
    tool_bridge_call_timeout_seconds: float = 120.0
    tool_bridge_max_concurrency: int = 16
    max_input_asset_bytes: int = DEFAULT_MAX_RUNTIME_ASSET_BYTES

    def __post_init__(self) -> None:
        for field_name in ("provider", "model", "profile"):
            value = getattr(self, field_name)
            _require_config_string(value, field_name)
        for field_name in ("reasoning_effort", "runtime_cwd", "dsh_bin", "dsh_home", "base_url", "api_key"):
            value = getattr(self, field_name)
            if value is not None:
                _require_config_string(value, field_name)
        if self.base_url is not None:
            parsed = urlsplit(self.base_url)
            if parsed.scheme not in {"http", "https"} or parsed.hostname is None or parsed.fragment:
                raise ValueError("base_url must be an absolute HTTP(S) URL without a fragment")
        if self.max_tokens is not None and (
            isinstance(self.max_tokens, bool) or not isinstance(self.max_tokens, int) or self.max_tokens < 1
        ):
            raise ValueError("max_tokens must be a positive integer when provided")
        if not isinstance(self.patches, tuple):
            raise ValueError("patches must be a tuple")
        for patch in self.patches:
            _require_config_string(patch, "patches item")
        if len(self.patches) != len(set(self.patches)):
            raise ValueError("patches must not contain duplicates")
        if not isinstance(self.env, Mapping):
            raise ValueError("env must be a string mapping")
        normalized_env: dict[str, str] = {}
        for key, value in self.env.items():
            if not isinstance(key, str) or _ENVIRONMENT_NAME.fullmatch(key) is None:
                raise ValueError("env keys must be portable environment variable names")
            if not isinstance(value, str) or "\x00" in value:
                raise ValueError("env values must be strings without NUL bytes")
            normalized_env[key] = value
        object.__setattr__(self, "env", MappingProxyType(normalized_env))
        if (
            not isinstance(self.input_modalities, tuple)
            or not self.input_modalities
            or any(not isinstance(item, Modality) for item in self.input_modalities)
            or len(set(self.input_modalities)) != len(self.input_modalities)
            or Modality.TEXT not in self.input_modalities
            or set(self.input_modalities).difference({Modality.TEXT, Modality.IMAGE})
        ):
            raise ValueError("input_modalities must uniquely contain text and may contain image")
        if not isinstance(self.application_tool_bridge, bool):
            raise ValueError("application_tool_bridge must be a boolean")
        if self.application_tool_bridge_transport not in {"mcp", "legacy-http"}:
            raise ValueError("application_tool_bridge_transport must be 'mcp' or 'legacy-http'")
        if (
            isinstance(self.max_concurrency, bool)
            or not isinstance(self.max_concurrency, int)
            or self.max_concurrency < 1
        ):
            raise ValueError("max_concurrency must be positive")
        if (
            isinstance(self.tool_bridge_ready_timeout_seconds, bool)
            or not isinstance(self.tool_bridge_ready_timeout_seconds, (int, float))
            or not math.isfinite(self.tool_bridge_ready_timeout_seconds)
            or self.tool_bridge_ready_timeout_seconds <= 0
        ):
            raise ValueError("tool_bridge_ready_timeout_seconds must be positive")
        if (
            isinstance(self.tool_bridge_call_timeout_seconds, bool)
            or not isinstance(self.tool_bridge_call_timeout_seconds, (int, float))
            or not math.isfinite(self.tool_bridge_call_timeout_seconds)
            or self.tool_bridge_call_timeout_seconds <= 0
        ):
            raise ValueError("tool_bridge_call_timeout_seconds must be positive")
        if (
            isinstance(self.tool_bridge_max_concurrency, bool)
            or not isinstance(self.tool_bridge_max_concurrency, int)
            or self.tool_bridge_max_concurrency < 1
        ):
            raise ValueError("tool_bridge_max_concurrency must be positive")
        if (
            isinstance(self.max_input_asset_bytes, bool)
            or not isinstance(self.max_input_asset_bytes, int)
            or self.max_input_asset_bytes < 1
            or self.max_input_asset_bytes > MAX_RUNTIME_ASSET_BYTES
        ):
            raise ValueError(
                f"max_input_asset_bytes must be between one and {MAX_RUNTIME_ASSET_BYTES}"
            )


def _require_config_string(value: object, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or "\x00" in value
    ):
        raise ValueError(f"{field_name} must be a non-blank, trimmed string without NUL bytes")
    return value


def _session_backend_config(
    spec: RuntimeSessionSpec,
    config: DSHRuntimeConfig,
    *,
    bridged_tool_names: Iterable[str] = (),
) -> DSHRuntimeConfig:
    """Bind resolved session authority and system text to the DSH process.

    The Application owns these values. Always overwrite the environment seams
    so deployment settings cannot grant permissions or replace instructions
    resolved from the immutable AgentEnvironment and AgentSpec.
    """

    allowed_tool_names = {
        tool.name
        for tool in spec.agent_environment.tools
        if tool.execution == ToolExecution.RUNTIME
    }
    allowed_tool_names.update(bridged_tool_names)
    if spec.metadata.get("runtimeSubagentsAllowed") is True:
        allowed_tool_names.update(_NATIVE_DELEGATION_TOOL_NAMES)
    return replace(
        config,
        env={
            **{key: value for key, value in config.env.items() if key not in {SKILLS_FILE_ENV, SKILLS_SHA256_ENV}},
            _SESSION_BINDING_ENV: json.dumps({"sessionId": spec.session_id, "resume": spec.resume}),
            _NATIVE_SUBAGENTS_ENV: (
                "1" if spec.metadata.get("runtimeSubagentsAllowed") is True else "0"
            ),
            _ALLOWED_TOOLS_ENV: json.dumps(
                sorted(allowed_tool_names),
                ensure_ascii=True,
                separators=(",", ":"),
            ),
            # The Cordis integration installs this as the agent-scoped DSH
            # deployment persona.  It is bound from the immutable, resolved
            # AgentEnvironment rather than deployment or Planner input.
            _SYSTEM_PROMPT_ENV: "\n".join(
                text
                for resource in spec.agent_environment.system_prompts
                if (text := (
                    resource.content
                    if isinstance(resource.content, str)
                    else json.dumps(resource.content, ensure_ascii=False)
                ))
            ),
        },
    )


class _SessionExtensionResponse(BaseModel):
    protocolVersion: Literal["areal.agent-runtime.dsh-session/v1"]
    sessionId: str
    resume: bool | None = None


class _OfficialDSHSession:
    def __init__(self, spec: RuntimeSessionSpec, config: DSHRuntimeConfig) -> None:
        try:
            from deepseek_harness import DeepSeekHarness, DeepSeekHarnessConfig
        except ImportError as exc:  # pragma: no cover - exercised without the optional extra
            raise RuntimeError("Install areal-agent-runtime[dsh] to use the DSH adapter") from exc

        payload = native_skill_payload(spec.agent_environment)
        # Keep skill bodies out of environment variables (OS argv/env limits).
        # The native registry reads and verifies the snapshot once at startup.
        self._skills_directory = tempfile.TemporaryDirectory(prefix="areal-dsh-skills-")
        try:
            skills_file = Path(self._skills_directory.name) / "skills.json"
            skills_file.touch(mode=0o600)
            skills_file.write_bytes(payload)
            cwd = spec.workspace.mount_hint
            harness_config = DeepSeekHarnessConfig(
                provider=spec.provider or config.provider,
                model=spec.model or config.model,
                reasoning_effort=config.reasoning_effort,
                max_tokens=config.max_tokens,
                cwd=cwd,
                runtime_cwd=config.runtime_cwd or cwd,
                dsh_bin=config.dsh_bin,
                profile=config.profile,
                patches=config.patches,
                dsh_home=config.dsh_home,
                env={
                    **config.env,
                    SKILLS_FILE_ENV: str(skills_file),
                    SKILLS_SHA256_ENV: hashlib.sha256(payload).hexdigest(),
                },
                base_url=config.base_url,
                api_key=config.api_key,
            )
            self._harness = DeepSeekHarness(harness_config)
            self._session_id = spec.session_id
            self._session = self._harness.start_session(spec.session_id)
            # A stale/custom profile must not silently discard portable skills
            # or fall back to ambient filesystem skills, even for an empty set.
            try:
                acknowledgement = json.loads(Path(f"{skills_file}.ready").read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                raise RuntimeError(
                    "DSH_SKILLS_BRIDGE_UNAVAILABLE: install the current agent-runtime DSH bundle"
                ) from exc
            if acknowledgement != {
                "protocolVersion": "areal.agent-runtime.dsh-skills/v1",
                "sha256": hashlib.sha256(payload).hexdigest(),
            }:
                raise RuntimeError("DSH_SKILLS_BRIDGE_MISMATCH: native skill snapshot was not acknowledged")
            if spec.resume:
                response = self._extension_request("areal/session-binding")
                if response.resume is not True:
                    raise RuntimeError("DSH_SESSION_RESUME_NOT_BOUND")
        except BaseException as exc:
            try:
                if hasattr(self, "_harness"):
                    self._harness.close()
            except BaseException as cleanup_exc:
                exc.add_note(
                    "DSH harness cleanup after start_session failure also failed: "
                    f"{cleanup_exc!r}"
                )
            finally:
                self._skills_directory.cleanup()
            raise

    def run(
        self,
        input: list[dict[str, Any]],
        *,
        on_notification: Callable[[DSHNotification], None] | None = None,
    ) -> DSHRunResult:
        return self._session.run(input, on_notification=on_notification)

    def close(self) -> None:
        try:
            self._harness.close()
        finally:
            self._skills_directory.cleanup()

    def _extension_request(self, method: str) -> _SessionExtensionResponse:
        try:
            response = self._harness.client.request(
                method,
                {"sessionId": self._session_id},
                response_model=_SessionExtensionResponse,
                timeout_seconds=15,
            )
        except Exception as exc:
            raise RuntimeError(
                f"DSH_SESSION_EXTENSION_FAILED: {method}; install the current agent-runtime DSH bundle: {exc}"
            ) from exc
        if response.sessionId != self._session_id:
            raise RuntimeError("DSH_SESSION_ID_MISMATCH")
        return response

    def run_public_answer(
        self,
        input: list[dict[str, Any]],
        *,
        on_notification: Callable[[DSHNotification], None] | None = None,
    ) -> DSHRunResult:
        self._extension_request("areal/final-answer")
        try:
            return self._session.run(input, on_notification=on_notification)
        finally:
            # Cancellation owns process shutdown; cleanup must not replace its error.
            with contextlib.suppress(Exception):
                self._extension_request("areal/final-answer/end")


@dataclass(slots=True)
class _DSHSessionState:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    backend: DSHSessionBackend | None = None
    tool_catalog_signature: str | None = None
    bridged_tools: tuple[DSHBridgeTool, ...] = ()
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    active: bool = False
    closed: bool = False
    channel: ExecutionChannel | None = None
    backend_close_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    backend_close_task: asyncio.Task[None] | None = None

    async def close_backend(self) -> None:
        """Coalesce concurrent closes and permit an explicit retry after failure."""

        async with self.backend_close_lock:
            if self.backend is None:
                return
            previous = self.backend_close_task
            retry_failed_close = previous is not None and previous.done() and (
                previous.cancelled() or previous.exception() is not None
            )
            if previous is None or retry_failed_close:
                task = asyncio.create_task(
                    asyncio.to_thread(self.backend.close),
                    name=f"dsh:close:{self.ref.runtime_session_id}",
                )
                self.backend_close_task = task
            else:
                task = previous
        # A cancelled caller must not cancel the only process-cleanup attempt.
        await asyncio.shield(task)


@dataclass(frozen=True, slots=True)
class _MappedEvent:
    type: EventType
    data: Any
    agent_id: str
    parent_agent_id: str | None = None
    ignorable: bool = False


@dataclass(slots=True)
class _DSHToolCallState:
    fingerprint: str
    future: asyncio.Future[ToolResult]


class _DSHExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        *,
        runtime_instance_id: str,
        request: ExecutionRequest,
        backend: DSHSessionBackend,
        prompt: list[dict[str, Any]],
        execution_slots: asyncio.Semaphore,
        bridge: _ApplicationToolGateway | None = None,
        bridged_tools: tuple[DSHBridgeTool, ...] = (),
        close_backend: Callable[[], Awaitable[None]],
        on_finish: Callable[[], None] | None = None,
    ) -> None:
        self._runtime_instance_id = runtime_instance_id
        self._request = request
        self._backend = backend
        self._prompt = prompt
        self._execution_slots = execution_slots
        self._queue: asyncio.Queue[RuntimeEvent | object] = asyncio.Queue()
        self._loop = asyncio.get_running_loop()
        self._sequence = 0
        self._ended = False
        self._cancelled = False
        self._saw_root_message = False
        self._last_root_public_text = False
        self._last_root_reasoning = False
        self._child_parents: dict[str, str] = {}
        self._finished_children: set[str] = set()
        self._bridge = bridge
        self._close_backend = close_backend
        self._on_finish = on_finish
        self._bridged_by_canonical = {tool.canonical_name: tool for tool in bridged_tools}
        self._bridged_runtime_names = {tool.runtime_name for tool in bridged_tools}
        self._bridged_call_ids: set[str] = set()
        self._observed_tool_names: dict[str, str] = {}
        self._tool_calls: dict[str, _DSHToolCallState] = {}
        self._protocol_failed = False
        self._protocol_abort_task: asyncio.Task[None] | None = None
        if bridge is not None:
            bridge.bind(request.session_id, self)
        self._task = asyncio.create_task(self._run(), name=f"dsh:{request.execution_id}")

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        while True:
            item = await self._queue.get()
            if item is _END:
                return
            if isinstance(item, RuntimeEvent):
                yield item

    def _emit(
        self,
        event_type: EventType,
        data: Any,
        *,
        agent_id: str | None = None,
        parent_agent_id: str | None = None,
        ignorable: bool = False,
    ) -> None:
        if self._ended:
            return
        effective_agent_id = agent_id or self._request.agent.agent_id
        event_data = data
        if effective_agent_id != self._request.agent.agent_id and isinstance(data, dict):
            event_data = {**data, **self._lineage_data()}
        event = RuntimeEvent(
            runtime_instance_id=self._runtime_instance_id,
            runtime_sequence=self._sequence,
            execution_id=self._request.execution_id,
            agent_id=effective_agent_id,
            parent_agent_id=(parent_agent_id if agent_id is not None else self._request.agent.parent_agent_id),
            type=event_type,
            data=event_data,
            ignorable=ignorable,
        )
        self._sequence += 1
        self._queue.put_nowait(event)

    def _finish(self) -> None:
        if self._ended:
            return
        self._ended = True
        self._queue.put_nowait(_END)

    def _notification_from_worker(self, notification: DSHNotification) -> None:
        with contextlib.suppress(RuntimeError):
            self._loop.call_soon_threadsafe(self._handle_notification_safely, notification)

    def _handle_notification_safely(self, notification: DSHNotification) -> None:
        if self._ended:
            return
        try:
            self._handle_notification(notification)
        except Exception as exc:
            # Exceptions raised by call_soon_threadsafe callbacks otherwise only
            # reach the event-loop exception handler, leaving the canonical
            # execution waiting indefinitely for a terminal RuntimeEvent.
            self._protocol_failed = True
            self._terminate_active_children(
                event_type=EventType.AGENT_FAILED,
                reason="invalid_notification",
            )
            self._emit(
                EventType.EXECUTION_FAILED,
                {
                    "reason": "invalid_notification",
                    "message": str(exc) or type(exc).__name__,
                    "vendor": "dsh",
                },
            )
            self._finish()
            if self._protocol_abort_task is None:
                self._protocol_abort_task = asyncio.create_task(
                    self._abort_protocol_failure(),
                    name=f"dsh:abort:{self._request.execution_id}",
                )

    async def _abort_protocol_failure(self) -> None:
        with contextlib.suppress(BaseException):
            await self._close_backend()
        if not self._task.done():
            self._task.cancel()

    def _handle_notification(self, notification: DSHNotification) -> None:
        for item in self._map_notification(notification):
            if item.type == EventType.MESSAGE_COMPLETED and item.agent_id == self._request.agent.agent_id:
                self._saw_root_message = True
                blocks = item.data.get("content", [])
                self._last_root_public_text = any(
                    block.get("type") == "text" and str(block.get("text", "")).strip()
                    for block in blocks
                )
                self._last_root_reasoning = any(
                    block.get("type") == "reasoning" and str(block.get("text", "")).strip()
                    for block in blocks
                )
            self._emit(
                item.type,
                item.data,
                agent_id=item.agent_id,
                parent_agent_id=item.parent_agent_id,
                ignorable=item.ignorable,
            )

    def _map_notification(self, notification: DSHNotification) -> list[_MappedEvent]:
        method = _required_vendor_string(notification.method, "notification.method")
        payload = notification.payload
        if not isinstance(payload, dict):
            raise ValueError("notification.payload must be an object")
        root_agent = self._request.agent.agent_id

        if method == "subagent.started":
            parent_session = _optional_vendor_string(payload.get("parentSessionId"), "parentSessionId")
            parent_session = parent_session or self._request.session_id
            child_session = _required_vendor_string(payload.get("childSessionId"), "childSessionId")
            if child_session == self._request.session_id or child_session == root_agent:
                raise ValueError("DSH child session collides with the root identity")
            if child_session in self._child_parents or child_session in self._finished_children:
                raise ValueError(f"DSH child started more than once: {child_session}")
            if parent_session == self._request.session_id:
                parent_agent = root_agent
            else:
                if parent_session not in self._child_parents or parent_session in self._finished_children:
                    raise ValueError(f"DSH child references an unknown parent: {parent_session}")
                parent_agent = parent_session
            if child_session == parent_agent:
                raise ValueError("DSH child cannot be its own parent")
            self._child_parents[child_session] = parent_agent
            return [
                _MappedEvent(
                    EventType.AGENT_STARTED,
                    {
                        "runtimeAgentId": child_session,
                        "vendor": "dsh",
                        **self._lineage_data(),
                    },
                    child_session,
                    parent_agent,
                )
            ]

        if method == "subagent.finished":
            raw_child = payload.get("childSessionId") or payload.get("agentId")
            child = _required_vendor_string(raw_child, "childSessionId")
            if child not in self._child_parents or child in self._finished_children:
                raise ValueError(f"DSH finished an unknown or terminal child: {child}")
            parent = self._child_parents[child]
            declared_parent = _optional_vendor_string(payload.get("parentSessionId"), "parentSessionId")
            if declared_parent is not None:
                expected_parent = (
                    self._request.session_id if parent == root_agent else parent
                )
                if declared_parent != expected_parent:
                    raise ValueError(f"DSH child parent changed before completion: {child}")
            status = _optional_vendor_string(payload.get("status"), "status") or "error"
            event_type = EventType.AGENT_COMPLETED if status == "ok" else EventType.AGENT_FAILED
            self._finished_children.add(child)
            return [
                _MappedEvent(
                    event_type,
                    {"vendor": "dsh", **payload, **self._lineage_data()},
                    child,
                    parent,
                )
            ]

        session_id = _optional_vendor_string(payload.get("sessionId"), "sessionId")
        session_id = session_id or self._request.session_id
        agent_id = root_agent if session_id == self._request.session_id else session_id
        if agent_id != root_agent and (
            session_id not in self._child_parents or session_id in self._finished_children
        ):
            raise ValueError(f"DSH emitted an event for an inactive child: {session_id}")
        parent_id = (
            self._child_parents.get(session_id) if agent_id != root_agent else self._request.agent.parent_agent_id
        )

        if method == "session.status":
            return [
                _MappedEvent(
                    EventType.RUNTIME_STATUS,
                    {"vendor": "dsh", "status": payload.get("status"), "sessionId": session_id},
                    agent_id,
                    parent_id,
                    True,
                )
            ]

        if method != "session.event":
            return [
                _MappedEvent(
                    EventType.RUNTIME_STATUS,
                    {"vendor": "dsh", "notification": method, "payload": payload},
                    agent_id,
                    parent_id,
                    True,
                )
            ]

        raw_event = payload.get("event")
        if not isinstance(raw_event, dict):
            return []
        vendor_type = _required_vendor_string(raw_event.get("type"), "event.type")
        data = raw_event.get("data")
        event_data = data if isinstance(data, dict) else {}

        if vendor_type == "assistant/chunk":
            chunk = event_data.get("chunk")
            if not isinstance(chunk, dict):
                return []
            chunk_type = chunk.get("type")
            if chunk_type == "text-delta":
                text = _required_vendor_text(chunk.get("text"), "text-delta.text")
                return [
                    _MappedEvent(
                        EventType.MESSAGE_DELTA,
                        {"delta": {"type": "text", "text": text}},
                        agent_id,
                        parent_id,
                    )
                ]
            if chunk_type == "reasoning-delta":
                text = _required_vendor_text(chunk.get("text"), "reasoning-delta.text")
                return [
                    _MappedEvent(
                        EventType.REASONING_DELTA,
                        {"text": text},
                        agent_id,
                        parent_id,
                    )
                ]
            if chunk_type == "usage":
                return self._usage_events(
                    chunk.get("usage", {}),
                    agent_id,
                    parent_id,
                    vendor_event_type="content/usage",
                )

        if vendor_type == "assistant/message":
            message = event_data.get("message")
            content_owner = message if isinstance(message, dict) else event_data
            content = _content_from_dsh(content_owner.get("content"))
            event_type = EventType.MESSAGE_COMPLETED if agent_id == root_agent else EventType.AGENT_MESSAGE
            # DSH emits an empty assistant/message around a tool-call turn.
            # Canonical message events require at least one ContentBlock, so
            # preserve usage but do not invent an empty model message.
            mapped = []
            if content:
                mapped.append(
                    _MappedEvent(
                        event_type,
                        {
                            "content": [block.model_dump(mode="json", by_alias=True) for block in content],
                            **(self._lineage_data() if agent_id != root_agent else {}),
                        },
                        agent_id,
                        parent_id,
                    )
                )
            if "usage" in event_data:
                mapped.extend(
                    self._usage_events(
                        event_data["usage"],
                        agent_id,
                        parent_id,
                        vendor_event_type="assistant/message.usage",
                    )
                )
            return mapped

        if vendor_type == "tool/call":
            runtime_name = _required_vendor_string(event_data.get("name"), "tool/call.name")
            vendor_call_id = _required_vendor_string(event_data.get("callId"), "tool/call.callId")
            if runtime_name in self._bridged_runtime_names:
                self._bridged_call_ids.add(vendor_call_id)
                return []
            self._observed_tool_names[vendor_call_id] = runtime_name
            raw_arguments_value = event_data.get("arguments")
            arguments, raw_arguments = _dsh_tool_arguments(raw_arguments_value)
            return [
                _MappedEvent(
                    EventType.TOOL_REQUESTED,
                    {
                        "callId": vendor_call_id,
                        "name": runtime_name,
                        "arguments": arguments,
                        "rawArguments": raw_arguments,
                    },
                    agent_id,
                    parent_id,
                )
            ]

        if vendor_type == "tool/result":
            message = event_data.get("message")
            message_data = message if isinstance(message, dict) else {}
            blocks = message_data.get("content")
            raw_call_id = event_data.get("callId")
            call_id = _optional_vendor_string(raw_call_id, "tool/result.callId") or ""
            result_block: dict[str, Any] | None = None
            is_error = _dsh_tool_result_is_error(event_data.get("error"))
            if isinstance(blocks, list):
                for block in blocks:
                    if isinstance(block, dict) and block.get("type") == "tool-result":
                        result_block = block
                        call_id = _required_vendor_string(block.get("toolCallId"), "toolCallId")
                        block_error = _optional_vendor_bool(block.get("isError"), "isError")
                        is_error = is_error or (block_error or False)
                        break
            call_id = _required_vendor_string(call_id, "tool/result.callId")
            raw_record = _MappedEvent(
                EventType.RAW_EVENT_RECORDED,
                {
                    "producer": "deepseek-harness",
                    "vendorEventType": vendor_type,
                    "runtimeInstanceId": self._runtime_instance_id,
                    "runtimeSequence": self._sequence,
                    "reason": "unsupported-event",
                    "payload": raw_event,
                },
                agent_id,
                parent_id,
                True,
            )
            if call_id in self._bridged_call_ids:
                # The Application tool bridge already emitted the canonical
                # lifecycle event.  Retain the Harness acknowledgement as raw
                # evidence without manufacturing a duplicate tool result.
                return [raw_record]
            result_content, result_value = _dsh_tool_result(result_block, event_data)
            return [
                _MappedEvent(
                    EventType.TOOL_FAILED if is_error else EventType.TOOL_COMPLETED,
                    {
                        "callId": call_id,
                        "name": self._observed_tool_names.get(call_id),
                        "content": [
                            block.model_dump(mode="json", by_alias=True)
                            for block in result_content
                        ],
                        "value": result_value,
                    },
                    agent_id,
                    parent_id,
                ),
                raw_record,
            ]

        return [
            _MappedEvent(
                EventType.RUNTIME_STATUS,
                {"vendor": "dsh", "event": raw_event},
                agent_id,
                parent_id,
                True,
            )
        ]

    def _usage_events(
        self,
        usage: object,
        agent_id: str,
        parent_id: str | None,
        *,
        vendor_event_type: str,
    ) -> list[_MappedEvent]:
        normalized = normalize_token_usage(usage, scope="execution")
        mapped: list[_MappedEvent] = []
        if normalized is not None:
            mapped.append(
                _MappedEvent(
                    EventType.USAGE_UPDATED,
                    {"usage": normalized.model_dump(mode="json", by_alias=True)},
                    agent_id,
                    parent_id,
                )
            )
        mapped.append(
            _MappedEvent(
                EventType.RAW_EVENT_RECORDED,
                {
                    "producer": "deepseek-harness",
                    "vendorEventType": vendor_event_type,
                    "runtimeInstanceId": self._runtime_instance_id,
                    "runtimeSequence": self._sequence,
                    "reason": "unsupported-event",
                    "payload": usage,
                },
                agent_id,
                parent_id,
                True,
            )
        )
        return mapped

    async def _run(self) -> None:
        self._emit(EventType.EXECUTION_STARTED, {"vendor": "dsh"})
        try:
            async with self._execution_slots:
                result = await asyncio.to_thread(
                    self._backend.run,
                    self._prompt,
                    on_notification=self._notification_from_worker,
                )
            # ``call_soon_threadsafe`` notifications queued by the worker must
            # be projected before the synthesized fallback and terminal event.
            await asyncio.sleep(0)
            if (
                not self._cancelled
                and not self._protocol_failed
                and result.finish_reason not in _FAILED_DSH_REASONS
                and self._last_root_reasoning
                and not self._last_root_public_text
            ):
                self._emit(
                    EventType.RUNTIME_STATUS,
                    {"vendor": "dsh", "reason": "public_answer_retry", "attempt": 1, "maxAttempts": 1},
                    ignorable=True,
                )
                finalizer = getattr(self._backend, "run_public_answer", self._backend.run)
                async with self._execution_slots:
                    result = await asyncio.to_thread(
                        finalizer,
                        [{"type": "text", "text": _PUBLIC_ANSWER_PROMPT}],
                        on_notification=self._notification_from_worker,
                    )
                await asyncio.sleep(0)
                if not self._last_root_public_text and not self._cancelled:
                    self._terminate_active_children(
                        event_type=EventType.AGENT_FAILED,
                        reason="public_answer_missing",
                    )
                    self._emit(
                        EventType.EXECUTION_FAILED,
                        {
                            "vendor": "dsh", "reason": "public_answer_missing",
                            "code": "DSH_PUBLIC_ANSWER_MISSING", "publicAnswerAttempts": 1,
                            "message": "DSH returned no public final answer after one bounded follow-up request",
                        },
                    )
                    return
            if result.final_response and not self._saw_root_message:
                self._emit(
                    EventType.MESSAGE_COMPLETED,
                    {"content": [TextBlock(text=result.final_response).model_dump(mode="json", by_alias=True)]},
                )
            reason = result.finish_reason
            if self._cancelled or reason in _FAILED_DSH_REASONS:
                self._terminate_active_children(
                    event_type=(EventType.AGENT_CANCELLED if self._cancelled else EventType.AGENT_FAILED),
                    reason="cancelled" if self._cancelled else (reason or "runtime_failed"),
                )
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"reason": "cancelled" if self._cancelled else reason, "vendor": "dsh"},
                )
            elif self._active_children():
                self._terminate_active_children(
                    event_type=EventType.AGENT_FAILED,
                    reason="terminal_event_missing",
                )
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"reason": "invalid_child_lifecycle", "vendor": "dsh"},
                )
            else:
                self._emit(EventType.EXECUTION_COMPLETED, {"finishReason": reason, "vendor": "dsh"})
        except asyncio.CancelledError:
            self._terminate_active_children(
                event_type=EventType.AGENT_CANCELLED,
                reason="cancelled",
            )
            self._emit(EventType.EXECUTION_FAILED, {"reason": "cancelled", "vendor": "dsh"})
        except Exception as exc:
            self._terminate_active_children(
                event_type=EventType.AGENT_FAILED,
                reason="runtime_error",
            )
            self._emit(
                EventType.EXECUTION_FAILED,
                {"reason": "runtime_error", "message": str(exc) or type(exc).__name__, "vendor": "dsh"},
            )
        finally:
            for call_id, state in self._tool_calls.items():
                if not state.future.done():
                    state.future.set_result(
                        ToolResult(
                            call_id=call_id,
                            error=ErrorInfo(
                                code="DSH_TOOL_BRIDGE_CLOSED",
                                category=ErrorCategory.UNAVAILABLE,
                                message="DSH execution ended before the application tool returned",
                                retryable=True,
                            ),
                        )
                    )
            if self._bridge is not None:
                self._bridge.unbind(self._request.session_id, self)
            if self._on_finish is not None:
                self._on_finish()
            self._finish()

    async def send_tool_result(self, result: ToolResult) -> None:
        if not isinstance(result, ToolResult):
            raise TypeError("DSH send_tool_result requires a ToolResult")
        state = self._tool_calls.get(result.call_id)
        if state is None:
            raise LookupError(f"Unknown DSH application tool call: {result.call_id}")
        if state.future.done():
            completed = state.future.result()
            if completed == result or (
                completed.error is not None
                and completed.error.code == "DSH_TOOL_BRIDGE_CLOSED"
            ):
                return
            raise RuntimeError(f"DSH application tool call already completed: {result.call_id}")
        state.future.set_result(result)

    async def invoke_application_tool(
        self,
        *,
        call_id: str,
        name: str,
        arguments: dict[str, object],
        agent_id: str | None,
    ) -> ToolResult:
        try:
            call_id = _required_vendor_string(call_id, "application tool callId")
            name = _required_vendor_string(name, "application tool name")
            if agent_id is not None:
                agent_id = _required_vendor_string(agent_id, "application tool agentId")
            fingerprint = _tool_call_fingerprint(name, arguments, agent_id)
        except (TypeError, ValueError) as exc:
            return ToolResult(
                call_id=(
                    call_id
                    if isinstance(call_id, str) and call_id and call_id == call_id.strip()
                    else "invalid-dsh-call"
                ),
                error=ErrorInfo(
                    code="DSH_TOOL_CALL_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=str(exc) or type(exc).__name__,
                ),
            )
        if self._ended:
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="DSH_TOOL_BRIDGE_CLOSED",
                    category=ErrorCategory.UNAVAILABLE,
                    message="DSH execution is no longer accepting Application tool calls",
                    retryable=True,
                ),
            )
        tool = self._bridged_by_canonical.get(name)
        if tool is None:
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="DSH_TOOL_NOT_BRIDGED",
                    category=ErrorCategory.PERMISSION,
                    message=f"DSH requested a tool outside the active Application catalog: {name}",
                ),
            )
        if agent_id is not None and agent_id != self._request.agent.agent_id and (
            agent_id not in self._child_parents or agent_id in self._finished_children
        ):
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="DSH_TOOL_AGENT_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=f"DSH attributed an Application tool call to an inactive agent: {agent_id}",
                ),
            )
        existing = self._tool_calls.get(call_id)
        if existing is not None:
            if existing.fingerprint != fingerprint:
                return ToolResult(
                    call_id=call_id,
                    error=ErrorInfo(
                        code="DSH_TOOL_CALL_CONFLICT",
                        category=ErrorCategory.PROTOCOL,
                        message=f"DSH reused application tool call id with different input: {call_id}",
                    ),
                )
            # MCP request retries share the original canonical execution.  Shield
            # the rendezvous so one disconnected HTTP waiter cannot cancel it.
            return await asyncio.shield(existing.future)
        future: asyncio.Future[ToolResult] = self._loop.create_future()
        self._tool_calls[call_id] = _DSHToolCallState(
            fingerprint=fingerprint,
            future=future,
        )
        self._bridged_call_ids.add(call_id)
        effective_agent_id = agent_id or self._request.agent.agent_id
        parent_agent_id = (
            self._child_parents.get(effective_agent_id)
            if effective_agent_id != self._request.agent.agent_id
            else self._request.agent.parent_agent_id
        )
        self._emit(
            EventType.TOOL_REQUESTED,
            {
                "callId": call_id,
                "name": name,
                "arguments": arguments,
                "execution": tool.execution.value,
                "context": {
                    "runtimeToolName": tool.runtime_name,
                    "vendor": "dsh",
                    **self._lineage_data(),
                },
            },
            agent_id=effective_agent_id,
            parent_agent_id=parent_agent_id,
        )
        return await asyncio.shield(future)

    def _lineage_data(self) -> dict[str, object]:
        data: dict[str, object] = {"parentExecutionId": self._request.execution_id}
        group_id = self._request.metadata.get("parallelGroupId")
        if isinstance(group_id, str) and group_id:
            data["groupId"] = group_id
        return data

    def _active_children(self) -> tuple[str, ...]:
        return tuple(child for child in self._child_parents if child not in self._finished_children)

    def _terminate_active_children(self, *, event_type: EventType, reason: str) -> None:
        # Children are inserted parent-before-child.  Terminating in reverse
        # order preserves lineage when a nested subtree is aborted.
        for child in reversed(self._active_children()):
            self._emit(
                event_type,
                {"vendor": "dsh", "reason": reason, **self._lineage_data()},
                agent_id=child,
                parent_agent_id=self._child_parents[child],
            )
            self._finished_children.add(child)

    async def respond(self, response: InteractionResponse) -> None:
        raise NotImplementedError("The current DSH SDK protocol has no interaction response method")

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        raise NotImplementedError("The current DSH SDK protocol has no steer method")

    async def cancel(self, reason: CancelReason) -> None:
        # DSH has no turn-level cancel.  Because this adapter owns one runtime
        # process per ARealAgentRuntime session, closing it is a safe hard-cancel.
        self._cancelled = True
        try:
            await self._close_backend()
        finally:
            if not self._task.done():
                self._task.cancel()

    async def close(self) -> None:
        if not self._task.done():
            if not self._protocol_failed:
                self._cancelled = True
            try:
                await self._close_backend()
            finally:
                self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        if self._protocol_abort_task is not None:
            with contextlib.suppress(asyncio.CancelledError):
                await self._protocol_abort_task
        self._tool_calls.clear()


class DSHRuntimeAdapter:
    """One replaceable ``AgentRuntimePort`` implementation backed by DSH.

    DSH remains free to compose its own Cordis plugins internally.  To the
    ARealAgentRuntime Kernel the complete DSH composition is one Runtime Adapter.
    """

    def __init__(
        self,
        *,
        asset_store: AssetStorePort | None = None,
        config: DSHRuntimeConfig | None = None,
        backend_factory: DSHBackendFactory | None = None,
    ) -> None:
        self._instance_id = new_id("runtime")
        self._asset_store = asset_store
        self._config = config or DSHRuntimeConfig()
        self._backend_factory = backend_factory or self._create_official_backend
        self._sessions: dict[str, _DSHSessionState] = {}
        self._closed_sessions: dict[str, RuntimeSessionRef] = {}
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._execution_slots = asyncio.Semaphore(self._config.max_concurrency)
        self._close_lock = asyncio.Lock()
        self._closing = False
        self._closed = False
        self._legacy_tool_bridge = (
            DSHApplicationToolBridge()
            if self._config.application_tool_bridge
            and self._config.application_tool_bridge_transport == "legacy-http"
            else None
        )
        self._mcp_tool_gateway = (
            ApplicationToolMcpGateway(
                asset_store=asset_store,
                call_timeout_seconds=self._config.tool_bridge_call_timeout_seconds,
                max_concurrency_per_session=self._config.tool_bridge_max_concurrency,
            )
            if self._config.application_tool_bridge
            and self._config.application_tool_bridge_transport == "mcp"
            else None
        )

    @staticmethod
    def _create_official_backend(
        spec: RuntimeSessionSpec,
        config: DSHRuntimeConfig,
    ) -> DSHSessionBackend:
        return _OfficialDSHSession(spec, config)

    async def describe(self) -> RuntimeDescriptor:
        try:
            runtime_version = version("deepseek-harness-sdk")
        except PackageNotFoundError:
            runtime_version = "not-installed"
        input_modalities = tuple(
            modality
            for modality in self._config.input_modalities
            if modality != Modality.IMAGE or self._asset_store is not None
        )
        return RuntimeDescriptor(
            name="deepseek-harness",
            adapter_version="1.2.0",
            runtime_version=runtime_version,
            capabilities=RuntimeCapabilities(
                input_modalities=input_modalities,
                output_modalities=(Modality.TEXT,),
                tool_calling=True,
                application_tool_bridge=self._config.application_tool_bridge,
                cancel=True,
                steer=False,
                resume=True,
                interaction=False,
                native_multi_agent=True,
                child_event_projection=ChildEventProjection.FULL,
                native_graph_execution=False,
                data_coverage=DataCoverage(
                    messages=MessageCoverage.FINAL,
                    model_calls=DetailCoverage.NONE,
                    tool_calls=DetailCoverage.FULL,
                    usage=UsageCoverage.NORMALIZED,
                    child_agents=DetailCoverage.FULL,
                    raw_events=RawEventCoverage.FULL,
                ),
                extensions={
                    "ai.deepseek.dsh/capabilities/v1": {
                        "runtimeOwnedPlugins": True,
                        "skillBinding": "native-snapshot/v1",
                        "hostToolResults": self._config.application_tool_bridge,
                        "hardCancelByProcessClose": True,
                        "maxConcurrency": self._config.max_concurrency,
                        "configuredInputModalities": [item.value for item in self._config.input_modalities],
                        "applicationToolBridgeTransport": (
                            (
                                APPLICATION_TOOL_MCP_PROTOCOL
                                if self._config.application_tool_bridge_transport == "mcp"
                                else "areal.agent-runtime.dsh-loopback-http"
                            )
                            if self._config.application_tool_bridge
                            else "unavailable"
                        ),
                        "applicationToolBridgeProtocol": (
                            (
                                APPLICATION_TOOL_MCP_PROTOCOL
                                if self._config.application_tool_bridge_transport == "mcp"
                                else BRIDGE_PROTOCOL_VERSION
                            )
                            if self._config.application_tool_bridge
                            else None
                        ),
                    },
                },
            ),
        )

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("DSH runtime is closing")
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        native_skill_payload(spec.agent_environment)
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("DSH runtime is closing")
            existing = self._sessions.get(spec.session_id)
            if existing is not None:
                if existing.closed or existing.backend_close_task is not None:
                    raise RuntimeError(f"DSH session is closing: {spec.session_id}")
                require_same_runtime_session_spec(existing.spec, spec)
                return existing.ref
            ref = RuntimeSessionRef(
                session_id=spec.session_id,
                runtime_session_id=new_id("dsh_session"),
            )
            backend = None
            if not self._config.application_tool_bridge:
                backend = await _create_backend_safely(
                    self._backend_factory,
                    spec,
                    _session_backend_config(spec, self._config),
                )
            self._sessions[spec.session_id] = _DSHSessionState(spec=spec, ref=ref, backend=backend)
            self._closed_sessions.pop(spec.session_id, None)
            return ref

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("DSH runtime is closing")
        outer = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with outer:
            try:
                session = self._sessions[request.session_id]
            except KeyError as exc:
                raise LookupError(f"DSH session is not open: {request.session_id}") from exc
            async with session.lock:
                if (
                    self._closing
                    or session.closed
                    or session.backend_close_task is not None
                    or self._sessions.get(request.session_id) is not session
                ):
                    raise LookupError(f"DSH session is not open: {request.session_id}")
                require_session_environment(session.spec, request)
                if session.active:
                    raise RuntimeError(
                        f"DSH session already has an active execution: {request.session_id}"
                    )
                if session.backend is None:
                    session.backend = await self._create_bridged_backend(session, request)
                elif self._config.application_tool_bridge:
                    signature = _tool_catalog_signature(request)
                    if signature != session.tool_catalog_signature:
                        raise ValueError(
                            "DSH application tool catalog cannot change inside one runtime session; "
                            "open a new RuntimeSession"
                        )
                prompt = await _request_to_dsh(
                    request,
                    self._asset_store,
                    max_input_asset_bytes=self._config.max_input_asset_bytes,
                )
                session.active = True

                def finish() -> None:
                    session.active = False
                    session.channel = None

                try:
                    channel = _DSHExecutionChannel(
                        runtime_instance_id=self._instance_id,
                        request=request,
                        backend=session.backend,
                        prompt=prompt,
                        execution_slots=self._execution_slots,
                        bridge=self._application_tool_gateway(),
                        bridged_tools=session.bridged_tools,
                        close_backend=session.close_backend,
                        on_finish=finish,
                    )
                except BaseException:
                    session.active = False
                    raise
                session.channel = channel
                return channel

    async def _create_bridged_backend(
        self,
        session: _DSHSessionState,
        request: ExecutionRequest,
    ) -> DSHSessionBackend:
        if not self._config.application_tool_bridge:
            raise RuntimeError("DSH bridge backend requested while the bridge is disabled")
        if self._mcp_tool_gateway is not None:
            endpoint = await self._mcp_tool_gateway.open_session(session.spec.session_id, request.tools)
            bridged_tools = tuple(
                DSHBridgeTool(
                    canonical_name=tool.canonical_name,
                    runtime_name=_dsh_mcp_public_tool_name(endpoint.server_name, tool.exposed_name),
                    description=tool.description,
                    input_schema=tool.input_schema,
                    execution=tool.execution,
                    terminal_on_success=tool.terminal_on_success,
                )
                for tool in endpoint.tools
            )
            environment = {
                **self._config.env,
                "AREAL_AGENT_RUNTIME_APPLICATION_TOOLS_MCP_URL": endpoint.url,
                "AREAL_AGENT_RUNTIME_APPLICATION_TOOLS_MCP_TOKEN": endpoint.bearer_token,
                "AREAL_AGENT_RUNTIME_APPLICATION_TOOLS_MCP_SERVER_NAME": endpoint.server_name,
            }
        else:
            bridge = self._legacy_tool_bridge
            if bridge is None:
                raise RuntimeError("DSH application tool bridge transport is not configured")
            await bridge.start()
            bridged_tools = bridge.register_session(session.spec.session_id, request.tools)
            environment = {
                **self._config.env,
                "AREAL_AGENT_RUNTIME_DSH_TOOL_BRIDGE_URL": bridge.endpoint,
                "AREAL_AGENT_RUNTIME_DSH_TOOL_BRIDGE_TOKEN": bridge.token,
                "AREAL_AGENT_RUNTIME_DSH_TOOL_BRIDGE_SESSION_ID": session.spec.session_id,
            }
        backend_config = _session_backend_config(
            session.spec,
            replace(self._config, env=environment),
            bridged_tool_names=(tool.runtime_name for tool in bridged_tools),
        )
        try:
            backend = await _create_backend_safely(
                self._backend_factory,
                session.spec,
                backend_config,
            )
            if self._legacy_tool_bridge is not None:
                await self._legacy_tool_bridge.wait_ready(
                    session.spec.session_id,
                    self._config.tool_bridge_ready_timeout_seconds,
                )
        except BaseException as exc:
            if "backend" in locals():
                try:
                    await _close_backend_instance(backend)
                except BaseException as cleanup_exc:
                    exc.add_note(f"DSH backend cleanup also failed: {cleanup_exc!r}")
            try:
                await self._close_tool_gateway_session(session.spec.session_id)
            except BaseException as cleanup_exc:
                exc.add_note(f"DSH tool gateway cleanup also failed: {cleanup_exc!r}")
            raise
        session.tool_catalog_signature = _tool_catalog_signature(request)
        session.bridged_tools = bridged_tools
        return backend

    async def close_session(self, session: RuntimeSessionRef) -> None:
        outer = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with outer:
            state = self._sessions.get(session.session_id)
            if state is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("DSH session reference is not owned by this adapter")
            if state.ref != session:
                raise ValueError("DSH session reference does not match the open session")
            async with state.lock:
                state.closed = True
                errors: list[BaseException] = []
                if state.channel is not None:
                    try:
                        await state.channel.close()
                    except BaseException as exc:
                        errors.append(exc)
                try:
                    await state.close_backend()
                except BaseException as exc:
                    errors.append(exc)
                try:
                    await self._close_tool_gateway_session(session.session_id)
                except BaseException as exc:
                    errors.append(exc)
                if not errors and self._sessions.get(session.session_id) is state:
                    self._sessions.pop(session.session_id, None)
                    self._closed_sessions[session.session_id] = session
                if errors:
                    raise BaseExceptionGroup("DSH session cleanup failed", errors)

    async def health(self) -> HealthStatus:
        try:
            installed = version("deepseek-harness-sdk")
        except PackageNotFoundError:
            return HealthStatus(
                status="unhealthy",
                details={"reason": "optional_dependency_missing", "package": "deepseek-harness-sdk"},
            )
        return HealthStatus(status="healthy", details={"sdkVersion": installed})

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closing = True
            errors: list[BaseException] = []
            for state in tuple(self._sessions.values()):
                try:
                    await self.close_session(state.ref)
                except BaseException as exc:
                    errors.append(exc)
            if self._legacy_tool_bridge is not None:
                try:
                    await self._legacy_tool_bridge.close()
                except BaseException as exc:
                    errors.append(exc)
            if self._mcp_tool_gateway is not None:
                try:
                    await self._mcp_tool_gateway.close()
                except BaseException as exc:
                    errors.append(exc)
            if errors:
                raise BaseExceptionGroup("DSH runtime cleanup failed", errors)
            self._closed = True
            self._closed_sessions.clear()

    def _application_tool_gateway(self) -> _ApplicationToolGateway | None:
        return self._mcp_tool_gateway or self._legacy_tool_bridge

    async def _close_tool_gateway_session(self, session_id: str) -> None:
        if self._mcp_tool_gateway is not None:
            await self._mcp_tool_gateway.close_session(session_id)
        if self._legacy_tool_bridge is not None:
            self._legacy_tool_bridge.unregister_session(session_id)


async def _request_to_dsh(
    request: ExecutionRequest,
    asset_store: AssetStorePort | None,
    *,
    max_input_asset_bytes: int,
) -> list[dict[str, Any]]:
    blocks: list[dict[str, Any]] = []
    total_asset_bytes = 0
    for block in request.input:
        if isinstance(block, TextBlock):
            blocks.append({"type": "text", "text": block.text})
        elif isinstance(block, ReasoningBlock):
            blocks.append({"type": "text", "text": block.text})
        elif isinstance(block, JsonBlock):
            blocks.append({"type": "text", "text": json.dumps(block.value, ensure_ascii=False)})
        elif isinstance(block, ImageRefBlock):
            if asset_store is None:
                raise ValueError("DSH image input requires an AssetStorePort")
            remaining = max_input_asset_bytes - total_asset_bytes
            if remaining < 1:
                raise ValueError(
                    f"Assets exceed the configured {max_input_asset_bytes}-byte Runtime input limit"
                )
            payload = await read_asset_bytes(
                asset_store,
                block.asset_id,
                expected_media_type=block.media_type,
                max_bytes=remaining,
                aggregate_max_bytes=max_input_asset_bytes,
            )
            total_asset_bytes += len(payload)
            blocks.append(
                {
                    "type": "image",
                    "data": base64.b64encode(payload).decode("ascii"),
                    "mimeType": block.media_type,
                }
            )
        elif isinstance(block, (AudioRefBlock, VideoRefBlock, FileRefBlock)):
            raise ValueError(f"DSH does not advertise support for {block.type}")
    return blocks


def _plain_text(blocks: tuple[ContentBlock, ...]) -> str:
    parts: list[str] = []
    for block in blocks:
        if isinstance(block, (TextBlock, ReasoningBlock)):
            parts.append(block.text)
        elif isinstance(block, JsonBlock):
            parts.append(json.dumps(block.value, ensure_ascii=False))
    return "\n".join(part for part in parts if part)


def _tool_catalog_signature(request: ExecutionRequest) -> str:
    payload = [
        tool.model_dump(mode="json", by_alias=True)
        for tool in request.tools
        if tool.execution in {ToolExecution.APPLICATION, ToolExecution.REMOTE}
    ]
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _dsh_mcp_public_tool_name(server_name: str, raw_name: str) -> str:
    """Mirror DSH MCP's deterministic model-facing name for event de-duplication."""

    import re

    joined = f"mcp__{server_name}__{raw_name}"
    normalized = re.sub(r"[^A-Za-z0-9_-]", "_", joined)
    if normalized == joined and len(normalized) <= 64:
        return normalized
    digest = hashlib.sha256(f"{server_name}\0{raw_name}".encode()).hexdigest()[:12]
    return f"{normalized[: 64 - len(digest) - 1]}_{digest}"


async def _create_backend_safely(
    factory: DSHBackendFactory,
    spec: RuntimeSessionSpec,
    config: DSHRuntimeConfig,
) -> DSHSessionBackend:
    """Do not orphan a thread-created backend when its awaiting task is cancelled."""

    creation = asyncio.create_task(
        asyncio.to_thread(factory, spec, config),
        name=f"dsh:create:{spec.session_id}",
    )
    try:
        return await asyncio.shield(creation)
    except BaseException as primary:
        backend: DSHSessionBackend | None = None
        try:
            backend = creation.result() if creation.done() else await asyncio.shield(creation)
        except BaseException as completion_exc:
            if completion_exc is not primary:
                primary.add_note(f"DSH backend creation also failed: {completion_exc!r}")
        if backend is not None:
            try:
                await _close_backend_instance(backend)
            except BaseException as cleanup_exc:
                primary.add_note(f"DSH backend cleanup after cancelled creation failed: {cleanup_exc!r}")
        raise


async def _close_backend_instance(backend: DSHSessionBackend) -> None:
    cleanup = asyncio.create_task(asyncio.to_thread(backend.close), name="dsh:close-unowned")
    try:
        await asyncio.shield(cleanup)
    except BaseException:
        if not cleanup.done():
            with contextlib.suppress(BaseException):
                await asyncio.shield(cleanup)
        raise


def _required_vendor_string(value: object, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or "\x00" in value
    ):
        raise ValueError(f"DSH {field_name} must be a non-blank, trimmed string")
    return value


def _optional_vendor_string(value: object, field_name: str) -> str | None:
    if value is None:
        return None
    return _required_vendor_string(value, field_name)


def _required_vendor_text(value: object, field_name: str) -> str:
    if not isinstance(value, str) or "\x00" in value:
        raise ValueError(f"DSH {field_name} must be text without NUL bytes")
    return value


def _optional_vendor_bool(value: object, field_name: str) -> bool | None:
    if value is None:
        return None
    if not isinstance(value, bool):
        raise ValueError(f"DSH {field_name} must be a boolean")
    return value


def _dsh_tool_result_is_error(value: object) -> bool:
    """Normalize both DSH tool-result error encodings.

    Durable DSH events use ``message.content[].isError`` as the boolean flag and
    may additionally place structured ``{name, code, ...}`` failure details in
    ``data.error``. Older seams also emitted a boolean at ``data.error``.
    """

    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, dict):
        return True
    raise ValueError("DSH tool/result.error must be a boolean, an object, or null")


def _dsh_tool_arguments(value: object) -> tuple[dict[str, Any] | None, str]:
    if value is None or value == "":
        return {}, ""
    if isinstance(value, dict):
        try:
            raw = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
        except (TypeError, ValueError):
            return None, repr(value)
        return value, raw
    if not isinstance(value, str):
        raise ValueError("DSH tool/call.arguments must be a JSON object or string")
    try:
        parsed = json.loads(
            value,
            parse_constant=lambda constant: (_raise_invalid_json_constant(constant)),
            object_pairs_hook=_reject_duplicate_json_keys,
        )
    except (json.JSONDecodeError, ValueError):
        return None, value
    return (parsed if isinstance(parsed, dict) else None), value


def _reject_duplicate_json_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _raise_invalid_json_constant(constant: str) -> None:
    raise ValueError(f"non-finite JSON number: {constant}")


def _tool_call_fingerprint(
    name: str,
    arguments: dict[str, object],
    agent_id: str | None,
) -> str:
    encoded = json.dumps(
        {"name": name, "arguments": arguments, "agentId": agent_id},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _content_from_dsh(raw: object) -> tuple[ContentBlock, ...]:
    if not isinstance(raw, list):
        return ()
    result: list[ContentBlock] = []
    for block in raw:
        if not isinstance(block, dict):
            continue
        block_type = block.get("type")
        if block_type == "text":
            result.append(TextBlock(text=_required_vendor_text(block.get("text"), "content.text")))
        elif block_type == "reasoning":
            result.append(
                ReasoningBlock(
                    text=_required_vendor_text(block.get("text"), "content.reasoning"),
                    visibility="private",
                )
            )
    return tuple(result)


def _dsh_tool_result(
    block: dict[str, Any] | None,
    event_data: dict[str, Any],
) -> tuple[tuple[ContentBlock, ...], Any]:
    """Extract stable tool output while keeping the vendor envelope in RawEvent.

    DSH has shipped both message-block and top-level result shapes.  Only the
    actual content/value belongs in the canonical tool observation; fields such
    as ``message``, ``toolCallId`` and future vendor metadata are retained by
    the adjacent raw record.
    """

    source = block if block is not None else event_data
    content = _content_from_dsh(source.get("content"))
    structured = source.get("structuredContent")
    if isinstance(structured, dict) and "value" in structured:
        value = structured["value"]
    elif structured is not None:
        value = structured
    elif "value" in source:
        value = source["value"]
    elif "result" in source:
        value = source["result"]
    else:
        value = None
    return content, value
