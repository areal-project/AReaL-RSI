"""Standard ``vision.ocr`` ToolProvider independent of any OCR vendor."""

from __future__ import annotations

from enum import StrEnum
from typing import Protocol, runtime_checkable

from pydantic import Field, JsonValue, ValidationError

from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import JsonBlock, TextBlock
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    HealthStatus,
    ToolCall,
    ToolExecution,
    ToolResult,
    ToolSpec,
)

OCR_TOOL_NAME = "vision.ocr"


class CoordinateUnit(StrEnum):
    PIXEL = "pixel"
    NORMALIZED = "normalized"


class BoundingBox(ContractModel):
    x: float = Field(ge=0)
    y: float = Field(ge=0)
    width: float = Field(ge=0)
    height: float = Field(ge=0)
    unit: CoordinateUnit = CoordinateUnit.PIXEL


class OCRSpan(ContractModel):
    text: str
    confidence: float | None = Field(default=None, ge=0, le=1)
    box: BoundingBox | None = None
    page: int | None = Field(default=None, ge=1)


class OCRExtraction(ContractModel):
    text: str
    spans: tuple[OCRSpan, ...] = ()
    detected_language: str | None = None
    engine: str = Field(min_length=1)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)


class _OCRArguments(ContractModel):
    asset_id: str = Field(min_length=1)
    language: str | None = None


@runtime_checkable
class OCREngine(Protocol):
    async def recognize(
        self,
        image: bytes,
        *,
        media_type: str,
        language: str | None,
    ) -> OCRExtraction: ...

    async def health(self) -> HealthStatus: ...


class OCRToolProvider:
    """Resolve an AssetRef, call an OCR engine, and preserve source provenance."""

    def __init__(self, asset_store: AssetStorePort, engine: OCREngine) -> None:
        self._assets = asset_store
        self._engine = engine

    async def list_tools(self) -> tuple[ToolSpec, ...]:
        return (
            ToolSpec(
                name=OCR_TOOL_NAME,
                description="Extract text and bounding boxes from an image AssetRef.",
                input_schema={
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["assetId"],
                    "properties": {
                        "assetId": {"type": "string", "minLength": 1},
                        "language": {"type": ["string", "null"]},
                    },
                },
                execution=ToolExecution.APPLICATION,
                permissions=("asset.read", "vision.ocr"),
            ),
        )

    async def invoke(self, call: ToolCall) -> ToolResult:
        if call.name != OCR_TOOL_NAME:
            return self._error(call, "TOOL_NOT_FOUND", ErrorCategory.NOT_FOUND, f"Unknown tool: {call.name}")
        try:
            arguments = _OCRArguments.model_validate(call.arguments)
        except ValidationError as exc:
            return self._error(
                call,
                "OCR_ARGUMENTS_INVALID",
                ErrorCategory.INVALID_REQUEST,
                str(exc),
            )

        source = await self._assets.get(arguments.asset_id)
        if source is None:
            return self._error(
                call,
                "OCR_ASSET_NOT_FOUND",
                ErrorCategory.NOT_FOUND,
                f"Unknown image asset: {arguments.asset_id}",
            )
        if not source.media_type.startswith("image/"):
            return self._error(
                call,
                "OCR_ASSET_TYPE_INVALID",
                ErrorCategory.INVALID_REQUEST,
                f"OCR requires image/*, got {source.media_type}",
            )

        try:
            image = b"".join([chunk async for chunk in self._assets.open(source.asset_id)])
            extraction = await self._engine.recognize(
                image,
                media_type=source.media_type,
                language=arguments.language,
            )
        except Exception as exc:
            return self._error(
                call,
                "OCR_ENGINE_FAILED",
                ErrorCategory.INTERNAL,
                str(exc) or type(exc).__name__,
            )

        payload: JsonValue = {
            "schemaVersion": "areal.agent-runtime.vision.ocr/v1",
            "sourceAsset": source.model_dump(mode="json", by_alias=True),
            "transform": {
                "type": "ocr",
                "language": arguments.language,
                "engine": extraction.engine,
            },
            "text": extraction.text,
            "spans": [span.model_dump(mode="json", by_alias=True) for span in extraction.spans],
            "detectedLanguage": extraction.detected_language,
            "metadata": extraction.metadata,
        }
        return ToolResult(
            call_id=call.call_id,
            content=(
                TextBlock(text=extraction.text),
                JsonBlock(value=payload, schema_name="areal.agent-runtime.vision.ocr/v1"),
            ),
            value=payload,
        )

    async def health(self) -> HealthStatus:
        return await self._engine.health()

    @staticmethod
    def _error(
        call: ToolCall,
        code: str,
        category: ErrorCategory,
        message: str,
    ) -> ToolResult:
        return ToolResult(
            call_id=call.call_id,
            error=ErrorInfo(code=code, category=category, message=message),
        )
