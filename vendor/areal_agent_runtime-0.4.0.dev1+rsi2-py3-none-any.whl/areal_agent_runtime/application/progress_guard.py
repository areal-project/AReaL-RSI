"""Deterministic, Runtime-neutral no-progress detection for tool loops."""

from __future__ import annotations

import hashlib
import json
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import Field, JsonValue

from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.runtime import ToolCall, ToolResult

_SOURCE_TOOLS = frozenset({"workspace.write", "workspace.edit"})
_READ_TOOLS = frozenset({"workspace.read", "workspace.list", "workspace.search"})
_READ_FINGERPRINT_LIMIT = 1024
_ERROR_FAMILIES = frozenset(
    {
        "GLOB_NO_MATCH",
        "TOOL_NOT_FOUND",
        "TOOL_NOT_AUTHORIZED",
        "WORKSPACE_PATH_NOT_FOUND",
        "WORKSPACE_EDIT_CONFLICT",
    }
)


@dataclass(frozen=True, slots=True)
class ToolProgress:
    stalled_count: int = 0
    threshold_reached: bool = False
    fingerprint: str = ""
    workspace_changed: bool = False


class NoProgressReport(ContractModel):
    schema_version: Literal["areal.agent-runtime.no-progress/v1"] = "areal.agent-runtime.no-progress/v1"
    status: Literal["no_progress_blocked"] = "no_progress_blocked"
    workspace_revision: int = Field(ge=0)
    stalled_count: int = Field(ge=2)
    fingerprint: str = Field(pattern=r"^[a-f0-9]{16}$")
    workspace_changed: bool = False
    previous_result: dict[str, JsonValue]
    next_action: str = Field(min_length=1)


class ToolProgressGuard:
    """Detect recent repeated reads, ineffective writes and stable tool errors.

    Read-loop detection uses the latest 1024 distinct reads. It is a heuristic,
    not a durable idempotency ledger; retaining older fingerprints indefinitely
    makes legitimate long-running investigations consume unbounded memory.
    """

    def __init__(self, max_stalled: int) -> None:
        self.max_stalled = max(2, min(int(max_stalled), 30))
        self._last_action_fingerprint = ""
        self._last_action_kind = ""
        self._stalled_count = 0
        self._seen_read_fingerprints: OrderedDict[str, None] = OrderedDict()
        self._last_successful_mutation_fingerprint = ""
        self._successful_mutation_streak = 0

    def observe(
        self,
        call: ToolCall,
        result: ToolResult,
        *,
        revision_before: int,
        revision_after: int,
    ) -> ToolProgress:
        if revision_after > revision_before:
            fingerprint = _fingerprint({"name": call.name, "arguments": call.arguments})
            if fingerprint == self._last_successful_mutation_fingerprint:
                self._successful_mutation_streak += 1
            else:
                self._last_successful_mutation_fingerprint = fingerprint
                self._successful_mutation_streak = 1
            self._reset_actions()
            return self._result(
                self._successful_mutation_streak,
                fingerprint,
                workspace_changed=True,
            )

        is_source_attempt = call.name in _SOURCE_TOOLS
        is_read_candidate = call.name in _READ_TOOLS and result.error is None
        is_error_candidate = result.error is not None
        if not (is_source_attempt or is_read_candidate or is_error_candidate):
            self._reset_actions()
            return ToolProgress()

        error_code = result.error.code.upper() if result.error is not None else ""
        if is_error_candidate and error_code in _ERROR_FAMILIES:
            family: dict[str, Any] = {
                "kind": error_code.casefold(),
                "code": error_code,
                "revision": revision_after,
            }
            path = call.arguments.get("path")
            if error_code == "WORKSPACE_PATH_NOT_FOUND" and isinstance(path, str):
                family["path"] = path
            fingerprint = _fingerprint(family)
        else:
            fingerprint = _fingerprint(
                {
                    "name": call.name,
                    "arguments": call.arguments,
                    "revision": revision_after,
                }
            )

        if is_source_attempt and self._last_action_kind == "source":
            self._stalled_count += 1
        elif is_read_candidate and fingerprint in self._seen_read_fingerprints:
            self._stalled_count += 1
        elif is_error_candidate and self._last_action_kind == "error" and fingerprint == self._last_action_fingerprint:
            self._stalled_count += 1
        else:
            self._stalled_count = 1

        if is_source_attempt:
            self._last_action_kind = "source"
        elif is_read_candidate:
            self._last_action_kind = "read"
            self._seen_read_fingerprints[fingerprint] = None
            self._seen_read_fingerprints.move_to_end(fingerprint)
            if len(self._seen_read_fingerprints) > _READ_FINGERPRINT_LIMIT:
                self._seen_read_fingerprints.popitem(last=False)
        else:
            self._last_action_kind = "error"
        self._last_action_fingerprint = fingerprint
        return self._result(self._stalled_count, fingerprint)

    def _result(
        self,
        count: int,
        fingerprint: str,
        *,
        workspace_changed: bool = False,
    ) -> ToolProgress:
        return ToolProgress(
            stalled_count=count,
            threshold_reached=count >= self.max_stalled,
            fingerprint=fingerprint,
            workspace_changed=workspace_changed,
        )

    def _reset_actions(self) -> None:
        self._last_action_fingerprint = ""
        self._last_action_kind = ""
        self._stalled_count = 0
        self._seen_read_fingerprints.clear()


def _fingerprint(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()[:16]


__all__ = ["NoProgressReport", "ToolProgress", "ToolProgressGuard"]
