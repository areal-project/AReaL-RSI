"""Canonical data-plane projection and pre-storage governance.

The operational ``RunEvent`` log remains the v1 source of truth.  This module
defines the deterministic, one-event-to-one-observation translation used by
the data API.  Strict projection is run before a new event is committed;
permissive projection exists only to read historical v1 logs and turns any
legacy mismatch into an explicit governed raw observation.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping

from pydantic import JsonValue, TypeAdapter, ValidationError

from areal_agent_runtime.contracts.base import require_optional_trimmed
from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.data import (
    CanonicalObservation,
    DataClassification,
    DataGovernance,
    InteractionObservation,
    LifecycleObservation,
    MessageObservation,
    ModelCallObservation,
    ObservationLineage,
    RawEventObservation,
    RedactionStatus,
    RetentionClass,
    SchemaReference,
    StreamingSignalObservation,
    ToolCallObservation,
    UsageObservation,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import (
    EnvironmentCreatedEventData,
    EventType,
    RunEvent,
)
from areal_agent_runtime.contracts.product import StartRunCommand
from areal_agent_runtime.contracts.runtime import (
    InteractionRequest,
    InteractionResolvedEventData,
    MessageCompletedEventData,
    MessageDeltaEventData,
    ModelCallCompletedEventData,
    ModelCallFailedEventData,
    ModelCallStartedEventData,
    RawRuntimeEventData,
    ReasoningDeltaEventData,
    RuntimeEvent,
    ToolLifecycleEventData,
    ToolRequestedEventData,
    UsageUpdatedEventData,
    normalize_finish_reason,
    normalize_token_usage,
)

_MESSAGE_DELTA = TypeAdapter(MessageDeltaEventData)
_MESSAGE_COMPLETED = TypeAdapter(MessageCompletedEventData)
_REASONING_DELTA = TypeAdapter(ReasoningDeltaEventData)
_MODEL_STARTED = TypeAdapter(ModelCallStartedEventData)
_MODEL_COMPLETED = TypeAdapter(ModelCallCompletedEventData)
_MODEL_FAILED = TypeAdapter(ModelCallFailedEventData)
_USAGE = TypeAdapter(UsageUpdatedEventData)
_TOOL_REQUESTED = TypeAdapter(ToolRequestedEventData)
_TOOL_LIFECYCLE = TypeAdapter(ToolLifecycleEventData)
_INTERACTION_REQUIRED = TypeAdapter(InteractionRequest)
_INTERACTION_RESOLVED = TypeAdapter(InteractionResolvedEventData)
_RAW = TypeAdapter(RawRuntimeEventData)
_ENVIRONMENT_CREATED = TypeAdapter(EnvironmentCreatedEventData)
_CONTENT = TypeAdapter(tuple[ContentBlock, ...])

_SENSITIVE_KEYS = frozenset(
    {
        "accesstoken",
        "apikey",
        "authorization",
        "clientsecret",
        "cookie",
        "credential",
        "password",
        "privatekey",
        "proxyauthorization",
        "refreshtoken",
        "secret",
        "secretkey",
        "sessiontoken",
        "setcookie",
        "xapikey",
    }
)
_CONFIDENTIAL_EVENT_TYPES = frozenset(
    {
        EventType.RUN_QUEUED,
        EventType.RUN_STARTED,
        EventType.RUN_RESUMED,
        EventType.RUN_COMPLETED,
        EventType.RUN_FAILED,
        EventType.RUN_CANCELLED,
        EventType.EXECUTION_FAILED,
        EventType.MESSAGE_DELTA,
        EventType.MESSAGE_COMPLETED,
        EventType.ASSET_CREATED,
        EventType.ASSET_ATTACHED,
        EventType.TOOL_REQUESTED,
        EventType.TOOL_STARTED,
        EventType.TOOL_PROGRESS,
        EventType.TOOL_COMPLETED,
        EventType.TOOL_FAILED,
        EventType.INTERACTION_REQUIRED,
        EventType.INTERACTION_RESOLVED,
        EventType.AGENT_ENVIRONMENT_RESOLVED,
        EventType.AGENT_MESSAGE,
        EventType.AGENT_COMPLETED,
        EventType.AGENT_FAILED,
        EventType.AGENT_CANCELLED,
        EventType.AGENT_RETRY_SCHEDULED,
        EventType.ORCHESTRATOR_DECIDED,
        EventType.RUNTIME_GRAPH_SNAPSHOTTED,
        EventType.PARALLEL_GROUP_FAILED,
        EventType.PARALLEL_GROUP_CANCELLED,
        EventType.ENVIRONMENT_CREATED,
        EventType.WORKSPACE_CHECKPOINTED,
        EventType.SESSION_COMMITTED,
        EventType.MODEL_CALL_FAILED,
        EventType.RUNTIME_STATUS,
        EventType.WARNING_RAISED,
    }
)


class CanonicalizationError(ValueError):
    """A new canonical event could not satisfy its typed data/v1 payload."""


class RuntimeEventLineageValidator:
    """Execution-local guard for references which cannot be checked by one DTO."""

    def __init__(self) -> None:
        self._models: dict[str, tuple[object, object, object]] = {}
        self._model_owners: dict[str, tuple[str, str | None]] = {}
        self._terminal_models: set[str] = set()

    def observe(self, event: RuntimeEvent) -> None:
        if not isinstance(event.type, EventType) or not isinstance(event.data, dict):
            return
        data = event.data
        if event.type == EventType.MODEL_CALL_STARTED:
            model_call_id = _required_identity(data.get("modelCallId"), "modelCallId")
            if model_call_id in self._models:
                raise ValueError(f"modelCallId started more than once: {model_call_id}")
            self._models[model_call_id] = (
                data.get("provider"),
                data.get("model"),
                data.get("attempt"),
            )
            self._model_owners[model_call_id] = (event.agent_id, event.parent_agent_id)
            return
        if event.type in {EventType.MODEL_CALL_COMPLETED, EventType.MODEL_CALL_FAILED}:
            model_call_id = _required_identity(data.get("modelCallId"), "modelCallId")
            expected = self._models.get(model_call_id)
            if expected is None:
                raise ValueError(f"modelCallId terminal has no start: {model_call_id}")
            if model_call_id in self._terminal_models:
                raise ValueError(f"modelCallId terminated more than once: {model_call_id}")
            actual = (data.get("provider"), data.get("model"), data.get("attempt"))
            if actual != expected:
                raise ValueError(
                    f"modelCallId provider/model/attempt changed before terminal: {model_call_id}"
                )
            self._validate_model_owner(model_call_id, event)
            self._terminal_models.add(model_call_id)
            return
        if event.type in {
            EventType.MESSAGE_DELTA,
            EventType.MESSAGE_COMPLETED,
            EventType.AGENT_MESSAGE,
            EventType.USAGE_UPDATED,
            EventType.TOOL_REQUESTED,
            EventType.TOOL_STARTED,
            EventType.TOOL_COMPLETED,
            EventType.TOOL_FAILED,
        }:
            model_call_id = data.get("modelCallId")
            if model_call_id is not None and model_call_id not in self._models:
                raise ValueError(
                    f"{event.type.value} references unknown modelCallId: {model_call_id}"
                )
            if isinstance(model_call_id, str):
                self._validate_model_owner(model_call_id, event)

    def _validate_model_owner(self, model_call_id: str, event: RuntimeEvent) -> None:
        if self._model_owners[model_call_id] != (event.agent_id, event.parent_agent_id):
            raise ValueError(f"modelCallId references another agent's model call: {model_call_id}")

    def finish(self) -> None:
        active = sorted(set(self._models).difference(self._terminal_models))
        if active:
            raise ValueError(
                "execution terminated with unterminated modelCallId(s): "
                + ", ".join(active)
            )


def canonicalize_runtime_usage(
    data: dict[str, JsonValue],
) -> tuple[dict[str, JsonValue] | None, bool]:
    """Return typed usage data and whether a legacy vendor shape was used.

    Runtime v1 admitted arbitrary ``usage.updated`` objects.  New adapters
    emit ``UsageUpdatedEventData`` directly, while this bridge keeps old
    adapters running without allowing their vendor dictionaries into the
    canonical EventLog.  Callers persist the original shape as governed raw
    data whenever the second return value is true.
    """

    try:
        typed = UsageUpdatedEventData.model_validate(data)
    except ValidationError:
        raw_model_call_id = data.get("modelCallId")
        try:
            model_call_id = require_optional_trimmed(
                raw_model_call_id if isinstance(raw_model_call_id, str) else None,
                "legacy usage modelCallId",
            )
        except ValueError:
            # Runtime v1 allowed arbitrary usage dictionaries. An invalid
            # vendor identifier must not make an otherwise readable legacy
            # event fatal or enter canonical lineage. The complete value is
            # retained in the governed raw companion event by the caller.
            model_call_id = None
        try:
            usage = normalize_token_usage(
                data.get("usage"),
                scope="model-call" if model_call_id is not None else "execution",
            )
        except ValueError:
            usage = None
        if usage is None:
            return None, True
        typed = UsageUpdatedEventData(
            model_call_id=model_call_id,
            usage=usage,
        )
        return typed.model_dump(mode="json", by_alias=True), True
    return typed.model_dump(mode="json", by_alias=True), False


class CanonicalDataPolicy:
    """Small, deterministic authority-boundary policy used before persistence.

    This is intentionally not advertised as semantic DLP.  It blocks common
    credential-shaped fields, classifies sensitive classes, and lets storage
    and external projectors enforce the label.  Deployments can replace this
    policy with stronger content scanning without changing the event contract.
    """

    def protect(
        self,
        event_type: EventType,
        data: dict[str, JsonValue],
    ) -> tuple[dict[str, JsonValue], DataGovernance]:
        protected, redacted = self._redact(data)
        assert isinstance(protected, dict)
        classification = DataClassification.INTERNAL
        retention = RetentionClass.STANDARD
        redaction = RedactionStatus.APPLIED if redacted else RedactionStatus.NOT_REQUIRED

        if event_type == EventType.REASONING_DELTA:
            classification = DataClassification.RESTRICTED
            retention = RetentionClass.TRANSIENT
            if not redacted:
                redaction = RedactionStatus.REQUIRED
        elif event_type == EventType.RAW_EVENT_RECORDED:
            classification = DataClassification.CONFIDENTIAL
            retention = RetentionClass.AUDIT
        elif event_type in _CONFIDENTIAL_EVENT_TYPES:
            classification = DataClassification.CONFIDENTIAL

        return protected, DataGovernance(
            classification=classification,
            retention=retention,
            redaction=redaction,
            policy_id="runtime-authority-boundary/v1",
        )

    @staticmethod
    def combine(
        inferred: DataGovernance,
        requested: DataGovernance | None,
    ) -> DataGovernance:
        """Allow stricter caller labels without permitting a policy downgrade."""

        if requested is None:
            return inferred
        classifications = (
            DataClassification.PUBLIC,
            DataClassification.INTERNAL,
            DataClassification.CONFIDENTIAL,
            DataClassification.RESTRICTED,
        )
        retentions = (
            RetentionClass.TRANSIENT,
            RetentionClass.STANDARD,
            RetentionClass.AUDIT,
            RetentionClass.LEGAL_HOLD,
        )
        redactions = (
            RedactionStatus.NOT_REQUIRED,
            RedactionStatus.REQUIRED,
            RedactionStatus.APPLIED,
        )
        requested_redaction = (
            RedactionStatus.REQUIRED
            if requested.redaction == RedactionStatus.APPLIED
            else requested.redaction
        )
        return DataGovernance(
            classification=max(
                (inferred.classification, requested.classification),
                key=classifications.index,
            ),
            retention=max(
                (inferred.retention, requested.retention),
                key=retentions.index,
            ),
            redaction=max(
                (inferred.redaction, requested_redaction),
                key=redactions.index,
            ),
            policy_id=inferred.policy_id,
        )

    @classmethod
    def _redact(cls, value: JsonValue) -> tuple[JsonValue, bool]:
        if isinstance(value, list):
            changed = False
            items: list[JsonValue] = []
            for item in value:
                protected, item_changed = cls._redact(item)
                items.append(protected)
                changed = changed or item_changed
            return items, changed
        if isinstance(value, dict):
            changed = False
            result: dict[str, JsonValue] = {}
            for key, item in value.items():
                normalized = "".join(character for character in key.lower() if character.isalnum())
                if normalized in _SENSITIVE_KEYS:
                    result[key] = "[REDACTED]"
                    changed = True
                    continue
                protected, item_changed = cls._redact(item)
                result[key] = protected
                changed = changed or item_changed
            return result, changed
        return value, False


class CanonicalObservationProjector:
    """Translate one durable v1 event into one typed data/v1 observation."""

    def project(self, event: RunEvent, *, strict: bool = False) -> CanonicalObservation:
        try:
            payload, identity = self._payload(event)
        except (KeyError, TypeError, ValueError, ValidationError) as exc:
            if strict:
                raise CanonicalizationError(
                    f"{event.type.value} cannot be projected to data/v1: {exc}"
                ) from exc
            payload = RawEventObservation(
                producer="areal-agent-runtime-v1",
                vendor_event_type=event.type.value,
                reason="canonicalization-failed",
                inline=event.data,
            )
            identity = {}

        lineage = ObservationLineage(
            tenant_id=event.tenant_id,
            project_id=event.project_id,
            session_id=event.session_id,
            run_id=event.run_id,
            execution_id=event.execution_id,
            agent_attempt_id=event.agent_attempt_id,
            agent_id=event.agent_id,
            parent_agent_id=event.parent_agent_id,
            model_call_id=identity.get("model_call_id"),
            message_id=identity.get("message_id"),
            tool_call_id=identity.get("tool_call_id"),
            interaction_id=identity.get("interaction_id"),
            correlation_id=event.correlation_id,
            trace_id=event.trace_id,
            span_id=event.span_id,
            episode_id=event.episode_id,
            environment_id=event.environment_id,
            agent_environment_id=event.agent_environment_id,
            workspace_id=event.workspace_id,
        )
        kind = payload.kind
        return CanonicalObservation(
            observation_id=f"obs_{event.event_id}",
            sequence=event.sequence,
            time=event.time,
            source_event_id=event.event_id,
            source_event_api_version=event.api_version,
            source_event_type=event.type.value,
            schema_ref=SchemaReference(
                namespace=f"areal.agent-runtime.observation.{kind}",
                version="v1",
            ),
            lineage=lineage,
            governance=event.governance,
            payload=payload,
        )

    def _payload(self, event: RunEvent) -> tuple[object, dict[str, str | None]]:
        data = event.data
        identity: dict[str, str | None] = {}

        # Product v1 already persists the complete StartRun request inside the
        # run.queued event. Project it into a canonical user message instead of
        # adding another Event API v1 event that old consumers would have to
        # understand. Historical/manual queue events without a request retain
        # their original lifecycle projection.
        if event.type == EventType.RUN_QUEUED and isinstance(data.get("request"), dict):
            request = StartRunCommand.model_validate(data["request"])
            identity["message_id"] = _projected_id("msg", event.event_id)
            return (
                MessageObservation(
                    role="user",
                    content=request.input,
                    identity_source="projection",
                ),
                identity,
            )

        if event.type == EventType.MESSAGE_DELTA:
            parsed = _MESSAGE_DELTA.validate_python(data)
            identity["message_id"] = parsed.message_id or _projected_id("msg", event.event_id)
            identity["model_call_id"] = parsed.model_call_id
            return (
                StreamingSignalObservation(
                    signal_type="message-delta",
                    content=(parsed.delta,),
                ),
                identity,
            )
        if event.type in {EventType.MESSAGE_COMPLETED, EventType.AGENT_MESSAGE}:
            parsed = _MESSAGE_COMPLETED.validate_python(data)
            identity["message_id"] = parsed.message_id or _projected_id("msg", event.event_id)
            identity["model_call_id"] = parsed.model_call_id
            return (
                MessageObservation(
                    role=parsed.role,
                    content=parsed.content,
                    identity_source="producer" if parsed.message_id is not None else "projection",
                ),
                identity,
            )
        if event.type == EventType.REASONING_DELTA:
            parsed = _REASONING_DELTA.validate_python(data)
            return (
                StreamingSignalObservation(
                    signal_type="reasoning-delta",
                    text=parsed.text,
                    final=parsed.final,
                ),
                identity,
            )
        if event.type == EventType.MODEL_CALL_STARTED:
            parsed = _MODEL_STARTED.validate_python(data)
            identity["model_call_id"] = parsed.model_call_id
            return (
                ModelCallObservation(
                    phase="started",
                    provider=parsed.provider,
                    model=parsed.model,
                    attempt=parsed.attempt,
                ),
                identity,
            )
        if event.type == EventType.MODEL_CALL_COMPLETED:
            parsed = _MODEL_COMPLETED.validate_python(data)
            identity["model_call_id"] = parsed.model_call_id
            return (
                ModelCallObservation(
                    phase="completed",
                    provider=parsed.provider,
                    model=parsed.model,
                    provider_request_id=parsed.provider_request_id,
                    finish_reason=normalize_finish_reason(parsed.finish_reason),
                    duration_seconds=parsed.duration_seconds,
                    attempt=parsed.attempt,
                ),
                identity,
            )
        if event.type == EventType.MODEL_CALL_FAILED:
            parsed = _MODEL_FAILED.validate_python(data)
            identity["model_call_id"] = parsed.model_call_id
            return (
                ModelCallObservation(
                    phase="failed",
                    provider=parsed.provider,
                    model=parsed.model,
                    error=parsed.error,
                    duration_seconds=parsed.duration_seconds,
                    attempt=parsed.attempt,
                ),
                identity,
            )
        if event.type == EventType.USAGE_UPDATED:
            parsed = _USAGE.validate_python(data)
            identity["model_call_id"] = parsed.model_call_id
            return UsageObservation(usage=parsed.usage), identity
        if event.type in {EventType.TOOL_REQUESTED, EventType.TOOL_STARTED}:
            parsed = _TOOL_REQUESTED.validate_python(data)
            identity["tool_call_id"] = parsed.call_id
            identity["model_call_id"] = parsed.model_call_id
            return (
                ToolCallObservation(
                    phase=("requested" if event.type == EventType.TOOL_REQUESTED else "started"),
                    name=parsed.name,
                    arguments=parsed.arguments,
                ),
                identity,
            )
        if event.type in {EventType.TOOL_COMPLETED, EventType.TOOL_FAILED}:
            parsed = _TOOL_LIFECYCLE.validate_python(data)
            identity["tool_call_id"] = parsed.call_id
            identity["model_call_id"] = parsed.model_call_id
            name = parsed.name or _required_tool_name(data)
            error = _normalized_error(parsed.error, event, "TOOL_CALL_FAILED")
            if event.type == EventType.TOOL_FAILED and error is None:
                error = ErrorInfo(
                    code="TOOL_CALL_FAILED",
                    category=ErrorCategory.INTERNAL,
                    message=parsed.summary or "Harness reported a failed tool call",
                )
            return (
                ToolCallObservation(
                    phase=("failed" if event.type == EventType.TOOL_FAILED else "completed"),
                    name=name,
                    arguments=parsed.arguments,
                    content=parsed.content,
                    value=parsed.value if parsed.value is not None else parsed.result,
                    error=error,
                    duration_seconds=parsed.duration_seconds,
                ),
                identity,
            )
        if event.type == EventType.INTERACTION_REQUIRED:
            parsed = _INTERACTION_REQUIRED.validate_python(data)
            identity["interaction_id"] = parsed.interaction_id
            return (
                InteractionObservation(
                    phase="required",
                    interaction_kind=parsed.kind,
                    request=parsed.request,
                    terminal=parsed.terminal,
                    commit_barrier=parsed.commit_barrier,
                ),
                identity,
            )
        if event.type == EventType.INTERACTION_RESOLVED:
            parsed = _INTERACTION_RESOLVED.validate_python(data)
            identity["interaction_id"] = parsed.interaction_id
            return (
                InteractionObservation(
                    phase="resolved",
                    interaction_kind=parsed.kind,
                    pending_interactions=parsed.pending_interactions,
                ),
                identity,
            )
        if event.type == EventType.RAW_EVENT_RECORDED:
            parsed = _RAW.validate_python(data)
            return (
                RawEventObservation(
                    producer=parsed.producer,
                    vendor_event_type=parsed.vendor_event_type,
                    reason=parsed.reason,
                    storage=parsed.storage,
                    inline=parsed.payload,
                    asset_id=parsed.asset_id,
                ),
                identity,
            )
        if event.type == EventType.ENVIRONMENT_CREATED:
            parsed = _ENVIRONMENT_CREATED.validate_python(data)
            if (
                parsed.environment_id != event.environment_id
                or parsed.workspace_id != event.workspace_id
            ):
                raise ValueError(
                    "environment.created payload does not match event lineage"
                )
            return _lifecycle_payload(event), identity
        if event.type in {EventType.RUNTIME_STATUS, EventType.WARNING_RAISED}:
            producer = data.get("vendor")
            vendor_type = data.get("messageType") or data.get("event") or event.type.value
            return (
                RawEventObservation(
                    producer=producer if isinstance(producer, str) and producer else "harness",
                    vendor_event_type=(
                        vendor_type if isinstance(vendor_type, str) and vendor_type else event.type.value
                    ),
                    reason="unsupported-event",
                    inline=data,
                ),
                identity,
            )

        return _lifecycle_payload(event), identity


def canonical_asset_ids(event: RunEvent) -> tuple[str, ...]:
    """Read asset references only from defined content slots.

    Arbitrary JSON (tool arguments/value, JsonBlock.value, metadata, raw vendor
    payload) is data, even if it contains a perfectly valid serialized AssetRef.
    Traversing it would let an echoed object grant run-scoped download access.
    """

    found: set[str] = set()
    if event.type in {EventType.ASSET_CREATED, EventType.ASSET_ATTACHED}:
        asset_id = event.data.get("assetId")
        if isinstance(asset_id, str) and asset_id:
            found.add(asset_id)
    if event.type == EventType.RAW_EVENT_RECORDED and event.data.get("storage") == "asset-ref":
        asset_id = event.data.get("assetId")
        if isinstance(asset_id, str) and asset_id:
            found.add(asset_id)

    def content(value: object) -> None:
        try:
            blocks = _CONTENT.validate_python(value)
        except ValidationError:
            return
        for block in blocks:
            if isinstance(block, (ImageRefBlock, AudioRefBlock, VideoRefBlock, FileRefBlock)):
                found.add(block.asset_id)
            if isinstance(block, VideoRefBlock) and block.poster_asset_id is not None:
                found.add(block.poster_asset_id)

    data = event.data
    if event.type == EventType.RUN_QUEUED:
        request = data.get("request")
        if isinstance(request, dict):
            content(request.get("input"))
    elif event.type in {EventType.RUN_STARTED, EventType.RUN_RESUMED}:
        # Historical v1 Hosts placed canonical input on run.started.
        content(data.get("input"))
    elif event.type in {
        EventType.MESSAGE_COMPLETED, EventType.AGENT_MESSAGE,
        EventType.TOOL_COMPLETED, EventType.TOOL_FAILED,
    }:
        content(data.get("content"))
    elif event.type == EventType.MESSAGE_DELTA:
        content([data["delta"]] if "delta" in data else [])
    elif event.type in {EventType.RUN_COMPLETED, EventType.AGENT_COMPLETED}:
        content(data.get("output"))
    elif event.type == EventType.RUNTIME_GRAPH_SNAPSHOTTED:
        for key in ("agents", "groups"):
            nodes = data.get(key)
            if isinstance(nodes, list):
                for node in nodes:
                    if isinstance(node, dict):
                        content(node.get("output"))
    return tuple(sorted(found))


def governance_allows_external(
    event: RunEvent,
    *,
    include_restricted: bool = False,
    include_confidential: bool = True,
) -> bool:
    if include_restricted:
        return True
    if (
        event.governance.classification == DataClassification.CONFIDENTIAL
        and not include_confidential
    ):
        return False
    return event.governance.classification != DataClassification.RESTRICTED


def _lifecycle_payload(event: RunEvent) -> LifecycleObservation:
    value = event.type.value
    if value.endswith(".started") or value in {"run.queued", "run.resumed"}:
        phase = "started"
    elif value.endswith(".completed") or value.endswith(".joined"):
        phase = "completed"
    elif value.endswith(".failed"):
        phase = "failed"
    elif value.endswith(".cancelled"):
        phase = "cancelled"
    elif value == "interaction.required":
        phase = "waiting"
    else:
        phase = "updated"
    finish_reason = _optional_text(
        event.data.get("finishReason")
        or event.data.get("stopReason")
        or event.data.get("reason")
    )
    duration = event.data.get("durationSeconds")
    duration_seconds = (
        float(duration)
        if isinstance(duration, (int, float)) and not isinstance(duration, bool)
        else None
    )
    error = _normalized_error(event.data.get("error"), event, "RUNTIME_EVENT_FAILED")
    return LifecycleObservation(
        event_type=value,
        phase=phase,
        finish_reason=normalize_finish_reason(finish_reason),
        error=error,
        duration_seconds=duration_seconds,
    )


def _normalized_error(value: object, event: RunEvent, fallback_code: str) -> ErrorInfo | None:
    if value is None:
        return None
    try:
        return ErrorInfo.model_validate(value)
    except (TypeError, ValueError, ValidationError):
        return ErrorInfo(
            code=fallback_code,
            category=ErrorCategory.INTERNAL,
            message=f"{event.type.value} reported an unstructured error",
        )


def _required_tool_name(data: Mapping[str, JsonValue]) -> str:
    name = data.get("name")
    if isinstance(name, str) and name:
        return name
    raise ValueError("tool terminal event requires canonical name")


def _projected_id(prefix: str, source: str) -> str:
    digest = hashlib.sha256(source.encode("utf-8")).hexdigest()[:24]
    return f"{prefix}_{digest}"


def _optional_text(value: object) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def _required_identity(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{field} must be a non-empty string")
    return value
