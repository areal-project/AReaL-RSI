"""Translate Hermes' TUI Gateway JSON-RPC into the ARealAgentRuntime Runtime Port."""

from __future__ import annotations

import asyncio
import base64
import json
import math
import os
import re
import sys
import weakref
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from areal_agent_runtime.adapters.hermes.native import HermesNativeRuntimeAdapter

from areal_agent_runtime.adapters._asset_io import MAX_RUNTIME_ASSET_BYTES, read_asset_bytes
from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    JsonBlock,
    ReasoningBlock,
    TextBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.data import (
    DataCoverage,
    DetailCoverage,
    MessageCoverage,
    RawEventCoverage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ChildEventProjection,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolResult,
    normalize_token_usage,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
    runtime_session_binding_digest,
)
from areal_agent_runtime.kernel.ids import new_id
from areal_agent_runtime.transports.jsonrpc import JsonRpcPeer, JsonRpcProtocolError

_END = object()
NotificationHandler = Callable[[Any], Awaitable[None]]
DEFAULT_MAX_HERMES_INPUT_ASSET_BYTES = 8 * 1024 * 1024


class HermesPeer(Protocol):
    def on_notification(self, method: str, handler: NotificationHandler) -> None: ...

    async def request(
        self,
        method: str,
        params: Any = None,
        *,
        timeout_seconds: float | None = None,
    ) -> Any: ...


@dataclass(slots=True)
class _HermesSessionState:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    live_session_id: str
    stored_session_id: str
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    closed: bool = False


class _HermesExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        *,
        runtime_instance_id: str,
        request: ExecutionRequest,
        peer: HermesPeer,
        live_session_id: str,
        prompt_text: str,
        images: list[tuple[str, str]],
        execution_slots: asyncio.Semaphore,
        on_finish: Callable[[str], None],
    ) -> None:
        self._runtime_instance_id = runtime_instance_id
        self._request = request
        self._peer = peer
        self._live_session_id = live_session_id
        self._prompt_text = prompt_text
        self._images = images
        self._execution_slots = execution_slots
        self._slot_acquired = False
        self._on_finish = on_finish
        self._queue: asyncio.Queue[RuntimeEvent | object] = asyncio.Queue()
        self._sequence = 0
        self._ended = False
        self._terminal = False
        self._interactions: dict[str, tuple[str, str | None]] = {}
        self._interaction_lock = asyncio.Lock()
        self._cancel_lock = asyncio.Lock()
        self._started_children: dict[str, str] = {}
        self._terminal_children: set[str] = set()
        self._child_phases: dict[str, set[str]] = {}
        self._tools: dict[str, str] = {}
        self._terminal_tools: set[str] = set()
        self._emit(EventType.EXECUTION_STARTED, {"vendor": "hermes"})
        self._task = asyncio.create_task(self._submit(), name=f"hermes:{request.execution_id}")

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        while True:
            item = await self._queue.get()
            if item is _END:
                return
            if isinstance(item, RuntimeEvent):
                yield item

    def _emit(
        self,
        event_type: EventType,
        data: Any,
        *,
        agent_id: str | None = None,
        parent_agent_id: str | None = None,
        ignorable: bool = False,
    ) -> None:
        if self._ended:
            return
        effective_agent_id = agent_id or self._request.agent.agent_id
        event_data = data
        if effective_agent_id != self._request.agent.agent_id and isinstance(data, dict):
            event_data = {**data, "parentExecutionId": self._request.execution_id}
            group_id = self._request.metadata.get("parallelGroupId")
            if isinstance(group_id, str) and group_id:
                event_data["groupId"] = group_id
        self._queue.put_nowait(
            RuntimeEvent(
                runtime_instance_id=self._runtime_instance_id,
                runtime_sequence=self._sequence,
                execution_id=self._request.execution_id,
                agent_id=effective_agent_id,
                parent_agent_id=(parent_agent_id if agent_id is not None else self._request.agent.parent_agent_id),
                type=event_type,
                data=event_data,
                ignorable=ignorable,
            )
        )
        self._sequence += 1

    def _finish(self) -> None:
        if self._ended:
            return
        self._terminal = True
        self._ended = True
        self._interactions.clear()
        if self._slot_acquired:
            self._execution_slots.release()
            self._slot_acquired = False
        try:
            self._on_finish(self._live_session_id)
        finally:
            self._queue.put_nowait(_END)
        task = getattr(self, "_task", None)
        if task is not None and task is not asyncio.current_task() and not task.done():
            task.cancel()

    def _start_child(self, child_id: str, parent_id: str, data: dict[str, Any]) -> None:
        if child_id in self._started_children:
            return
        if child_id == self._request.agent.agent_id or child_id == parent_id:
            raise ValueError("Hermes child identity collides with its parent")
        if parent_id != self._request.agent.agent_id and (
            parent_id not in self._started_children or parent_id in self._terminal_children
        ):
            raise ValueError(f"Hermes child references an inactive parent: {parent_id}")
        self._started_children[child_id] = parent_id
        self._emit(
            EventType.AGENT_STARTED,
            data,
            agent_id=child_id,
            parent_agent_id=parent_id,
        )

    def _active_child(self, child_id: str, parent_id: str, data: dict[str, Any]) -> None:
        if child_id not in self._started_children:
            self._start_child(
                child_id,
                parent_id,
                {**data, "vendor": "hermes", "synthetic": True},
            )
        elif self._started_children[child_id] != parent_id:
            raise ValueError(f"Hermes child parent changed: {child_id}")
        if child_id in self._terminal_children:
            raise ValueError(f"Hermes emitted an event for terminal child: {child_id}")

    def _finish_child(self, child_id: str, event_type: EventType, data: dict[str, Any]) -> None:
        if child_id not in self._started_children or child_id in self._terminal_children:
            raise ValueError(f"Hermes finished an unknown or terminal child: {child_id}")
        parent_id = self._started_children[child_id]
        self._emit(
            event_type,
            data,
            agent_id=child_id,
            parent_agent_id=parent_id,
        )
        self._terminal_children.add(child_id)

    def _active_children(self) -> tuple[str, ...]:
        return tuple(child for child in self._started_children if child not in self._terminal_children)

    def _terminate_active_children(self, event_type: EventType, reason: str) -> None:
        for child_id in reversed(self._active_children()):
            self._finish_child(
                child_id,
                event_type,
                {"vendor": "hermes", "reason": reason, "synthetic": True},
            )

    def _terminate_active_tools(self, reason: str) -> None:
        for call_id, name in self._tools.items():
            if call_id in self._terminal_tools:
                continue
            self._emit(
                EventType.TOOL_FAILED,
                {
                    "callId": call_id,
                    "name": name,
                    "error": {"reason": reason, "synthetic": True},
                },
            )
            self._terminal_tools.add(call_id)

    async def _submit(self) -> None:
        try:
            await self._execution_slots.acquire()
            self._slot_acquired = True
            if self._terminal:
                self._execution_slots.release()
                self._slot_acquired = False
                return
            for encoded, filename in self._images:
                await self._peer.request(
                    "image.attach_bytes",
                    {
                        "session_id": self._live_session_id,
                        "content_base64": encoded,
                        "filename": filename,
                    },
                )
            await self._peer.request(
                "prompt.submit",
                {"session_id": self._live_session_id, "text": self._prompt_text},
            )
        except asyncio.CancelledError:
            if not self._terminal:
                self._terminate_active_tools("cancelled")
                self._terminate_active_children(EventType.AGENT_CANCELLED, "cancelled")
                self._emit(EventType.EXECUTION_FAILED, {"vendor": "hermes", "reason": "cancelled"})
                self._finish()
        except Exception as exc:
            if not self._terminal:
                self._terminate_active_tools("submit_failed")
                self._terminate_active_children(EventType.AGENT_FAILED, "submit_failed")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"vendor": "hermes", "reason": "submit_failed", "message": str(exc) or type(exc).__name__},
                )
                self._finish()

    def handle_gateway_event(self, event: dict[str, Any]) -> None:
        if self._ended:
            return
        event_type = _hermes_identity(event.get("type"), "event.type")
        payload = event.get("payload")
        if event_type == "message.start" and payload is None:
            payload = {}
        if not isinstance(payload, dict):
            raise ValueError("Hermes event.payload must be an object")
        data = payload

        if event_type == "message.delta":
            text = _hermes_optional_text_field(data, ("text", "rendered"), "message.delta text")
            if text is None:
                raise ValueError("Hermes message.delta requires text or rendered")
            self._emit(
                EventType.MESSAGE_DELTA,
                {"delta": {"type": "text", "text": text}},
            )
            return
        if event_type in {"thinking.delta", "reasoning.delta", "reasoning.available"}:
            text = _hermes_optional_text_field(data, ("text",), "reasoning text")
            if text is None:
                raise ValueError(f"Hermes {event_type} requires text")
            self._emit(
                EventType.REASONING_DELTA,
                {"text": text},
            )
            return
        if event_type == "message.complete":
            active_tools = [call_id for call_id in self._tools if call_id not in self._terminal_tools]
            if active_tools:
                raise ValueError("Hermes completed a message while tools were still active: " + ", ".join(active_tools))
            if self._interactions:
                raise ValueError("Hermes completed a message while interactions were unresolved")
            text = _hermes_optional_text_field(
                data,
                ("text", "rendered", "response"),
                "message.complete text",
            )
            # Native Hermes may return success after empty-response recovery
            # is exhausted, with no text or its explicit "(empty)" sentinel.
            # Reasoning remains separate and cannot satisfy a final answer.
            has_final_text = text is not None and bool(text.strip()) and text.strip() != "(empty)"
            if has_final_text and text is not None:
                self._emit(
                    EventType.MESSAGE_COMPLETED,
                    {"content": [TextBlock(text=text).model_dump(mode="json", by_alias=True)]},
                )
            reasoning = data.get("reasoning")
            if reasoning is not None:
                reasoning = _hermes_text(reasoning, "message.complete reasoning")
                if reasoning:
                    self._emit(EventType.REASONING_DELTA, {"text": reasoning, "final": True})
            if data.get("usage") is not None or data.get("billing") is not None:
                self._emit_usage(
                    data.get("usage"),
                    vendor_payload={
                        "usage": data.get("usage"),
                        "billing": data.get("billing"),
                    },
                )
            status = _hermes_identity(
                data["status"] if "status" in data else "complete",
                "message.complete status",
            ).lower()
            if status not in {
                "complete",
                "completed",
                "success",
                "error",
                "failed",
                "interrupted",
                "cancelled",
                "stopped",
                "killed",
            }:
                raise ValueError(f"Hermes returned an unknown terminal status: {status}")
            failure = next(
                (data[key] for key in ("failure_reason", "error") if key in data and data[key] not in (None, "")),
                None,
            )
            recoverable = data.get("recoverable")
            if recoverable is not None and not isinstance(recoverable, bool):
                raise ValueError("Hermes message.complete recoverable must be a boolean")
            if failure or status in {"error", "failed"}:
                self._terminate_active_children(EventType.AGENT_FAILED, "runtime_error")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {
                        "vendor": "hermes",
                        "reason": _hermes_error_message(failure or "runtime_error"),
                        "status": status,
                        "errorSurface": data.get("error_surface"),
                        "recoverable": recoverable,
                    },
                )
            elif status in {"interrupted", "cancelled", "stopped", "killed"}:
                self._terminate_active_children(EventType.AGENT_CANCELLED, "cancelled")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"vendor": "hermes", "reason": "cancelled", "status": status},
                )
            elif not has_final_text:
                self._terminate_active_children(EventType.AGENT_FAILED, "MODEL_FINAL_ANSWER_REQUIRED")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {
                        "vendor": "hermes",
                        "reason": "MODEL_FINAL_ANSWER_REQUIRED",
                        "status": status,
                        "recoverable": False,
                    },
                )
            else:
                self._terminate_active_children(EventType.AGENT_COMPLETED, "parent_completed")
                self._emit(
                    EventType.EXECUTION_COMPLETED,
                    {"vendor": "hermes", "status": status},
                )
            self._finish()
            return
        if event_type == "tool.start":
            call_id = _hermes_identity(data.get("tool_id"), "tool.start tool_id")
            name = _hermes_identity(data.get("name"), "tool.start name")
            if call_id in self._tools:
                raise ValueError(f"Hermes started tool more than once: {call_id}")
            raw_args = data.get("args_text")
            if raw_args is not None and not isinstance(raw_args, str):
                raise ValueError("Hermes tool.start args_text must be text")
            raw_arguments = data.get("args")
            if raw_arguments is not None and not isinstance(raw_arguments, dict):
                raise ValueError("Hermes tool.start args must be an object")
            # Current Gateway builds do not always include raw tool arguments
            # in tool.start.  An empty object is the only canonical lossless
            # projection available; ``context`` still carries the preview.
            arguments = raw_arguments if isinstance(raw_arguments, dict) else {}
            self._tools[call_id] = name
            tool_data = {
                "callId": call_id,
                "name": name,
                "arguments": arguments,
                "rawArguments": raw_args,
                "context": data.get("context"),
                "execution": "runtime",
            }
            self._emit(EventType.TOOL_REQUESTED, tool_data)
            self._emit(
                EventType.TOOL_STARTED,
                tool_data,
            )
            return
        if event_type == "tool.progress":
            raw_call_id = data.get("tool_id")
            if raw_call_id is None:
                raw_name = data.get("name")
                if raw_name is None:
                    self._emit(
                        EventType.RUNTIME_STATUS,
                        {"vendor": "hermes", "event": event_type, "data": data},
                        ignorable=True,
                    )
                    return
                name = _hermes_identity(raw_name, "tool.progress name")
                candidates = [
                    candidate
                    for candidate, candidate_name in self._tools.items()
                    if candidate_name == name and candidate not in self._terminal_tools
                ]
                if len(candidates) != 1:
                    self._emit(
                        EventType.RUNTIME_STATUS,
                        {"vendor": "hermes", "event": event_type, "data": data},
                        ignorable=True,
                    )
                    return
                call_id = candidates[0]
            else:
                call_id = _hermes_identity(raw_call_id, "tool.progress tool_id")
            if call_id not in self._tools or call_id in self._terminal_tools:
                raise ValueError(f"Hermes progressed an inactive tool: {call_id}")
            self._emit(EventType.TOOL_PROGRESS, {**data, "callId": call_id})
            return
        if event_type == "tool.complete":
            call_id = _hermes_identity(data.get("tool_id"), "tool.complete tool_id")
            if call_id not in self._tools or call_id in self._terminal_tools:
                raise ValueError(f"Hermes completed an inactive tool: {call_id}")
            completion_name = data.get("name")
            if (
                completion_name is not None
                and _hermes_identity(completion_name, "tool.complete name") != self._tools[call_id]
            ):
                raise ValueError(f"Hermes changed tool name before completion: {call_id}")
            result = data.get("result") if "result" in data else data.get("result_text")
            error = data.get("error")
            if error is None and isinstance(result, dict):
                error = result.get("error") or ("tool returned ok=false" if result.get("ok") is False else None)
            failed = error is not None and error != ""
            duration = data.get("duration_s")
            if duration is not None:
                if (
                    isinstance(duration, bool)
                    or not isinstance(duration, (int, float))
                    or not math.isfinite(duration)
                    or duration < 0
                ):
                    raise ValueError("Hermes tool duration must be a finite non-negative number")
                duration = float(duration)
            self._emit(
                EventType.TOOL_FAILED if failed else EventType.TOOL_COMPLETED,
                {
                    "callId": call_id,
                    "name": self._tools[call_id],
                    "result": result,
                    "summary": data.get("summary"),
                    "error": error,
                    "durationSeconds": duration,
                },
            )
            self._terminal_tools.add(call_id)
            return
        if event_type in {
            "clarify.request",
            "approval.request",
            "sudo.request",
            "secret.request",
            "terminal.read.request",
        }:
            vendor_request_id = _hermes_identity(data.get("request_id"), "interaction request_id")
            interaction_id = vendor_request_id
            kind = event_type.removesuffix(".request")
            if interaction_id in self._interactions:
                raise ValueError(f"Hermes repeated interaction request: {interaction_id}")
            self._interactions[interaction_id] = (
                kind,
                vendor_request_id,
            )
            self._emit(
                EventType.INTERACTION_REQUIRED,
                {"interactionId": interaction_id, "kind": kind, "request": data},
            )
            return
        if event_type.startswith("subagent."):
            self._map_subagent(event_type, data)
            return
        if event_type == "session.usage":
            self._emit_usage(data.get("usage"), vendor_payload=data)
            return
        if event_type == "error":
            self._emit(
                EventType.WARNING_RAISED,
                {
                    "vendor": "hermes",
                    "message": _hermes_identity(data.get("message"), "error message"),
                },
            )
            return
        self._emit(
            EventType.RUNTIME_STATUS,
            {"vendor": "hermes", "event": event},
            ignorable=True,
        )

    def _emit_usage(self, usage: object, *, vendor_payload: object) -> None:
        normalized = normalize_token_usage(usage, scope="execution")
        if normalized is not None:
            self._emit(
                EventType.USAGE_UPDATED,
                {"usage": normalized.model_dump(mode="json", by_alias=True)},
            )
        self._emit(
            EventType.RAW_EVENT_RECORDED,
            {
                "producer": "hermes-agent",
                "vendorEventType": "usage",
                "runtimeInstanceId": self._runtime_instance_id,
                "runtimeSequence": self._sequence,
                "reason": "unsupported-event",
                "payload": vendor_payload,
            },
            ignorable=True,
        )

    def _map_subagent(self, vendor_type: str, data: dict[str, Any]) -> None:
        raw_child_id = data.get("subagent_id")
        if raw_child_id is None:
            task_index = data.get("task_index")
            if isinstance(task_index, bool) or not isinstance(task_index, int) or task_index < 0:
                raise ValueError("Hermes subagent event requires subagent_id or non-negative task_index")
            child_id = f"hermes-task:{task_index}"
        else:
            child_id = _hermes_identity(raw_child_id, "subagent_id")
        parent_id = _hermes_identity(
            data["parent_id"] if data.get("parent_id") is not None else self._request.agent.agent_id,
            "subagent parent_id",
        )
        if vendor_type in {"subagent.spawn_requested", "subagent.start"}:
            phases = self._child_phases.setdefault(child_id, set())
            if vendor_type in phases:
                raise ValueError(f"Hermes repeated {vendor_type} for child: {child_id}")
            phases.add(vendor_type)
            if child_id in self._terminal_children:
                raise ValueError(f"Hermes restarted terminal child: {child_id}")
            if child_id in self._started_children:
                if self._started_children[child_id] != parent_id:
                    raise ValueError(f"Hermes child parent changed: {child_id}")
                return
            self._start_child(child_id, parent_id, {**data, "vendor": "hermes"})
        elif vendor_type == "subagent.thinking":
            self._active_child(child_id, parent_id, data)
            self._emit(
                EventType.REASONING_DELTA,
                {"text": _hermes_text(data.get("text") or "", "subagent thinking")},
                agent_id=child_id,
                parent_agent_id=parent_id,
            )
        elif vendor_type == "subagent.text":
            self._active_child(child_id, parent_id, data)
            self._emit(
                EventType.AGENT_MESSAGE,
                {
                    "content": [
                        TextBlock(text=_hermes_text(data.get("text") or "", "subagent text")).model_dump(
                            mode="json", by_alias=True
                        )
                    ]
                },
                agent_id=child_id,
                parent_agent_id=parent_id,
            )
        elif vendor_type == "subagent.tool":
            self._active_child(child_id, parent_id, data)
            self._emit(
                EventType.RUNTIME_STATUS,
                {
                    "vendor": "hermes",
                    "subagentEvent": vendor_type,
                    "toolName": data.get("tool_name"),
                    "toolPreview": data.get("tool_preview"),
                },
                agent_id=child_id,
                parent_agent_id=parent_id,
                ignorable=True,
            )
        elif vendor_type == "subagent.complete":
            self._active_child(child_id, parent_id, data)
            status = _hermes_identity(
                data["status"] if "status" in data else "completed",
                "subagent status",
            ).lower()
            if status not in {
                "complete",
                "completed",
                "success",
                "error",
                "failed",
                "cancelled",
                "stopped",
                "killed",
            }:
                raise ValueError(f"Hermes returned an unknown subagent status: {status}")
            failed = status in {"error", "failed"}
            cancelled = status in {"cancelled", "stopped", "killed"}
            event_type = (
                EventType.AGENT_CANCELLED
                if cancelled
                else EventType.AGENT_FAILED
                if failed
                else EventType.AGENT_COMPLETED
            )
            self._finish_child(
                child_id,
                event_type,
                {**data, "vendor": "hermes"},
            )
        else:
            self._active_child(child_id, parent_id, data)
            self._emit(
                EventType.RUNTIME_STATUS,
                {"vendor": "hermes", "subagentEvent": vendor_type, "data": data},
                agent_id=child_id,
                parent_agent_id=parent_id,
                ignorable=True,
            )

    async def send_tool_result(self, result: ToolResult) -> None:
        raise NotImplementedError("Hermes Gateway executes its configured tools inside the runtime")

    async def respond(self, response: InteractionResponse) -> None:
        async with self._interaction_lock:
            if self._terminal:
                raise RuntimeError("Hermes execution is already terminal")
            try:
                kind, vendor_request_id = self._interactions[response.interaction_id]
            except KeyError as exc:
                raise LookupError(f"Unknown Hermes interaction: {response.interaction_id}") from exc
            response_fields = {
                "clarify": ("answer", False),
                "approval": ("choice", True),
                "sudo": ("password", False),
                "secret": ("value", False),
                "terminal.read": ("text", False),
            }
            try:
                field_name, require_non_blank = response_fields[kind]
            except KeyError as exc:
                raise RuntimeError(f"Unsupported Hermes interaction kind: {kind}") from exc
            value = _hermes_response_text(
                response.response,
                field_name=field_name,
                require_non_blank=require_non_blank,
            )
            params: dict[str, Any] = {
                "session_id": self._live_session_id,
                "request_id": vendor_request_id,
                field_name: value,
            }
            await self._peer.request(f"{kind}.respond", params)
            if self._terminal:
                raise RuntimeError("Hermes execution ended while delivering an interaction response")
            current = self._interactions.get(response.interaction_id)
            if current != (kind, vendor_request_id):
                raise RuntimeError("Hermes interaction state changed while delivering its response")
            self._interactions.pop(response.interaction_id)
            self._emit(
                EventType.INTERACTION_RESOLVED,
                {"interactionId": response.interaction_id, "kind": kind},
            )

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        if self._terminal:
            raise RuntimeError("Hermes execution is already terminal")
        text = _plain_text(input, field_name="steer input")
        if not text:
            raise ValueError("Hermes steer requires text content")
        result = await self._peer.request(
            "session.steer",
            {"session_id": self._live_session_id, "text": text},
        )
        if isinstance(result, dict) and result.get("status") == "rejected":
            raise RuntimeError("Hermes rejected steer input")

    async def cancel(self, reason: CancelReason) -> None:
        interrupt_error: BaseException | None = None
        async with self._cancel_lock:
            if self._terminal:
                return
            try:
                await self._peer.request(
                    "session.interrupt",
                    {"session_id": self._live_session_id, "reason": reason.message},
                )
            except BaseException as exc:
                interrupt_error = exc
            if not self._terminal:
                self._terminate_active_tools("cancelled")
                self._terminate_active_children(EventType.AGENT_CANCELLED, "cancelled")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {
                        "vendor": "hermes",
                        "reason": "cancelled",
                        "interruptDelivered": interrupt_error is None,
                    },
                )
                self._finish()
            if not self._task.done() and self._task is not asyncio.current_task():
                self._task.cancel()
        if interrupt_error is not None:
            raise interrupt_error

    async def close(self) -> None:
        error: BaseException | None = None
        if not self._terminal:
            try:
                await self.cancel(CancelReason(message="execution channel closed"))
            except BaseException as exc:
                error = exc
        if not self._task.done():
            self._task.cancel()
        try:
            await self._task
        except asyncio.CancelledError:
            pass
        except BaseException as exc:
            if error is None:
                error = exc
            else:
                error.add_note(f"Hermes submit task cleanup also failed: {exc!r}")
        if error is not None:
            raise error

    def fail_disconnected(self) -> None:
        if self._terminal:
            return
        self._terminate_active_tools("gateway_disconnected")
        self._terminate_active_children(EventType.AGENT_FAILED, "gateway_disconnected")
        self._emit(
            EventType.EXECUTION_FAILED,
            {"vendor": "hermes", "reason": "gateway_disconnected"},
        )
        self._finish()
        if not self._task.done():
            self._task.cancel()

    def fail_protocol(self, message: str) -> None:
        if self._terminal:
            return
        self._terminate_active_tools("invalid_gateway_event")
        self._terminate_active_children(EventType.AGENT_FAILED, "invalid_gateway_event")
        self._emit(
            EventType.EXECUTION_FAILED,
            {"vendor": "hermes", "reason": "invalid_gateway_event", "message": message},
        )
        self._finish()
        if not self._task.done():
            self._task.cancel()


class HermesGatewayRuntimeAdapter:
    """AgentRuntimePort backed by Hermes' full-featured TUI Gateway protocol."""

    def __init__(
        self,
        peer: HermesPeer,
        *,
        asset_store: AssetStorePort | None = None,
        runtime_version: str = "remote",
        process: asyncio.subprocess.Process | None = None,
        max_concurrency: int = 8,
        max_input_asset_bytes: int = DEFAULT_MAX_HERMES_INPUT_ASSET_BYTES,
        native_environment_bound: bool = False,
    ) -> None:
        if isinstance(max_concurrency, bool) or not isinstance(max_concurrency, int) or max_concurrency < 1:
            raise ValueError("max_concurrency must be a positive integer")
        if (
            isinstance(max_input_asset_bytes, bool)
            or not isinstance(max_input_asset_bytes, int)
            or max_input_asset_bytes < 1
            or max_input_asset_bytes > MAX_RUNTIME_ASSET_BYTES
        ):
            raise ValueError(f"max_input_asset_bytes must be between one and {MAX_RUNTIME_ASSET_BYTES}")
        if (
            not isinstance(runtime_version, str)
            or not runtime_version.strip()
            or runtime_version != runtime_version.strip()
            or "\x00" in runtime_version
        ):
            raise ValueError("runtime_version must be a non-blank, trimmed string")
        self._peer = peer
        self._native_environment_bound = native_environment_bound
        self._asset_store = asset_store
        self._runtime_version = runtime_version
        self._max_input_asset_bytes = max_input_asset_bytes
        self._max_concurrency = max_concurrency
        self._execution_slots = asyncio.Semaphore(max_concurrency)
        self._process = process
        self._instance_id = new_id("runtime")
        self._sessions: dict[str, _HermesSessionState] = {}
        self._closed_sessions: dict[str, RuntimeSessionRef] = {}
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._resume_ids: dict[str, tuple[str, str]] = {}
        self._pending_session_closes: set[str] = set()
        # The native process coordinator requires real history for resume.
        # Legacy directly managed peers retain first-use resume compatibility.
        self._strict_resume = False
        self._channels: dict[str, _HermesExecutionChannel] = {}
        self._ready = asyncio.Event()
        self._startup_error: str | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._closing = False
        self._closed = False
        self._close_lock = asyncio.Lock()
        wait_closed = getattr(peer, "wait_closed", None)
        self._peer_wait_closed: Callable[[], Awaitable[None]] | None = wait_closed if callable(wait_closed) else None
        self._peer_watch_task: asyncio.Task[None] | None = None
        self._peer.on_notification("event", self._on_gateway_event)

    @classmethod
    async def spawn_stdio(
        cls,
        *,
        python: str | None = None,
        hermes_root: str | Path | None = None,
        cwd: str | Path | None = None,
        env: dict[str, str] | None = None,
        asset_store: AssetStorePort | None = None,
        startup_timeout_seconds: float = 30.0,
        max_concurrency: int = 8,
        max_input_asset_bytes: int = DEFAULT_MAX_HERMES_INPUT_ASSET_BYTES,
        profile_binding: str = "auto",
        native_toolsets: tuple[str, ...] | None = None,
        _raw_stdio: bool = False,
        _native_manifest: str | None = None,
    ) -> HermesGatewayRuntimeAdapter | HermesNativeRuntimeAdapter:
        if (
            isinstance(startup_timeout_seconds, bool)
            or not isinstance(startup_timeout_seconds, (int, float))
            or not math.isfinite(startup_timeout_seconds)
            or startup_timeout_seconds <= 0
        ):
            raise ValueError("startup_timeout_seconds must be a finite positive number")
        if isinstance(max_concurrency, bool) or not isinstance(max_concurrency, int) or max_concurrency < 1:
            raise ValueError("max_concurrency must be a positive integer")
        if (
            isinstance(max_input_asset_bytes, bool)
            or not isinstance(max_input_asset_bytes, int)
            or max_input_asset_bytes < 1
            or max_input_asset_bytes > MAX_RUNTIME_ASSET_BYTES
        ):
            raise ValueError(f"max_input_asset_bytes must be between one and {MAX_RUNTIME_ASSET_BYTES}")
        executable = _optional_path_string(python, "python") or sys.executable
        root = _optional_path_string(hermes_root, "hermes_root")
        if root is None and python is None:
            conventional_root = Path.home() / ".hermes" / "hermes-agent"
            if (conventional_root / "tui_gateway" / "entry.py").is_file():
                root = str(conventional_root)
        if root is not None and python is None:
            vendor_python = Path(root) / "venv" / "bin" / "python"
            if vendor_python.is_file():
                executable = str(vendor_python)
        launch_cwd = _optional_path_string(cwd, "cwd")
        launch_overrides = _launch_environment(env)
        if profile_binding not in {"auto", "runtime-owned"}:
            raise ValueError("Hermes supports only auto/runtime-owned profileBinding; portable tools are unsupported")
        if not _raw_stdio:
            from areal_agent_runtime.adapters.hermes.native import HermesNativeRuntimeAdapter

            return await HermesNativeRuntimeAdapter.create(
                python=executable,
                hermes_root=root,
                cwd=launch_cwd,
                env=launch_overrides,
                asset_store=asset_store,
                startup_timeout_seconds=startup_timeout_seconds,
                max_concurrency=max_concurrency,
                max_input_asset_bytes=max_input_asset_bytes,
                native_toolsets=native_toolsets,
            )
        launch_env = os.environ.copy()
        launch_env.update(launch_overrides)
        if root is not None:
            current = launch_env.get("PYTHONPATH")
            launch_env["PYTHONPATH"] = root if not current else f"{root}{os.pathsep}{current}"
            launch_env["HERMES_PYTHON_SRC_ROOT"] = root
        command = (
            [executable, str(Path(__file__).with_name("native_entry.py")), _native_manifest]
            if _native_manifest is not None
            else [executable, "-m", "tui_gateway.entry"]
        )
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=launch_cwd,
            env=launch_env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        if process.stdout is None or process.stdin is None:
            process.terminate()
            await process.wait()
            raise RuntimeError("Hermes gateway did not expose stdio pipes")
        peer = JsonRpcPeer(process.stdout, process.stdin)
        adapter = cls(
            peer,
            asset_store=asset_store,
            runtime_version=_detect_hermes_version(root),
            process=process,
            max_concurrency=max_concurrency,
            max_input_asset_bytes=max_input_asset_bytes,
            native_environment_bound=_native_manifest is not None,
        )
        try:
            await peer.start()
            if process.stderr is not None:
                adapter._stderr_task = asyncio.create_task(
                    _drain_stderr(process.stderr),
                    name="hermes-gateway-stderr",
                )
            async with asyncio.timeout(startup_timeout_seconds):
                ready = asyncio.create_task(adapter._ready.wait())
                exited = asyncio.create_task(process.wait())
                try:
                    await asyncio.wait((ready, exited), return_when=asyncio.FIRST_COMPLETED)
                    if adapter._startup_error is not None:
                        raise RuntimeError(adapter._startup_error)
                    if not adapter._ready.is_set():
                        raise RuntimeError("Hermes gateway exited before native initialization completed")
                finally:
                    ready.cancel()
                    exited.cancel()
                    await asyncio.gather(ready, exited, return_exceptions=True)
        except BaseException as exc:
            try:
                await adapter.close()
            except BaseException as cleanup_exc:
                exc.add_note(f"Hermes startup cleanup also failed: {cleanup_exc!r}")
            raise
        return adapter

    async def describe(self) -> RuntimeDescriptor:
        return RuntimeDescriptor(
            name="hermes-agent",
            adapter_version="1.1.0",
            runtime_version=self._runtime_version,
            capabilities=RuntimeCapabilities(
                input_modalities=(
                    (Modality.TEXT, Modality.IMAGE) if self._asset_store is not None else (Modality.TEXT,)
                ),
                output_modalities=(Modality.TEXT,),
                tool_calling=True,
                application_tool_bridge=False,
                cancel=True,
                steer=True,
                resume=True,
                interaction=True,
                live_interaction=True,
                native_multi_agent=True,
                # The current parent-session Gateway projects child lifecycle,
                # reasoning, tools and completion summaries, but intentionally
                # keeps token-level subagent text on the child watch session.
                child_event_projection=ChildEventProjection.AGGREGATE,
                native_graph_execution=False,
                data_coverage=DataCoverage(
                    messages=MessageCoverage.FINAL,
                    model_calls=DetailCoverage.NONE,
                    tool_calls=DetailCoverage.FULL,
                    usage=UsageCoverage.NORMALIZED,
                    child_agents=DetailCoverage.AGGREGATE,
                    raw_events=RawEventCoverage.FULL,
                ),
                extensions={
                    "org.hermes-agent/capabilities/v1": {
                        "binding": "tui-gateway-jsonrpc",
                        "runtimeOwnedPlugins": True,
                        "approvalKinds": ["clarify", "approval", "sudo", "secret"],
                        "maxConcurrency": self._max_concurrency,
                        "maxInputAssetBytes": self._max_input_asset_bytes,
                    },
                },
            ),
        )

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("Hermes runtime is closing")
        if not self._native_environment_bound and (
            spec.agent_environment.system_prompts
            or spec.agent_environment.skills
            or spec.agent_environment.tool_catalog
            or spec.agent_environment.tool_sources
            or spec.agent_environment.mcp_sources
        ):
            raise ValueError(
                "Direct Hermes peers require a trusted native_environment_bound=True declaration; "
                "use spawn_stdio for automatic native environment mapping"
            )
        self._ensure_peer_watch()
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Hermes runtime is closing")
            return await self._open_session_locked(spec)

    async def _open_session_locked(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._pending_session_closes:
            raise RuntimeError("Hermes failed session cleanup requires close() retry")
        existing = self._sessions.get(spec.session_id)
        if existing is not None:
            if existing.closed:
                raise RuntimeError(f"Hermes session is closing: {spec.session_id}")
            require_same_runtime_session_spec(existing.spec, spec)
            return existing.ref
        spec_digest = runtime_session_binding_digest(spec)
        durable_record = self._resume_ids.get(spec.session_id)
        durable_id: str | None = None
        if durable_record is not None:
            durable_id, previous_digest = durable_record
            if spec.resume and previous_digest != spec_digest:
                raise ValueError(
                    "Hermes durable session does not match the requested immutable "
                    f"RuntimeSessionSpec: {spec.session_id}"
                )
        metadata_resume = spec.metadata.get("hermesStoredSessionId")
        if metadata_resume is not None:
            durable_id = _hermes_identity(metadata_resume, "hermesStoredSessionId")
        durable_title = _durable_session_title(spec_digest)
        result: Any | None = None
        created = False
        if spec.resume:
            targets = tuple(dict.fromkeys((durable_id, durable_title)))
            for target in (item for item in targets if item):
                try:
                    result = await self._peer.request(
                        "session.resume",
                        {
                            "session_id": target,
                            "source": "areal_agent_runtime",
                            "omit_messages": True,
                        },
                    )
                    break
                except JsonRpcProtocolError as exc:
                    # Hermes resolves resume targets by stored id and then by
                    # title.  A caller-supplied first-use session id is allowed
                    # to create, but transport/auth/DB failures must not be
                    # mistaken for "not found".
                    if exc.code != 4007:
                        raise
        if result is None:
            if spec.resume and self._strict_resume:
                raise LookupError("Hermes native resume found no history matching the immutable RuntimeSessionSpec")
            created = True
            params: dict[str, Any] = {
                "source": "areal_agent_runtime",
                "cwd": spec.workspace.mount_hint or "",
                "close_on_disconnect": False,
                "hidden": True,
                "title": durable_title,
            }
            if spec.model:
                params["model"] = spec.model
            if spec.provider:
                params["provider"] = spec.provider
            result = await self._peer.request("session.create", params)
        live_id: str | None = None
        active_live_id_conflict = False
        try:
            if not isinstance(result, dict):
                raise RuntimeError("Hermes returned an invalid session response")
            live_id = _hermes_identity(result.get("session_id"), "session response session_id")
            if any(state.live_session_id == live_id for state in self._sessions.values()):
                # Never close this id during error cleanup: it belongs to an
                # already-open canonical session and the peer violated isolation.
                active_live_id_conflict = True
                live_id = None
                raise RuntimeError("Hermes reused an active live session id")
        except BaseException as exc:
            candidate = result.get("session_id") if isinstance(result, dict) else None
            if not active_live_id_conflict and (
                live_id is not None or (isinstance(candidate, str) and candidate.strip())
            ):
                cleanup_id = live_id or str(candidate).strip()
                try:
                    await self._peer.request("session.close", {"session_id": cleanup_id})
                except BaseException as cleanup_exc:
                    exc.add_note(f"Hermes invalid-session cleanup also failed: {cleanup_exc!r}")
            raise
        assert live_id is not None
        if created:
            # Hermes keeps a fresh session in memory until its first prompt.
            # Setting the deterministic title now ensures that title is written
            # with the transcript once Hermes materializes the durable row.
            # There is intentionally nothing to resume if the Gateway crashes
            # before the first prompt has persisted any conversation.
            try:
                await self._peer.request(
                    "session.title",
                    {"session_id": live_id, "title": durable_title},
                )
            except BaseException as exc:
                try:
                    await self._peer.request("session.close", {"session_id": live_id})
                except BaseException as cleanup_exc:
                    exc.add_note(f"Hermes session cleanup after title failure also failed: {cleanup_exc!r}")
                raise
        try:
            stored_id = _first_hermes_identity(
                (
                    result.get("stored_session_id"),
                    result.get("session_key"),
                    result.get("resumed"),
                    durable_id,
                    live_id,
                ),
                "session response stored session id",
            )
            if any(state.stored_session_id == stored_id for state in self._sessions.values()):
                raise RuntimeError("Hermes reused an active stored session id")
        except BaseException as exc:
            try:
                await self._peer.request("session.close", {"session_id": live_id})
            except BaseException as cleanup_exc:
                exc.add_note(f"Hermes invalid-session cleanup also failed: {cleanup_exc!r}")
            raise
        if not created:
            try:
                await self._bind_resumed_workspace(spec, live_id, result)
            except BaseException as exc:
                try:
                    await self._peer.request("session.close", {"session_id": live_id})
                except BaseException as cleanup_exc:
                    # No SessionRef may escape before workspace binding. Keep
                    # the failed live session owned so close() can retry it.
                    self._pending_session_closes.add(live_id)
                    exc.add_note(f"Hermes workspace binding cleanup also failed: {cleanup_exc!r}")
                raise
        self._resume_ids[spec.session_id] = (stored_id, spec_digest)
        ref = RuntimeSessionRef(
            session_id=spec.session_id,
            runtime_session_id=new_id("hermes_session"),
        )
        self._sessions[spec.session_id] = _HermesSessionState(
            spec=spec,
            ref=ref,
            live_session_id=live_id,
            stored_session_id=stored_id,
        )
        self._closed_sessions.pop(spec.session_id, None)
        return ref

    async def _bind_resumed_workspace(
        self, spec: RuntimeSessionSpec, live_id: str, result: dict[str, Any]
    ) -> None:
        requested = spec.workspace.mount_hint
        if requested is None:
            return
        info = result.get("info")
        has_cwd = isinstance(info, dict) and "cwd" in info
        # Legacy self-managed peers do not all expose session info or the cwd
        # RPC. Preserve that trusted integration contract. Native processes
        # must prove the current workspace even when resume omits its info.
        if not has_cwd and not self._strict_resume:
            return
        if isinstance(info, dict) and info.get("cwd") == requested:
            return
        bound = await self._peer.request("session.cwd.set", {"session_id": live_id, "cwd": requested})
        _validate_workspace_binding(bound, requested)

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Hermes runtime is closing")
        outer = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with outer:
            try:
                session = self._sessions[request.session_id]
            except KeyError as exc:
                raise LookupError(f"Hermes session is not open: {request.session_id}") from exc
            async with session.lock:
                if self._closing or session.closed or self._sessions.get(request.session_id) is not session:
                    raise LookupError(f"Hermes session is not open: {request.session_id}")
                require_session_environment(session.spec, request)
                if session.live_session_id in self._channels:
                    raise RuntimeError(f"Hermes session already has an active execution: {request.session_id}")
                prompt_text, images = await _request_to_hermes(
                    request,
                    self._asset_store,
                    max_input_asset_bytes=self._max_input_asset_bytes,
                )
                channel = _HermesExecutionChannel(
                    runtime_instance_id=self._instance_id,
                    request=request,
                    peer=self._peer,
                    live_session_id=session.live_session_id,
                    prompt_text=prompt_text,
                    images=images,
                    execution_slots=self._execution_slots,
                    on_finish=self._forget_channel,
                )
                self._channels[session.live_session_id] = channel
                return channel

    def _forget_channel(self, key: str) -> None:
        self._channels.pop(key, None)

    async def close_session(self, session: RuntimeSessionRef) -> None:
        outer = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with outer:
            state = self._sessions.get(session.session_id)
            if state is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("Hermes session reference is not owned by this adapter")
            if state.ref != session:
                raise ValueError("Hermes session reference does not match the open session")
            async with state.lock:
                state.closed = True
                errors: list[BaseException] = []
                channel = self._channels.get(state.live_session_id)
                if channel is not None:
                    try:
                        await channel.close()
                    except BaseException as exc:
                        errors.append(exc)
                try:
                    await self._peer.request("session.close", {"session_id": state.live_session_id})
                except BaseException as exc:
                    errors.append(exc)
                if not errors and self._sessions.get(session.session_id) is state:
                    self._sessions.pop(session.session_id, None)
                    self._closed_sessions[session.session_id] = session
                if errors:
                    raise BaseExceptionGroup("Hermes session cleanup failed", errors)

    async def health(self) -> HealthStatus:
        if self._closing:
            return HealthStatus(status="unhealthy", details={"reason": "runtime_closing"})
        self._ensure_peer_watch()
        try:
            await self._peer.request("session.active_list", {}, timeout_seconds=5.0)
        except Exception as exc:
            return HealthStatus(
                status="unhealthy",
                details={"reason": "gateway_unreachable", "message": str(exc) or type(exc).__name__},
            )
        return HealthStatus(status="healthy")

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closing = True
            errors: list[BaseException] = []
            for live_id in tuple(self._pending_session_closes):
                try:
                    await self._peer.request("session.close", {"session_id": live_id})
                    self._pending_session_closes.remove(live_id)
                except BaseException as exc:
                    errors.append(exc)
            for state in tuple(self._sessions.values()):
                try:
                    await self.close_session(state.ref)
                except BaseException as exc:
                    errors.append(exc)
            # Keep the transport alive when explicit session cleanup failed so
            # close() can be retried without leaking durable Hermes sessions.
            if errors:
                raise BaseExceptionGroup("Hermes runtime session cleanup failed", errors)
            close = getattr(self._peer, "close", None)
            if close is not None:
                try:
                    await close()
                except BaseException as exc:
                    errors.append(exc)
            if self._process is not None and self._process.returncode is None:
                try:
                    self._process.terminate()
                    try:
                        async with asyncio.timeout(2.0):
                            await self._process.wait()
                    except TimeoutError:
                        self._process.kill()
                        await self._process.wait()
                except BaseException as exc:
                    errors.append(exc)
            if self._stderr_task is not None:
                self._stderr_task.cancel()
                try:
                    await self._stderr_task
                except asyncio.CancelledError:
                    pass
                except BaseException as exc:
                    errors.append(exc)
                self._stderr_task = None
            if self._peer_watch_task is not None:
                self._peer_watch_task.cancel()
                try:
                    await self._peer_watch_task
                except asyncio.CancelledError:
                    pass
                except BaseException as exc:
                    errors.append(exc)
                self._peer_watch_task = None
            if errors:
                raise BaseExceptionGroup("Hermes runtime cleanup failed", errors)
            self._closed = True
            self._closed_sessions.clear()
            self._resume_ids.clear()

    async def _on_gateway_event(self, params: object) -> None:
        if not isinstance(params, dict):
            self._fail_all_protocol("Hermes event notification must be an object")
            return
        try:
            event_type = _hermes_identity(params.get("type"), "event.type")
        except ValueError as exc:
            self._fail_all_protocol(str(exc))
            return
        if event_type == "gateway.ready":
            self._ready.set()
            return
        if event_type == "gateway.error" and not self._ready.is_set():
            self._startup_error = "Hermes native bootstrap rejected the installed API or nativeToolsets configuration"
            self._ready.set()
            return
        session_id = params.get("session_id")
        if event_type.startswith("gateway.") and session_id is None:
            return
        try:
            session_id = _hermes_identity(session_id, "event.session_id")
        except ValueError as exc:
            self._fail_all_protocol(str(exc))
            return
        channel = self._channels.get(session_id)
        if channel is not None:
            try:
                channel.handle_gateway_event(params)
            except Exception as exc:
                channel.fail_protocol(str(exc) or type(exc).__name__)

    def _fail_all_protocol(self, message: str) -> None:
        for channel in tuple(self._channels.values()):
            channel.fail_protocol(message)

    async def _watch_peer(self, wait_closed: Callable[[], Awaitable[None]]) -> None:
        try:
            await wait_closed()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        if self._closing:
            return
        for channel in tuple(self._channels.values()):
            channel.fail_disconnected()

    def _ensure_peer_watch(self) -> None:
        if self._peer_watch_task is None and self._peer_wait_closed is not None:
            self._peer_watch_task = asyncio.create_task(
                self._watch_peer(self._peer_wait_closed),
                name="hermes-gateway-peer-watch",
            )


def _durable_session_title(session_binding_digest: str) -> str:
    """Return a non-sensitive, deterministic Hermes resume lookup key."""

    return f"areal_agent_runtime-{session_binding_digest}"


async def _request_to_hermes(
    request: ExecutionRequest,
    asset_store: AssetStorePort | None,
    *,
    max_input_asset_bytes: int,
) -> tuple[str, list[tuple[str, str]]]:
    parts: list[str] = []
    images: list[tuple[str, str]] = []
    total_asset_bytes = 0
    for index, block in enumerate(request.input):
        if isinstance(block, (TextBlock, ReasoningBlock)):
            parts.append(block.text)
        elif isinstance(block, JsonBlock):
            parts.append(_canonical_json(block.value, field_name="JSON input"))
        elif isinstance(block, ImageRefBlock):
            if asset_store is None:
                raise ValueError("Hermes image input requires an AssetStorePort")
            extensions = {
                "image/png": "png",
                "image/jpeg": "jpg",
                "image/webp": "webp",
                "image/gif": "gif",
            }
            try:
                extension = extensions[block.media_type]
            except KeyError as exc:
                raise ValueError(f"Hermes does not support image media type {block.media_type}") from exc
            remaining = max_input_asset_bytes - total_asset_bytes
            if remaining < 1:
                raise ValueError(f"Assets exceed the configured {max_input_asset_bytes}-byte Runtime input limit")
            payload = await read_asset_bytes(
                asset_store,
                block.asset_id,
                expected_media_type=block.media_type,
                max_bytes=remaining,
                aggregate_max_bytes=max_input_asset_bytes,
            )
            total_asset_bytes += len(payload)
            images.append((base64.b64encode(payload).decode("ascii"), f"input-{index}.{extension}"))
        elif isinstance(block, (AudioRefBlock, VideoRefBlock, FileRefBlock)):
            raise ValueError(f"Hermes adapter does not advertise support for {block.type}")
    text = "\n\n".join(part for part in parts if part)
    if images and not text:
        text = "Please inspect the attached image."
    return text, images


def _plain_text(blocks: tuple[ContentBlock, ...], *, field_name: str) -> str:
    parts: list[str] = []
    for block in blocks:
        if isinstance(block, (TextBlock, ReasoningBlock)):
            parts.append(block.text)
        elif isinstance(block, JsonBlock):
            parts.append(_canonical_json(block.value, field_name=field_name))
        else:
            raise ValueError(f"Hermes {field_name} only supports text, reasoning, and JSON blocks")
    return "\n".join(part for part in parts if part)


async def _drain_stderr(stream: asyncio.StreamReader) -> None:
    while await stream.read(64 * 1024):
        pass


def _hermes_identity(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"Hermes {field_name} must be a non-blank, trimmed string")
    return value


def _hermes_text(value: object, field_name: str) -> str:
    if not isinstance(value, str) or "\x00" in value:
        raise ValueError(f"Hermes {field_name} must be text without NUL bytes")
    return value


def _hermes_optional_text_field(
    data: dict[str, Any],
    keys: tuple[str, ...],
    field_name: str,
) -> str | None:
    for key in keys:
        if key in data and data[key] is not None:
            return _hermes_text(data[key], field_name)
    return None


def _hermes_error_message(value: object) -> str:
    if isinstance(value, str):
        return _hermes_identity(value, "error message")
    if isinstance(value, dict):
        for field_name in ("message", "error", "reason"):
            candidate = value.get(field_name)
            if candidate is not None:
                return _hermes_identity(candidate, f"error {field_name}")
    return _canonical_json(value, field_name="error")


def _hermes_response_text(
    response: object,
    *,
    field_name: str,
    require_non_blank: bool,
) -> str:
    value = response.get(field_name) if isinstance(response, dict) else response
    value = _hermes_text(value, f"interaction response {field_name}")
    if require_non_blank and not value.strip():
        raise ValueError(f"Hermes interaction response {field_name} must be non-blank")
    return value


def _first_hermes_identity(values: tuple[object, ...], field_name: str) -> str:
    for value in values:
        if value is not None:
            return _hermes_identity(value, field_name)
    raise ValueError(f"Hermes {field_name} is missing")


def _canonical_json(value: object, *, field_name: str) -> str:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Hermes {field_name} must contain finite JSON data") from exc


def _optional_path_string(value: object, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, (str, bytes, os.PathLike)):
        raise ValueError(f"{field_name} must be a path string")
    try:
        parsed = os.fspath(value)
    except TypeError as exc:
        raise ValueError(f"{field_name} must be a path string") from exc
    if not isinstance(parsed, str) or not parsed or parsed != parsed.strip() or "\x00" in parsed:
        raise ValueError(f"{field_name} must be a non-blank, trimmed path string")
    return parsed


def _validate_workspace_binding(bound: Any, requested: str) -> None:
    if not isinstance(bound, dict):
        raise RuntimeError("Hermes returned an invalid workspace binding response")
    cwd = _hermes_identity(bound.get("cwd"), "workspace binding cwd")
    # Pure lexical normalization performs no filesystem access. Absolute mount
    # hints are deployment-owned locators; relative hints resolve at the Gateway.
    if os.path.isabs(requested) and os.path.normpath(cwd) != os.path.normpath(requested):
        raise RuntimeError("Hermes resumed workspace differs from the requested mountHint")


def _launch_environment(value: object) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict) or len(value) > 256:
        raise ValueError("env must be an object with at most 256 entries")
    result: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) is None:
            raise ValueError("env keys must be portable environment variable names")
        if not isinstance(item, str) or "\x00" in item:
            raise ValueError("env values must be strings without NUL bytes")
        result[key] = item
    return result


def _detect_hermes_version(hermes_root: str | Path | None) -> str:
    if hermes_root is not None:
        init = Path(hermes_root).expanduser() / "hermes_cli" / "__init__.py"
        try:
            source = init.read_text(encoding="utf-8")
        except OSError:
            pass
        else:
            match = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', source, re.MULTILINE)
            if match:
                return match.group(1)
    try:
        return version("hermes-agent")
    except PackageNotFoundError:
        return "source-unversioned" if hermes_root is not None else "remote"
