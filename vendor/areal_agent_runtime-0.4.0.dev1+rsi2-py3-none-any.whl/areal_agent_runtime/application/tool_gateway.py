"""Application-owned tool catalog, routing and failure normalization."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError

from areal_agent_runtime.application.evidence_loop import EvidenceLoopGuard
from areal_agent_runtime.contracts.environment import McpProviderBinding
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import ToolProviderPort
from areal_agent_runtime.contracts.runtime import HealthStatus, ToolCall, ToolResult, ToolSpec

_MAX_TOOL_SCHEMA_BYTES = 1024 * 1024
_MAX_TOOL_SCHEMA_DEPTH = 64


@dataclass(frozen=True, slots=True)
class RegisteredTool:
    provider_name: str
    provider_version: str
    provider: ToolProviderPort
    spec: ToolSpec


class ToolGateway:
    """Merge ToolProvider plugins into one deterministic Application catalog."""

    def __init__(
        self,
        providers: dict[str, ToolProviderPort] | None = None,
        *,
        provider_versions: dict[str, str] | None = None,
        allowed_permissions: tuple[str, ...] | None = None,
    ) -> None:
        self._providers = dict(providers or {})
        self._provider_versions = dict(provider_versions or {})
        if any(
            not isinstance(name, str) or not name or name != name.strip()
            for name in self._providers
        ):
            raise ValueError("ToolProvider names must be non-empty, trimmed strings")
        if any(not isinstance(provider, ToolProviderPort) for provider in self._providers.values()):
            raise TypeError("ToolProvider values must implement ToolProviderPort")
        if any(
            provider not in self._providers
            or not isinstance(version, str)
            or not version
            or version != version.strip()
            for provider, version in self._provider_versions.items()
        ):
            raise ValueError("ToolProvider versions must identify installed providers with trimmed versions")
        if allowed_permissions is not None and (
            not isinstance(allowed_permissions, tuple)
            or any(
                not isinstance(permission, str)
                or not permission
                or permission != permission.strip()
                for permission in allowed_permissions
            )
            or len(allowed_permissions) != len(set(allowed_permissions))
        ):
            raise ValueError("allowed Tool permissions must be unique, trimmed strings")
        self._allowed_permissions = frozenset(allowed_permissions) if allowed_permissions is not None else None
        self._catalog: dict[str, RegisteredTool] | None = None
        self._catalog_lock = asyncio.Lock()
        self._evidence = EvidenceLoopGuard()

    async def initialize(self) -> None:
        """Run provider health/discovery/schema/permission gates before registration."""

        await self._load_catalog()

    async def catalog(self, names: tuple[str, ...] = ()) -> tuple[ToolSpec, ...]:
        tools = await self._load_catalog()
        if not names:
            return ()
        missing = [name for name in names if name not in tools]
        if missing:
            raise LookupError(f"ToolProvider is missing required tools: {', '.join(sorted(missing))}")
        return tuple(tools[name].spec for name in names)

    async def catalog_names(self) -> tuple[str, ...]:
        """Return the immutable Session Tool Catalog identity set."""

        return tuple(sorted(await self._load_catalog()))

    async def registered(self, name: str) -> RegisteredTool | None:
        return (await self._load_catalog()).get(name)

    def provider_version(self, provider_name: str) -> str:
        if provider_name not in self._providers:
            raise LookupError(f"ToolProvider is not installed: {provider_name}")
        return self._provider_versions.get(provider_name, "unknown")

    def mcp_binding(self, provider_name: str) -> McpProviderBinding:
        try:
            provider = self._providers[provider_name]
        except KeyError as exc:
            raise LookupError(f"MCP ToolProvider is not installed: {provider_name}") from exc
        describe = getattr(provider, "mcp_binding", None)
        if not callable(describe):
            raise TypeError(f"ToolProvider is not an MCP source-bound provider: {provider_name}")
        binding = describe()
        if not isinstance(binding, McpProviderBinding):
            raise TypeError(f"ToolProvider returned an invalid MCP binding: {provider_name}")
        return binding

    async def select(
        self,
        selections: tuple[tuple[str, tuple[str, ...], tuple[str, ...]], ...],
    ) -> tuple[RegisteredTool, ...]:
        """Return only explicitly exposed tools after provider and permission checks."""

        catalog = await self._load_catalog()
        selected: dict[str, RegisteredTool] = {}
        for provider_name, names, allowed_permissions in selections:
            source_permissions = frozenset(allowed_permissions)
            for name in names:
                registered = catalog.get(name)
                if registered is None:
                    raise LookupError(f"ToolProvider is missing required tool: {name}")
                if registered.provider_name != provider_name:
                    raise PermissionError(
                        f"tool {name} belongs to provider {registered.provider_name}, not {provider_name}"
                    )
                denied = set(registered.spec.permissions).difference(source_permissions)
                if denied:
                    raise PermissionError(
                        f"tool source does not allow permissions for {name}: {', '.join(sorted(denied))}"
                    )
                selected[name] = registered
        return tuple(selected[name] for name in sorted(selected))

    async def invoke(
        self,
        call: ToolCall,
        *,
        max_stalled_actions: int | None = None,
    ) -> ToolResult:
        registered = await self.registered(call.name)
        if registered is None:
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="TOOL_NOT_FOUND",
                    category=ErrorCategory.NOT_FOUND,
                    message=f"No ToolProvider registered {call.name}",
                ),
            )
        try:
            Draft202012Validator(registered.spec.input_schema).validate(call.arguments)
        except ValidationError as exc:
            location = ".".join(str(item) for item in exc.absolute_path) or "<root>"
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="TOOL_ARGUMENTS_INVALID",
                    category=ErrorCategory.INVALID_REQUEST,
                    message=f"Tool arguments are invalid at {location}: {exc.message}",
                    details={"provider": registered.provider_name, "tool": call.name},
                ),
            )
        try:
            result = await self._evidence.invoke(
                call,
                registered.spec,
                lambda: registered.provider.invoke(call),
                max_stalled_actions=max_stalled_actions,
            )
        except Exception as exc:
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="TOOL_PROVIDER_FAILED",
                    category=ErrorCategory.INTERNAL,
                    message=str(exc) or type(exc).__name__,
                    details={"provider": registered.provider_name, "tool": call.name},
                ),
            )
        if not isinstance(result, ToolResult):
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="TOOL_RESULT_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=f"ToolProvider returned a non-ToolResult value for {call.name}",
                    details={"provider": registered.provider_name, "tool": call.name},
                ),
            )
        if result.call_id != call.call_id:
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="TOOL_RESULT_CORRELATION_MISMATCH",
                    category=ErrorCategory.PROTOCOL,
                    message=f"ToolProvider returned {result.call_id} for call {call.call_id}",
                    details={"provider": registered.provider_name, "tool": call.name},
                ),
            )
        return result

    async def refresh(self) -> None:
        async with self._catalog_lock:
            self._catalog = None

    def release_run(self, run_id: str) -> None:
        self._evidence.release_run(run_id)

    async def _load_catalog(self) -> dict[str, RegisteredTool]:
        if self._catalog is not None:
            return self._catalog
        async with self._catalog_lock:
            if self._catalog is not None:
                return self._catalog
            catalog: dict[str, RegisteredTool] = {}
            for provider_name in sorted(self._providers):
                provider = self._providers[provider_name]
                health = await provider.health()
                if not isinstance(health, HealthStatus):
                    raise TypeError(f"ToolProvider {provider_name} returned an invalid HealthStatus")
                if health.status == "unhealthy":
                    raise RuntimeError(f"ToolProvider {provider_name} is unhealthy: {health.details}")
                specs = await provider.list_tools()
                if not isinstance(specs, tuple) or any(not isinstance(spec, ToolSpec) for spec in specs):
                    raise TypeError(f"ToolProvider {provider_name} must return a tuple of ToolSpec values")
                for spec in specs:
                    self._validate_schema(spec)
                    if self._allowed_permissions is not None:
                        denied = sorted(set(spec.permissions).difference(self._allowed_permissions))
                        if denied:
                            raise PermissionError(
                                f"ToolProvider {provider_name} tool {spec.name} requests denied permissions: "
                                f"{', '.join(denied)}"
                            )
                    previous = catalog.get(spec.name)
                    if previous is not None:
                        raise ValueError(
                            f"Duplicate tool {spec.name}: {previous.provider_name} and {provider_name}"
                        )
                    catalog[spec.name] = RegisteredTool(
                        provider_name=provider_name,
                        provider_version=self._provider_versions.get(provider_name, "unknown"),
                        provider=provider,
                        spec=spec,
                    )
            self._catalog = catalog
            return catalog

    @staticmethod
    def _validate_schema(spec: ToolSpec) -> None:
        schema = spec.input_schema
        try:
            encoded = json.dumps(
                schema,
                ensure_ascii=False,
                allow_nan=False,
                separators=(",", ":"),
            ).encode("utf-8")
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"tool {spec.name} inputSchema must be strict JSON") from exc
        if len(encoded) > _MAX_TOOL_SCHEMA_BYTES:
            raise ValueError(
                f"tool {spec.name} inputSchema exceeds {_MAX_TOOL_SCHEMA_BYTES} bytes"
            )
        ToolGateway._validate_schema_references(schema, spec.name, depth=0)
        try:
            Draft202012Validator.check_schema(schema)
        except SchemaError as exc:
            raise ValueError(f"tool {spec.name} inputSchema is invalid: {exc.message}") from exc
        if schema.get("type") != "object":
            raise ValueError(f"tool {spec.name} inputSchema.type must be object")

    @staticmethod
    def _validate_schema_references(value: object, tool_name: str, *, depth: int) -> None:
        if depth > _MAX_TOOL_SCHEMA_DEPTH:
            raise ValueError(
                f"tool {tool_name} inputSchema exceeds {_MAX_TOOL_SCHEMA_DEPTH} JSON levels"
            )
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"$ref", "$dynamicRef"} and (
                    not isinstance(item, str) or not item.startswith("#")
                ):
                    raise ValueError(
                        f"tool {tool_name} inputSchema must be self-contained; external {key} is not allowed"
                    )
                ToolGateway._validate_schema_references(item, tool_name, depth=depth + 1)
        elif isinstance(value, list):
            for item in value:
                ToolGateway._validate_schema_references(item, tool_name, depth=depth + 1)
