"""Bidirectional Anthropic Messages loop implementing AgentRuntimePort."""

from __future__ import annotations

import asyncio
import base64
import binascii
import contextlib
import copy
import hashlib
import json
import math
import os
import re
import tempfile
import time
import weakref
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from stat import S_ISREG
from types import MappingProxyType
from typing import Any, Protocol
from urllib.parse import urlsplit

from pydantic import TypeAdapter

from areal_agent_runtime.adapters._asset_io import (
    DEFAULT_MAX_RUNTIME_ASSET_BYTES,
    MAX_RUNTIME_ASSET_BYTES,
    read_asset_bytes,
)
from areal_agent_runtime.contracts.content import (
    ContentBlock,
    ImageRefBlock,
    JsonBlock,
    ReasoningBlock,
    TextBlock,
)
from areal_agent_runtime.contracts.data import (
    DataCoverage,
    DetailCoverage,
    MessageCoverage,
    RawEventCoverage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolExecution,
    ToolResult,
    normalize_token_usage,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
    runtime_session_binding_digest,
)
from areal_agent_runtime.kernel.ids import new_id

_END = object()
_OUTPUT_CONTINUATION = "Continue exactly where the previous response stopped. Do not repeat completed work."
_TRUNCATED_TOOL_RETRY = (
    "The previous response ended while constructing a tool call. Retry that tool call as one complete, valid call."
)
_HISTORY_SCHEMA_VERSION = "areal.agent-runtime.anthropic-session/v2"
_LEGACY_HISTORY_SCHEMA_VERSION = "areal_agent_runtime.anthropic-session/v1"
_CONTENT_BLOCKS_ADAPTER = TypeAdapter(tuple[ContentBlock, ...])
_HTTP_HEADER_NAME = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")
_MAX_ANTHROPIC_VENDOR_JSON_BYTES = 64 * 1024 * 1024
_MAX_ANTHROPIC_TURNS = 10_000
_MAX_ANTHROPIC_CONCURRENCY = 1_024
_MAX_ANTHROPIC_TOKENS = 1_000_000
_ANTHROPIC_IMAGE_MEDIA_TYPES = frozenset(
    {"image/jpeg", "image/png", "image/gif", "image/webp"}
)


class AnthropicBackend(Protocol):
    async def create_message(self, request: dict[str, Any]) -> dict[str, Any]: ...

    async def close(self) -> None: ...


def _validate_model_parameters(value: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError("model_parameters must be an object")
    result = dict(value)
    ranges = {
        "temperature": (0, 1),
        "top_p": (0, 1),
        "min_p": (0, 1),
        "presence_penalty": (-2, 2),
    }
    for key, item in result.items():
        if key in ranges:
            lower, upper = ranges[key]
            valid = (
                not isinstance(item, bool) and isinstance(item, (int, float))
                and math.isfinite(item) and lower <= item <= upper
            )
        elif key == "top_k":
            valid = not isinstance(item, bool) and isinstance(item, int) and 0 <= item <= 1_000_000
        elif key == "repetition_penalty":
            valid = (
                not isinstance(item, bool) and isinstance(item, (int, float))
                and math.isfinite(item) and item > 0
            )
        elif key == "reasoning_effort":
            valid = isinstance(item, str) and item in {"low", "medium", "high", "max"}
        else:
            raise ValueError(f"Unsupported model_parameters field: {key}")
        if not valid:
            raise ValueError(f"Invalid model_parameters field: {key}")
    return result


@dataclass(frozen=True, slots=True)
class AnthropicRuntimeConfig:
    model: str = "claude-sonnet-4-5"
    max_tokens: int = 8192
    max_turns: int = 50
    max_retries: int = 2
    retry_backoff_seconds: float = 0.25
    max_no_progress_rounds: int = 3
    max_history_chars: int = 400_000
    max_concurrency: int = 8
    max_input_asset_bytes: int = DEFAULT_MAX_RUNTIME_ASSET_BYTES
    api_key: str | None = None
    base_url: str | None = None
    default_headers: Mapping[str, str] = field(default_factory=dict)
    history_root: str | None = None
    max_final_answer_attempts: int = 1
    model_parameters: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if (
            isinstance(self.max_final_answer_attempts, bool)
            or not isinstance(self.max_final_answer_attempts, int)
            or not 0 <= self.max_final_answer_attempts <= 3
        ):
            raise ValueError("max_final_answer_attempts must be an integer between zero and three")
        parameters = _validate_model_parameters(self.model_parameters)
        object.__setattr__(self, "model_parameters", MappingProxyType(parameters))
        if (
            not isinstance(self.model, str)
            or not self.model
            or self.model != self.model.strip()
            or "\x00" in self.model
        ):
            raise ValueError("model must be a non-blank, trimmed string")
        if (
            isinstance(self.max_tokens, bool)
            or not isinstance(self.max_tokens, int)
            or not 1 <= self.max_tokens <= _MAX_ANTHROPIC_TOKENS
        ):
            raise ValueError(
                f"max_tokens must be between one and {_MAX_ANTHROPIC_TOKENS}"
            )
        if (
            isinstance(self.max_turns, bool)
            or not isinstance(self.max_turns, int)
            or not 1 <= self.max_turns <= _MAX_ANTHROPIC_TURNS
        ):
            raise ValueError(
                f"max_turns must be between one and {_MAX_ANTHROPIC_TURNS}"
            )
        if (
            isinstance(self.max_retries, bool)
            or not isinstance(self.max_retries, int)
            or self.max_retries < 0
            or self.max_retries > 20
        ):
            raise ValueError("max_retries must be between zero and 20")
        if (
            isinstance(self.retry_backoff_seconds, bool)
            or not isinstance(self.retry_backoff_seconds, (int, float))
            or not math.isfinite(self.retry_backoff_seconds)
            or self.retry_backoff_seconds < 0
            or self.retry_backoff_seconds > 3600
        ):
            raise ValueError("retry_backoff_seconds must be between zero and 3600")
        if (
            isinstance(self.max_no_progress_rounds, bool)
            or not isinstance(self.max_no_progress_rounds, int)
            or self.max_no_progress_rounds < 2
            or self.max_no_progress_rounds > _MAX_ANTHROPIC_TURNS
        ):
            raise ValueError(
                "max_no_progress_rounds must be between two and "
                f"{_MAX_ANTHROPIC_TURNS}"
            )
        if (
            isinstance(self.max_history_chars, bool)
            or not isinstance(self.max_history_chars, int)
            or self.max_history_chars < 256
            or self.max_history_chars > _MAX_ANTHROPIC_VENDOR_JSON_BYTES
        ):
            raise ValueError(
                "max_history_chars must be between 256 and "
                f"{_MAX_ANTHROPIC_VENDOR_JSON_BYTES}"
            )
        if (
            isinstance(self.max_concurrency, bool)
            or not isinstance(self.max_concurrency, int)
            or self.max_concurrency < 1
            or self.max_concurrency > _MAX_ANTHROPIC_CONCURRENCY
        ):
            raise ValueError(
                "max_concurrency must be between one and "
                f"{_MAX_ANTHROPIC_CONCURRENCY}"
            )
        if (
            isinstance(self.max_input_asset_bytes, bool)
            or not isinstance(self.max_input_asset_bytes, int)
            or self.max_input_asset_bytes < 1
            or self.max_input_asset_bytes > MAX_RUNTIME_ASSET_BYTES
        ):
            raise ValueError(
                f"max_input_asset_bytes must be between one and {MAX_RUNTIME_ASSET_BYTES}"
            )
        if self.api_key is not None and (
            not isinstance(self.api_key, str)
            or not self.api_key.strip()
            or self.api_key != self.api_key.strip()
            or "\x00" in self.api_key
        ):
            raise ValueError("api_key must be a non-blank, trimmed string")
        if self.base_url is not None:
            if (
                not isinstance(self.base_url, str)
                or not self.base_url
                or self.base_url != self.base_url.strip()
                or "\x00" in self.base_url
            ):
                raise ValueError("base_url must be a non-blank, trimmed HTTP(S) URL")
            parsed = urlsplit(self.base_url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise ValueError("base_url must be an HTTP(S) URL")
        if self.history_root is not None and (
            not isinstance(self.history_root, str)
            or not self.history_root
            or self.history_root != self.history_root.strip()
            or "\x00" in self.history_root
        ):
            raise ValueError("history_root must be a non-blank, trimmed path")
        if not isinstance(self.default_headers, Mapping) or len(self.default_headers) > 128:
            raise ValueError("default_headers must be a mapping with at most 128 entries")
        normalized_headers: dict[str, str] = {}
        for key, value in self.default_headers.items():
            if not isinstance(key, str) or _HTTP_HEADER_NAME.fullmatch(key) is None:
                raise ValueError("default_headers contains an invalid HTTP header name")
            if not isinstance(value, str) or any(
                ord(character) == 127
                or (ord(character) < 32 and character != "\t")
                for character in value
            ):
                raise ValueError("default_headers values must not contain invalid controls")
            normalized_headers[key] = value
        object.__setattr__(self, "default_headers", MappingProxyType(normalized_headers))


class _AnthropicSDKBackend:
    def __init__(self, config: AnthropicRuntimeConfig) -> None:
        try:
            from anthropic import AsyncAnthropic
        except ImportError as exc:  # pragma: no cover - optional dependency guard
            raise RuntimeError("Install areal-agent-runtime[anthropic] to use this adapter") from exc
        kwargs: dict[str, Any] = {"default_headers": dict(config.default_headers)}
        if config.api_key is not None:
            kwargs["api_key"] = config.api_key
        if config.base_url is not None:
            kwargs["base_url"] = config.base_url
        self._client = AsyncAnthropic(**kwargs)

    async def create_message(self, request: dict[str, Any]) -> dict[str, Any]:
        response = await self._client.messages.create(**request)
        if hasattr(response, "model_dump"):
            return response.model_dump(mode="json")
        raise TypeError("Anthropic SDK returned an unsupported response object")

    async def close(self) -> None:
        await self._client.close()


@dataclass(slots=True)
class _InvocationState:
    run_id: str
    agent_id: str
    request_digest: str
    status: str = "active"
    phase: str = "model"
    pending_tool_uses: list[dict[str, Any]] = field(default_factory=list)
    outputs: list[list[dict[str, Any]]] = field(default_factory=list)
    turns: int = 0
    no_progress_rounds: int = 0
    final_answer_attempts: int = 0
    stop_reason: str | None = None
    failure_reason: str | None = None


@dataclass(slots=True)
class _SessionState:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    spec_digest: str
    messages: list[dict[str, Any]] = field(default_factory=list)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    admission_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    active: bool = False
    closed: bool = False
    channel: ExecutionChannel | None = None
    invocation: _InvocationState | None = None
    persist: Callable[
        [list[dict[str, Any]], _InvocationState | None],
        Awaitable[None],
    ] | None = None


@dataclass(slots=True)
class _AnthropicToolCallState:
    future: asyncio.Future[ToolResult]


@dataclass(frozen=True, slots=True)
class _ModelCallResult:
    response: dict[str, Any]
    model_call_id: str
    provider: str
    model: str
    attempt: int
    started_at: float


class _AnthropicExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        *,
        runtime_instance_id: str,
        request: ExecutionRequest,
        state: _SessionState,
        backend: AnthropicBackend,
        config: AnthropicRuntimeConfig,
        user_content: list[dict[str, Any]],
        assets: AssetStorePort | None,
        execution_slots: asyncio.Semaphore,
        on_finish: Callable[[], None] | None = None,
    ) -> None:
        self._runtime_instance_id = runtime_instance_id
        self._request = request
        self._state = state
        self._backend = backend
        self._config = config
        self._user_content = user_content
        self._assets = assets
        self._execution_slots = execution_slots
        self._on_finish = on_finish
        self._queue: asyncio.Queue[RuntimeEvent | object] = asyncio.Queue()
        self._tool_calls: dict[str, _AnthropicToolCallState] = {}
        self._sequence = 0
        self._ended = False
        self._owns_invocation = False
        self._explicit_cancel = False
        self._cancel_lock = asyncio.Lock()
        self._task = asyncio.create_task(self._run(), name=f"anthropic:{request.execution_id}")

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        while True:
            item = await self._queue.get()
            if item is _END:
                return
            if isinstance(item, RuntimeEvent):
                yield item

    def _emit(self, event_type: EventType, data: Any, *, ignorable: bool = False) -> None:
        if self._ended:
            return
        self._queue.put_nowait(
            RuntimeEvent(
                runtime_instance_id=self._runtime_instance_id,
                runtime_sequence=self._sequence,
                execution_id=self._request.execution_id,
                agent_id=self._request.agent.agent_id,
                parent_agent_id=self._request.agent.parent_agent_id,
                type=event_type,
                data=data,
                ignorable=ignorable,
            )
        )
        self._sequence += 1

    async def _run(self) -> None:
        try:
            self._emit(EventType.EXECUTION_STARTED, {"vendor": "anthropic-messages"})
            async with self._execution_slots:
                async with self._state.lock:
                    invocation = await self._prepare_invocation()
                    self._replay_outputs(invocation)
                    if invocation.status == "completed":
                        self._emit(
                            EventType.EXECUTION_COMPLETED,
                            {
                                "stopReason": invocation.stop_reason,
                                "vendor": "anthropic-messages",
                            },
                        )
                        return
                    if invocation.status == "failed":
                        self._emit(
                            EventType.EXECUTION_FAILED,
                            {
                                "reason": invocation.failure_reason or "failed",
                                "vendor": "anthropic-messages",
                            },
                        )
                        return
                    if invocation.phase == "tools":
                        validated = self._validate_tool_uses(invocation.pending_tool_uses)
                        tool_results = await self._request_tools(validated)
                        self._state.messages.append({"role": "user", "content": tool_results})
                        invocation.pending_tool_uses.clear()
                        invocation.phase = "model"
                        await self._persist_history()

                    while invocation.turns < self._config.max_turns:
                        if invocation.no_progress_rounds >= self._config.max_no_progress_rounds:
                            raise RuntimeError(
                                "LITE_NO_PROGRESS: repeated truncated model rounds produced "
                                "no completed tool call or terminal answer"
                            )
                        compaction = _compact_read_tool_history(
                            self._state.messages,
                            max_history_chars=self._config.max_history_chars,
                        )
                        if compaction["compactedResults"]:
                            await self._persist_history()
                            self._emit(
                                EventType.WARNING_RAISED,
                                {
                                    "code": "CONTEXT_HISTORY_COMPACTED",
                                    "vendor": "anthropic-messages",
                                    **compaction,
                                },
                            )
                        call = await self._create_message_with_retries()
                        try:
                            (
                                raw_content,
                                tool_uses,
                                canonical,
                                reasoning,
                                stop_reason,
                                usage,
                            ) = _parse_anthropic_response(call.response)
                        except Exception as exc:
                            self._emit_model_call_failed(
                                call,
                                exc,
                                category=ErrorCategory.PROTOCOL,
                                retryable=False,
                            )
                            raise
                        self._emit_model_call_completed(call, stop_reason)
                        if stop_reason == "model_context_window_exceeded":
                            raise RuntimeError("Anthropic model context window exceeded")
                        invocation.turns += 1
                        canonical_payload = [
                            block.model_dump(mode="json", by_alias=True) for block in canonical
                        ]
                        if invocation.final_answer_attempts and tool_uses:
                            raise RuntimeError(
                                "MODEL_FINAL_ANSWER_REQUIRED: tool calls are disabled during finalization"
                            )
                        if stop_reason == "max_tokens":
                            if invocation.final_answer_attempts:
                                if (
                                    invocation.final_answer_attempts >= self._config.max_final_answer_attempts
                                    or invocation.turns >= self._config.max_turns
                                ):
                                    self._emit_observations(
                                        canonical_payload, reasoning, usage, model_call_id=call.model_call_id,
                                    )
                                    raise RuntimeError("MODEL_FINAL_ANSWER_REQUIRED: final answer was truncated")
                                invocation.final_answer_attempts += 1
                            invocation.no_progress_rounds += 1
                            if canonical_payload:
                                invocation.outputs.append(canonical_payload)
                            if tool_uses:
                                # A truncated tool_use is not protocol-complete and must
                                # never be executed or persisted as an assistant turn.
                                self._state.messages.append(
                                    {
                                        "role": "user",
                                        "content": [{"type": "text", "text": _TRUNCATED_TOOL_RETRY}],
                                    }
                                )
                            else:
                                self._append_assistant_history(raw_content)
                                self._state.messages.append(
                                    {
                                        "role": "user",
                                        "content": [{"type": "text", "text": _OUTPUT_CONTINUATION}],
                                    }
                                )
                            await self._persist_history()
                            self._emit_observations(
                                canonical_payload,
                                reasoning,
                                usage,
                                model_call_id=call.model_call_id,
                            )
                            self._emit(
                                EventType.WARNING_RAISED,
                                {
                                    "code": "MODEL_OUTPUT_TRUNCATED",
                                    "vendor": "anthropic-messages",
                                    "turn": invocation.turns,
                                    "discardedToolCalls": len(tool_uses),
                                },
                            )
                            if invocation.no_progress_rounds >= self._config.max_no_progress_rounds:
                                self._emit(
                                    EventType.WARNING_RAISED,
                                    {
                                        "code": "MODEL_NO_PROGRESS",
                                        "vendor": "anthropic-messages",
                                        "rounds": invocation.no_progress_rounds,
                                        "maxNoProgressRounds": self._config.max_no_progress_rounds,
                                    },
                                )
                                raise RuntimeError(
                                    "LITE_NO_PROGRESS: repeated truncated model rounds produced "
                                    "no completed tool call or terminal answer"
                                )
                            continue
                        invocation.no_progress_rounds = 0
                        validated = self._validate_tool_uses(tool_uses)
                        if tool_uses and stop_reason != "tool_use":
                            raise ValueError(
                                "Anthropic returned tool_use content without stop_reason=tool_use"
                            )
                        if not tool_uses and stop_reason not in {
                            "",
                            "end_turn",
                            "stop_sequence",
                        }:
                            raise RuntimeError(
                                "Anthropic model stopped without completing the tool loop: "
                                f"stop_reason={stop_reason}"
                            )
                        if not tool_uses and not any(
                            isinstance(block, TextBlock) and block.text.strip() for block in canonical
                        ):
                            # A reasoning-only vendor response is not a public
                            # answer. Preserve it in history and observations,
                            # then request a new answer without repeating tools.
                            self._append_assistant_history(raw_content)
                            self._emit_observations(
                                canonical_payload, reasoning, usage, model_call_id=call.model_call_id,
                            )
                            if (
                                invocation.final_answer_attempts >= self._config.max_final_answer_attempts
                                or invocation.turns >= self._config.max_turns
                            ):
                                raise RuntimeError("MODEL_FINAL_ANSWER_REQUIRED: model returned no public final answer")
                            invocation.final_answer_attempts += 1
                            self._state.messages.append({
                                "role": "user", "content": [{"type": "text", "text": (
                                    "Provide your final answer to the original user now, using the completed work "
                                    "and tool results in this conversation. Return the answer as ordinary public "
                                    "text, not as thinking. Do not use tools or repeat completed work. "
                                    "If the requested result is unavailable, state that limitation explicitly."
                                )}],
                            })
                            await self._persist_history()
                            self._emit(EventType.WARNING_RAISED, {
                                "code": "MODEL_FINAL_ANSWER_REQUIRED", "vendor": "anthropic-messages",
                                "attempt": invocation.final_answer_attempts,
                                "maxAttempts": self._config.max_final_answer_attempts,
                            })
                            continue
                        self._append_assistant_history(raw_content)
                        if canonical_payload:
                            invocation.outputs.append(canonical_payload)
                        if tool_uses:
                            invocation.phase = "tools"
                            invocation.pending_tool_uses = copy.deepcopy(tool_uses)
                        else:
                            invocation.status = "completed"
                            invocation.stop_reason = stop_reason or None
                        await self._persist_history()
                        self._emit_observations(
                            canonical_payload,
                            reasoning,
                            usage,
                            model_call_id=call.model_call_id,
                        )
                        if not tool_uses:
                            self._emit(
                                EventType.EXECUTION_COMPLETED,
                                {"stopReason": stop_reason or None, "vendor": "anthropic-messages"},
                            )
                            return
                        tool_results = await self._request_tools(
                            validated,
                            model_call_id=call.model_call_id,
                        )
                        self._state.messages.append({"role": "user", "content": tool_results})
                        invocation.pending_tool_uses.clear()
                        invocation.phase = "model"
                        await self._persist_history()
                    raise RuntimeError(f"Anthropic runtime exceeded max_turns={self._config.max_turns}")
        except asyncio.CancelledError:
            persistence_error: BaseException | None = None
            if self._explicit_cancel:
                try:
                    await self._mark_failed("cancelled")
                except BaseException as exc:
                    persistence_error = exc
            data: dict[str, Any] = {"reason": "cancelled", "vendor": "anthropic-messages"}
            if persistence_error is not None:
                data["persistenceError"] = str(persistence_error) or type(persistence_error).__name__
            self._emit(EventType.EXECUTION_FAILED, data)
        except Exception as exc:
            persistence_error = None
            try:
                await self._mark_failed(str(exc) or type(exc).__name__)
            except BaseException as persist_exc:
                persistence_error = persist_exc
                exc.add_note(f"Anthropic failure-state persistence also failed: {persist_exc!r}")
            data = {
                "reason": str(exc) or type(exc).__name__,
                "vendor": "anthropic-messages",
            }
            if persistence_error is not None:
                data["persistenceError"] = (
                    str(persistence_error) or type(persistence_error).__name__
                )
            self._emit(
                EventType.EXECUTION_FAILED,
                data,
            )
        finally:
            for call_id, state in self._tool_calls.items():
                if not state.future.done():
                    state.future.set_result(
                        ToolResult(
                            call_id=call_id,
                            error=ErrorInfo(
                                code="ANTHROPIC_TOOL_BRIDGE_CLOSED",
                                category=ErrorCategory.UNAVAILABLE,
                                message=(
                                    "Anthropic execution ended before the application tool returned"
                                ),
                                retryable=True,
                            ),
                        )
                    )
            try:
                if self._on_finish is not None:
                    self._on_finish()
            finally:
                self._finish()

    async def _prepare_invocation(self) -> _InvocationState:
        digest = _request_digest(self._request, self._user_content)
        invocation = self._state.invocation
        if invocation is not None:
            same_invocation = (
                invocation.run_id == self._request.run_id
                and invocation.agent_id == self._request.agent.agent_id
            )
            if same_invocation:
                if invocation.request_digest != digest:
                    raise ValueError(
                        "Anthropic recovery request does not match the persisted invocation"
                    )
                self._owns_invocation = True
                return invocation
            if invocation.status == "active":
                raise RuntimeError(
                    "Anthropic session contains an unfinished invocation for a different run"
                )
        invocation = _InvocationState(
            run_id=self._request.run_id,
            agent_id=self._request.agent.agent_id,
            request_digest=digest,
        )
        self._state.invocation = invocation
        self._owns_invocation = True
        self._state.messages.append(
            {"role": "user", "content": copy.deepcopy(self._user_content)}
        )
        await self._persist_history()
        return invocation

    def _replay_outputs(self, invocation: _InvocationState) -> None:
        for content in invocation.outputs:
            self._emit(
                EventType.MESSAGE_COMPLETED,
                {"content": copy.deepcopy(content)},
            )

    def _emit_observations(
        self,
        canonical_payload: list[dict[str, Any]],
        reasoning: list[str],
        usage: Any,
        *,
        model_call_id: str,
    ) -> None:
        for thinking in reasoning:
            self._emit(EventType.REASONING_DELTA, {"text": thinking, "final": True})
        if canonical_payload:
            self._emit(
                EventType.MESSAGE_COMPLETED,
                {
                    "content": canonical_payload,
                    "messageId": f"msg_{model_call_id}",
                    "modelCallId": model_call_id,
                    "role": "assistant",
                },
            )
        if usage is not None:
            normalized = normalize_token_usage(usage)
            if normalized is not None:
                self._emit(
                    EventType.USAGE_UPDATED,
                    {
                        "modelCallId": model_call_id,
                        "usage": normalized.model_dump(mode="json", by_alias=True),
                    },
                )
            known = {
                "input_tokens",
                "inputTokens",
                "output_tokens",
                "outputTokens",
                "total_tokens",
                "totalTokens",
                "cache_read_input_tokens",
                "cache_creation_input_tokens",
            }
            if not isinstance(usage, dict) or set(usage).difference(known):
                self._emit_raw("message.usage", usage, reason="unsupported-event")

    async def _mark_failed(self, reason: str) -> None:
        invocation = self._state.invocation
        if not self._owns_invocation or invocation is None:
            return
        if invocation.status == "active":
            invocation.status = "failed"
            invocation.failure_reason = reason
        if invocation.status == "failed" and invocation.failure_reason == reason:
            await self._persist_history()

    async def _create_message_with_retries(self) -> _ModelCallResult:
        provider = self._state.spec.provider or "anthropic"
        model = self._state.spec.model or self._config.model
        for attempt in range(self._config.max_retries + 1):
            call = _ModelCallResult(
                response={},
                model_call_id=new_id("mcall"),
                provider=provider,
                model=model,
                attempt=attempt + 1,
                started_at=time.monotonic(),
            )
            self._emit(
                EventType.MODEL_CALL_STARTED,
                {
                    "modelCallId": call.model_call_id,
                    "provider": provider,
                    "model": model,
                    "attempt": call.attempt,
                },
            )
            try:
                response = await self._backend.create_message(self._vendor_request())
                return _ModelCallResult(
                    response=response,
                    model_call_id=call.model_call_id,
                    provider=provider,
                    model=model,
                    attempt=call.attempt,
                    started_at=call.started_at,
                )
            except Exception as exc:
                retryable = attempt < self._config.max_retries and _is_transport_error(exc)
                self._emit_model_call_failed(
                    call,
                    exc,
                    category=(ErrorCategory.UNAVAILABLE if retryable else ErrorCategory.INTERNAL),
                    retryable=retryable,
                )
                if attempt >= self._config.max_retries or not _is_transport_error(exc):
                    raise
                retry_number = attempt + 1
                self._emit(
                    EventType.WARNING_RAISED,
                    {
                        "code": "MODEL_TRANSPORT_RETRY",
                        "vendor": "anthropic-messages",
                        "attempt": retry_number,
                        "maxRetries": self._config.max_retries,
                        "errorType": type(exc).__name__,
                    },
                )
                delay = self._config.retry_backoff_seconds * (2**attempt)
                if delay > 0:
                    await asyncio.sleep(delay)
        raise AssertionError("unreachable")

    def _emit_model_call_completed(self, call: _ModelCallResult, finish_reason: str) -> None:
        request_id = call.response.get("id")
        self._emit(
            EventType.MODEL_CALL_COMPLETED,
            {
                "modelCallId": call.model_call_id,
                "provider": call.provider,
                "model": call.model,
                "attempt": call.attempt,
                "providerRequestId": (
                    request_id if isinstance(request_id, str) and request_id else None
                ),
                "finishReason": finish_reason or "unknown",
                "durationSeconds": time.monotonic() - call.started_at,
            },
        )

    def _emit_model_call_failed(
        self,
        call: _ModelCallResult,
        error: BaseException,
        *,
        category: ErrorCategory,
        retryable: bool,
    ) -> None:
        self._emit(
            EventType.MODEL_CALL_FAILED,
            {
                "modelCallId": call.model_call_id,
                "provider": call.provider,
                "model": call.model,
                "attempt": call.attempt,
                "durationSeconds": time.monotonic() - call.started_at,
                "error": ErrorInfo(
                    code="ANTHROPIC_MODEL_CALL_FAILED",
                    category=category,
                    message=str(error) or type(error).__name__,
                    retryable=retryable,
                    details={"exceptionType": type(error).__name__},
                ).model_dump(mode="json", by_alias=True),
            },
        )

    def _emit_raw(
        self,
        vendor_event_type: str,
        payload: Any,
        *,
        reason: str,
    ) -> None:
        self._emit(
            EventType.RAW_EVENT_RECORDED,
            {
                "producer": "anthropic-messages",
                "vendorEventType": vendor_event_type,
                "runtimeInstanceId": self._runtime_instance_id,
                "runtimeSequence": self._sequence,
                "reason": reason,
                "payload": payload,
            },
            ignorable=True,
        )

    def _append_assistant_history(self, content: list[dict[str, Any]]) -> None:
        # Empty public text cannot be replayed as an assistant message to the
        # vendor. Preserve signed thinking and tool content without alteration.
        replayable = [item for item in content if item.get("type") != "text" or item["text"].strip()]
        if replayable:
            self._state.messages.append({"role": "assistant", "content": copy.deepcopy(replayable)})

    def _vendor_request(self) -> dict[str, Any]:
        messages = []
        for message in copy.deepcopy(self._state.messages):
            if message["role"] == "assistant":
                message["content"] = [
                    item for item in message["content"]
                    if item.get("type") != "text" or item["text"].strip()
                ]
                if not message["content"]:
                    continue
            messages.append(message)
        request: dict[str, Any] = {
            "model": self._state.spec.model or self._config.model,
            "max_tokens": self._config.max_tokens,
            # Older adapters persisted empty assistant messages. Filter only
            # this vendor projection; preserve their durable history as read.
            "messages": messages,
        }
        native_parameters = {"temperature", "top_p", "top_k"}
        custom_parameters: dict[str, Any] = {}
        for key, value in self._config.model_parameters.items():
            if key in native_parameters:
                request[key] = value
            else:
                custom_parameters[key] = value
        if custom_parameters:
            request["extra_body"] = custom_parameters
        system = _plain_system(self._request.system)
        if system:
            request["system"] = system
        finalizing = self._state.invocation is not None and self._state.invocation.final_answer_attempts > 0
        if self._request.tools and not finalizing:
            request["tools"] = [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "input_schema": copy.deepcopy(tool.input_schema),
                }
                for tool in self._request.tools
            ]
        return request

    def _validate_tool_uses(
        self,
        tool_uses: list[dict[str, Any]],
    ) -> list[tuple[str, str, dict[str, Any]]]:
        selected = {tool.name: tool for tool in self._request.tools}
        validated: list[tuple[str, str, dict[str, Any]]] = []
        call_ids: set[str] = set()
        for item in tool_uses:
            call_id = _anthropic_identity(item.get("id"), "tool_use.id")
            name = _anthropic_identity(item.get("name"), "tool_use.name")
            arguments = item.get("input")
            if name not in selected or not isinstance(arguments, dict):
                raise ValueError(f"Anthropic requested an undeclared or malformed tool: {name}")
            _require_finite_json(arguments, "tool_use.input")
            if call_id in call_ids or call_id in self._tool_calls:
                raise ValueError(f"Anthropic returned duplicate tool call id: {call_id}")
            call_ids.add(call_id)
            validated.append((call_id, name, arguments))
        return validated

    async def _request_tools(
        self,
        validated: list[tuple[str, str, dict[str, Any]]],
        *,
        model_call_id: str | None = None,
    ) -> list[dict[str, Any]]:
        selected = {tool.name: tool for tool in self._request.tools}
        waits: list[tuple[str, asyncio.Future[ToolResult]]] = []
        for call_id, name, arguments in validated:
            future = asyncio.get_running_loop().create_future()
            self._tool_calls[call_id] = _AnthropicToolCallState(future=future)
            waits.append((call_id, future))
            self._emit(
                EventType.TOOL_REQUESTED,
                {
                    "callId": call_id,
                    "name": name,
                    "arguments": arguments,
                    "execution": selected[name].execution.value,
                    "modelCallId": model_call_id,
                },
            )
        results: list[dict[str, Any]] = []
        for _call_id, future in waits:
            result = await future
            results.append(
                await _tool_result_to_anthropic(
                    result,
                    self._assets,
                    max_asset_bytes=self._config.max_input_asset_bytes,
                )
            )
        return results

    async def send_tool_result(self, result: ToolResult) -> None:
        if not isinstance(result, ToolResult):
            raise TypeError("Anthropic send_tool_result requires a ToolResult")
        state = self._tool_calls.get(result.call_id)
        if state is None:
            raise LookupError(f"Unknown Anthropic tool call: {result.call_id}")
        if state.future.done():
            completed = state.future.result()
            if completed == result or (
                completed.error is not None
                and completed.error.code == "ANTHROPIC_TOOL_BRIDGE_CLOSED"
            ):
                return
            raise ValueError(f"Conflicting Anthropic tool result: {result.call_id}")
        state.future.set_result(result)

    async def _persist_history(self) -> None:
        if self._state.persist is not None:
            await self._state.persist(self._state.messages, self._state.invocation)

    async def respond(self, response: InteractionResponse) -> None:
        raise NotImplementedError("Anthropic Messages binding does not expose interactions")

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        raise NotImplementedError("Anthropic Messages binding does not expose steer")

    async def cancel(self, reason: CancelReason) -> None:
        del reason
        async with self._cancel_lock:
            self._explicit_cancel = True
            if not self._task.done():
                self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            # cancel_run() can race the Application's finally block, whose close()
            # may have already stopped this task as a recoverable interruption.
            # Make caller intent durable even in that ordering.
            async with self._state.lock:
                await self._mark_failed("cancelled")

    async def close(self) -> None:
        if not self._task.done():
            self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task

    def _finish(self) -> None:
        if self._ended:
            return
        self._ended = True
        self._queue.put_nowait(_END)


class AnthropicMessagesRuntimeAdapter:
    def __init__(
        self,
        *,
        asset_store: AssetStorePort | None = None,
        backend: AnthropicBackend | None = None,
        config: AnthropicRuntimeConfig | None = None,
    ) -> None:
        self._instance_id = new_id("runtime")
        self._assets = asset_store
        self._config = config or AnthropicRuntimeConfig()
        self._backend = backend or _AnthropicSDKBackend(self._config)
        self._sessions: dict[str, _SessionState] = {}
        self._closed_sessions: dict[str, RuntimeSessionRef] = {}
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._history: dict[
            str,
            tuple[list[dict[str, Any]], _InvocationState | None, str],
        ] = {}
        self._close_lock = asyncio.Lock()
        self._execution_slots = asyncio.Semaphore(self._config.max_concurrency)
        self._closing = False
        self._closed = False
        self._history_root = (
            Path(self._config.history_root).expanduser().resolve() if self._config.history_root is not None else None
        )
        if self._history_root is not None:
            self._history_root.mkdir(parents=True, exist_ok=True)

    async def describe(self) -> RuntimeDescriptor:
        try:
            runtime_version = version("anthropic")
        except PackageNotFoundError:
            runtime_version = "injected"
        modalities = (Modality.TEXT, Modality.IMAGE) if self._assets is not None else (Modality.TEXT,)
        return RuntimeDescriptor(
            name="anthropic-messages",
            adapter_version="1.1.0",
            runtime_version=runtime_version,
            capabilities=RuntimeCapabilities(
                input_modalities=modalities,
                output_modalities=(Modality.TEXT,),
                tool_calling=True,
                application_tool_bridge=True,
                cancel=True,
                steer=False,
                resume=True,
                interaction=False,
                native_multi_agent=False,
                native_graph_execution=False,
                data_coverage=DataCoverage(
                    messages=MessageCoverage.FULL,
                    model_calls=DetailCoverage.FULL,
                    tool_calls=DetailCoverage.FULL,
                    usage=UsageCoverage.NORMALIZED,
                    raw_events=RawEventCoverage.FULL,
                ),
                extensions={
                    "com.anthropic.messages/capabilities/v1": {
                        "resumeDurability": ("filesystem" if self._history_root is not None else "process"),
                        "maxConcurrency": self._config.max_concurrency,
                        "maxInputAssetBytes": self._config.max_input_asset_bytes,
                    },
                },
            ),
        )

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("Anthropic runtime is closing")
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Anthropic runtime is closing")
            existing = self._sessions.get(spec.session_id)
            if existing is not None:
                if existing.closed:
                    raise RuntimeError(f"Anthropic session is closing: {spec.session_id}")
                require_same_runtime_session_spec(existing.spec, spec)
                return existing.ref
            ref = RuntimeSessionRef(
                session_id=spec.session_id,
                runtime_session_id=new_id("anthropic_session"),
            )
            spec_digest = runtime_session_binding_digest(spec)
            messages, invocation = (
                await self._load_history(spec, spec_digest) if spec.resume else ([], None)
            )
            self._sessions[spec.session_id] = _SessionState(
                spec=spec,
                ref=ref,
                spec_digest=spec_digest,
                messages=messages,
                invocation=invocation,
                persist=lambda current, active: self._save_history(
                    spec.session_id,
                    spec_digest,
                    current,
                    active,
                ),
            )
            self._closed_sessions.pop(spec.session_id, None)
            return ref

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Anthropic runtime is closing")
        session_lock = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with session_lock:
            try:
                state = self._sessions[request.session_id]
            except KeyError as exc:
                raise ValueError(
                    f"Anthropic session is not open: {request.session_id}"
                ) from exc
            async with state.admission_lock:
                if self._closing or state.closed or self._sessions.get(request.session_id) is not state:
                    raise ValueError(f"Anthropic session is not open: {request.session_id}")
                require_session_environment(state.spec, request)
                if state.active:
                    raise RuntimeError(
                        "Anthropic session already has an active execution: "
                        f"{request.session_id}"
                    )
                runtime_tools = [
                    tool.name for tool in request.tools if tool.execution == ToolExecution.RUNTIME
                ]
                if runtime_tools:
                    raise ValueError(
                        "Anthropic Messages only supports application/remote tools: "
                        + ", ".join(runtime_tools)
                    )
                user_content = await _content_to_anthropic(
                    request.input,
                    self._assets,
                    max_asset_bytes=self._config.max_input_asset_bytes,
                )
                state.active = True

                def finish() -> None:
                    state.active = False
                    state.channel = None

                try:
                    channel = _AnthropicExecutionChannel(
                        runtime_instance_id=self._instance_id,
                        request=request,
                        state=state,
                        backend=self._backend,
                        config=self._config,
                        user_content=user_content,
                        assets=self._assets,
                        execution_slots=self._execution_slots,
                        on_finish=finish,
                    )
                except BaseException:
                    state.active = False
                    raise
                state.channel = channel
                return channel

    async def close_session(self, session: RuntimeSessionRef) -> None:
        lock = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with lock:
            state = self._sessions.get(session.session_id)
            if state is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("Anthropic session reference is not owned by this adapter")
            if state.ref != session:
                raise ValueError("Anthropic session reference does not match the open session")
            async with state.admission_lock:
                state.closed = True
                errors: list[BaseException] = []
                if state.channel is not None:
                    try:
                        await state.channel.close()
                    except BaseException as exc:
                        errors.append(exc)
                try:
                    await self._save_history(
                        session.session_id,
                        state.spec_digest,
                        state.messages,
                        state.invocation,
                    )
                except BaseException as exc:
                    errors.append(exc)
                if not errors and self._sessions.get(session.session_id) is state:
                    self._sessions.pop(session.session_id, None)
                    self._closed_sessions[session.session_id] = session
                if errors:
                    raise BaseExceptionGroup("Anthropic session cleanup failed", errors)

    async def health(self) -> HealthStatus:
        if self._closing:
            return HealthStatus(status="unhealthy", details={"reason": "runtime_closing"})
        return HealthStatus(status="healthy")

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closing = True
            errors: list[BaseException] = []
            for state in tuple(self._sessions.values()):
                try:
                    await self.close_session(state.ref)
                except BaseException as exc:
                    errors.append(exc)
            if errors:
                raise BaseExceptionGroup("Anthropic runtime session cleanup failed", errors)
            try:
                await self._backend.close()
            except BaseException as exc:
                errors.append(exc)
            if errors:
                raise BaseExceptionGroup("Anthropic runtime cleanup failed", errors)
            self._closed = True
            self._closed_sessions.clear()
            self._history.clear()

    async def _load_history(
        self,
        spec: RuntimeSessionSpec,
        spec_digest: str,
    ) -> tuple[list[dict[str, Any]], _InvocationState | None]:
        session_id = spec.session_id
        cached = self._history.get(session_id)
        if cached is not None:
            messages, invocation, cached_digest = cached
            _require_history_spec_digest(cached_digest, spec_digest, session_id)
            return _copy_history(messages, invocation)
        if self._history_root is None:
            return [], None
        path = self._history_path(session_id)
        try:
            value = await asyncio.to_thread(_read_history_json, path)
        except FileNotFoundError:
            return [], None
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError(f"Corrupt Anthropic session history: {session_id}") from exc
        messages, invocation, persisted_digest = _parse_history(value, session_id)
        if persisted_digest is not None:
            _require_history_spec_digest(persisted_digest, spec_digest, session_id)
        snapshot, invocation_snapshot = _copy_history(messages, invocation)
        # Legacy v0/v1 records had no binding. Once admitted by an explicit
        # resume request, bind the in-process copy immediately and write v2 on
        # the next persistence boundary.
        self._history[session_id] = (snapshot, invocation_snapshot, spec_digest)
        return messages, invocation

    async def _save_history(
        self,
        session_id: str,
        spec_digest: str,
        messages: list[dict[str, Any]],
        invocation: _InvocationState | None,
    ) -> None:
        snapshot, invocation_snapshot = _copy_history(messages, invocation)
        if self._history_root is not None:
            await asyncio.to_thread(
                self._write_history,
                self._history_path(session_id),
                spec_digest,
                snapshot,
                invocation_snapshot,
            )
        self._history[session_id] = (snapshot, invocation_snapshot, spec_digest)

    def _history_path(self, session_id: str) -> Path:
        assert self._history_root is not None
        safe = hashlib.sha256(session_id.encode("utf-8")).hexdigest()
        return self._history_root / f"{safe}.json"

    @staticmethod
    def _write_history(
        path: Path,
        spec_digest: str,
        messages: list[dict[str, Any]],
        invocation: _InvocationState | None,
    ) -> None:
        encoded = json.dumps(
            {
                "schemaVersion": _HISTORY_SCHEMA_VERSION,
                "sessionSpecDigest": spec_digest,
                "messages": messages,
                "invocation": _invocation_to_json(invocation),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        if len(encoded) + 1 > _MAX_ANTHROPIC_VENDOR_JSON_BYTES:
            raise ValueError("Anthropic session history exceeds the adapter JSON limit")
        descriptor, temporary_name = tempfile.mkstemp(prefix="history-", dir=path.parent)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(encoded)
                handle.write(b"\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise


AnthropicLiteRuntimeAdapter = AnthropicMessagesRuntimeAdapter


def _parse_anthropic_response(
    response: object,
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[ContentBlock],
    list[str],
    str,
    dict[str, Any] | None,
]:
    if not isinstance(response, dict):
        raise TypeError("Anthropic backend response must be an object")
    _require_finite_json(response, "response")
    raw_content = response.get("content")
    if not isinstance(raw_content, list) or any(not isinstance(item, dict) for item in raw_content):
        raise ValueError("Anthropic response content must be a list of objects")
    if len(raw_content) > 10_000:
        raise ValueError("Anthropic response contains too many content blocks")
    tool_uses: list[dict[str, Any]] = []
    canonical: list[ContentBlock] = []
    reasoning: list[str] = []
    for item in raw_content:
        kind = _anthropic_identity(item.get("type"), "content block type")
        if kind == "text":
            canonical.append(TextBlock(text=_anthropic_text(item.get("text"), "text block text")))
        elif kind == "thinking":
            thinking = _anthropic_text(item.get("thinking"), "thinking block text")
            _anthropic_identity(item.get("signature"), "thinking block signature")
            if thinking:
                reasoning.append(thinking)
        elif kind == "redacted_thinking":
            # The encrypted redacted payload must be replayed to Anthropic but
            # is not human-readable reasoning and must never be surfaced as it.
            _anthropic_identity(item.get("data"), "redacted thinking data")
        elif kind == "tool_use":
            tool_uses.append(item)
        else:
            raise ValueError(f"Anthropic returned unsupported content block: {kind}")
    raw_stop_reason = response.get("stop_reason")
    if raw_stop_reason is not None and not isinstance(raw_stop_reason, str):
        raise ValueError("Anthropic response stop_reason must be a string or null")
    stop_reason = raw_stop_reason or ""
    usage = response.get("usage")
    if usage is not None:
        if not isinstance(usage, dict):
            raise ValueError("Anthropic response usage must be an object or null")
        _require_finite_json(usage, "response usage")
    return raw_content, tool_uses, canonical, reasoning, stop_reason, usage


def _anthropic_identity(value: object, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or "\x00" in value
    ):
        raise ValueError(f"Anthropic {field_name} must be a non-blank, trimmed string")
    return value


def _anthropic_text(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"Anthropic {field_name} must be text")
    return value


def _require_finite_json(value: object, field_name: str) -> None:
    try:
        encoded = json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Anthropic {field_name} must contain finite JSON data") from exc
    if len(encoded) > _MAX_ANTHROPIC_VENDOR_JSON_BYTES:
        raise ValueError(f"Anthropic {field_name} exceeds the adapter JSON limit")


def _is_transport_error(exc: Exception) -> bool:
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return True
    try:
        import httpx
    except ImportError:
        pass
    else:
        if isinstance(exc, httpx.TransportError):
            return True
    try:
        from anthropic import APIConnectionError
    except ImportError:
        return False
    return isinstance(exc, APIConnectionError)


def _copy_history(
    messages: list[dict[str, Any]],
    invocation: _InvocationState | None,
) -> tuple[list[dict[str, Any]], _InvocationState | None]:
    return copy.deepcopy(messages), copy.deepcopy(invocation)


def _require_history_spec_digest(
    persisted: str,
    requested: str,
    session_id: str,
) -> None:
    if persisted != requested:
        raise ValueError(
            "Anthropic durable session does not match the requested immutable "
            f"RuntimeSessionSpec: {session_id}"
        )


def _read_history_json(path: Path) -> object:
    flags = os.O_RDONLY
    if hasattr(os, "O_CLOEXEC"):
        flags |= os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    try:
        metadata = os.fstat(descriptor)
        if not S_ISREG(metadata.st_mode):
            raise ValueError("Anthropic history path is not a regular file")
        if metadata.st_size > _MAX_ANTHROPIC_VENDOR_JSON_BYTES:
            raise ValueError("Anthropic history file exceeds the adapter JSON limit")
        chunks: list[bytes] = []
        remaining = _MAX_ANTHROPIC_VENDOR_JSON_BYTES
        while remaining > 0:
            chunk = os.read(descriptor, min(1024 * 1024, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        if remaining == 0 and os.read(descriptor, 1):
            raise ValueError("Anthropic history file exceeds the adapter JSON limit")
    finally:
        os.close(descriptor)
    raw = b"".join(chunks).decode("utf-8")
    return json.loads(
        raw,
        object_pairs_hook=_reject_duplicate_json_object,
        parse_constant=_reject_non_finite_json_constant,
    )


def _reject_duplicate_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def _reject_non_finite_json_constant(value: str) -> object:
    raise ValueError(f"non-finite JSON number: {value}")


def _invocation_to_json(invocation: _InvocationState | None) -> dict[str, Any] | None:
    if invocation is None:
        return None
    return {
        "runId": invocation.run_id,
        "agentId": invocation.agent_id,
        "requestDigest": invocation.request_digest,
        "status": invocation.status,
        "phase": invocation.phase,
        "pendingToolUses": copy.deepcopy(invocation.pending_tool_uses),
        "outputs": copy.deepcopy(invocation.outputs),
        "turns": invocation.turns,
        "noProgressRounds": invocation.no_progress_rounds,
        **({"finalAnswerAttempts": invocation.final_answer_attempts} if invocation.final_answer_attempts else {}),
        "stopReason": invocation.stop_reason,
        "failureReason": invocation.failure_reason,
    }


def _parse_history(
    value: Any,
    session_id: str,
) -> tuple[list[dict[str, Any]], _InvocationState | None, str | None]:
    # v0 wrote the bare Anthropic messages list. Keep it readable so rollout
    # does not invalidate existing resumable sessions.
    if isinstance(value, list):
        messages = _validate_messages(value, session_id)
        return messages, None, None
    if not isinstance(value, dict):
        raise ValueError(f"Corrupt Anthropic session history: {session_id}")
    schema_version = value.get("schemaVersion")
    if schema_version not in {
        _HISTORY_SCHEMA_VERSION,
        _LEGACY_HISTORY_SCHEMA_VERSION,
    }:
        raise ValueError(f"Corrupt Anthropic session history: {session_id}")
    expected_keys = {"schemaVersion", "messages", "invocation"}
    persisted_digest: str | None = None
    if schema_version == _HISTORY_SCHEMA_VERSION:
        expected_keys.add("sessionSpecDigest")
        raw_digest = value.get("sessionSpecDigest")
        if (
            not isinstance(raw_digest, str)
            or len(raw_digest) != 64
            or any(character not in "0123456789abcdef" for character in raw_digest)
        ):
            raise ValueError(f"Corrupt Anthropic session binding: {session_id}")
        persisted_digest = raw_digest
    if set(value) != expected_keys:
        raise ValueError(f"Corrupt Anthropic session history envelope: {session_id}")
    messages = _validate_messages(value.get("messages"), session_id)
    raw_invocation = value.get("invocation")
    if raw_invocation is None:
        return messages, None, persisted_digest
    if not isinstance(raw_invocation, dict):
        raise ValueError(f"Corrupt Anthropic invocation state: {session_id}")
    required_invocation_keys = {
        "runId",
        "agentId",
        "requestDigest",
        "status",
        "phase",
        "pendingToolUses",
        "outputs",
        "turns",
        "noProgressRounds",
        "stopReason",
        "failureReason",
    }
    if not required_invocation_keys <= set(raw_invocation) <= required_invocation_keys | {"finalAnswerAttempts"}:
        raise ValueError(f"Corrupt Anthropic invocation envelope: {session_id}")

    def required_string(key: str) -> str:
        result = raw_invocation.get(key)
        if (
            not isinstance(result, str)
            or not result
            or result != result.strip()
            or "\x00" in result
        ):
            raise ValueError(f"Corrupt Anthropic invocation {key}: {session_id}")
        return result

    run_id = required_string("runId")
    agent_id = required_string("agentId")
    request_digest = required_string("requestDigest")
    if len(request_digest) != 64 or any(
        character not in "0123456789abcdef" for character in request_digest
    ):
        raise ValueError(f"Corrupt Anthropic invocation requestDigest: {session_id}")
    status = required_string("status")
    phase = required_string("phase")
    if status not in {"active", "completed", "failed"} or phase not in {
        "model",
        "tools",
    }:
        raise ValueError(f"Corrupt Anthropic invocation lifecycle: {session_id}")
    pending = raw_invocation.get("pendingToolUses", [])
    if (
        not isinstance(pending, list)
        or len(pending) > 10_000
        or any(not isinstance(item, dict) for item in pending)
    ):
        raise ValueError(f"Corrupt Anthropic pending tool calls: {session_id}")
    if status == "active" and phase == "tools" and not pending:
        raise ValueError(f"Corrupt Anthropic tool phase: {session_id}")
    if status == "active" and phase == "model" and pending:
        raise ValueError(f"Corrupt Anthropic model phase: {session_id}")
    if status == "completed" and pending:
        raise ValueError(f"Corrupt Anthropic completed invocation: {session_id}")
    raw_outputs = raw_invocation.get("outputs", [])
    if not isinstance(raw_outputs, list):
        raise ValueError(f"Corrupt Anthropic invocation outputs: {session_id}")
    outputs: list[list[dict[str, Any]]] = []
    for output in raw_outputs:
        try:
            blocks = _CONTENT_BLOCKS_ADAPTER.validate_python(output)
        except Exception as exc:
            raise ValueError(
                f"Corrupt Anthropic invocation output: {session_id}"
            ) from exc
        if not blocks:
            raise ValueError(f"Corrupt Anthropic invocation output: {session_id}")
        outputs.append(
            [block.model_dump(mode="json", by_alias=True) for block in blocks]
        )
    turns = raw_invocation.get("turns", 0)
    no_progress_rounds = raw_invocation.get("noProgressRounds", 0)
    final_answer_attempts = raw_invocation.get("finalAnswerAttempts", 0)
    if (
        isinstance(turns, bool)
        or not isinstance(turns, int)
        or turns < 0
        or turns > _MAX_ANTHROPIC_TURNS
        or isinstance(no_progress_rounds, bool)
        or not isinstance(no_progress_rounds, int)
        or no_progress_rounds < 0
        or no_progress_rounds > turns
        or isinstance(final_answer_attempts, bool)
        or not isinstance(final_answer_attempts, int)
        or not 0 <= final_answer_attempts <= min(3, turns)
    ):
        raise ValueError(f"Corrupt Anthropic invocation counters: {session_id}")
    stop_reason = raw_invocation.get("stopReason")
    failure_reason = raw_invocation.get("failureReason")
    if stop_reason is not None and not isinstance(stop_reason, str):
        raise ValueError(f"Corrupt Anthropic invocation stopReason: {session_id}")
    if failure_reason is not None and not isinstance(failure_reason, str):
        raise ValueError(f"Corrupt Anthropic invocation failureReason: {session_id}")
    if status == "active" and (stop_reason is not None or failure_reason is not None):
        raise ValueError(f"Corrupt Anthropic active invocation terminal data: {session_id}")
    if status == "completed" and failure_reason is not None:
        raise ValueError(f"Corrupt Anthropic completed invocation failure: {session_id}")
    if status == "failed" and (not failure_reason or stop_reason is not None):
        raise ValueError(f"Corrupt Anthropic failed invocation terminal data: {session_id}")
    return (
        messages,
        _InvocationState(
            run_id=run_id,
            agent_id=agent_id,
            request_digest=request_digest,
            status=status,
            phase=phase,
            pending_tool_uses=copy.deepcopy(pending),
            outputs=outputs,
            turns=turns,
            no_progress_rounds=no_progress_rounds,
            final_answer_attempts=final_answer_attempts,
            stop_reason=stop_reason,
            failure_reason=failure_reason,
        ),
        persisted_digest,
    )


def _validate_messages(value: Any, session_id: str) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        raise ValueError(f"Corrupt Anthropic session history: {session_id}")
    if len(value) > 100_000:
        raise ValueError(f"Corrupt Anthropic session history: {session_id}")
    _require_finite_json(value, "session history")
    for message in value:
        if (
            not isinstance(message, dict)
            or message.get("role") not in {"user", "assistant"}
            or not isinstance(message.get("content"), list)
            or any(not isinstance(block, dict) for block in message["content"])
            or len(message["content"]) > 10_000
        ):
            raise ValueError(f"Corrupt Anthropic session history: {session_id}")
        for block in message["content"]:
            _validate_history_block(block, message["role"], session_id)
    return copy.deepcopy(value)


def _validate_history_block(block: dict[str, Any], role: str, session_id: str) -> None:
    try:
        kind = _anthropic_identity(block.get("type"), "history content block type")
        if kind == "text":
            _anthropic_text(block.get("text"), "history text block text")
            return
        if role == "assistant" and kind == "thinking":
            _anthropic_text(block.get("thinking"), "history thinking block text")
            _anthropic_identity(block.get("signature"), "history thinking signature")
            return
        if role == "assistant" and kind == "redacted_thinking":
            _anthropic_identity(block.get("data"), "history redacted thinking data")
            return
        if role == "assistant" and kind == "tool_use":
            _anthropic_identity(block.get("id"), "history tool_use.id")
            _anthropic_identity(block.get("name"), "history tool_use.name")
            if not isinstance(block.get("input"), dict):
                raise ValueError("history tool_use.input must be an object")
            return
        if role == "user" and kind == "image":
            _validate_history_image(block)
            return
        if role == "user" and kind == "tool_result":
            _anthropic_identity(block.get("tool_use_id"), "history tool_result.tool_use_id")
            if not isinstance(block.get("is_error"), bool):
                raise ValueError("history tool_result.is_error must be a boolean")
            content = block.get("content")
            if (
                not isinstance(content, list)
                or not content
                or len(content) > 10_000
                or any(not isinstance(item, dict) for item in content)
            ):
                raise ValueError("history tool_result.content must be a non-empty block list")
            for item in content:
                nested_kind = item.get("type")
                if nested_kind == "text":
                    _anthropic_text(item.get("text"), "history tool result text")
                elif nested_kind == "image":
                    _validate_history_image(item)
                else:
                    raise ValueError("unsupported history tool result content")
            return
        raise ValueError(f"unsupported {role} history content block: {kind}")
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Corrupt Anthropic session history: {session_id}") from exc


def _validate_history_image(block: dict[str, Any]) -> None:
    source = block.get("source")
    if not isinstance(source, dict) or source.get("type") != "base64":
        raise ValueError("history image source must be base64")
    media_type = source.get("media_type")
    if media_type not in _ANTHROPIC_IMAGE_MEDIA_TYPES:
        raise ValueError("history image media type is unsupported")
    data = source.get("data")
    if not isinstance(data, str):
        raise ValueError("history image data must be text")
    try:
        base64.b64decode(data, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ValueError("history image data is not valid base64") from exc


def _request_digest(
    request: ExecutionRequest,
    user_content: list[dict[str, Any]],
) -> str:
    payload = {
        "request": request.model_dump(
            mode="json",
            by_alias=True,
            exclude={"execution_id"},
        ),
        "resolvedUserContent": user_content,
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _compact_read_tool_history(
    messages: list[dict[str, Any]],
    *,
    max_history_chars: int,
) -> dict[str, int]:
    """Replace old Read bodies with verifiable receipts while preserving tool pairing."""

    before = len(json.dumps(messages, ensure_ascii=False, separators=(",", ":")))
    if before <= max_history_chars:
        return {"compactedResults": 0, "removedChars": 0, "historyChars": before}

    read_calls: dict[str, dict[str, Any]] = {}
    for message in messages:
        if message.get("role") != "assistant" or not isinstance(message.get("content"), list):
            continue
        for block in message["content"]:
            if isinstance(block, dict) and block.get("type") == "tool_use" and block.get("name") == "workspace.read":
                arguments = block.get("input")
                read_calls[str(block.get("id") or "")] = arguments if isinstance(arguments, dict) else {}

    records: list[tuple[int, dict[str, Any], dict[str, Any], str]] = []
    for index, message in enumerate(messages):
        if message.get("role") != "user" or not isinstance(message.get("content"), list):
            continue
        for block in message["content"]:
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            arguments = read_calls.get(str(block.get("tool_use_id") or ""))
            content = block.get("content")
            if arguments is None or not isinstance(content, list) or block.get("is_error") is True:
                continue
            texts = [
                str(part.get("text") or "") for part in content if isinstance(part, dict) and part.get("type") == "text"
            ]
            raw = "\n".join(texts)
            if not raw or "READ_RESULT_COMPACTED" in raw:
                continue
            records.append((index, block, arguments, raw))

    compacted = 0
    removed = 0
    protected_message = len(messages) - 1
    target = int(max_history_chars * 0.8)
    current = before
    for message_index, block, arguments, raw in records:
        if current <= target:
            break
        if message_index == protected_message:
            continue
        receipt = {
            "ok": True,
            "code": "READ_RESULT_COMPACTED",
            "path": str(arguments.get("path") or ""),
            "returnedChars": len(raw),
            "sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(),
            "note": "The earlier read body was consumed and compacted; read a bounded window again if needed.",
        }
        replacement = [{"type": "text", "text": json.dumps(receipt, separators=(",", ":"))}]
        replacement_chars = len(replacement[0]["text"])
        block["content"] = replacement
        current -= max(0, len(raw) - replacement_chars)
        removed += max(0, len(raw) - replacement_chars)
        compacted += 1
    current = len(json.dumps(messages, ensure_ascii=False, separators=(",", ":")))
    return {
        "compactedResults": compacted,
        "removedChars": removed,
        "historyChars": current,
    }


async def _content_to_anthropic(
    content: tuple[ContentBlock, ...],
    assets: AssetStorePort | None,
    *,
    max_asset_bytes: int,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    total_asset_bytes = 0
    for block in content:
        if isinstance(block, TextBlock):
            result.append({"type": "text", "text": block.text})
        elif isinstance(block, ReasoningBlock):
            result.append({"type": "text", "text": block.text})
        elif isinstance(block, JsonBlock):
            result.append(
                {"type": "text", "text": _canonical_anthropic_json(block.value, "JSON input")}
            )
        elif isinstance(block, ImageRefBlock):
            if assets is None:
                raise ValueError("Anthropic image input requires an AssetStorePort")
            if block.media_type not in _ANTHROPIC_IMAGE_MEDIA_TYPES:
                raise ValueError(f"Anthropic does not support image media type {block.media_type}")
            remaining = max_asset_bytes - total_asset_bytes
            if remaining < 1:
                raise ValueError(
                    f"Assets exceed the configured {max_asset_bytes}-byte Runtime input limit"
                )
            image = await read_asset_bytes(
                assets,
                block.asset_id,
                expected_media_type=block.media_type,
                max_bytes=remaining,
                aggregate_max_bytes=max_asset_bytes,
            )
            total_asset_bytes += len(image)
            result.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": block.media_type,
                        "data": base64.b64encode(image).decode("ascii"),
                    },
                }
            )
        else:
            raise ValueError(f"Anthropic Messages does not support {block.type} input")
    return result


def _plain_system(content: tuple[ContentBlock, ...]) -> str:
    parts: list[str] = []
    for block in content:
        if isinstance(block, (TextBlock, ReasoningBlock)):
            parts.append(block.text)
        elif isinstance(block, JsonBlock):
            parts.append(_canonical_anthropic_json(block.value, "system JSON"))
        else:
            raise ValueError("Anthropic system prompt only supports text, reasoning, and JSON blocks")
    return "\n\n".join(parts)


async def _tool_result_to_anthropic(
    result: ToolResult,
    assets: AssetStorePort | None,
    *,
    max_asset_bytes: int,
) -> dict[str, Any]:
    content: list[dict[str, Any]] = []
    total_asset_bytes = 0
    for block in result.content:
        if isinstance(block, TextBlock):
            content.append({"type": "text", "text": block.text})
        elif isinstance(block, ReasoningBlock):
            content.append({"type": "text", "text": block.text})
        elif isinstance(block, JsonBlock):
            content.append(
                {
                    "type": "text",
                    "text": _canonical_anthropic_json(block.value, "tool result JSON"),
                }
            )
        elif isinstance(block, ImageRefBlock):
            if assets is None:
                raise ValueError("Anthropic image tool result requires an AssetStorePort")
            if block.media_type not in _ANTHROPIC_IMAGE_MEDIA_TYPES:
                raise ValueError(f"Anthropic does not support image media type {block.media_type}")
            remaining = max_asset_bytes - total_asset_bytes
            if remaining < 1:
                raise ValueError(
                    f"Assets exceed the configured {max_asset_bytes}-byte Runtime input limit"
                )
            image = await read_asset_bytes(
                assets,
                block.asset_id,
                expected_media_type=block.media_type,
                max_bytes=remaining,
                aggregate_max_bytes=max_asset_bytes,
            )
            total_asset_bytes += len(image)
            content.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": block.media_type,
                        "data": base64.b64encode(image).decode("ascii"),
                    },
                }
            )
        else:
            content.append(
                {
                    "type": "text",
                    "text": _canonical_anthropic_json(
                        block.model_dump(mode="json", by_alias=True),
                        "tool result content",
                    ),
                }
            )
    if not content and result.value is not None:
        content.append(
            {"type": "text", "text": _canonical_anthropic_json(result.value, "tool result value")}
        )
    if result.error is not None:
        content.append({"type": "text", "text": result.error.message})
    payload = {
        "type": "tool_result",
        "tool_use_id": result.call_id,
        "content": content or [{"type": "text", "text": ""}],
        "is_error": result.error is not None,
    }
    _require_finite_json(payload, "tool result")
    return payload


def _canonical_anthropic_json(value: object, field_name: str) -> str:
    _require_finite_json(value, field_name)
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )
