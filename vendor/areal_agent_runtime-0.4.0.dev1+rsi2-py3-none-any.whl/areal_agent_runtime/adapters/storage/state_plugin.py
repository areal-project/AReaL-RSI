"""Independent SQLite StateStore plugin, reusable without replacing media/sinks."""

from __future__ import annotations

from pydantic import JsonValue

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.adapters.storage.sqlite_state import SQLiteStateStore
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class SQLiteStateStorePlugin:
    manifest = PluginManifest(
        name="sqlite-state", version="1.0.0", implements=(PortKey.STATE_STORE,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.storage.state_plugin:create_plugin"),
        config_schema="state.schema.json", permissions=("filesystem.read", "filesystem.write"),
    )

    def __init__(self) -> None:
        self.state_store: SQLiteStateStore | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        root = config.get("root")
        if not isinstance(root, str) or not root or root != root.strip():
            raise ValueError("SQLite state plugin requires a trimmed config.root")
        page_max_bytes = config.get("pageMaxBytes", 8 * 1024 * 1024)
        if isinstance(page_max_bytes, bool) or not isinstance(page_max_bytes, int) or page_max_bytes < 1:
            raise ValueError("SQLite state plugin pageMaxBytes must be a positive integer")
        self.state_store = await run_blocking_io(SQLiteStateStore, root, page_max_bytes=page_max_bytes)
        context.provide(PortKey.STATE_STORE, self.state_store)

    async def start(self) -> None:
        if self.state_store is None:
            raise RuntimeError("SQLite state plugin is not configured")

    async def health(self) -> HealthStatus:
        return HealthStatus(status="healthy" if self.state_store is not None else "unhealthy")

    async def stop(self) -> None:
        return None


def create_plugin() -> SQLiteStateStorePlugin:
    return SQLiteStateStorePlugin()
