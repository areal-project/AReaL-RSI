"""Plugin packaging for Bridge artifact publication."""

from __future__ import annotations

import math

from pydantic import JsonValue

from areal_agent_runtime.adapters.bridge.publisher import (
    BridgeArtifactPublisher,
    BridgeHttpClient,
    BridgePublisherConfig,
)
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class BridgeArtifactPublisherPlugin:
    manifest = PluginManifest(
        name="bridge-artifact-publisher",
        version="1.0.0",
        implements=(PortKey.ARTIFACT_PUBLISHER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.bridge.plugin:create_plugin"),
        config_schema="publisher.config.schema.json",
        permissions=("network.bridge", "artifact.read"),
    )

    def __init__(self) -> None:
        self.publisher: BridgeArtifactPublisher | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        endpoint = config.get("endpoint")
        if not isinstance(endpoint, str) or not endpoint:
            raise ValueError("bridge-artifact-publisher requires config.endpoint")
        timeout_seconds = float(config.get("timeoutSeconds") or 60)
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("bridge-artifact-publisher timeoutSeconds must be positive and finite")
        client = BridgeHttpClient(
            BridgePublisherConfig(
                endpoint=endpoint,
                token=_optional_string(config.get("token")),
                headers=_string_map(config.get("headers")),
                timeout_seconds=timeout_seconds,
            )
        )
        self.publisher = BridgeArtifactPublisher(client)
        context.provide(PortKey.ARTIFACT_PUBLISHER, self.publisher)

    async def start(self) -> None:
        if self.publisher is None:
            raise RuntimeError("Bridge plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.publisher is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.publisher.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> BridgeArtifactPublisherPlugin:
    return BridgeArtifactPublisherPlugin()


def _optional_string(value: JsonValue | None) -> str | None:
    return value if isinstance(value, str) and value else None


def _string_map(value: JsonValue | None) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(key): item for key, item in value.items() if isinstance(item, str)}
