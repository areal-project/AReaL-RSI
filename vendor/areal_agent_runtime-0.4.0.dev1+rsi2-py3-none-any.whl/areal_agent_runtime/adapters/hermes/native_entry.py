"""Standalone Hermes 0.17 Gateway bootstrap; runs in the vendor interpreter.

This file intentionally imports no Runtime package. Hermes remains responsible
for model calls, native tool execution, approvals, transcripts and interrupts.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import os
import sys
from contextvars import ContextVar
from functools import wraps
from pathlib import Path
from typing import Any


def _install_completion_projection(agent_class: Any, server: Any) -> None:
    """Preserve native empty-response failure across Gateway's display projection."""
    native_run = agent_class.run_conversation
    native_emit = server._emit
    failure: ContextVar[str | None] = ContextVar("areal_hermes_completion_failure", default=None)

    @wraps(native_run)
    def run(agent: Any, *args: Any, **kwargs: Any) -> Any:
        failure.set(None)
        result = native_run(agent, *args, **kwargs)
        exhausted = (
            isinstance(result, dict)
            and not result.get("interrupted")
            and result.get("turn_exit_reason") == "empty_response_exhausted"
        )
        failure.set("MODEL_FINAL_ANSWER_REQUIRED" if exhausted else None)
        return result

    def emit(event: str, sid: str, payload: dict[str, Any] | None = None) -> Any:
        reason = failure.get()
        if event == "message.complete" and reason is not None:
            # The native finalizer can replace '(empty)' with a diagnostic.
            # It is a failed model response, not assistant-authored text.
            payload = {**(payload or {}), "status": "error", "failure_reason": reason, "text": ""}
            payload.pop("rendered", None)
            payload.pop("response", None)
            failure.set(None)
        return native_emit(event, sid, payload)

    agent_class.run_conversation = run
    server._emit = emit


def install(manifest_path: Path) -> None:
    raw = manifest_path.read_bytes()
    if len(raw) > 16 * 1024 * 1024:
        raise ValueError("Hermes native manifest exceeds 16 MiB")
    manifest = json.loads(raw)
    if manifest.get("version") != 1:
        raise ValueError("Unsupported Hermes native manifest version")
    import hermes_bootstrap

    hermes_bootstrap.harden_import_path()
    import hermes_constants

    documents = manifest.get("skills")
    allowed_documents: dict[str, tuple[Path, str]] = {}
    if documents is not None:
        skill_root = manifest_path.parent / "skills"
        skill_root.mkdir(mode=0o700)
        for item in documents:
            name, document = item["name"], item["document"]
            target = skill_root / name / "SKILL.md"
            target.parent.mkdir(mode=0o700)
            target.touch(mode=0o600)
            target.write_text(document, encoding="utf-8")
            allowed_documents[name] = (target, hashlib.sha256(target.read_bytes()).hexdigest())
        # Patch before any native importer binds aliases to get_skills_dir.
        hermes_constants.get_skills_dir = lambda: skill_root
        from agent import skill_utils

        skill_utils.get_skills_dir = lambda: skill_root
        skill_utils.get_external_skills_dirs = lambda: []
        from tools import skills_tool

        skills_tool.SKILLS_DIR = skill_root
        native_view = skills_tool.skill_view
        native_list = skills_tool.skills_list

        def verify() -> None:
            for path, digest in allowed_documents.values():
                if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                    raise ValueError("Hermes immutable skill snapshot changed")

        def view(name: str, file_path: str | None = None, task_id: str | None = None, **_: Any) -> str:
            if name not in allowed_documents or file_path is not None:
                return json.dumps({"success": False, "error": "Skill is outside the Runtime snapshot"})
            verify()
            # Upstream resource text is data. Native inline-shell templating
            # must never execute commands merely by loading that text.
            return native_view(name, task_id=task_id, preprocess=False)

        def listing(category: str | None = None, task_id: str | None = None) -> str:
            verify()
            return native_list(category=category, task_id=task_id)

        skills_tool.skill_view = view
        skills_tool.skills_list = listing
        original_iter = skill_utils.iter_skill_index_files

        def index_files(root: Path, filename: str):  # type: ignore[no-untyped-def]
            verify()
            allowed = {path for path, _ in allowed_documents.values()}
            return (path for path in original_iter(root, filename) if path in allowed)

        skill_utils.iter_skill_index_files = index_files
        from agent import prompt_builder

        prompt_builder.iter_skill_index_files = index_files
        # Exclude skill_manage using Hermes' own toolset resolution and
        # execution validation. This is a read-only resource snapshot.
        import toolsets

        toolsets.TOOLSETS["areal-snapshot-write"] = {
            "description": "Immutable Runtime skill snapshot",
            "tools": ["skill_manage"],
            "includes": [],
        }

    import run_agent
    from tui_gateway import entry, server

    signature = inspect.signature(run_agent.AIAgent.__init__)
    if "ephemeral_system_prompt" not in signature.parameters or not hasattr(server, "_make_agent"):
        raise RuntimeError("Installed Hermes does not support the required native system API")
    native_init = run_agent.AIAgent.__init__
    system = manifest.get("system") or ""
    selected = manifest.get("toolsets")
    if selected is not None:
        from toolsets import validate_toolset

        unknown = [name for name in selected if not validate_toolset(name)]
        if unknown:
            raise ValueError("Unknown Hermes nativeToolsets: " + ", ".join(unknown))

    @wraps(native_init)
    def initialize(agent: Any, *args: Any, **kwargs: Any) -> None:
        if system:
            kwargs["ephemeral_system_prompt"] = "\n\n".join(
                value for value in (kwargs.get("ephemeral_system_prompt"), system) if value
            )
        if selected is not None:
            kwargs["enabled_toolsets"] = list(selected)
        if documents is not None:
            kwargs["disabled_toolsets"] = [*(kwargs.get("disabled_toolsets") or []), "areal-snapshot-write"]
        native_init(agent, *args, **kwargs)

    run_agent.AIAgent.__init__ = initialize
    _install_completion_projection(run_agent.AIAgent, server)

    @server.method("areal.native.info")
    def info(rid: Any, params: dict[str, Any]) -> dict[str, Any]:
        del params
        return server._ok(rid, {"version": 1, "system": "ephemeral_system_prompt", "skills": "native-filesystem"})

    # The native startup-skill option eagerly inserts full skill text in the
    # system prompt; it cannot be combined with snapshot progressive loading.
    if documents is not None:
        os.environ.pop("HERMES_TUI_SKILLS", None)
    entry.main()


if __name__ == "__main__":
    try:
        install(Path(sys.argv[1]))
    except Exception:
        # Do not echo vendor exception strings: installed config may contain
        # credentials. A bounded protocol error makes startup fail immediately.
        print(
            json.dumps(
                {
                    "jsonrpc": "2.0",
                    "method": "event",
                    "params": {"type": "gateway.error", "payload": {"code": "native_bootstrap_failed"}},
                }
            ),
            flush=True,
        )
        raise SystemExit(1) from None
