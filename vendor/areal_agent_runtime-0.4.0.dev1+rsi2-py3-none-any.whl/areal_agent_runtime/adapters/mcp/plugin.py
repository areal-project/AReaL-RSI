"""Plugin packaging for a policy-constrained Generic MCP ToolProvider."""

from __future__ import annotations

import math
import os
import re
from typing import cast
from urllib.parse import urlsplit

from pydantic import JsonValue, TypeAdapter

from areal_agent_runtime.adapters.mcp.provider import (
    GenericMcpConfig,
    GenericMcpToolProvider,
    OfficialStreamableHttpMcpClient,
    streamable_http_binding,
)
from areal_agent_runtime.contracts.environment import SecretRef
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey

_HEADER_NAME_RE = re.compile(r"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")


class GenericMcpPlugin:
    manifest = PluginManifest(
        name="generic-mcp",
        version="1.0.0",
        implements=(PortKey.TOOL_PROVIDER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.mcp.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("network.mcp", "asset.write", "secret.read"),
    )

    def __init__(self) -> None:
        self.provider: GenericMcpToolProvider | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        url = config.get("url")
        if not isinstance(url, str) or not url or url != url.strip():
            raise ValueError("generic-mcp requires config.url")
        try:
            parsed = urlsplit(url)
            port = parsed.port
        except ValueError as exc:
            raise PermissionError("generic-mcp URL is invalid") from exc
        if (
            parsed.scheme != "https"
            or parsed.hostname is None
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or port is not None and not 1 <= port <= 65535
        ):
            raise PermissionError("generic-mcp URL must be credential-free HTTPS")
        if config.get("headers") is not None:
            raise PermissionError("generic-mcp credentials must use headerSecretRefs, not literal headers")
        server_name = _optional_string(config.get("serverName"), "serverName") or "mcp"
        allowed = _allowed_tools(config.get("allowedTools"))
        timeout_seconds = _positive_number(config.get("timeoutSeconds"), 120.0, "timeoutSeconds")
        headers, secret_refs = _resolve_header_secrets(config.get("headerSecretRefs"))
        mcp_config = GenericMcpConfig(
            url=url,
            server_name=server_name,
            headers=headers,
            allowed_tools=allowed,
            timeout_seconds=timeout_seconds,
            verify_tls=True,
            secret_refs=secret_refs,
            max_tools=_positive_integer(config.get("maxTools"), 1024, "maxTools"),
            max_content_items=_positive_integer(
                config.get("maxContentItems"),
                256,
                "maxContentItems",
            ),
            max_result_bytes=_positive_integer(
                config.get("maxResultBytes"),
                16 * 1024 * 1024,
                "maxResultBytes",
            ),
            max_asset_bytes=_positive_integer(
                config.get("maxAssetBytes"),
                8 * 1024 * 1024,
                "maxAssetBytes",
            ),
        )
        self.provider = GenericMcpToolProvider(
            OfficialStreamableHttpMcpClient(mcp_config),
            server_name=server_name,
            allowed_tools=allowed,
            asset_store=_optional_asset_store(context),
            binding=streamable_http_binding(mcp_config),
            max_tools=mcp_config.max_tools,
            max_content_items=mcp_config.max_content_items,
            max_result_bytes=mcp_config.max_result_bytes,
            max_asset_bytes=mcp_config.max_asset_bytes,
        )
        context.provide(PortKey.TOOL_PROVIDER, self.provider)

    async def start(self) -> None:
        if self.provider is None:
            raise RuntimeError("generic-mcp is not configured")

    async def health(self) -> HealthStatus:
        if self.provider is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.provider.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> GenericMcpPlugin:
    return GenericMcpPlugin()


def _resolve_header_secrets(value: JsonValue | None) -> tuple[dict[str, str], tuple[SecretRef, ...]]:
    if value is None:
        return {}, ()
    if not isinstance(value, dict):
        raise ValueError("headerSecretRefs must be an object")
    headers: dict[str, str] = {}
    refs: list[SecretRef] = []
    for header, raw_ref in value.items():
        if not isinstance(header, str) or _HEADER_NAME_RE.fullmatch(header) is None:
            raise ValueError("headerSecretRefs keys must be safe HTTP header names")
        ref = TypeAdapter(SecretRef).validate_python(raw_ref)
        if ref.provider != "env":
            raise ValueError(f"unsupported SecretRef provider: {ref.provider}")
        try:
            secret = os.environ[ref.key]
        except KeyError as exc:
            raise RuntimeError(f"SecretRef is unavailable: {ref.name}") from exc
        if "\r" in secret or "\n" in secret:
            raise ValueError(f"SecretRef contains an unsafe HTTP header value: {ref.name}")
        headers[header] = secret
        refs.append(ref)
    names = [ref.name for ref in refs]
    if len(names) != len(set(names)):
        raise ValueError("headerSecretRefs must not repeat SecretRef names")
    return headers, tuple(refs)


def _allowed_tools(value: JsonValue | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item or item != item.strip() for item in value
    ):
        raise ValueError("allowedTools must be an array of trimmed non-empty strings")
    if len(value) != len(set(value)):
        raise ValueError("allowedTools must not contain duplicates")
    return tuple(value)


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _optional_string(value: JsonValue | None, name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError(f"{name} must be a trimmed non-empty string")
    return value


def _positive_number(value: JsonValue | None, default: float, name: str) -> float:
    if value is None:
        return default
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise ValueError(f"{name} must be a positive finite number")
    return float(value)


def _positive_integer(value: JsonValue | None, default: int, name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value
