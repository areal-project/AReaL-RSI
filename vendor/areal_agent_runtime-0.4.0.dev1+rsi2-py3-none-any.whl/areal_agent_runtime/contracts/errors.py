"""Stable errors crossing Host and Runtime boundaries."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, JsonValue, StrictBool, field_validator

from areal_agent_runtime.contracts.base import ContractModel, require_trimmed


class ErrorCategory(StrEnum):
    INVALID_REQUEST = "invalid_request"
    AUTHENTICATION = "authentication"
    PERMISSION = "permission"
    NOT_FOUND = "not_found"
    CONFLICT = "conflict"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"
    UNAVAILABLE = "unavailable"
    PROTOCOL = "protocol"
    INTERNAL = "internal"


class ErrorInfo(ContractModel):
    code: str = Field(min_length=1)
    category: ErrorCategory
    message: str = Field(min_length=1)
    retryable: StrictBool = False
    details: dict[str, JsonValue] = Field(default_factory=dict)
    cause: str | None = None

    @field_validator("code")
    @classmethod
    def validate_code(cls, value: str) -> str:
        return require_trimmed(value, "error code")

    @field_validator("message")
    @classmethod
    def validate_message(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("error message must be non-blank")
        return value


class ContractError(RuntimeError):
    """Python exception carrying a stable ErrorInfo payload."""

    def __init__(self, info: ErrorInfo) -> None:
        super().__init__(info.message)
        self.info = info
