"""Stable Plugin SPI and extension ports for product/plugin authors."""

from areal_agent_runtime.contracts.ports import (
    ArtifactPublisherPort,
    AssetStorePort,
    EnvironmentPort,
    EventSinkPort,
    ResourceLoaderPort,
    StateStorePort,
    StateStoreQueryPort,
    ToolProviderPort,
)
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.contracts.version import PLUGIN_API_VERSION
from areal_agent_runtime.plugin_sdk.contracts import (
    Plugin,
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)
from areal_agent_runtime.plugin_sdk.loader import PluginManager, PluginPermissionPolicy, ServiceRegistry

__all__ = [
    "ArtifactPublisherPort",
    "AssetStorePort",
    "EnvironmentPort",
    "EventSinkPort",
    "HealthStatus",
    "Plugin",
    "PluginContext",
    "PluginEntrypoints",
    "PluginManager",
    "PluginManifest",
    "PluginPermissionPolicy",
    "PLUGIN_API_VERSION",
    "PortKey",
    "ResourceLoaderPort",
    "ServiceRegistry",
    "StateStorePort",
    "StateStoreQueryPort",
    "ToolProviderPort",
]
