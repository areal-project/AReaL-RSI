"""First-class, vendor-neutral Agent environment sources and immutable snapshots."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from enum import StrEnum
from pathlib import PurePosixPath
from typing import Annotated, Literal

from pydantic import Field, JsonValue, StrictBool, field_validator, model_validator

from areal_agent_runtime.contracts.base import (
    ContractModel,
    require_media_type,
    require_optional_trimmed,
    require_trimmed,
    require_unique_trimmed,
)
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.tools import ToolSpec

_RESOURCE_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9._:/-]*$"
_PROVIDER_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9._:-]*$"
_SHA256_PATTERN = r"^[a-fA-F0-9]{64}$"
_EXTENSION_KEY_PATTERN = (
    r"^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?/"
    r"[a-z0-9][a-z0-9._-]*/v[1-9][0-9]*$"
)


class PromptResolutionMode(StrEnum):
    """How the four deterministic source layers are selected."""

    FALLBACK = "fallback"
    MERGE = "merge"
    REPLACE = "replace"


class ResourceLayer(StrEnum):
    BUILTIN = "builtin"
    RELEASE_PROFILE = "release_profile"
    HOST_MOUNT = "host_mount"
    INVOCATION = "invocation"


class ResourceCategory(StrEnum):
    SYSTEM_PROMPT = "system_prompt"
    SKILL = "skill"
    TOOL_SOURCE = "tool_source"
    MCP_SOURCE = "mcp_source"


class ResourceSourceBase(ContractModel):
    resource_id: str = Field(min_length=1, max_length=256, pattern=_RESOURCE_ID_PATTERN)
    version: str | None = Field(default=None, max_length=128)
    media_type: str = Field(default="text/plain", min_length=1, max_length=128)
    expected_sha256: str | None = Field(default=None, pattern=_SHA256_PATTERN)

    @field_validator("expected_sha256")
    @classmethod
    def normalize_expected_sha256(cls, value: str | None) -> str | None:
        return value.lower() if value is not None else None

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "ResourceSource version")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value)


class BuiltinResourceSource(ResourceSourceBase):
    kind: Literal["builtin"] = "builtin"


class InlineResourceSource(ResourceSourceBase):
    kind: Literal["inline"] = "inline"
    content: JsonValue


class ArtifactResourceSource(ResourceSourceBase):
    kind: Literal["artifact"] = "artifact"
    artifact_id: str = Field(min_length=1, max_length=512)

    @field_validator("artifact_id")
    @classmethod
    def validate_artifact_id(cls, value: str) -> str:
        return require_trimmed(value, "artifactId")


class UriResourceSource(ResourceSourceBase):
    kind: Literal["uri"] = "uri"
    uri: str = Field(min_length=1, max_length=4096)

    @field_validator("uri")
    @classmethod
    def validate_uri(cls, value: str) -> str:
        return require_trimmed(value, "Resource URI")


class MountResourceSource(ResourceSourceBase):
    kind: Literal["mount"] = "mount"
    mount_id: str = Field(min_length=1, max_length=128, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    relative_path: str = Field(min_length=1, max_length=1024)

    @field_validator("relative_path")
    @classmethod
    def validate_relative_path(cls, value: str) -> str:
        if "\\" in value or "\x00" in value:
            raise ValueError("relativePath must use a portable POSIX path")
        path = PurePosixPath(value)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts) or path.as_posix() != value:
            raise ValueError("relativePath must stay within its logical mount")
        return value


ResourceSource = Annotated[
    BuiltinResourceSource | InlineResourceSource | ArtifactResourceSource | UriResourceSource | MountResourceSource,
    Field(discriminator="kind"),
]


class SecretRef(ContractModel):
    """Opaque credential identity. Secret values never enter a Runtime DTO or trajectory."""

    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    provider: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    key: str = Field(min_length=1, max_length=512)
    version: str | None = Field(default=None, max_length=128)

    @field_validator("key")
    @classmethod
    def validate_key(cls, value: str) -> str:
        return require_trimmed(value, "SecretRef key")

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "SecretRef version")


class ToolSourceSpec(ContractModel):
    source: ResourceSource
    provider: str = Field(min_length=1, max_length=128, pattern=_PROVIDER_ID_PATTERN)
    tool_names: tuple[str, ...] = Field(min_length=1)
    allowed_permissions: tuple[str, ...] = ()
    required: StrictBool = True

    @field_validator("tool_names", "allowed_permissions")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return require_unique_trimmed(value, f"ToolSourceSpec {info.field_name}")


class McpTransport(StrEnum):
    STREAMABLE_HTTP = "streamable_http"
    STDIO = "stdio"


class McpSourceSpec(ContractModel):
    source: ResourceSource
    server_id: str = Field(min_length=1, max_length=128, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    provider: str = Field(
        default="generic-mcp",
        min_length=1,
        max_length=128,
        pattern=_PROVIDER_ID_PATTERN,
    )
    transport: McpTransport = McpTransport.STREAMABLE_HTTP
    endpoint: str | None = Field(default=None, max_length=4096)
    executable: MountResourceSource | None = None
    arguments: tuple[str, ...] = ()
    secret_refs: tuple[SecretRef, ...] = ()
    tool_names: tuple[str, ...] = Field(min_length=1)
    allowed_permissions: tuple[str, ...] = ()
    required: StrictBool = True

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "MCP endpoint")

    @field_validator("tool_names", "allowed_permissions")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return require_unique_trimmed(value, f"McpSourceSpec {info.field_name}")

    @field_validator("arguments")
    @classmethod
    def validate_arguments(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any("\x00" in argument for argument in value):
            raise ValueError("MCP arguments cannot contain NUL")
        return value

    @model_validator(mode="after")
    def validate_transport_fields(self) -> McpSourceSpec:
        secret_names = [item.name for item in self.secret_refs]
        if len(secret_names) != len(set(secret_names)):
            raise ValueError("MCP SecretRef names must be unique")
        if self.transport == McpTransport.STREAMABLE_HTTP:
            if self.endpoint is None:
                raise ValueError("streamable_http MCP requires endpoint")
            if self.executable is not None:
                raise ValueError("streamable_http MCP cannot declare executable")
        else:
            if self.executable is None:
                raise ValueError("stdio MCP requires a mount executable")
            if self.endpoint is not None:
                raise ValueError("stdio MCP cannot declare endpoint")
            if self.executable.expected_sha256 is None:
                raise ValueError("stdio MCP executable requires expectedSha256")
        return self


class McpProviderBinding(ContractModel):
    """Credential-free identity asserted by an installed MCP ToolProvider."""

    server_id: str = Field(min_length=1, max_length=128, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    transport: McpTransport
    endpoint: str | None = Field(default=None, max_length=4096)
    executable_sha256: str | None = Field(default=None, pattern=_SHA256_PATTERN)
    secret_refs: tuple[SecretRef, ...] = ()

    @field_validator("executable_sha256")
    @classmethod
    def normalize_executable_sha256(cls, value: str | None) -> str | None:
        return value.lower() if value is not None else None

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "MCP binding endpoint")

    @model_validator(mode="after")
    def validate_transport_identity(self) -> McpProviderBinding:
        secret_names = [item.name for item in self.secret_refs]
        if len(secret_names) != len(set(secret_names)):
            raise ValueError("MCP binding SecretRef names must be unique")
        if self.transport == McpTransport.STREAMABLE_HTTP:
            if self.endpoint is None or self.executable_sha256 is not None:
                raise ValueError("streamable_http binding requires only endpoint")
        elif self.endpoint is not None or self.executable_sha256 is None:
            raise ValueError("stdio binding requires only executableSha256")
        return self


class AgentEnvironmentLayer(ContractModel):
    system_prompts: tuple[ResourceSource, ...] = ()
    skills: tuple[ResourceSource, ...] = ()
    tool_sources: tuple[ToolSourceSpec, ...] = ()
    mcp_sources: tuple[McpSourceSpec, ...] = ()

    @model_validator(mode="after")
    def validate_unique_sources(self) -> AgentEnvironmentLayer:
        collections = {
            "systemPrompts": self.system_prompts,
            "skills": self.skills,
            "toolSources": self.tool_sources,
            "mcpSources": self.mcp_sources,
        }
        for field, values in collections.items():
            identities = [
                item.source.resource_id
                if isinstance(item, (ToolSourceSpec, McpSourceSpec))
                else item.resource_id
                for item in values
            ]
            if len(identities) != len(set(identities)):
                raise ValueError(f"AgentEnvironmentLayer {field} resourceId values must be unique")
        server_ids = [item.server_id for item in self.mcp_sources]
        if len(server_ids) != len(set(server_ids)):
            raise ValueError("AgentEnvironmentLayer MCP serverId values must be unique")
        return self


class ExtensionSpec(ContractModel):
    key: str = Field(min_length=1, max_length=256, pattern=_EXTENSION_KEY_PATTERN)
    value: JsonValue = None
    required: StrictBool = False


class AgentEnvironmentSpec(ContractModel):
    """Unresolved CreateSession/Run input. No vendor DTOs or physical Host paths."""

    prompt_resolution: PromptResolutionMode = PromptResolutionMode.FALLBACK
    builtin: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    release_profile: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    host_mount: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    invocation: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    extensions: tuple[ExtensionSpec, ...] = ()

    @model_validator(mode="after")
    def unique_extensions(self) -> AgentEnvironmentSpec:
        keys = [item.key for item in self.extensions]
        if len(keys) != len(set(keys)):
            raise ValueError("agent environment extension keys must be unique")
        return self


class ResolvedResourceSnapshot(ContractModel):
    resource_id: str = Field(min_length=1)
    category: ResourceCategory
    layer: ResourceLayer
    kind: Literal["builtin", "inline", "artifact", "uri", "mount"]
    version: str = Field(min_length=1)
    media_type: str = Field(min_length=1)
    sha256: str = Field(pattern=_SHA256_PATTERN)
    locator: str = Field(min_length=1)
    content: JsonValue

    @field_validator("resource_id", "version", "media_type", "locator")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Resolved resource identity")

    @field_validator("sha256")
    @classmethod
    def normalize_sha256(cls, value: str) -> str:
        return value.lower()


class ResolvedToolSourceSnapshot(ContractModel):
    resource: ResolvedResourceSnapshot
    provider: str = Field(min_length=1)
    provider_version: str = Field(min_length=1)
    tool_names: tuple[str, ...] = Field(min_length=1)
    allowed_permissions: tuple[str, ...] = ()
    required: StrictBool = True

    @field_validator("provider", "provider_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Resolved tool source identity")

    @field_validator("tool_names", "allowed_permissions")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return require_unique_trimmed(value, f"Resolved tool source {info.field_name}")


class ResolvedMcpSourceSnapshot(ContractModel):
    resource: ResolvedResourceSnapshot
    server_id: str = Field(min_length=1)
    provider: str = Field(min_length=1)
    provider_version: str = Field(min_length=1)
    transport: McpTransport
    endpoint: str | None = None
    executable: ResolvedResourceSnapshot | None = None
    arguments: tuple[str, ...] = ()
    secret_refs: tuple[SecretRef, ...] = ()
    tool_names: tuple[str, ...] = Field(min_length=1)
    allowed_permissions: tuple[str, ...] = ()
    required: StrictBool = True

    @field_validator("server_id", "provider", "provider_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Resolved MCP source identity")

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Resolved MCP endpoint")

    @field_validator("tool_names", "allowed_permissions")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return require_unique_trimmed(value, f"Resolved MCP source {info.field_name}")

    @field_validator("arguments")
    @classmethod
    def validate_arguments(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any("\x00" in argument for argument in value):
            raise ValueError("Resolved MCP arguments cannot contain NUL")
        return value

    @model_validator(mode="after")
    def validate_transport_fields(self) -> ResolvedMcpSourceSnapshot:
        names = [item.name for item in self.secret_refs]
        if len(names) != len(set(names)):
            raise ValueError("Resolved MCP SecretRef names must be unique")
        if self.transport == McpTransport.STREAMABLE_HTTP:
            if self.endpoint is None or self.executable is not None:
                raise ValueError("Resolved streamable_http MCP requires only endpoint")
        elif self.endpoint is not None or self.executable is None:
            raise ValueError("Resolved stdio MCP requires only executable")
        return self


class ToolCatalogEntrySnapshot(ContractModel):
    provider: str = Field(min_length=1)
    provider_version: str = Field(min_length=1)
    spec: ToolSpec
    schema_sha256: str = Field(pattern=_SHA256_PATTERN)

    @field_validator("provider", "provider_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Tool catalog identity")

    @field_validator("schema_sha256")
    @classmethod
    def normalize_schema_sha256(cls, value: str) -> str:
        return value.lower()

    @model_validator(mode="after")
    def validate_schema_digest(self) -> ToolCatalogEntrySnapshot:
        if self.schema_sha256 != _json_digest(self.spec.input_schema):
            raise ValueError("Tool catalog schemaSha256 does not match inputSchema")
        return self


class RuntimeIdentitySnapshot(ContractModel):
    name: str = Field(min_length=1)
    runtime_version: str = Field(min_length=1)
    adapter_version: str = Field(min_length=1)
    capabilities_sha256: str = Field(pattern=_SHA256_PATTERN)

    @field_validator("name", "runtime_version", "adapter_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Runtime identity snapshot")

    @field_validator("capabilities_sha256")
    @classmethod
    def normalize_capabilities_sha256(cls, value: str) -> str:
        return value.lower()


class AgentEnvironmentSnapshot(ContractModel):
    """Fully materialized immutable Session input and trajectory provenance record."""

    snapshot_id: str = Field(min_length=1)
    digest: str = Field(pattern=_SHA256_PATTERN)
    spec_digest: str = Field(pattern=_SHA256_PATTERN)
    prompt_resolution: PromptResolutionMode
    system_prompts: tuple[ResolvedResourceSnapshot, ...] = ()
    skills: tuple[ResolvedResourceSnapshot, ...] = ()
    tool_sources: tuple[ResolvedToolSourceSnapshot, ...] = ()
    mcp_sources: tuple[ResolvedMcpSourceSnapshot, ...] = ()
    tool_catalog: tuple[ToolCatalogEntrySnapshot, ...] = ()
    runtime: RuntimeIdentitySnapshot | None = None
    extensions: tuple[ExtensionSpec, ...] = ()

    @field_validator("snapshot_id")
    @classmethod
    def validate_snapshot_id(cls, value: str) -> str:
        return require_trimmed(value, "Agent environment snapshotId")

    @field_validator("digest", "spec_digest")
    @classmethod
    def normalize_digest(cls, value: str) -> str:
        return value.lower()

    @classmethod
    def create(
        cls,
        *,
        spec_digest: str,
        prompt_resolution: PromptResolutionMode,
        system_prompts: tuple[ResolvedResourceSnapshot, ...] = (),
        skills: tuple[ResolvedResourceSnapshot, ...] = (),
        tool_sources: tuple[ResolvedToolSourceSnapshot, ...] = (),
        mcp_sources: tuple[ResolvedMcpSourceSnapshot, ...] = (),
        tool_catalog: tuple[ToolCatalogEntrySnapshot, ...] = (),
        runtime: RuntimeIdentitySnapshot | None = None,
        extensions: tuple[ExtensionSpec, ...] = (),
    ) -> AgentEnvironmentSnapshot:
        digest = _snapshot_digest(
            spec_digest=spec_digest,
            prompt_resolution=prompt_resolution,
            system_prompts=system_prompts,
            skills=skills,
            tool_sources=tool_sources,
            mcp_sources=mcp_sources,
            tool_catalog=tool_catalog,
            runtime=runtime,
            extensions=extensions,
        )
        return cls(
            snapshot_id=f"env_{digest[:24]}",
            digest=digest,
            spec_digest=spec_digest,
            prompt_resolution=prompt_resolution,
            system_prompts=system_prompts,
            skills=skills,
            tool_sources=tool_sources,
            mcp_sources=mcp_sources,
            tool_catalog=tool_catalog,
            runtime=runtime,
            extensions=extensions,
        )

    @model_validator(mode="after")
    def validate_digest(self) -> AgentEnvironmentSnapshot:
        return self.assert_integrity()

    def assert_integrity(self) -> AgentEnvironmentSnapshot:
        """Recompute the digest so nested JSON mutation cannot bypass frozen fields."""

        self._validate_structure()

        if self.snapshot_id == "env_empty" and self.digest == "0" * 64:
            if (
                self.spec_digest != "0" * 64
                or self.prompt_resolution != PromptResolutionMode.FALLBACK
                or self.system_prompts
                or self.skills
                or self.tool_sources
                or self.mcp_sources
                or self.tool_catalog
                or self.runtime is not None
                or self.extensions
            ):
                raise ValueError("env_empty cannot contain resolved resources")
            return self
        expected = _snapshot_digest(
            spec_digest=self.spec_digest,
            prompt_resolution=self.prompt_resolution,
            system_prompts=self.system_prompts,
            skills=self.skills,
            tool_sources=self.tool_sources,
            mcp_sources=self.mcp_sources,
            tool_catalog=self.tool_catalog,
            runtime=self.runtime,
            extensions=self.extensions,
        )
        if self.digest != expected or self.snapshot_id != f"env_{expected[:24]}":
            raise ValueError("AgentEnvironmentSnapshot digest or snapshotId is invalid")
        return self

    def _validate_structure(self) -> None:
        named_collections = {
            "systemPrompts": [item.resource_id for item in self.system_prompts],
            "skills": [item.resource_id for item in self.skills],
            "toolSources": [item.resource.resource_id for item in self.tool_sources],
            "mcpSources": [item.resource.resource_id for item in self.mcp_sources],
            "MCP serverIds": [item.server_id for item in self.mcp_sources],
            "toolCatalog": [item.spec.name for item in self.tool_catalog],
            "extensions": [item.key for item in self.extensions],
        }
        for field, identities in named_collections.items():
            if len(identities) != len(set(identities)):
                raise ValueError(f"AgentEnvironmentSnapshot {field} identities must be unique")
        for item in self.tool_catalog:
            if item.schema_sha256 != _json_digest(item.spec.input_schema):
                raise ValueError(f"AgentEnvironmentSnapshot tool schema digest is invalid: {item.spec.name}")

    @classmethod
    def empty(cls) -> AgentEnvironmentSnapshot:
        zero = "0" * 64
        return cls(
            snapshot_id="env_empty",
            digest=zero,
            spec_digest=zero,
            prompt_resolution=PromptResolutionMode.FALLBACK,
        )

    @property
    def system(self) -> tuple[ContentBlock, ...]:
        from areal_agent_runtime.contracts.content import JsonBlock, TextBlock

        self.assert_integrity()
        blocks: list[ContentBlock] = []
        for resource in (*self.system_prompts, *self.skills):
            if isinstance(resource.content, str):
                blocks.append(TextBlock(text=resource.content))
            else:
                blocks.append(JsonBlock(value=resource.content, schema_name=resource.category.value))
        return tuple(blocks)

    @property
    def tools(self) -> tuple[ToolSpec, ...]:
        self.assert_integrity()
        return tuple(item.spec for item in self.tool_catalog)

    def trajectory_manifest(self) -> dict[str, JsonValue]:
        """Return replay provenance without copying prompt bodies or credential locators."""

        self.assert_integrity()
        payload = self.model_dump(mode="json", by_alias=True)
        for key in ("systemPrompts", "skills"):
            for resource in payload[key]:
                resource.pop("content", None)
        for source in payload["toolSources"]:
            source["resource"].pop("content", None)
        for source in payload["mcpSources"]:
            source["resource"].pop("content", None)
            executable = source.get("executable")
            if isinstance(executable, dict):
                executable.pop("content", None)
            for secret in source["secretRefs"]:
                secret["key"] = "[REDACTED]"
        for extension in payload["extensions"]:
            extension["valueSha256"] = hashlib.sha256(
                json.dumps(
                    extension.pop("value", None),
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                ).encode("utf-8")
            ).hexdigest()
        return payload


def _snapshot_digest(
    *,
    spec_digest: str,
    prompt_resolution: PromptResolutionMode,
    system_prompts: tuple[ResolvedResourceSnapshot, ...],
    skills: tuple[ResolvedResourceSnapshot, ...],
    tool_sources: tuple[ResolvedToolSourceSnapshot, ...],
    mcp_sources: tuple[ResolvedMcpSourceSnapshot, ...],
    tool_catalog: tuple[ToolCatalogEntrySnapshot, ...],
    runtime: RuntimeIdentitySnapshot | None,
    extensions: tuple[ExtensionSpec, ...],
) -> str:
    payload = {
        "specDigest": spec_digest,
        "promptResolution": prompt_resolution.value,
        "systemPrompts": _json_items(system_prompts),
        "skills": _json_items(skills),
        "toolSources": _json_items(tool_sources),
        "mcpSources": _json_items(mcp_sources),
        "toolCatalog": _json_items(tool_catalog),
        "runtime": _json_model(runtime),
        "extensions": _json_items(extensions),
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _json_digest(value: object) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _json_items(value: Iterable[ContractModel]) -> list[object]:
    return [item.model_dump(mode="json", by_alias=True) for item in value]


def _json_model(value: ContractModel | None) -> object:
    return value.model_dump(mode="json", by_alias=True) if value is not None else None
