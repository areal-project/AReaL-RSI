"""Keep blocking I/O inside its caller's ownership and cleanup boundary."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import ParamSpec, TypeVar

_P = ParamSpec("_P")
_T = TypeVar("_T")


async def run_blocking_io(function: Callable[_P, _T], /, *args: _P.args, **kwargs: _P.kwargs) -> _T:
    """Finish an already started filesystem operation before propagating cancellation.

    Cancelling ``to_thread`` only cancels the waiter. The thread can still use
    files or mutate state after the caller releases its lock. Wait for it here
    so the caller can safely clean up and release ownership. Use this for
    bounded I/O, never for an unbounded worker or a vendor execution loop.
    Resource acquisition must include its cleanup in ``function``: cancellation
    discards a completed result, so returning a newly opened handle would leak it.
    """

    operation = asyncio.create_task(asyncio.to_thread(function, *args, **kwargs))
    try:
        return await asyncio.shield(operation)
    except asyncio.CancelledError as cancellation:
        while not operation.done():
            try:
                await asyncio.shield(operation)
            except asyncio.CancelledError:
                # Repeated cancellation must not bypass the ownership barrier.
                continue
            except BaseException:
                break
        try:
            operation.result()
        except BaseException as error:
            cancellation.add_note(f"Blocking I/O also failed: {type(error).__name__}: {error}")
        raise
