"""Legacy Bridge adapter that publishes release archives through a mounted output directory.

The historical ARealAgentRuntime/Bridge contract is deliberately kept here, outside the
Application layer: Bridge watches ``/output`` for one release archive and one
backup archive whose names share an epoch-millisecond suffix.
"""

from __future__ import annotations

import asyncio
import contextlib
import fcntl
import hashlib
import json
import os
import tempfile
import time
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path

from pydantic import JsonValue, ValidationError

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.contracts.content import FileRefBlock
from areal_agent_runtime.contracts.ports import (
    ArtifactPublishReceipt,
    ArtifactRef,
    AssetStorePort,
)
from areal_agent_runtime.contracts.runtime import HealthStatus


@dataclass(frozen=True, slots=True)
class MountedOutputPublisherConfig:
    output_root: Path = Path("/output")
    create_root: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.output_root, Path):
            raise ValueError("output_root must be a Path")
        if not isinstance(self.create_root, bool):
            raise ValueError("create_root must be a boolean")


@dataclass(frozen=True, slots=True)
class _PublishedFile:
    asset_id: str
    role: str
    path: Path
    md5: str
    sha256: str
    size: int


@dataclass(frozen=True, slots=True)
class _ExpectedFile:
    asset_id: str
    role: str
    path: Path
    sha256: str
    size: int


_PUBLISH_RECORD_SCHEMA = "areal.agent-runtime.bridge-mounted-output-publish/v1"


class MountedOutputArtifactPublisher:
    """Implement the original Bridge filesystem protocol behind ArtifactPublisherPort."""

    def __init__(
        self,
        assets: AssetStorePort,
        config: MountedOutputPublisherConfig | None = None,
        *,
        clock_ms: Callable[[], int] | None = None,
    ) -> None:
        self._assets = assets
        self._config = config or MountedOutputPublisherConfig()
        self._clock_ms = clock_ms or (lambda: int(time.time() * 1000))
        self._lock = asyncio.Lock()

    async def publish(self, artifact: ArtifactRef) -> ArtifactPublishReceipt:
        async with self._lock:
            root = await run_blocking_io(self._prepare_root)
            async with self._output_lock(root):
                selected = self._selected_assets(artifact)
                idempotency_key = self._idempotency_key(artifact)
                record_path = self._record_path(root, idempotency_key) if idempotency_key is not None else None
                record = await run_blocking_io(self._read_record, record_path) if record_path is not None else None
                if record is not None:
                    timestamp = self._validate_record_identity(record, artifact, idempotency_key)
                else:
                    timestamp = self._next_available_timestamp(root)

                expected = await self._expected_files(root, timestamp, selected)
                if record is not None:
                    self._validate_record_files(record, expected)
                    recovered = self._receipt_from_record(record, expected)
                    if recovered is not None:
                        return recovered
                elif record_path is not None:
                    assert idempotency_key is not None
                    await run_blocking_io(
                        self._write_record,
                        record_path,
                        self._record_payload(
                            artifact,
                            idempotency_key,
                            timestamp,
                            expected,
                        ),
                    )

                # Backup becomes visible before release.  The legacy watcher
                # treats release_<timestamp>.tar.gz as the delivery signal, so
                # it can never observe a release without its matching backup.
                published: list[_PublishedFile] = []
                try:
                    for item in sorted(expected, key=lambda value: value.role == "release"):
                        existing = await run_blocking_io(self._verified_existing, item)
                        output = (
                            existing
                            if existing is not None
                            else await self._publish_asset(item)
                        )
                        published.append(output)
                except BaseException:
                    if record_path is None:
                        await asyncio.gather(
                            *(run_blocking_io(item.path.unlink, missing_ok=True) for item in published)
                        )
                    raise

                receipt = self._build_receipt(artifact, timestamp, published, idempotency_key)
                if record_path is not None:
                    assert idempotency_key is not None
                    await run_blocking_io(
                        self._write_record,
                        record_path,
                        {
                            **self._record_payload(
                                artifact,
                                idempotency_key,
                                timestamp,
                                expected,
                            ),
                            "status": "completed",
                            "receipt": receipt.model_dump(mode="json", by_alias=True),
                        },
                    )
                return receipt

    async def health(self) -> HealthStatus:
        try:
            root = await run_blocking_io(self._prepare_root)
        except Exception as exc:
            return HealthStatus(
                status="unhealthy",
                details={"reason": str(exc) or type(exc).__name__},
            )
        return HealthStatus(status="healthy", details={"outputRoot": str(root)})

    def _prepare_root(self) -> Path:
        configured = self._config.output_root.expanduser()
        if self._config.create_root:
            configured.mkdir(parents=True, exist_ok=True)
        if not configured.is_dir():
            raise FileNotFoundError(f"Bridge output mount does not exist: {configured}")
        root = configured.resolve(strict=True)
        if not os.access(root, os.W_OK):
            raise PermissionError(f"Bridge output mount is not writable: {root}")
        return root

    async def _publish_asset(
        self,
        expected: _ExpectedFile,
    ) -> _PublishedFile:
        asset_id, role, target = expected.asset_id, expected.role, expected.path
        descriptor, temporary_name = tempfile.mkstemp(
            dir=target.parent,
            prefix=f".{target.name}.",
            suffix=".tmp",
        )
        temporary = Path(temporary_name)
        digest = hashlib.md5(usedforsecurity=False)
        sha256 = hashlib.sha256()
        size = 0
        try:
            # Reuse mkstemp's descriptor: a threaded open could acquire a
            # handle that cancellation prevents the caller from receiving.
            handle = os.fdopen(descriptor, "wb")
            try:
                async for chunk in self._assets.open(asset_id):
                    if not isinstance(chunk, bytes):
                        raise TypeError("AssetStorePort.open() must yield bytes")
                    digest.update(chunk)
                    sha256.update(chunk)
                    size += len(chunk)
                    if size > expected.size:
                        raise RuntimeError(f"AssetStore returned bytes inconsistent with metadata: {asset_id}")
                    await run_blocking_io(handle.write, chunk)
                if size != expected.size or sha256.hexdigest() != expected.sha256:
                    raise RuntimeError(f"AssetStore returned bytes inconsistent with metadata: {asset_id}")
                await run_blocking_io(handle.flush)
                await run_blocking_io(os.fsync, handle.fileno())
            finally:
                await run_blocking_io(handle.close)
            # The release filename is a delivery signal. Verify the complete
            # stream first, then make its rename durable before publishing the
            # next file or returning a receipt (also without an idempotency key).
            await run_blocking_io(self._commit_file, temporary, target)
            return _PublishedFile(
                asset_id=asset_id,
                role=role,
                path=target,
                md5=digest.hexdigest(),
                sha256=sha256.hexdigest(),
                size=size,
            )
        except BaseException:
            await run_blocking_io(temporary.unlink, missing_ok=True)
            raise

    @staticmethod
    def _commit_file(temporary: Path, target: Path) -> None:
        os.replace(temporary, target)
        MountedOutputArtifactPublisher._fsync_directory(target.parent)

    def _selected_assets(self, artifact: ArtifactRef) -> list[tuple[FileRefBlock, str]]:
        roles = self._asset_roles(artifact)
        candidates = [
            (block, roles.get(block.asset_id) or self._role_from_filename(block.filename))
            for block in artifact.content
            if isinstance(block, FileRefBlock)
        ]
        selected = [(block, role) for block, role in candidates if role is not None]
        selected_roles = [role for _block, role in selected]
        if selected_roles.count("release") != 1 or selected_roles.count("backup") != 1:
            raise ValueError("Mounted Bridge publication requires exactly one release and one backup FileRef")
        return [(block, role) for block, role in selected if role is not None]

    async def _expected_files(
        self,
        root: Path,
        timestamp: int,
        selected: list[tuple[FileRefBlock, str]],
    ) -> tuple[_ExpectedFile, ...]:
        expected: list[_ExpectedFile] = []
        for block, role in selected:
            ref = await self._assets.get(block.asset_id)
            if ref is None:
                raise FileNotFoundError(f"Unknown asset: {block.asset_id}")
            if ref.asset_id != block.asset_id or ref.media_type != block.media_type:
                raise ValueError(f"AssetStore returned an inconsistent descriptor: {block.asset_id}")
            if ref.sha256 is not None and ref.size is not None:
                sha256, size = ref.sha256, ref.size
            else:
                sha256, size = await self._digest_asset(block.asset_id)
            expected.append(
                _ExpectedFile(
                    asset_id=block.asset_id,
                    role=role,
                    path=(root / f"{role}_{timestamp}.tar.gz").resolve(),
                    sha256=sha256,
                    size=size,
                )
            )
        return tuple(expected)

    async def _digest_asset(self, asset_id: str) -> tuple[str, int]:
        digest = hashlib.sha256()
        size = 0
        async for chunk in self._assets.open(asset_id):
            if not isinstance(chunk, bytes):
                raise TypeError("AssetStorePort.open() must yield bytes")
            digest.update(chunk)
            size += len(chunk)
        return digest.hexdigest(), size

    @staticmethod
    def _verified_existing(expected: _ExpectedFile) -> _PublishedFile | None:
        if not expected.path.is_file() or expected.path.is_symlink():
            return None
        md5 = hashlib.md5(usedforsecurity=False)
        sha256 = hashlib.sha256()
        size = 0
        with expected.path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                md5.update(chunk)
                sha256.update(chunk)
                size += len(chunk)
        if size != expected.size or sha256.hexdigest() != expected.sha256:
            return None
        return _PublishedFile(
            asset_id=expected.asset_id,
            role=expected.role,
            path=expected.path,
            md5=md5.hexdigest(),
            sha256=sha256.hexdigest(),
            size=size,
        )

    @staticmethod
    def _build_receipt(
        artifact: ArtifactRef,
        timestamp: int,
        files: list[_PublishedFile],
        idempotency_key: str | None,
    ) -> ArtifactPublishReceipt:
        by_role = {item.role: item for item in files}
        release = by_role["release"]
        metadata: dict[str, JsonValue] = {
            "protocol": "areal.agent-runtime.bridge-mounted-output/v1",
            "timestampMs": timestamp,
            "releasePath": str(release.path),
            "backupPath": str(by_role["backup"].path),
            "assetLocators": {item.asset_id: str(item.path) for item in files},
            "files": [
                {
                    "assetId": item.asset_id,
                    "role": item.role,
                    "path": str(item.path),
                    "md5": item.md5,
                    "sha256": item.sha256,
                    "size": item.size,
                }
                for item in files
            ],
        }
        if idempotency_key is not None:
            metadata["idempotencyKey"] = idempotency_key
        return ArtifactPublishReceipt(
            publisher="bridge-mounted-output",
            artifact_id=artifact.artifact_id,
            version=artifact.version,
            locator=str(release.path),
            checksum=release.md5,
            metadata=metadata,
        )

    def _next_available_timestamp(self, root: Path) -> int:
        timestamp = int(self._clock_ms())
        if timestamp < 0:
            raise ValueError("Bridge publication clock must return a non-negative timestamp")
        while any((root / f"{role}_{timestamp}.tar.gz").exists() for role in ("release", "backup")):
            timestamp += 1
        return timestamp

    @staticmethod
    def _idempotency_key(artifact: ArtifactRef) -> str | None:
        value = artifact.metadata.get("idempotencyKey")
        if value is None:
            return None
        if not isinstance(value, str) or not value:
            raise ValueError("Artifact metadata idempotencyKey must be a non-empty string")
        return value

    @staticmethod
    def _record_path(root: Path, idempotency_key: str) -> Path:
        safe = hashlib.sha256(idempotency_key.encode("utf-8")).hexdigest()
        return root / f".areal-agent-runtime-publish-{safe}.json"

    @staticmethod
    def _record_payload(
        artifact: ArtifactRef,
        idempotency_key: str,
        timestamp: int,
        expected: tuple[_ExpectedFile, ...],
    ) -> dict[str, object]:
        return {
            "schemaVersion": _PUBLISH_RECORD_SCHEMA,
            "status": "pending",
            "idempotencyKey": idempotency_key,
            "artifactId": artifact.artifact_id,
            "version": artifact.version,
            "timestampMs": timestamp,
            "files": [
                {
                    "assetId": item.asset_id,
                    "role": item.role,
                    "path": str(item.path),
                    "sha256": item.sha256,
                    "size": item.size,
                }
                for item in expected
            ],
        }

    @staticmethod
    def _read_record(path: Path | None) -> dict[str, object] | None:
        if path is None:
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Mounted Bridge publication record is unreadable: {path}") from exc
        if not isinstance(payload, dict) or payload.get("schemaVersion") != _PUBLISH_RECORD_SCHEMA:
            raise RuntimeError(f"Mounted Bridge publication record is invalid: {path}")
        return payload

    @staticmethod
    def _validate_record_identity(
        record: dict[str, object],
        artifact: ArtifactRef,
        idempotency_key: str | None,
    ) -> int:
        timestamp = record.get("timestampMs")
        if (
            idempotency_key is None
            or record.get("idempotencyKey") != idempotency_key
            or record.get("artifactId") != artifact.artifact_id
            or record.get("version") != artifact.version
            or isinstance(timestamp, bool)
            or not isinstance(timestamp, int)
            or timestamp < 0
        ):
            raise RuntimeError("Mounted Bridge publication record identity is invalid")
        return timestamp

    @staticmethod
    def _validate_record_files(
        record: dict[str, object],
        expected: tuple[_ExpectedFile, ...],
    ) -> None:
        files = record.get("files")
        canonical = [
            {
                "assetId": item.asset_id,
                "role": item.role,
                "path": str(item.path),
                "sha256": item.sha256,
                "size": item.size,
            }
            for item in expected
        ]
        if files != canonical:
            raise RuntimeError("Mounted Bridge publication record assets are invalid")

    @staticmethod
    def _receipt_from_record(
        record: dict[str, object],
        expected: tuple[_ExpectedFile, ...],
    ) -> ArtifactPublishReceipt | None:
        if record.get("status") != "completed":
            # A crash may leave a completed pair with only the pending intent.
            # The caller verifies and reuses each existing file before it
            # atomically writes the final receipt.
            return None
        try:
            receipt = ArtifactPublishReceipt.model_validate(record.get("receipt"))
        except ValidationError as exc:
            raise RuntimeError("Mounted Bridge publication receipt is invalid") from exc
        if (
            receipt.artifact_id != record.get("artifactId")
            or receipt.version != record.get("version")
            or receipt.metadata.get("idempotencyKey") != record.get("idempotencyKey")
        ):
            raise RuntimeError("Mounted Bridge publication receipt identity is invalid")
        for item in expected:
            if MountedOutputArtifactPublisher._verified_existing(item) is None:
                raise RuntimeError(
                    f"Mounted Bridge publication receipt references a missing or corrupt {item.role} file"
                )
        return receipt

    @staticmethod
    def _write_record(path: Path, payload: dict[str, object]) -> None:
        descriptor, temporary_name = tempfile.mkstemp(
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            MountedOutputArtifactPublisher._fsync_directory(path.parent)
        except BaseException:
            with contextlib.suppress(OSError):
                os.close(descriptor)
            Path(temporary_name).unlink(missing_ok=True)
            raise

    @asynccontextmanager
    async def _output_lock(self, root: Path) -> AsyncIterator[None]:
        path = root / ".areal-agent-runtime-publish.lock"
        handle = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            while True:
                try:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    await asyncio.sleep(0.05)
            yield
        finally:
            with contextlib.suppress(OSError):
                fcntl.flock(handle, fcntl.LOCK_UN)
            os.close(handle)

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    @staticmethod
    def _asset_roles(artifact: ArtifactRef) -> dict[str, str]:
        value = artifact.metadata.get("assetRoles")
        if not isinstance(value, dict):
            return {}
        return {str(asset_id): str(role) for asset_id, role in value.items() if role in {"release", "backup"}}

    @staticmethod
    def _role_from_filename(filename: str | None) -> str | None:
        if not filename:
            return None
        lowered = filename.lower()
        if not lowered.endswith(".tar.gz"):
            return None
        return "backup" if "backup" in lowered else "release"
