"""Bounded pull-based AssetStore data plane over bidirectional Runtime Wire."""

from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
from collections import OrderedDict
from collections.abc import AsyncIterator

from pydantic import JsonValue

from areal_agent_runtime.adapters._identity_index import AdapterIdentitySet
from areal_agent_runtime.contracts.content import (
    AssetRef,
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.wire import AssetReadParams, AssetReadResult
from areal_agent_runtime.kernel.asset_context import get_asset_write_context
from areal_agent_runtime.transports.jsonrpc import JsonRpcPeer, JsonRpcProtocolError


class RuntimeWireAssetBridge:
    """Expose allowlisted local assets and materialize peer assets on demand."""

    def __init__(
        self,
        peer: JsonRpcPeer,
        store: AssetStorePort,
        *,
        max_asset_bytes: int = 64 * 1024 * 1024,
        chunk_bytes: int = 512 * 1024,
        max_cached_assets: int = 8,
        max_imported_assets: int = 1024,
    ) -> None:
        if (
            isinstance(max_asset_bytes, bool)
            or not isinstance(max_asset_bytes, int)
            or max_asset_bytes < 1
            or isinstance(chunk_bytes, bool)
            or not isinstance(chunk_bytes, int)
            or not 1 <= chunk_bytes <= 4 * 1024 * 1024
            or isinstance(max_cached_assets, bool)
            or not isinstance(max_cached_assets, int)
            or max_cached_assets < 1
            or isinstance(max_imported_assets, bool)
            or not isinstance(max_imported_assets, int)
            or max_imported_assets < 1
        ):
            raise ValueError("invalid Runtime Wire asset transfer limits")
        self._peer = peer
        self._store = store
        self._max_asset_bytes = max_asset_bytes
        self._chunk_bytes = chunk_bytes
        self._max_cached_assets = max_cached_assets
        self._max_imported_assets = max_imported_assets
        self._enabled = False
        self._closed = False
        self._allowed_exports = AdapterIdentitySet()
        self._export_cache: OrderedDict[str, bytes] = OrderedDict()
        self._export_cache_bytes = 0
        self._imported: OrderedDict[tuple[str | None, str | None, str | None, str], str] = OrderedDict()
        self._import_lock = asyncio.Lock()
        self._cache_lock = asyncio.Lock()
        peer.on_request("asset.read", self._read)

    @property
    def enabled(self) -> bool:
        return self._enabled

    def enable(self) -> None:
        self._require_open()
        self._enabled = True

    def allow_content(self, blocks: tuple[ContentBlock, ...]) -> None:
        self._require_open()
        self._allowed_exports.update(asset_ids_from_content(blocks))

    def allow_asset(self, asset_id: str) -> None:
        self._require_open()
        self._validate_asset_id(asset_id)
        self._allowed_exports.add(asset_id)

    @staticmethod
    def _validate_asset_id(asset_id: str) -> None:
        if not isinstance(asset_id, str) or not asset_id or asset_id != asset_id.strip():
            raise ValueError("asset_id must be a trimmed non-blank string")

    def allow_json(self, value: JsonValue) -> None:
        self._require_open()
        self._allowed_exports.update(asset_ids_from_json(value))

    async def materialize_content(self, blocks: tuple[ContentBlock, ...]) -> tuple[ContentBlock, ...]:
        self._require_open()
        if not self._enabled:
            return blocks
        mapping = await self._materialize(asset_ids_from_content(blocks))
        return rewrite_content_assets(blocks, mapping)

    async def materialize_json(self, value: JsonValue) -> JsonValue:
        self._require_open()
        if not self._enabled:
            return value
        mapping = await self._materialize(asset_ids_from_json(value))
        return rewrite_json_assets(value, mapping)

    async def materialize_asset(self, asset_id: str) -> str:
        self._require_open()
        if not self._enabled:
            raise RuntimeError("Runtime Wire asset transfer was not negotiated")
        self._validate_asset_id(asset_id)
        return (await self._materialize({asset_id}))[asset_id]

    async def _materialize(self, asset_ids: set[str]) -> dict[str, str]:
        context = get_asset_write_context()
        scope = (context.get("run_id"), context.get("profile_id"), context.get("agent_id"))
        async with self._import_lock:
            self._require_open()
            mapping: dict[str, str] = {}
            for asset_id in sorted(asset_ids):
                cache_key = (*scope, asset_id)
                local_id = self._imported.get(cache_key)
                if local_id is None:
                    # Asset IDs are scoped to each side's store. Treating an
                    # accidental/malicious local ID collision as a cache hit
                    # would substitute unrelated local bytes for peer bytes.
                    local_id = await self._pull(asset_id)
                    self._require_open()
                    # A remote asset can be referenced by different runs or
                    # agents whose deployment rules select different stores.
                    # This mapping is only a read-through optimization. Eviction
                    # repeats verified transfer/immutable put, never revokes the
                    # peer's allowlisted exports or deletes persisted assets.
                    while len(self._imported) >= self._max_imported_assets:
                        self._imported.popitem(last=False)
                    self._imported[cache_key] = local_id
                else:
                    self._imported.move_to_end(cache_key)
                mapping[asset_id] = local_id
            return mapping

    async def _pull(self, asset_id: str) -> str:
        offset = 0
        expected = None
        payload = bytearray()
        while True:
            # Base64 plus the JSON-RPC/AssetRef envelope must fit the currently
            # negotiated frame.  Small frames intentionally trade throughput
            # for a response that the transport can actually deliver.
            frame_budget = self._peer.max_frame_bytes
            reserve = min(4096, max(512, frame_budget // 2))
            request_bytes = min(
                self._chunk_bytes,
                max(1, ((frame_budget - reserve) * 3) // 4),
            )
            result = AssetReadResult.model_validate(
                await self._peer.request(
                    "asset.read",
                    AssetReadParams(
                        asset_id=asset_id,
                        offset=offset,
                        max_bytes=request_bytes,
                    ).model_dump(mode="json", by_alias=True),
                )
            )
            if result.asset.asset_id != asset_id or result.offset != offset:
                raise JsonRpcProtocolError(-32031, "Runtime Wire asset stream identity/offset mismatch")
            if expected is None:
                expected = result.asset
                if expected.size is not None and expected.size > self._max_asset_bytes:
                    raise JsonRpcProtocolError(-32032, "Runtime Wire asset exceeds configured limit")
            elif result.asset != expected:
                raise JsonRpcProtocolError(
                    -32031,
                    "Runtime Wire asset metadata changed during transfer",
                )
            try:
                chunk = base64.b64decode(result.data_base64, validate=True)
            except (ValueError, binascii.Error) as exc:
                raise JsonRpcProtocolError(-32031, "Runtime Wire asset chunk is not valid base64") from exc
            if len(chunk) > request_bytes:
                raise JsonRpcProtocolError(
                    -32031,
                    "Runtime Wire asset chunk exceeds the requested size",
                )
            payload.extend(chunk)
            if len(payload) > self._max_asset_bytes:
                raise JsonRpcProtocolError(-32032, "Runtime Wire asset exceeds configured limit")
            offset += len(chunk)
            if result.eof:
                break
            if not chunk:
                raise JsonRpcProtocolError(-32031, "Runtime Wire asset stream made no progress")
        assert expected is not None
        if expected.size is not None and len(payload) != expected.size:
            raise JsonRpcProtocolError(-32031, "Runtime Wire asset size mismatch")
        digest = hashlib.sha256(payload).hexdigest()
        if expected.sha256 is not None and digest != expected.sha256.lower():
            raise JsonRpcProtocolError(-32031, "Runtime Wire asset digest mismatch")
        imported = await self._store.put(
            _one_chunk(bytes(payload)),
            media_type=expected.media_type,
            metadata={
                **expected.metadata,
                "wireSourceAssetId": expected.asset_id,
                "wireSourceSha256": digest,
            },
        )
        return imported.asset_id

    async def _read(self, params: object) -> object:
        if not self._enabled:
            raise JsonRpcProtocolError(-32030, "Runtime Wire asset transfer was not negotiated")
        request = AssetReadParams.model_validate(params)
        if request.asset_id not in self._allowed_exports:
            raise JsonRpcProtocolError(-32030, "Runtime Wire asset is not authorized for this connection")
        ref = await self._store.get(request.asset_id)
        if ref is None:
            raise JsonRpcProtocolError(-32033, f"Unknown Runtime Wire asset: {request.asset_id}")
        if ref.size is not None and ref.size > self._max_asset_bytes:
            raise JsonRpcProtocolError(-32032, "Runtime Wire asset exceeds configured limit")
        payload = await self._export_payload(ref)
        if request.offset > len(payload):
            raise JsonRpcProtocolError(-32031, "Runtime Wire asset offset is out of range")
        end = min(len(payload), request.offset + request.max_bytes)
        chunk = payload[request.offset : end]
        eof = end == len(payload)
        if eof:
            self._drop_cached_export(ref.asset_id)
        return AssetReadResult(
            asset=ref,
            offset=request.offset,
            data_base64=base64.b64encode(chunk).decode("ascii"),
            eof=eof,
        ).model_dump(mode="json", by_alias=True)

    async def _export_payload(self, ref: AssetRef) -> bytes:
        self._require_open()
        cached = self._export_cache.get(ref.asset_id)
        if cached is not None:
            self._validate_export_payload(ref, cached)
            self._export_cache.move_to_end(ref.asset_id)
            return cached
        async with self._cache_lock:
            self._require_open()
            cached = self._export_cache.get(ref.asset_id)
            if cached is not None:
                self._validate_export_payload(ref, cached)
                self._export_cache.move_to_end(ref.asset_id)
                return cached
            payload = bytearray()
            async for chunk in self._store.open(ref.asset_id):
                if not isinstance(chunk, bytes):
                    raise JsonRpcProtocolError(
                        -32031,
                        "AssetStorePort.open() yielded a non-bytes chunk",
                    )
                payload.extend(chunk)
                if len(payload) > self._max_asset_bytes:
                    raise JsonRpcProtocolError(-32032, "Runtime Wire asset exceeds configured limit")
            result = bytes(payload)
            self._validate_export_payload(ref, result)
            self._require_open()
            while self._export_cache and (
                len(self._export_cache) >= self._max_cached_assets
                or self._export_cache_bytes + len(result) > self._max_asset_bytes
            ):
                _discarded_id, discarded = self._export_cache.popitem(last=False)
                self._export_cache_bytes -= len(discarded)
            self._export_cache[ref.asset_id] = result
            self._export_cache_bytes += len(result)
            return result

    @staticmethod
    def _validate_export_payload(ref: AssetRef, payload: bytes) -> None:
        if ref.size is not None and len(payload) != ref.size:
            raise JsonRpcProtocolError(-32031, "Runtime Wire source asset size mismatch")
        if ref.sha256 is not None and hashlib.sha256(payload).hexdigest() != ref.sha256:
            raise JsonRpcProtocolError(-32031, "Runtime Wire source asset digest mismatch")

    def _drop_cached_export(self, asset_id: str) -> None:
        cached = self._export_cache.pop(asset_id, None)
        if cached is not None:
            self._export_cache_bytes -= len(cached)

    def _require_open(self) -> None:
        if self._closed:
            raise RuntimeError("Runtime Wire asset bridge is closed")

    def close(self) -> None:
        # The owner closes dispatch first. In-flight asset-store operations
        # recheck this flag after await, so they cannot refill a cleared cache.
        self._closed = True
        self._enabled = False
        self._allowed_exports.close()
        self._imported.clear()
        self._export_cache.clear()
        self._export_cache_bytes = 0


def asset_ids_from_content(blocks: tuple[ContentBlock, ...]) -> set[str]:
    result: set[str] = set()
    for block in blocks:
        if isinstance(block, (ImageRefBlock, AudioRefBlock, FileRefBlock)):
            result.add(block.asset_id)
        elif isinstance(block, VideoRefBlock):
            result.add(block.asset_id)
            if block.poster_asset_id:
                result.add(block.poster_asset_id)
    return result


def rewrite_content_assets(
    blocks: tuple[ContentBlock, ...],
    mapping: dict[str, str],
) -> tuple[ContentBlock, ...]:
    rewritten: list[ContentBlock] = []
    for block in blocks:
        if isinstance(block, (ImageRefBlock, AudioRefBlock, FileRefBlock)):
            rewritten.append(block.model_copy(update={"asset_id": mapping.get(block.asset_id, block.asset_id)}))
        elif isinstance(block, VideoRefBlock):
            rewritten.append(
                block.model_copy(
                    update={
                        "asset_id": mapping.get(block.asset_id, block.asset_id),
                        "poster_asset_id": (
                            mapping.get(block.poster_asset_id, block.poster_asset_id)
                            if block.poster_asset_id is not None
                            else None
                        ),
                    }
                )
            )
        else:
            rewritten.append(block)
    return tuple(rewritten)


def asset_ids_from_json(value: JsonValue) -> set[str]:
    result: set[str] = set()
    _collect_json_asset_ids(value, result, active=set(), budget=[100_000], depth=0)
    return result


def rewrite_json_assets(value: JsonValue, mapping: dict[str, str]) -> JsonValue:
    return _rewrite_json_assets(value, mapping, active=set(), budget=[100_000], depth=0)


def _collect_json_asset_ids(
    value: JsonValue,
    result: set[str],
    *,
    active: set[int],
    budget: list[int],
    depth: int,
) -> None:
    _consume_json_budget(value, active=active, budget=budget, depth=depth)
    if isinstance(value, list):
        identity = id(value)
        active.add(identity)
        try:
            for item in value:
                _collect_json_asset_ids(
                    item,
                    result,
                    active=active,
                    budget=budget,
                    depth=depth + 1,
                )
        finally:
            active.remove(identity)
        return
    if isinstance(value, dict):
        identity = id(value)
        active.add(identity)
        try:
            for key, item in value.items():
                if key in {"assetId", "posterAssetId"} and isinstance(item, str) and item and item == item.strip():
                    result.add(item)
                _collect_json_asset_ids(
                    item,
                    result,
                    active=active,
                    budget=budget,
                    depth=depth + 1,
                )
        finally:
            active.remove(identity)


def _rewrite_json_assets(
    value: JsonValue,
    mapping: dict[str, str],
    *,
    active: set[int],
    budget: list[int],
    depth: int,
) -> JsonValue:
    _consume_json_budget(value, active=active, budget=budget, depth=depth)
    if isinstance(value, list):
        identity = id(value)
        active.add(identity)
        try:
            return [
                _rewrite_json_assets(
                    item,
                    mapping,
                    active=active,
                    budget=budget,
                    depth=depth + 1,
                )
                for item in value
            ]
        finally:
            active.remove(identity)
    if isinstance(value, dict):
        identity = id(value)
        active.add(identity)
        try:
            rewritten: dict[str, JsonValue] = {}
            for key, item in value.items():
                if key in {"assetId", "posterAssetId"} and isinstance(item, str):
                    _consume_json_budget(
                        item,
                        active=active,
                        budget=budget,
                        depth=depth + 1,
                    )
                    rewritten[key] = mapping.get(item, item)
                else:
                    rewritten[key] = _rewrite_json_assets(
                        item,
                        mapping,
                        active=active,
                        budget=budget,
                        depth=depth + 1,
                    )
            return rewritten
        finally:
            active.remove(identity)
    return value


def _consume_json_budget(
    value: JsonValue,
    *,
    active: set[int],
    budget: list[int],
    depth: int,
) -> None:
    if depth > 128:
        raise ValueError("Runtime Wire JSON exceeds the maximum nesting depth")
    budget[0] -= 1
    if budget[0] < 0:
        raise ValueError("Runtime Wire JSON exceeds the maximum node count")
    if isinstance(value, (list, dict)) and id(value) in active:
        raise ValueError("Runtime Wire JSON must not contain cycles")


async def _one_chunk(payload: bytes) -> AsyncIterator[bytes]:
    yield payload
