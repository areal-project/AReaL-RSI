"""ARealAgentRuntime-owned semantic contract for any Agent Harness."""

from __future__ import annotations

import hashlib
import json
from collections.abc import AsyncIterator, Mapping
from datetime import datetime
from enum import StrEnum
from typing import Literal, Protocol, cast, runtime_checkable

from pydantic import (
    ConfigDict,
    Field,
    JsonValue,
    StrictBool,
    StrictFloat,
    StrictInt,
    TypeAdapter,
    ValidationError,
    field_validator,
    model_validator,
)

from areal_agent_runtime.contracts.base import (
    ContractModel,
    require_optional_trimmed,
    require_trimmed,
    require_unique_trimmed,
)
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.data import (
    CanonicalFinishReason,
    CheckpointCoverage,
    DataCoverage,
    NormalizedUsage,
    SchemaReference,
)
from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot
from areal_agent_runtime.contracts.errors import ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.knowledge import KnowledgeRef
from areal_agent_runtime.contracts.tools import ToolExecution, ToolRepeatPolicy, ToolSpec
from areal_agent_runtime.contracts.version import RUNTIME_API_VERSION, RuntimeApiVersion

__all__ = ["ToolExecution", "ToolRepeatPolicy", "ToolSpec"]


class Modality(StrEnum):
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    FILE = "file"


class ChildEventProjection(StrEnum):
    """How much Runtime-owned child-agent activity reaches canonical events."""

    NONE = "none"
    AGGREGATE = "aggregate"
    FULL = "full"


class RuntimeCapabilities(ContractModel):
    model_config = ConfigDict(
        json_schema_extra={
            "allOf": [
                {
                    "if": {
                        "properties": {"applicationToolBridge": {"const": True}},
                        "required": ["applicationToolBridge"],
                    },
                    "then": {
                        "properties": {"toolCalling": {"const": True}},
                        "required": ["toolCalling"],
                    },
                },
                {
                    "if": {
                        "properties": {"liveInteraction": {"const": True}},
                        "required": ["liveInteraction"],
                    },
                    "then": {
                        "properties": {"interaction": {"const": True}},
                        "required": ["interaction"],
                    },
                },
                {
                    "if": {
                        "properties": {"nativeGraphExecution": {"const": True}},
                        "required": ["nativeGraphExecution"],
                    },
                    "then": {
                        "properties": {"nativeMultiAgent": {"const": True}},
                        "required": ["nativeMultiAgent"],
                    },
                },
                {
                    "if": {
                        "properties": {"nativeMultiAgent": {"const": True}},
                        "required": ["nativeMultiAgent"],
                    },
                    "then": {
                        "properties": {
                            "childEventProjection": {"enum": ["aggregate", "full"]}
                        },
                        "required": ["childEventProjection"],
                    },
                },
                {
                    "if": {
                        "properties": {
                            "childEventProjection": {"enum": ["aggregate", "full"]}
                        },
                        "required": ["childEventProjection"],
                    },
                    "then": {
                        "properties": {"nativeMultiAgent": {"const": True}},
                        "required": ["nativeMultiAgent"],
                    },
                },
            ]
        }
    )

    input_modalities: tuple[Modality, ...] = Field(default=(Modality.TEXT,), min_length=1)
    output_modalities: tuple[Modality, ...] = Field(default=(Modality.TEXT,), min_length=1)
    tool_calling: StrictBool = False
    application_tool_bridge: StrictBool = False
    cancel: StrictBool = False
    steer: StrictBool = False
    resume: StrictBool = False
    interaction: StrictBool = False
    live_interaction: StrictBool = False
    # The Runtime may spawn/manage descendants inside one Application-owned
    # execution (hybrid ownership) and project their lineage as canonical events.
    native_multi_agent: StrictBool = False
    child_event_projection: ChildEventProjection = ChildEventProjection.NONE
    # The Runtime accepts and owns an entire canonical AgentGraph. This is a
    # stronger capability and must not be inferred from native child agents.
    native_graph_execution: StrictBool = False
    portable_checkpoint: StrictBool = False
    data_coverage: DataCoverage = Field(default_factory=DataCoverage)
    extensions: dict[str, JsonValue] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def bridge_legacy_checkpoint_capability(cls, value: object) -> object:
        """Keep the historical portableCheckpoint flag source-compatible.

        ``dataCoverage`` was added after ``portableCheckpoint``.  A v1
        adapter that only sends the old boolean must therefore acquire the
        equivalent coverage declaration automatically.  When both fields are
        explicitly present, the normal post-validator still rejects a lie.
        """

        if not isinstance(value, Mapping):
            return value
        payload = dict(value)
        portable_key = next(
            (key for key in ("portableCheckpoint", "portable_checkpoint") if key in payload),
            None,
        )
        coverage_key = next(
            (key for key in ("dataCoverage", "data_coverage") if key in payload),
            None,
        )
        portable = payload.get(portable_key) if portable_key is not None else None
        coverage = payload.get(coverage_key) if coverage_key is not None else None
        checkpoint = (
            coverage.checkpoint
            if isinstance(coverage, DataCoverage)
            else coverage.get("checkpoint")
            if isinstance(coverage, Mapping)
            else None
        )
        if coverage_key is None and portable is True:
            payload["dataCoverage"] = {"checkpoint": CheckpointCoverage.PORTABLE.value}
        elif portable_key is None and checkpoint in {
            CheckpointCoverage.PORTABLE,
            CheckpointCoverage.PORTABLE.value,
        }:
            payload["portableCheckpoint"] = True
        return payload

    @field_validator("extensions")
    @classmethod
    def validate_extension_keys(cls, value: dict[str, JsonValue]) -> dict[str, JsonValue]:
        import re

        pattern = re.compile(
            r"^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?/"
            r"[a-z0-9][a-z0-9._-]*/v[1-9][0-9]*$"
        )
        invalid = sorted(key for key in value if pattern.fullmatch(key) is None)
        if invalid:
            raise ValueError("Runtime extension keys must be namespaced and versioned: " + ", ".join(invalid))
        return value

    @field_validator("input_modalities", "output_modalities")
    @classmethod
    def validate_modalities(cls, value: tuple[Modality, ...]) -> tuple[Modality, ...]:
        if len(value) != len(set(value)):
            raise ValueError("Runtime modality lists must not contain duplicates")
        return value

    @model_validator(mode="after")
    def validate_capability_implications(self) -> RuntimeCapabilities:
        if self.application_tool_bridge and not self.tool_calling:
            raise ValueError("applicationToolBridge requires toolCalling")
        if self.live_interaction and not self.interaction:
            raise ValueError("liveInteraction requires interaction")
        if self.native_graph_execution and not self.native_multi_agent:
            raise ValueError("nativeGraphExecution requires nativeMultiAgent")
        if self.native_multi_agent and self.child_event_projection == ChildEventProjection.NONE:
            raise ValueError("nativeMultiAgent requires childEventProjection=aggregate or full")
        if not self.native_multi_agent and self.child_event_projection != ChildEventProjection.NONE:
            raise ValueError("childEventProjection requires nativeMultiAgent")
        if self.portable_checkpoint != (
            self.data_coverage.checkpoint == CheckpointCoverage.PORTABLE
        ):
            raise ValueError(
                "portableCheckpoint and dataCoverage.checkpoint=portable must be declared together"
            )
        return self


class RuntimeDescriptor(ContractModel):
    runtime_api_version: RuntimeApiVersion = RUNTIME_API_VERSION
    name: str = Field(min_length=1)
    adapter_version: str = Field(min_length=1)
    runtime_version: str = Field(min_length=1)
    capabilities: RuntimeCapabilities

    @field_validator("name", "adapter_version", "runtime_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Runtime descriptor identity")


class WorkspaceRef(ContractModel):
    workspace_id: str = Field(min_length=1)
    mount_hint: str | None = None

    @field_validator("workspace_id")
    @classmethod
    def validate_workspace_id(cls, value: str) -> str:
        return require_trimmed(value, "workspaceId")

    @field_validator("mount_hint")
    @classmethod
    def validate_mount_hint(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "mountHint")


class RuntimeSessionSpec(ContractModel):
    session_id: str = Field(min_length=1)
    workspace: WorkspaceRef
    model: str | None = None
    provider: str | None = None
    resume: StrictBool = False
    agent_environment: AgentEnvironmentSnapshot
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("session_id")
    @classmethod
    def validate_session_id(cls, value: str) -> str:
        return require_trimmed(value, "Runtime sessionId")

    @field_validator("model", "provider")
    @classmethod
    def validate_optional_identity(cls, value: str | None, info) -> str | None:  # type: ignore[no-untyped-def]
        return require_optional_trimmed(value, f"Runtime session {info.field_name}")


class RuntimeSessionRef(ContractModel):
    session_id: str = Field(min_length=1)
    runtime_session_id: str = Field(min_length=1)

    @field_validator("session_id", "runtime_session_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "RuntimeSessionRef identity")


class AgentRef(ContractModel):
    agent_id: str = Field(min_length=1)
    parent_agent_id: str | None = None
    role: str = Field(min_length=1)

    @field_validator("agent_id", "role")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Agent identity")

    @field_validator("parent_agent_id")
    @classmethod
    def validate_parent(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "parentAgentId")

    @model_validator(mode="after")
    def reject_self_parent(self) -> AgentRef:
        if self.parent_agent_id == self.agent_id:
            raise ValueError("Agent cannot be its own parent")
        return self


class ExecutionPolicy(ContractModel):
    deadline: str | None = None
    max_turns: StrictInt | None = Field(default=None, ge=1)
    max_stalled_actions: StrictInt | None = Field(default=None, ge=2, le=30)
    required_capabilities: tuple[str, ...] = ()

    @field_validator("deadline")
    @classmethod
    def validate_deadline(cls, value: str | None) -> str | None:
        value = require_optional_trimmed(value, "execution deadline")
        if value is None:
            return None
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("execution deadline must be an RFC 3339 timestamp") from exc
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError("execution deadline must include a timezone")
        return value

    @field_validator("required_capabilities")
    @classmethod
    def validate_capabilities(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return require_unique_trimmed(value, "requiredCapabilities")


class ExecutionRequest(ContractModel):
    api_version: RuntimeApiVersion = RUNTIME_API_VERSION
    run_id: str = Field(min_length=1)
    execution_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    agent: AgentRef
    input: tuple[ContentBlock, ...] = Field(min_length=1)
    agent_environment: AgentEnvironmentSnapshot
    # Transitional request-scoped knowledge authorization. New Skill content lives in
    # agentEnvironment.skills; this remains until the legacy knowledge Tool is retired.
    knowledge: tuple[KnowledgeRef, ...] = ()
    workspace: WorkspaceRef
    policy: ExecutionPolicy = Field(default_factory=ExecutionPolicy)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("run_id", "execution_id", "session_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "ExecutionRequest identity")

    @property
    def system(self) -> tuple[ContentBlock, ...]:
        return self.agent_environment.system

    @property
    def tools(self) -> tuple[ToolSpec, ...]:
        return self.agent_environment.tools


class RuntimeEventLineageData(ContractModel):
    """Optional Application-owned execution lineage for Runtime child events."""

    parent_execution_id: str | None = Field(
        default=None,
        exclude_if=lambda value: value is None,
    )
    group_id: str | None = Field(
        default=None,
        exclude_if=lambda value: value is None,
    )

    @field_validator("parent_execution_id", "group_id")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "runtime event lineage identity")


class MessageDeltaEventData(RuntimeEventLineageData):
    delta: ContentBlock
    message_id: str | None = None
    model_call_id: str | None = None

    @field_validator("message_id", "model_call_id")
    @classmethod
    def validate_message_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "message delta identity")


class MessageCompletedEventData(RuntimeEventLineageData):
    content: tuple[ContentBlock, ...] = Field(min_length=1)
    message_id: str | None = None
    model_call_id: str | None = None
    role: str = "assistant"

    @field_validator("message_id", "model_call_id")
    @classmethod
    def validate_message_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "message identity")

    @field_validator("role")
    @classmethod
    def validate_role(cls, value: str) -> str:
        value = require_trimmed(value, "message role")
        if value not in {"system", "user", "assistant", "tool"}:
            raise ValueError("message role must be system, user, assistant or tool")
        return value


class ReasoningDeltaEventData(RuntimeEventLineageData):
    text: str
    final: StrictBool = False


class ToolRequestedEventData(RuntimeEventLineageData):
    call_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    arguments: dict[str, JsonValue] | None = None
    raw_arguments: str | None = None
    execution: ToolExecution | None = None
    context: JsonValue = None
    model_call_id: str | None = None

    @field_validator("call_id", "name")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Tool request identity")

    @field_validator("model_call_id")
    @classmethod
    def validate_model_call_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Tool request modelCallId")

    @model_validator(mode="after")
    def validate_arguments(self) -> ToolRequestedEventData:
        if self.arguments is None and self.raw_arguments is None:
            raise ValueError("Tool request requires arguments or rawArguments")
        return self


class ToolLifecycleEventData(RuntimeEventLineageData):
    call_id: str = Field(min_length=1)
    name: str | None = None
    arguments: dict[str, JsonValue] | None = None
    raw_arguments: str | None = None
    content: tuple[ContentBlock, ...] = ()
    value: JsonValue = None
    result: JsonValue = None
    summary: str | None = None
    error: ErrorInfo | JsonValue | None = None
    duration_seconds: StrictFloat | None = Field(default=None, ge=0)
    model_call_id: str | None = None

    @field_validator("call_id")
    @classmethod
    def validate_call_id(cls, value: str) -> str:
        return require_trimmed(value, "Tool lifecycle callId")

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Tool lifecycle name")

    @field_validator("raw_arguments")
    @classmethod
    def validate_raw_arguments(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Tool lifecycle rawArguments")

    @field_validator("model_call_id")
    @classmethod
    def validate_model_call_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Tool lifecycle modelCallId")


class UsageUpdatedEventData(RuntimeEventLineageData):
    model_call_id: str | None = None
    usage: NormalizedUsage

    @field_validator("model_call_id")
    @classmethod
    def validate_model_call_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "usage modelCallId")

    @model_validator(mode="after")
    def validate_scope_lineage(self) -> UsageUpdatedEventData:
        if self.usage.scope == "model-call" and self.model_call_id is None:
            raise ValueError("model-call usage requires modelCallId")
        return self


class ModelCallStartedEventData(RuntimeEventLineageData):
    model_call_id: str = Field(min_length=1)
    provider: str = Field(min_length=1)
    model: str = Field(min_length=1)
    attempt: StrictInt = Field(default=1, ge=1)

    @field_validator("model_call_id", "provider", "model")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "model call identity")


class ModelCallCompletedEventData(ModelCallStartedEventData):
    provider_request_id: str | None = None
    finish_reason: str | None = None
    duration_seconds: StrictFloat = Field(ge=0)

    @field_validator("provider_request_id", "finish_reason")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "model call completion identity")


class ModelCallFailedEventData(ModelCallStartedEventData):
    error: ErrorInfo
    duration_seconds: StrictFloat = Field(ge=0)


class RawRuntimeEventData(RuntimeEventLineageData):
    producer: str = Field(min_length=1)
    vendor_event_type: str = Field(min_length=1)
    runtime_instance_id: str = Field(min_length=1)
    runtime_sequence: StrictInt = Field(ge=0)
    reason: Literal["unknown-event", "unsupported-event", "canonicalization-failed"] = (
        "unknown-event"
    )
    storage: Literal["inline", "asset-ref"] = "inline"
    payload: JsonValue = None
    asset_id: str | None = None

    @field_validator("producer", "vendor_event_type", "runtime_instance_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "raw Runtime event identity")

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "raw Runtime event assetId")

    @model_validator(mode="after")
    def validate_storage(self) -> RawRuntimeEventData:
        if self.storage == "asset-ref" and self.asset_id is None:
            raise ValueError("asset-ref raw Runtime event requires assetId")
        if self.storage == "inline" and self.asset_id is not None:
            raise ValueError("inline raw Runtime event cannot include assetId")
        if self.storage == "asset-ref" and self.payload is not None:
            raise ValueError("asset-ref raw Runtime event cannot also inline payload")
        return self


class InteractionRequest(RuntimeEventLineageData):
    """Canonical request emitted by a Runtime before user/host interaction."""

    interaction_id: str = Field(min_length=1)
    kind: str = Field(min_length=1)
    request: JsonValue
    terminal: StrictBool = False
    commit_barrier: StrictBool = False

    @field_validator("interaction_id", "kind")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Interaction request identity")


class InteractionResolvedEventData(RuntimeEventLineageData):
    interaction_id: str = Field(min_length=1)
    kind: str | None = None
    pending_interactions: StrictInt | None = Field(default=None, ge=0)

    @field_validator("interaction_id")
    @classmethod
    def validate_interaction_id(cls, value: str) -> str:
        return require_trimmed(value, "Interaction resolution interactionId")

    @field_validator("kind")
    @classmethod
    def validate_kind(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Interaction resolution kind")


_RUNTIME_EVENT_DATA_ADAPTERS: dict[EventType, TypeAdapter[object]] = {
    EventType.MESSAGE_DELTA: TypeAdapter(MessageDeltaEventData),
    EventType.MESSAGE_COMPLETED: TypeAdapter(MessageCompletedEventData),
    EventType.AGENT_MESSAGE: TypeAdapter(MessageCompletedEventData),
    EventType.REASONING_DELTA: TypeAdapter(ReasoningDeltaEventData),
    EventType.TOOL_REQUESTED: TypeAdapter(ToolRequestedEventData),
    EventType.TOOL_STARTED: TypeAdapter(ToolRequestedEventData),
    EventType.TOOL_COMPLETED: TypeAdapter(ToolLifecycleEventData),
    EventType.TOOL_FAILED: TypeAdapter(ToolLifecycleEventData),
    EventType.USAGE_UPDATED: TypeAdapter(UsageUpdatedEventData),
    EventType.MODEL_CALL_STARTED: TypeAdapter(ModelCallStartedEventData),
    EventType.MODEL_CALL_COMPLETED: TypeAdapter(ModelCallCompletedEventData),
    EventType.MODEL_CALL_FAILED: TypeAdapter(ModelCallFailedEventData),
    EventType.RAW_EVENT_RECORDED: TypeAdapter(RawRuntimeEventData),
    EventType.INTERACTION_REQUIRED: TypeAdapter(InteractionRequest),
    EventType.INTERACTION_RESOLVED: TypeAdapter(InteractionResolvedEventData),
}

_RUNTIME_EVENT_TYPES = frozenset(
    {
        EventType.EXECUTION_STARTED,
        EventType.EXECUTION_COMPLETED,
        EventType.EXECUTION_FAILED,
        EventType.MESSAGE_DELTA,
        EventType.MESSAGE_COMPLETED,
        EventType.REASONING_DELTA,
        EventType.ASSET_CREATED,
        EventType.ASSET_ATTACHED,
        EventType.TOOL_REQUESTED,
        EventType.TOOL_STARTED,
        EventType.TOOL_PROGRESS,
        EventType.TOOL_COMPLETED,
        EventType.TOOL_FAILED,
        EventType.INTERACTION_REQUIRED,
        EventType.INTERACTION_RESOLVED,
        EventType.AGENT_STARTED,
        EventType.AGENT_MESSAGE,
        EventType.AGENT_COMPLETED,
        EventType.AGENT_FAILED,
        EventType.AGENT_CANCELLED,
        EventType.USAGE_UPDATED,
        EventType.MODEL_CALL_STARTED,
        EventType.MODEL_CALL_COMPLETED,
        EventType.MODEL_CALL_FAILED,
        EventType.RAW_EVENT_RECORDED,
        EventType.RUNTIME_STATUS,
        EventType.WARNING_RAISED,
    }
)
_RUNTIME_EVENT_TYPE_VALUES: list[JsonValue] = [
    cast(JsonValue, value) for value in sorted(item.value for item in _RUNTIME_EVENT_TYPES)
]
_ALL_EVENT_TYPE_VALUES: list[JsonValue] = [
    cast(JsonValue, value) for value in sorted(item.value for item in EventType)
]


class RuntimeEvent(ContractModel):
    model_config = ConfigDict(
        json_schema_extra={
            "anyOf": [
                {
                    "properties": {
                        "type": {"enum": _RUNTIME_EVENT_TYPE_VALUES},
                        "data": {"type": "object"},
                    },
                    "required": ["type", "data"],
                },
                {
                    "properties": {
                        "type": {"not": {"enum": _ALL_EVENT_TYPE_VALUES}},
                        "ignorable": {"const": True},
                    },
                    "required": ["type", "ignorable"],
                },
            ]
        }
    )

    api_version: RuntimeApiVersion = RUNTIME_API_VERSION
    runtime_instance_id: str = Field(min_length=1)
    runtime_sequence: StrictInt = Field(ge=0)
    execution_id: str = Field(min_length=1)
    agent_id: str = Field(min_length=1)
    parent_agent_id: str | None = None
    type: EventType | str
    data: JsonValue = Field(default_factory=dict)
    ignorable: StrictBool = False

    @field_validator("runtime_instance_id", "execution_id", "agent_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "RuntimeEvent identity")

    @field_validator("parent_agent_id")
    @classmethod
    def validate_parent(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "RuntimeEvent parentAgentId")

    @field_validator("type", mode="before")
    @classmethod
    def normalize_known_type(cls, value: object) -> object:
        if isinstance(value, EventType):
            return value
        if isinstance(value, str):
            try:
                return EventType(value)
            except ValueError:
                return value
        return value

    @model_validator(mode="after")
    def validate_known_event_data(self) -> RuntimeEvent:
        if not isinstance(self.type, EventType):
            require_trimmed(self.type, "RuntimeEvent type")
            if not self.ignorable:
                raise ValueError("Unknown RuntimeEvent types require ignorable=true")
            return self
        if self.type not in _RUNTIME_EVENT_TYPES:
            raise ValueError(f"{self.type.value} is not valid in Runtime execution scope")
        if not isinstance(self.data, dict):
            raise ValueError("RuntimeEvent data must be a JSON object")
        adapter = _RUNTIME_EVENT_DATA_ADAPTERS.get(self.type)
        if adapter is not None:
            try:
                adapter.validate_python(self.data)
            except ValidationError:
                # Runtime v1 historically allowed arbitrary usage payloads.
                # Keep accepting those only at the Harness ingress boundary;
                # Application converts known counters to typed data/v1 and
                # records the original vendor shape as governed raw data.
                if self.type != EventType.USAGE_UPDATED:
                    raise
        return self


class ToolCall(ContractModel):
    call_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    execution_id: str = Field(min_length=1)
    agent_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    arguments: dict[str, JsonValue]
    workspace: WorkspaceRef
    agent_environment: AgentEnvironmentSnapshot
    knowledge: tuple[KnowledgeRef, ...] = ()
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("call_id", "run_id", "session_id", "execution_id", "agent_id", "name")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "ToolCall identity")


class ToolResult(ContractModel):
    call_id: str = Field(min_length=1)
    content: tuple[ContentBlock, ...] = ()
    value: JsonValue = None
    error: ErrorInfo | None = None

    @field_validator("call_id")
    @classmethod
    def validate_call_id(cls, value: str) -> str:
        return require_trimmed(value, "ToolResult callId")


class InteractionResponse(ContractModel):
    interaction_id: str = Field(min_length=1)
    response: JsonValue

    @field_validator("interaction_id")
    @classmethod
    def validate_interaction_id(cls, value: str) -> str:
        return require_trimmed(value, "InteractionResponse interactionId")


class CancelReason(ContractModel):
    code: str = "user_cancelled"
    message: str = "Cancelled by caller"

    @field_validator("code")
    @classmethod
    def validate_code(cls, value: str) -> str:
        return require_trimmed(value, "CancelReason code")

    @field_validator("message")
    @classmethod
    def validate_message(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("CancelReason message must be non-blank")
        return value


class HealthStatus(ContractModel):
    status: str = Field(pattern=r"^(healthy|degraded|unhealthy)$")
    details: dict[str, JsonValue] = Field(default_factory=dict)


@runtime_checkable
class ExecutionChannel(Protocol):
    def events(self) -> AsyncIterator[RuntimeEvent]: ...

    async def send_tool_result(self, result: ToolResult) -> None: ...

    async def respond(self, response: InteractionResponse) -> None: ...

    async def steer(self, input: tuple[ContentBlock, ...]) -> None: ...

    async def cancel(self, reason: CancelReason) -> None: ...

    async def close(self) -> None: ...


@runtime_checkable
class AgentRuntimePort(Protocol):
    async def describe(self) -> RuntimeDescriptor: ...

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef: ...

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel: ...

    async def close_session(self, session: RuntimeSessionRef) -> None: ...

    async def health(self) -> HealthStatus: ...


# Public terminology for new integrations.  ``AgentRuntimePort`` remains the
# v1 source-compatible name and is intentionally not removed.
HarnessAdapterPort = AgentRuntimePort
AgentExecutorPort = AgentRuntimePort


class RuntimeCheckpointEntry(ContractModel):
    key: str = Field(min_length=1)
    value: JsonValue

    @field_validator("key")
    @classmethod
    def validate_key(cls, value: str) -> str:
        return require_trimmed(value, "Runtime checkpoint entry key")


class RuntimeCheckpoint(ContractModel):
    checkpoint_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    binding_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    format: Literal["opaque", "portable"]
    schema_ref: SchemaReference = Field(
        validation_alias="schema",
        serialization_alias="schema",
    )
    entries: tuple[RuntimeCheckpointEntry, ...]
    digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")

    @classmethod
    def create(
        cls,
        *,
        checkpoint_id: str,
        session_id: str,
        binding_digest: str,
        format: Literal["opaque", "portable"],
        schema: SchemaReference,
        entries: tuple[RuntimeCheckpointEntry, ...],
    ) -> RuntimeCheckpoint:
        payload = {
            "checkpointId": checkpoint_id,
            "sessionId": session_id,
            "bindingDigest": binding_digest.lower(),
            "format": format,
            "schema": schema.model_dump(mode="json", by_alias=True),
            "entries": [entry.model_dump(mode="json", by_alias=True) for entry in entries],
        }
        digest = hashlib.sha256(
            json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode("utf-8")
        ).hexdigest()
        return cls(
            checkpoint_id=checkpoint_id,
            session_id=session_id,
            binding_digest=binding_digest.lower(),
            format=format,
            schema_ref=schema,
            entries=entries,
            digest=digest,
        )

    @field_validator("checkpoint_id", "session_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Runtime checkpoint identity")

    @field_validator("binding_digest", "digest")
    @classmethod
    def normalize_digest(cls, value: str) -> str:
        return value.lower()

    @model_validator(mode="after")
    def validate_integrity(self) -> RuntimeCheckpoint:
        if len({entry.key for entry in self.entries}) != len(self.entries):
            raise ValueError("Runtime checkpoint entry keys must be unique")
        payload = {
            "checkpointId": self.checkpoint_id,
            "sessionId": self.session_id,
            "bindingDigest": self.binding_digest,
            "format": self.format,
            "schema": self.schema_ref.model_dump(mode="json", by_alias=True),
            "entries": [entry.model_dump(mode="json", by_alias=True) for entry in self.entries],
        }
        expected = hashlib.sha256(
            json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode("utf-8")
        ).hexdigest()
        if expected != self.digest:
            raise ValueError("Runtime checkpoint digest mismatch")
        return self


@runtime_checkable
class RuntimeCheckpointPort(Protocol):
    async def export_checkpoint(self, session: RuntimeSessionRef) -> RuntimeCheckpoint: ...

    async def import_checkpoint(
        self,
        spec: RuntimeSessionSpec,
        checkpoint: RuntimeCheckpoint,
    ) -> RuntimeSessionRef: ...


def require_session_environment(
    spec: RuntimeSessionSpec,
    request: ExecutionRequest,
) -> None:
    """Fail closed if an execution mutates Session-scoped immutable inputs."""

    if request.session_id != spec.session_id:
        raise ValueError("execution sessionId differs from RuntimeSessionSpec")
    if request.workspace != spec.workspace:
        raise ValueError("workspace differs from the immutable RuntimeSessionSpec workspace")
    require_same_session_environment(spec, request.agent_environment)


def require_same_session_environment(
    spec: RuntimeSessionSpec,
    environment: AgentEnvironmentSnapshot,
) -> None:
    """Reject open/execute attempts that change a durable Session snapshot."""

    spec.agent_environment.assert_integrity()
    environment.assert_integrity()
    if spec.agent_environment.digest != environment.digest:
        raise ValueError("agentEnvironment differs from the immutable RuntimeSessionSpec snapshot")


def require_same_runtime_session_spec(
    existing: RuntimeSessionSpec,
    requested: RuntimeSessionSpec,
) -> None:
    """Make repeated ``open_session`` idempotent only for the exact same spec."""

    if existing != requested:
        raise ValueError("RuntimeSessionSpec cannot change while a Session is open")


def runtime_session_binding_digest(spec: RuntimeSessionSpec) -> str:
    """Stable identity for vendor/durable state owned by one Runtime Session.

    ``resume`` is caller intent rather than identity. ``mountHint`` is a
    deployment-local locator and arbitrary metadata is invocation/Host
    context, so neither may decide which hidden model transcript is resumed.
    The logical workspace, model/provider choice, and resolved immutable Agent
    Environment are the state-bearing inputs.
    """

    spec.agent_environment.assert_integrity()
    payload = {
        "sessionId": spec.session_id,
        "workspaceId": spec.workspace.workspace_id,
        "model": spec.model,
        "provider": spec.provider,
        "agentEnvironmentDigest": spec.agent_environment.digest,
    }
    return hashlib.sha256(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def require_runtime_environment_identity(
    descriptor: RuntimeDescriptor,
    environment: AgentEnvironmentSnapshot,
) -> None:
    """Ensure a resolved Snapshot is not replayed against a different Adapter binary."""

    environment.assert_integrity()
    identity = environment.runtime
    if identity is None:
        return  # Transitional env_empty/direct Adapter compatibility.
    capabilities_sha256 = hashlib.sha256(
        json.dumps(
            descriptor.capabilities.model_dump(mode="json", by_alias=True),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()
    actual = (
        descriptor.name,
        descriptor.runtime_version,
        descriptor.adapter_version,
        capabilities_sha256,
    )
    expected = (
        identity.name,
        identity.runtime_version,
        identity.adapter_version,
        identity.capabilities_sha256,
    )
    if actual != expected:
        raise ValueError("agentEnvironment Runtime/Adapter identity does not match this Runtime")


def normalize_token_usage(
    value: object,
    *,
    scope: Literal["model-call", "execution", "run"] = "model-call",
    cumulative: bool = False,
) -> NormalizedUsage | None:
    """Normalize common provider token counters without retaining vendor-shaped data.

    Unknown fields are deliberately ignored; callers that need them must emit a
    governed raw event.  Non-integral, negative or non-finite counters fail
    closed instead of being rounded.
    """

    if value is None:
        return None
    if hasattr(value, "model_dump"):
        value = value.model_dump(mode="json")
    elif not isinstance(value, Mapping) and hasattr(value, "__dict__"):
        value = vars(value)
    if not isinstance(value, Mapping):
        raise ValueError("usage must be an object")

    def counter(*names: str) -> int | None:
        for name in names:
            if name not in value or value[name] is None:
                continue
            raw = value[name]
            if isinstance(raw, bool) or not isinstance(raw, int) or raw < 0:
                raise ValueError(f"usage counter {name} must be a non-negative integer")
            return raw
        return None

    input_tokens = counter("input_tokens", "inputTokens", "prompt_tokens", "promptTokens", "input")
    output_tokens = counter(
        "output_tokens",
        "outputTokens",
        "completion_tokens",
        "completionTokens",
        "output",
    )
    total_tokens = counter("total_tokens", "totalTokens", "total")
    cached_input_tokens = counter(
        "cached_input_tokens",
        "cachedInputTokens",
        "cache_read_input_tokens",
        "cacheReadInputTokens",
        "cache_read_tokens",
    )
    cache_write_tokens = counter(
        "cache_write_tokens",
        "cacheWriteTokens",
        "cache_creation_input_tokens",
        "cacheCreationInputTokens",
    )
    reasoning_tokens = counter("reasoning_tokens", "reasoningTokens")
    if total_tokens is None and input_tokens is not None and output_tokens is not None:
        total_tokens = input_tokens + output_tokens
    if all(
        item is None
        for item in (
            input_tokens,
            output_tokens,
            total_tokens,
            cached_input_tokens,
            cache_write_tokens,
            reasoning_tokens,
        )
    ):
        return None
    return NormalizedUsage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        cached_input_tokens=cached_input_tokens,
        cache_write_tokens=cache_write_tokens,
        reasoning_tokens=reasoning_tokens,
        scope=scope,
        cumulative=cumulative,
    )


def normalize_finish_reason(value: str | None) -> CanonicalFinishReason | None:
    """Map provider stop strings to a stable, deliberately small taxonomy."""

    if value is None:
        return None
    normalized = require_trimmed(value, "finish reason").lower().replace("_", "-")
    aliases = {
        "stop": CanonicalFinishReason.STOP,
        "stopped": CanonicalFinishReason.STOP,
        "complete": CanonicalFinishReason.STOP,
        "completed": CanonicalFinishReason.STOP,
        "success": CanonicalFinishReason.STOP,
        "end-turn": CanonicalFinishReason.STOP,
        "tool-call": CanonicalFinishReason.TOOL_CALL,
        "tool-calls": CanonicalFinishReason.TOOL_CALL,
        "tool-use": CanonicalFinishReason.TOOL_CALL,
        "length": CanonicalFinishReason.LENGTH,
        "max-tokens": CanonicalFinishReason.LENGTH,
        "interaction": CanonicalFinishReason.INTERACTION,
        "cancelled": CanonicalFinishReason.CANCELLED,
        "canceled": CanonicalFinishReason.CANCELLED,
        "abort": CanonicalFinishReason.CANCELLED,
        "aborted": CanonicalFinishReason.CANCELLED,
        "error": CanonicalFinishReason.ERROR,
        "failed": CanonicalFinishReason.ERROR,
        "unknown": CanonicalFinishReason.UNKNOWN,
    }
    return aliases.get(normalized, CanonicalFinishReason.UNKNOWN)
