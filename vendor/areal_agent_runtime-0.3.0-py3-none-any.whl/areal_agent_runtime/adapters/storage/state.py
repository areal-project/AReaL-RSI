"""Durable filesystem StateStore for local and mounted-volume deployments."""

from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import math
import os
import tempfile
import threading
import time
import weakref
from collections.abc import AsyncIterator, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.product import RunSnapshot, RunStatus
from areal_agent_runtime.kernel.state import status_for_event, validate_state_commit

TERMINAL_STATUSES = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}


@dataclass(slots=True)
class _LockedReadCache:
    """Parsed reads valid only while this thread holds one filesystem lock."""

    events: dict[Path, tuple[RunEvent, ...]] = field(default_factory=dict)
    outbox: dict[Path, list[dict[str, Any]]] = field(default_factory=dict)


class FileSystemStateStore:
    def __init__(self, root: str | Path) -> None:
        self._root = Path(root).expanduser().resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        # No cache survives an unlock. Other StateStore instances/processes and
        # even out-of-band corruption must be observed by the next operation.
        self._read_caches = threading.local()
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._conditions: weakref.WeakValueDictionary[str, asyncio.Condition] = weakref.WeakValueDictionary()

    async def create_run(self, snapshot: RunSnapshot) -> None:
        snapshot = _durable_copy(snapshot)
        async with self._lock(snapshot.run_id):
            await asyncio.to_thread(self._create_run, snapshot)
        await self._notify(snapshot.run_id)

    async def save_run(self, snapshot: RunSnapshot) -> None:
        snapshot = _durable_copy(snapshot)
        async with self._lock(snapshot.run_id):
            await asyncio.to_thread(self._save_run, snapshot)
        await self._notify(snapshot.run_id)

    async def get_run(self, run_id: str) -> RunSnapshot | None:
        self._validate_identity(run_id, "run_id")
        async with self._lock(run_id):
            return await asyncio.to_thread(self._get_run, run_id)

    async def try_acquire_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool:
        self._validate_identity(run_id, "run_id")
        self._validate_lease_input(owner_id, ttl_seconds)
        async with self._lock(run_id):
            return await asyncio.to_thread(
                self._try_acquire_run,
                run_id,
                owner_id,
                ttl_seconds,
            )

    async def renew_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool:
        self._validate_identity(run_id, "run_id")
        self._validate_lease_input(owner_id, ttl_seconds)
        async with self._lock(run_id):
            return await asyncio.to_thread(
                self._renew_run,
                run_id,
                owner_id,
                ttl_seconds,
            )

    async def release_run(self, run_id: str, owner_id: str) -> None:
        self._validate_identity(run_id, "run_id")
        self._validate_identity(owner_id, "run lease owner_id")
        async with self._lock(run_id):
            await asyncio.to_thread(self._release_run, run_id, owner_id)

    async def save_environment_snapshot(
        self,
        session_id: str,
        snapshot: AgentEnvironmentSnapshot,
    ) -> None:
        self._validate_identity(session_id, "session_id")
        snapshot = _durable_copy(snapshot)
        async with self._lock(f"session:{session_id}"):
            await asyncio.to_thread(self._save_environment_snapshot, session_id, snapshot)

    async def get_environment_snapshot(self, session_id: str) -> AgentEnvironmentSnapshot | None:
        self._validate_identity(session_id, "session_id")
        return await asyncio.to_thread(self._get_environment_snapshot, session_id)

    async def commit_event(
        self,
        event: RunEvent,
        snapshot: RunSnapshot,
        *,
        outbox_sinks: tuple[str, ...],
    ) -> None:
        self._validate_sink_ids(outbox_sinks)
        durable_event = _durable_copy(event)
        durable_snapshot = _durable_copy(snapshot)
        async with self._lock(durable_event.run_id):
            await asyncio.to_thread(
                self._commit_event,
                durable_event,
                durable_snapshot,
                outbox_sinks,
            )
        await self._notify(durable_event.run_id)

    async def append_event(self, event: RunEvent) -> None:
        """Compatibility helper; new code must use the atomic commit_event API."""

        current = await self.get_run(event.run_id)
        if current is None:
            raise KeyError(event.run_id)
        status = status_for_event(event, current.status)
        await self.commit_event(
            event,
            current.model_copy(update={"last_sequence": event.sequence, "status": status}),
            outbox_sinks=(),
        )

    async def latest_event_sequence(self, run_id: str) -> int:
        self._validate_identity(run_id, "run_id")
        async with self._lock(run_id):
            return await asyncio.to_thread(self._latest_event_sequence, run_id)

    async def list_run_ids(self) -> tuple[str, ...]:
        return await asyncio.to_thread(self._list_run_ids)

    async def pending_event_deliveries(
        self,
        run_id: str,
        sink_id: str,
        *,
        limit: int = 128,
    ) -> tuple[RunEvent, ...]:
        self._validate_identity(run_id, "run_id")
        self._validate_delivery_input(sink_id, limit)
        async with self._lock(run_id):
            return await asyncio.to_thread(self._pending_event_deliveries, run_id, sink_id, limit)

    async def acknowledge_event_delivery(
        self,
        run_id: str,
        sink_id: str,
        *,
        through_sequence: int,
    ) -> None:
        self._validate_identity(run_id, "run_id")
        self._validate_identity(sink_id, "sink_id")
        if (
            isinstance(through_sequence, bool)
            or not isinstance(through_sequence, int)
            or through_sequence < 0
        ):
            raise ValueError("through_sequence must be a non-negative integer")
        async with self._lock(run_id):
            await asyncio.to_thread(
                self._acknowledge_event_delivery,
                run_id,
                sink_id,
                through_sequence,
            )

    def stream_events(self, run_id: str, after: int | None = None) -> AsyncIterator[RunEvent]:
        return self._stream_events(run_id, after)

    async def list_events(self, run_id: str) -> tuple[RunEvent, ...]:
        self._validate_identity(run_id, "run_id")
        async with self._lock(run_id):
            return await asyncio.to_thread(self._list_events, run_id)

    async def _stream_events(self, run_id: str, after: int | None) -> AsyncIterator[RunEvent]:
        self._validate_identity(run_id, "run_id")
        if after is not None and (
            isinstance(after, bool) or not isinstance(after, int) or after < -1
        ):
            raise ValueError("event cursor must be an integer of at least -1")
        cursor = 0 if after is None else after + 1
        condition = self._conditions.setdefault(run_id, asyncio.Condition())
        while True:
            events = await self.list_events(run_id)
            for event in events[cursor:]:
                cursor = event.sequence + 1
                yield event
            snapshot = await self.get_run(run_id)
            # list_events() and get_run() are individually consistent reads,
            # but a writer may commit between them. Never terminate a stream
            # using a newer terminal Snapshot and an older EventLog view.
            if snapshot is not None and snapshot.last_sequence >= len(events):
                continue
            if snapshot is not None and snapshot.status in TERMINAL_STATUSES and cursor >= len(events):
                return
            async with condition:
                try:
                    async with asyncio.timeout(1):
                        await condition.wait()
                except TimeoutError:
                    pass  # Polling also observes writers in another process.

    def _create_run(self, snapshot: RunSnapshot) -> None:
        with self._run_file_lock(snapshot.run_id) as run_dir:
            snapshot_path = run_dir / "snapshot.json"
            if snapshot_path.exists():
                raise ValueError(f"run already exists: {snapshot.run_id}")
            if snapshot.last_sequence != -1:
                raise ValueError("a new RunSnapshot must start at sequence -1")
            self._write_snapshot_at(run_dir, snapshot)

    def _save_run(self, snapshot: RunSnapshot) -> None:
        with self._run_file_lock(snapshot.run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(snapshot.run_id)
            self._recover_pending_commit(run_dir)
            expected = len(self._read_events(run_dir)) - 1
            if snapshot.last_sequence != expected:
                raise ValueError(
                    f"RunSnapshot sequence must match EventLog for {snapshot.run_id}: "
                    f"expected {expected}, got {snapshot.last_sequence}"
                )
            current = self._read_snapshot(run_dir)
            if snapshot != current:
                raise ValueError(
                    "save_run is an idempotent compatibility operation; "
                    "RunSnapshot changes must be committed with their canonical event"
                )

    def _get_run(self, run_id: str) -> RunSnapshot | None:
        path = self._run_dir(run_id) / "snapshot.json"
        if not path.exists():
            return None
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                return None
            self._recover_pending_commit(run_dir)
            snapshot = self._read_snapshot(run_dir)
            if snapshot.run_id != run_id:
                raise ValueError(f"Corrupt StateStore snapshot for {run_id}")
            return snapshot

    def _try_acquire_run(self, run_id: str, owner_id: str, ttl_seconds: float) -> bool:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(run_id)
            self._recover_pending_commit(run_dir)
            if self._read_snapshot(run_dir).status in TERMINAL_STATUSES:
                return False
            now = time.time()
            current = self._read_run_lease(run_dir)
            if current is not None and current[0] != owner_id and current[1] > now:
                return False
            self._write_run_lease(run_dir, owner_id, now + ttl_seconds)
            return True

    def _renew_run(self, run_id: str, owner_id: str, ttl_seconds: float) -> bool:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(run_id)
            now = time.time()
            current = self._read_run_lease(run_dir)
            if current is None or current[0] != owner_id or current[1] <= now:
                return False
            self._write_run_lease(run_dir, owner_id, now + ttl_seconds)
            return True

    def _release_run(self, run_id: str, owner_id: str) -> None:
        with self._run_file_lock(run_id) as run_dir:
            lease_path = run_dir / "execution-lease.json"
            current = self._read_run_lease(run_dir)
            if current is None or current[0] != owner_id:
                return
            lease_path.unlink(missing_ok=True)
            self._fsync_directory(run_dir)

    def _commit_event(
        self,
        event: RunEvent,
        snapshot: RunSnapshot,
        outbox_sinks: tuple[str, ...],
    ) -> None:
        with self._run_file_lock(event.run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(event.run_id)
            self._recover_pending_commit(run_dir)
            current = self._read_snapshot(run_dir)
            events = self._read_events(run_dir)
            if event.sequence != len(events):
                raise ValueError(
                    f"non-contiguous event sequence for {event.run_id}: expected {len(events)}, got {event.sequence}"
                )
            if any(current_event.event_id == event.event_id for current_event in events):
                raise ValueError(f"duplicate event id: {event.event_id}")
            self._validate_commit(event, snapshot, current)
            transaction = {
                "schemaVersion": "areal.agent-runtime.state-commit/v1",
                "event": event.model_dump(mode="json", by_alias=True),
                "snapshot": snapshot.model_dump(mode="json", by_alias=True),
                "outboxSinks": list(dict.fromkeys(outbox_sinks)),
            }
            self._write_json_atomic(
                run_dir / "commit.pending.json",
                transaction,
                prefix="commit-pending-",
            )
            self._recover_pending_commit(run_dir)

    def _latest_event_sequence(self, run_id: str) -> int:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(run_id)
            self._recover_pending_commit(run_dir)
            return len(self._read_events(run_dir)) - 1

    def _save_environment_snapshot(
        self,
        session_id: str,
        snapshot: AgentEnvironmentSnapshot,
    ) -> None:
        snapshot.assert_integrity()
        path = self._session_dir(session_id) / "agent-environment.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        lock_handle = os.open(path.with_suffix(".lock"), os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(lock_handle, fcntl.LOCK_EX)
            if path.exists():
                existing = AgentEnvironmentSnapshot.model_validate(
                    _strict_json_loads(path.read_text(encoding="utf-8"))
                )
                if existing.digest != snapshot.digest:
                    raise ValueError(f"agent environment is immutable for session: {session_id}")
                return
            self._write_json_atomic(
                path,
                snapshot.model_dump(mode="json", by_alias=True),
                prefix="agent-environment-",
            )
        finally:
            fcntl.flock(lock_handle, fcntl.LOCK_UN)
            os.close(lock_handle)

    def _get_environment_snapshot(self, session_id: str) -> AgentEnvironmentSnapshot | None:
        path = self._session_dir(session_id) / "agent-environment.json"
        try:
            raw = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None
        return AgentEnvironmentSnapshot.model_validate(_strict_json_loads(raw))

    def _list_events(self, run_id: str) -> tuple[RunEvent, ...]:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                return ()
            self._recover_pending_commit(run_dir)
            return self._read_events(run_dir)

    def _list_run_ids(self) -> tuple[str, ...]:
        run_ids: list[str] = []
        for candidate in sorted(self._root.iterdir()):
            if not candidate.is_dir() or candidate.name == "sessions":
                continue
            snapshot_path = candidate / "snapshot.json"
            if not snapshot_path.exists():
                continue
            snapshot = RunSnapshot.model_validate(
                _strict_json_loads(snapshot_path.read_text(encoding="utf-8"))
            )
            restored = self._get_run(snapshot.run_id)
            if restored is not None:
                run_ids.append(restored.run_id)
        return tuple(sorted(run_ids))

    def _pending_event_deliveries(
        self,
        run_id: str,
        sink_id: str,
        limit: int,
    ) -> tuple[RunEvent, ...]:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(run_id)
            self._recover_pending_commit(run_dir)
            events = self._read_events(run_dir)
            outbox = self._read_outbox(run_dir)
            acknowledgements = self._read_outbox_acks(run_dir)
            self._validate_acknowledgements(outbox, acknowledgements)
            acknowledged = acknowledgements.get(sink_id, -1)
            pending = [
                events[int(entry["sequence"])]
                for entry in outbox
                if int(entry["sequence"]) > acknowledged and sink_id in entry["sinkIds"]
            ]
            return tuple(pending[:limit])

    def _acknowledge_event_delivery(
        self,
        run_id: str,
        sink_id: str,
        through_sequence: int,
    ) -> None:
        with self._run_file_lock(run_id) as run_dir:
            if not (run_dir / "snapshot.json").exists():
                raise KeyError(run_id)
            self._recover_pending_commit(run_dir)
            acknowledgements = self._read_outbox_acks(run_dir)
            outbox = self._read_outbox(run_dir)
            self._validate_acknowledgements(outbox, acknowledgements)
            current = acknowledgements.get(sink_id, -1)
            if through_sequence <= current:
                return
            pending = [
                int(entry["sequence"])
                for entry in outbox
                if int(entry["sequence"]) > current and sink_id in entry["sinkIds"]
            ]
            if through_sequence not in pending:
                raise ValueError(
                    f"outbox acknowledgement does not name a pending delivery for {sink_id}: {through_sequence}"
                )
            acknowledgements[sink_id] = through_sequence
            self._write_json_atomic(
                run_dir / "outbox-acks.json",
                {
                    "schemaVersion": "areal.agent-runtime.event-outbox-acks/v1",
                    "sinks": acknowledgements,
                },
                prefix="outbox-acks-",
            )

    def _recover_pending_commit(self, run_dir: Path) -> None:
        pending_path = run_dir / "commit.pending.json"
        if not pending_path.exists():
            self._reconcile_snapshot(run_dir)
            snapshot = self._read_snapshot(run_dir)
            events = self._read_events(run_dir)
            self._validate_event_log(events, snapshot)
            self._validate_outbox(events, self._read_outbox(run_dir), snapshot.run_id)
            return
        payload = _strict_json_loads(pending_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("schemaVersion") != "areal.agent-runtime.state-commit/v1":
            raise ValueError(f"Unsupported or corrupt StateStore transaction: {pending_path}")
        event = RunEvent.model_validate(payload.get("event"))
        snapshot = RunSnapshot.model_validate(payload.get("snapshot"))
        raw_sinks = payload.get("outboxSinks")
        if not isinstance(raw_sinks, list) or not all(isinstance(item, str) and item for item in raw_sinks):
            raise ValueError(f"Corrupt StateStore outbox transaction: {pending_path}")
        self._validate_commit(event, snapshot, self._read_snapshot(run_dir))

        events = list(self._read_events(run_dir))
        self._validate_event_log(tuple(events), self._read_snapshot(run_dir))
        if event.sequence == len(events):
            events.append(event)
            self._write_events(run_dir, events)
        elif event.sequence < len(events):
            if events[event.sequence] != event:
                raise ValueError(f"StateStore transaction conflicts with EventLog at sequence {event.sequence}")
        else:
            raise ValueError(
                f"StateStore transaction has an EventLog gap: expected {len(events)}, got {event.sequence}"
            )

        outbox = self._read_outbox(run_dir)
        self._validate_outbox(tuple(events[: len(outbox)]), outbox, event.run_id)
        if len(outbox) > len(events):
            raise ValueError("StateStore Outbox is ahead of EventLog")
        if len(outbox) < event.sequence:
            raise ValueError("StateStore Event Outbox is missing an earlier delivery intent")
        entry = self._outbox_entry(event, tuple(dict.fromkeys(raw_sinks)))
        if event.sequence == len(outbox):
            outbox.append(entry)
            self._write_outbox(run_dir, outbox)
        elif outbox[event.sequence] != entry:
            raise ValueError(f"StateStore transaction conflicts with Outbox at sequence {event.sequence}")
        self._validate_outbox(tuple(events), outbox, event.run_id)

        current_snapshot = self._read_snapshot(run_dir)
        if current_snapshot.last_sequence < event.sequence:
            self._write_snapshot_at(run_dir, snapshot)
        elif current_snapshot.last_sequence == event.sequence and current_snapshot != snapshot:
            raise ValueError(f"StateStore transaction conflicts with RunSnapshot at sequence {event.sequence}")
        elif current_snapshot.last_sequence > event.sequence:
            raise ValueError("StateStore transaction is older than the durable RunSnapshot")

        pending_path.unlink()
        self._fsync_directory(run_dir)

    def _reconcile_snapshot(self, run_dir: Path) -> None:
        snapshot_path = run_dir / "snapshot.json"
        if not snapshot_path.exists():
            return
        snapshot = self._read_snapshot(run_dir)
        events = self._read_events(run_dir)
        latest = len(events) - 1
        if snapshot.last_sequence > latest:
            raise ValueError(
                f"RunSnapshot is ahead of EventLog for {snapshot.run_id}: "
                f"snapshot={snapshot.last_sequence}, eventLog={latest}"
            )
        if snapshot.last_sequence == latest:
            return
        recovered = snapshot
        for event in events[snapshot.last_sequence + 1 :]:
            updates: dict[str, Any] = {
                "last_sequence": event.sequence,
                "status": status_for_event(event, recovered.status),
            }
            if event.type == EventType.RUN_FAILED:
                updates["error"] = event.data.get("error")
            candidate = recovered.model_copy(update=updates)
            validate_state_commit(event, candidate, recovered)
            recovered = candidate
        self._write_snapshot_at(run_dir, recovered)

    @staticmethod
    def _validate_commit(event: RunEvent, snapshot: RunSnapshot, current: RunSnapshot) -> None:
        validate_state_commit(event, snapshot, current)

    @staticmethod
    def _status_for_event(event: RunEvent, current: RunStatus) -> RunStatus:
        return status_for_event(event, current)

    @staticmethod
    def _validate_status_transition(
        event: RunEvent,
        snapshot: RunSnapshot,
        current: RunSnapshot,
    ) -> None:
        validate_state_commit(event, snapshot, current)

    @staticmethod
    def _outbox_entry(event: RunEvent, sink_ids: tuple[str, ...]) -> dict[str, Any]:
        return {
            "schemaVersion": "areal.agent-runtime.event-outbox-entry/v1",
            "runId": event.run_id,
            "eventId": event.event_id,
            "sequence": event.sequence,
            "sinkIds": list(sink_ids),
        }

    @staticmethod
    def _validate_event_log(events: tuple[RunEvent, ...], snapshot: RunSnapshot) -> None:
        event_ids: set[str] = set()
        for index, event in enumerate(events):
            if event.sequence != index:
                raise ValueError("StateStore EventLog sequences must be contiguous from zero")
            if event.run_id != snapshot.run_id or event.session_id != snapshot.session_id:
                raise ValueError("StateStore EventLog identity differs from RunSnapshot")
            expected_correlation = snapshot.context.correlation_id or snapshot.run_id
            if event.correlation_id != expected_correlation:
                raise ValueError("StateStore EventLog correlationId differs from Run context")
            if (
                event.tenant_id != snapshot.context.tenant_id
                or event.project_id != snapshot.context.project_id
                or event.trace_id != snapshot.context.trace_id
                or event.episode_id != snapshot.context.episode_id
            ):
                raise ValueError("StateStore EventLog lineage differs from Run context")
            if event.event_id in event_ids:
                raise ValueError(f"duplicate event id: {event.event_id}")
            event_ids.add(event.event_id)

    @staticmethod
    def _validate_outbox(
        events: tuple[RunEvent, ...],
        outbox: list[dict[str, Any]],
        run_id: str,
    ) -> None:
        if len(outbox) != len(events):
            raise ValueError("StateStore Event Outbox length differs from EventLog")
        for index, (event, entry) in enumerate(zip(events, outbox, strict=True)):
            if (
                entry["sequence"] != index
                or entry["runId"] != run_id
                or entry["eventId"] != event.event_id
            ):
                raise ValueError(f"StateStore Event Outbox identity mismatch at sequence {index}")

    @staticmethod
    def _validate_acknowledgements(
        outbox: list[dict[str, Any]],
        acknowledgements: dict[str, int],
    ) -> None:
        for sink_id, sequence in acknowledgements.items():
            if sequence < 0:
                continue
            if sequence >= len(outbox) or sink_id not in outbox[sequence]["sinkIds"]:
                raise ValueError(
                    f"StateStore acknowledgement is not backed by an Outbox delivery: {sink_id}@{sequence}"
                )

    @staticmethod
    def _read_snapshot(run_dir: Path) -> RunSnapshot:
        return RunSnapshot.model_validate(
            _strict_json_loads((run_dir / "snapshot.json").read_text(encoding="utf-8"))
        )

    def _read_events(self, run_dir: Path) -> tuple[RunEvent, ...]:
        cache: _LockedReadCache | None = getattr(self._read_caches, "current", None)
        if cache is not None and run_dir in cache.events:
            return cache.events[run_dir]
        path = run_dir / "events.jsonl"
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return ()
        events = tuple(RunEvent.model_validate(_strict_json_loads(line)) for line in lines if line)
        if any(event.sequence != index for index, event in enumerate(events)):
            raise ValueError(f"Corrupt non-contiguous EventLog: {path}")
        if cache is not None:
            cache.events[run_dir] = events
        return events

    def _read_outbox(self, run_dir: Path) -> list[dict[str, Any]]:
        cache: _LockedReadCache | None = getattr(self._read_caches, "current", None)
        if cache is not None and run_dir in cache.outbox:
            # Recovery appends to its own list before writing the transaction.
            return cache.outbox[run_dir].copy()
        path = run_dir / "outbox.jsonl"
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return []
        entries: list[dict[str, Any]] = []
        for index, line in enumerate(line for line in lines if line):
            entry = _strict_json_loads(line)
            if (
                not isinstance(entry, dict)
                or entry.get("schemaVersion") != "areal.agent-runtime.event-outbox-entry/v1"
                or not isinstance(entry.get("runId"), str)
                or not entry["runId"]
                or not isinstance(entry.get("eventId"), str)
                or not entry["eventId"]
                or isinstance(entry.get("sequence"), bool)
                or entry.get("sequence") != index
                or not isinstance(entry.get("sinkIds"), list)
                or not all(
                    isinstance(item, str) and item.strip() and item == item.strip()
                    for item in entry["sinkIds"]
                )
                or len(entry["sinkIds"]) != len(set(entry["sinkIds"]))
            ):
                raise ValueError(f"Corrupt Event Outbox at sequence {index}: {path}")
            entries.append(entry)
        if cache is not None:
            cache.outbox[run_dir] = entries.copy()
        return entries

    @staticmethod
    def _read_outbox_acks(run_dir: Path) -> dict[str, int]:
        path = run_dir / "outbox-acks.json"
        try:
            payload = _strict_json_loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        if not isinstance(payload, dict) or payload.get("schemaVersion") != "areal.agent-runtime.event-outbox-acks/v1":
            raise ValueError(f"Corrupt Event Outbox acknowledgements: {path}")
        sinks = payload.get("sinks")
        if not isinstance(sinks, dict) or not all(
            isinstance(key, str)
            and key.strip()
            and key == key.strip()
            and not isinstance(value, bool)
            and isinstance(value, int)
            and value >= -1
            for key, value in sinks.items()
        ):
            raise ValueError(f"Corrupt Event Outbox acknowledgements: {path}")
        return dict(sinks)

    @staticmethod
    def _read_run_lease(run_dir: Path) -> tuple[str, float] | None:
        path = run_dir / "execution-lease.json"
        try:
            payload = _strict_json_loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        if (
            not isinstance(payload, dict)
            or payload.get("schemaVersion") != "areal.agent-runtime.run-lease/v1"
            or not isinstance(payload.get("ownerId"), str)
            or not payload["ownerId"].strip()
            or payload["ownerId"] != payload["ownerId"].strip()
            or isinstance(payload.get("expiresAt"), bool)
            or not isinstance(payload.get("expiresAt"), (int, float))
            or not math.isfinite(payload["expiresAt"])
        ):
            raise ValueError(f"Corrupt Run execution lease: {path}")
        return payload["ownerId"], float(payload["expiresAt"])

    def _write_run_lease(self, run_dir: Path, owner_id: str, expires_at: float) -> None:
        self._write_json_atomic(
            run_dir / "execution-lease.json",
            {
                "schemaVersion": "areal.agent-runtime.run-lease/v1",
                "ownerId": owner_id,
                "expiresAt": expires_at,
            },
            prefix="execution-lease-",
        )

    def _write_snapshot_at(self, run_dir: Path, snapshot: RunSnapshot) -> None:
        path = run_dir / "snapshot.json"
        self._write_json_atomic(
            path,
            snapshot.model_dump(mode="json", by_alias=True),
            prefix="snapshot-",
        )

    def _write_events(self, run_dir: Path, events: list[RunEvent]) -> None:
        cache: _LockedReadCache | None = getattr(self._read_caches, "current", None)
        if cache is not None:
            cache.events.pop(run_dir, None)
        self._write_jsonl_atomic(
            run_dir / "events.jsonl",
            [event.model_dump(mode="json", by_alias=True) for event in events],
            prefix="events-",
        )

    def _write_outbox(self, run_dir: Path, entries: list[dict[str, Any]]) -> None:
        cache: _LockedReadCache | None = getattr(self._read_caches, "current", None)
        if cache is not None:
            cache.outbox.pop(run_dir, None)
        self._write_jsonl_atomic(run_dir / "outbox.jsonl", entries, prefix="outbox-")

    @staticmethod
    def _write_jsonl_atomic(path: Path, payloads: list[dict[str, Any]], *, prefix: str) -> None:
        descriptor, temporary_name = tempfile.mkstemp(prefix=prefix, dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                for payload in payloads:
                    json.dump(
                        payload,
                        handle,
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                        allow_nan=False,
                    )
                    handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            FileSystemStateStore._fsync_directory(path.parent)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise

    @staticmethod
    def _write_json_atomic(path: Path, payload: object, *, prefix: str) -> None:
        descriptor, temporary_name = tempfile.mkstemp(prefix=prefix, dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(
                    payload,
                    handle,
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                    allow_nan=False,
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            FileSystemStateStore._fsync_directory(path.parent)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise

    @contextmanager
    def _run_file_lock(self, run_id: str) -> Iterator[Path]:
        run_dir = self._run_dir(run_id)
        run_dir.mkdir(parents=True, exist_ok=True)
        lock_handle = os.open(run_dir / "events.lock", os.O_CREAT | os.O_RDWR, 0o600)
        previous_cache = getattr(self._read_caches, "current", None)
        try:
            fcntl.flock(lock_handle, fcntl.LOCK_EX)
            self._read_caches.current = _LockedReadCache()
            yield run_dir
        finally:
            self._read_caches.current = previous_cache
            fcntl.flock(lock_handle, fcntl.LOCK_UN)
            os.close(lock_handle)

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _run_dir(self, run_id: str) -> Path:
        safe = hashlib.sha256(run_id.encode("utf-8")).hexdigest()
        return self._root / safe

    def _session_dir(self, session_id: str) -> Path:
        safe = hashlib.sha256(session_id.encode("utf-8")).hexdigest()
        return self._root / "sessions" / safe

    @staticmethod
    def _validate_lease_input(owner_id: str, ttl_seconds: float) -> None:
        FileSystemStateStore._validate_identity(owner_id, "run lease owner_id")
        if (
            isinstance(ttl_seconds, bool)
            or not isinstance(ttl_seconds, (int, float))
            or not math.isfinite(ttl_seconds)
            or ttl_seconds <= 0
        ):
            raise ValueError("run lease ttl_seconds must be a finite positive number")

    @staticmethod
    def _validate_delivery_input(sink_id: str, limit: int) -> None:
        FileSystemStateStore._validate_identity(sink_id, "sink_id")
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            raise ValueError("delivery limit must be a positive integer")

    @staticmethod
    def _validate_identity(value: str, field: str) -> None:
        if not isinstance(value, str) or not value.strip() or value != value.strip():
            raise ValueError(f"{field} must be a non-empty trimmed string")

    @classmethod
    def _validate_sink_ids(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if not isinstance(values, tuple):
            raise TypeError("outbox_sinks must be a tuple")
        for value in values:
            cls._validate_identity(value, "outbox sink identity")
        if len(values) != len(set(values)):
            raise ValueError("outbox sink identities must not contain duplicates")
        return values

    def _lock(self, run_id: str) -> asyncio.Lock:
        return self._locks.setdefault(run_id, asyncio.Lock())

    async def _notify(self, run_id: str) -> None:
        condition = self._conditions.setdefault(run_id, asyncio.Condition())
        async with condition:
            condition.notify_all()


def _strict_json_loads(payload: str) -> object:
    def reject_constant(value: str) -> None:
        raise ValueError(f"non-finite JSON number is not allowed: {value}")

    def unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON object key: {key}")
            result[key] = value
        return result

    return json.loads(
        payload,
        parse_constant=reject_constant,
        object_pairs_hook=unique_object,
    )


def _durable_copy(value):  # type: ignore[no-untyped-def]
    return type(value).model_validate(value.model_dump(mode="json", by_alias=True))
