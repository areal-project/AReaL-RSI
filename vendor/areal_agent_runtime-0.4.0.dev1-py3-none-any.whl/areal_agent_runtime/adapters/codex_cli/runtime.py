"""Codex's native App Server loop, instructions, skill discovery and durable threads."""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import math
import os
import re
import shutil
import weakref
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlparse

from areal_agent_runtime.adapters._event_buffer import RuntimeEventBuffer, RuntimeEventBufferOverflow
from areal_agent_runtime.adapters._identity_index import session_identity_map
from areal_agent_runtime.adapters.codex_cli.process import CodexRpc
from areal_agent_runtime.adapters.codex_cli.skills import materialize_skills, verify_selected_skills
from areal_agent_runtime.contracts.content import ContentBlock, TextBlock
from areal_agent_runtime.contracts.data import DataCoverage, DetailCoverage, MessageCoverage, UsageCoverage
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolResult,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
    runtime_session_binding_digest,
)
from areal_agent_runtime.harness_sdk.events import HarnessEventBuilder
from areal_agent_runtime.kernel.ids import new_id

_END = object()
_TOOL_TERMINAL_DRAIN_SECONDS = 5.0


@dataclass(frozen=True, slots=True)
class CodexCliRuntimeConfig:
    codex_bin: str = "codex"
    codex_home: str | None = None
    model: str | None = None
    provider: str | None = None
    base_url: str | None = None
    api_key_env: str | None = None
    model_protocol: Literal["responses", "anthropic"] = "responses"
    max_tokens: int = 4096
    model_parameters: dict[str, Any] = field(default_factory=dict)
    state_directory: str | None = None
    skill_directories: tuple[str, ...] = ()
    profile_binding: Literal["auto", "runtime-owned", "portable"] = "auto"
    application_tool_bridge: bool = False
    sandbox: Literal["read-only", "workspace-write", "danger-full-access"] = "workspace-write"
    approval_policy: Literal["untrusted", "on-request", "never"] = "never"
    timeout_seconds: float = 300.0
    max_concurrency: int = 2

    def __post_init__(self) -> None:
        if self.profile_binding not in {"auto", "runtime-owned", "portable"}:
            raise ValueError("Invalid Codex profileBinding")
        if self.application_tool_bridge or self.profile_binding == "portable":
            raise ValueError(
                "Codex App Server adapter supports runtime-owned profileBinding only; portable tool catalogs "
                "and ApplicationToolBridge cannot precisely constrain all native tools in this version"
            )
        if self.sandbox not in {"read-only", "workspace-write", "danger-full-access"}:
            raise ValueError("Invalid Codex sandbox")
        if self.approval_policy not in {"untrusted", "on-request", "never"}:
            raise ValueError("Invalid Codex approvalPolicy")
        if not math.isfinite(self.timeout_seconds) or self.timeout_seconds <= 0:
            raise ValueError("Codex timeoutSeconds must be finite and positive")
        if (
            isinstance(self.max_concurrency, bool)
            or not isinstance(self.max_concurrency, int)
            or self.max_concurrency < 1
        ):
            raise ValueError("Codex maxConcurrency must be positive")
        if self.api_key_env is not None and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", self.api_key_env) is None:
            raise ValueError("Codex apiKeyEnv must name an environment variable")
        if self.base_url is not None:
            parsed = urlparse(self.base_url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
                raise ValueError("Codex baseUrl must be HTTP(S) without embedded credentials")
            if parsed.fragment:
                raise ValueError("Codex baseUrl must not contain a fragment")
        if self.model_protocol not in {"responses", "anthropic"}:
            raise ValueError("Codex modelProtocol must be responses or anthropic")
        if self.model_protocol == "anthropic" and (self.base_url is None or self.api_key_env is None):
            raise ValueError("Anthropic Codex provider requires baseUrl and apiKeyEnv")
        if self.model_protocol == "responses" and self.model_parameters:
            raise ValueError("modelParameters is an Anthropic bridge option; use native Codex config for Responses")
        if isinstance(self.max_tokens, bool) or not isinstance(self.max_tokens, int) or self.max_tokens < 1:
            raise ValueError("Codex maxTokens must be positive")


@dataclass(slots=True)
class _SessionState:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    rpc: CodexRpc
    skills: dict[str, Path]
    channel: CodexCliExecutionChannel | None = None
    closing: bool = False
    # Persist native thread totals; canonical notifications publish increments.
    token_total: dict[str, int] = field(default_factory=dict)
    bridge: Any = None


class CodexCliExecutionChannel(ExecutionChannel):
    def __init__(self, adapter: CodexCliRuntimeAdapter, state: _SessionState, request: ExecutionRequest) -> None:
        self._adapter, self._state, self._request = adapter, state, request
        # Inbound frames have a turn budget. Outbound terminal events must never
        # block close/cancel merely because the caller stopped consuming events.
        self._events_queue = RuntimeEventBuffer(_END)
        self._notifications: asyncio.Queue[tuple[str, dict[str, Any]] | Exception] = asyncio.Queue(maxsize=4096)
        self._builder = HarnessEventBuilder(
            producer="codex-cli",
            runtime_instance_id=adapter._instance_id,
            execution_id=request.execution_id,
            agent_id=request.agent.agent_id,
            parent_agent_id=request.agent.parent_agent_id,
        )
        self._turn_id: str | None = None
        self._begun = asyncio.Event()
        self._turn_started = asyncio.Event()
        self._cancelled = False
        self._draining_terminal_tools = False
        self._closed = False
        self._consumed = False
        self._tool_started: set[str] = set()
        self._tool_names: dict[str, str] = {}
        self._tool_finished: set[str] = set()
        self._messages: set[str] = set()
        self._reasoning_observed = False
        self._public_text_observed = False
        self._usage_base = dict(state.token_total)
        self._received_bytes = 0
        self._received_count = 0
        self._overflowed = False
        self._task = asyncio.create_task(
            self._events_queue.run_producer(self._run), name=f"codex:{request.execution_id}",
        )
        self._task.add_done_callback(self._events_queue.producer_done)

    def notification(self, method: str, params: dict[str, Any]) -> None:
        if self._closed or self._overflowed or params.get("threadId") != self._state.ref.runtime_session_id:
            return
        self._received_count += 1
        self._received_bytes += len(json.dumps(params, ensure_ascii=False).encode("utf-8"))
        if self._received_count > 16384 or self._received_bytes > 64 * 1024 * 1024:
            self._overflowed = True
            self._task.cancel()
            return
        try:
            self._notifications.put_nowait((method, params))
        except asyncio.QueueFull:
            self._overflowed = True
            self._task.cancel()

    def failure(self, error: Exception) -> None:
        if not self._closed:
            with contextlib.suppress(asyncio.QueueFull):
                self._notifications.put_nowait(error)

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        if self._consumed:
            raise RuntimeError("Codex execution events may only be consumed once")
        self._consumed = True
        while (item := await self._events_queue.get()) is not _END:
            assert isinstance(item, RuntimeEvent)
            yield item

    async def _emit(self, event_type: EventType, data: dict[str, Any]) -> None:
        await self._events_queue.put(self._builder.event(event_type, data))

    async def _run(self) -> None:
        self._begun.set()
        outcome = {"vendor": "codex-cli", "reason": "adapter_error"}
        completed = False
        try:
            await self._emit(EventType.EXECUTION_STARTED, {"vendor": "codex-cli"})
            async with self._adapter._execution_slots:
                if self._cancelled:
                    outcome["reason"] = "cancelled"
                    return
                async with asyncio.timeout(self._adapter._config.timeout_seconds):
                    # Reload and verify on every turn: native config/watchers may have changed.
                    await self._adapter._verify_skills(self._state)
                    response = await self._state.rpc.request(
                        "turn/start",
                        {
                            "threadId": self._state.ref.runtime_session_id,
                            "input": self._input(),
                        },
                    )
                    self._turn_id = response["turn"]["id"]
                    self._turn_started.set()
                    if self._cancelled:
                        await self._interrupt()
                    while True:
                        notification = await self._notifications.get()
                        if isinstance(notification, Exception):
                            raise notification
                        method, params = notification
                        turn_id = params.get("turnId") or params.get("turn", {}).get("id")
                        if turn_id is not None and turn_id != self._turn_id:
                            continue
                        if method == "turn/completed":
                            status = params["turn"]["status"]
                            outcome["reason"] = (
                                "cancelled" if self._cancelled or status == "interrupted" else "turn_failed"
                            )
                            if status == "completed" and not self._cancelled:
                                # Native unified exec may publish its real item
                                # completion after the model turn has ended.
                                if not await self._drain_tool_terminals():
                                    outcome["reason"] = "native_tool_completion_timeout"
                                    await self._abort()
                                    break
                                if self._cancelled:
                                    outcome["reason"] = "cancelled"
                                elif self._reasoning_observed and not self._public_text_observed:
                                    outcome["reason"] = "missing_public_message"
                                else:
                                    completed = True
                                    outcome["reason"] = "completed"
                            break
                        await self._project(method, params)
        except TimeoutError:
            outcome["reason"] = "timeout"
            await self._abort()
        except asyncio.CancelledError:
            outcome["reason"] = "cancelled" if self._cancelled else "event_backpressure"
            await self._abort()
        except Exception:
            # Native stderr/errors can contain request bodies or authentication details.
            outcome["reason"] = "native_request_failed"
            await self._abort()
        finally:
            self._closed = True
            try:
                if self._events_queue.error is None:
                    for call_id in self._tool_started - self._tool_finished:
                        await self._emit(EventType.TOOL_FAILED, {
                            "callId": call_id, "name": self._tool_names[call_id], "error": {"code": "interrupted"},
                        })
                    await self._emit(
                        EventType.EXECUTION_COMPLETED if completed else EventType.EXECUTION_FAILED, outcome,
                    )
            except RuntimeEventBufferOverflow:
                await self._abort()
            finally:
                self._events_queue.put_nowait(_END)
                if self._state.channel is self:
                    self._state.channel = None

    async def _drain_tool_terminals(self) -> bool:
        if not self._tool_started - self._tool_finished:
            return True
        self._draining_terminal_tools = True
        try:
            async with asyncio.timeout(_TOOL_TERMINAL_DRAIN_SECONDS):
                while self._tool_started - self._tool_finished:
                    notification = await self._notifications.get()
                    if isinstance(notification, Exception):
                        raise notification
                    method, params = notification
                    if (
                        method != "item/completed"
                        or params.get("threadId") != self._state.ref.runtime_session_id
                        or params.get("turnId") != self._turn_id
                        or params.get("item", {}).get("id") not in self._tool_started - self._tool_finished
                    ):
                        continue
                    await self._project(method, params)
            return True
        except TimeoutError:
            return False
        finally:
            self._draining_terminal_tools = False

    def _input(self) -> list[dict[str, Any]]:
        text = "\n".join(block.text for block in self._request.input if isinstance(block, TextBlock))
        result: list[dict[str, Any]] = [{"type": "text", "text": text, "text_elements": []}]
        # Native explicit skill inputs load only a skill the user actually mentioned.
        for name, path in self._state.skills.items():
            if re.search(r"(?<![\w$])\$" + re.escape(name) + r"(?![\w-])", text):
                result.append({"type": "skill", "name": name, "path": str(path)})
        return result

    async def _project(self, method: str, params: dict[str, Any]) -> None:
        if method in {"item/started", "item/completed"}:
            item = params.get("item", {})
            kind, item_id = item.get("type"), item.get("id")
            if not isinstance(item_id, str):
                return
            if kind == "reasoning":
                self._reasoning_observed = True
            if kind == "agentMessage" and method == "item/completed" and item_id not in self._messages:
                self._messages.add(item_id)
                self._public_text_observed = self._public_text_observed or bool(item["text"].strip())
                await self._events_queue.put(self._builder.message((TextBlock(text=item["text"]),), message_id=item_id))
            elif kind in {"commandExecution", "fileChange", "mcpToolCall", "dynamicToolCall", "webSearch", "imageView"}:
                name = {
                    "commandExecution": "exec_command",
                    "fileChange": "apply_patch",
                    "webSearch": "web_search",
                    "imageView": "view_image",
                }.get(kind, str(item.get("tool", kind)))
                if kind == "mcpToolCall":
                    name = "mcp__" + str(item.get("server", "")) + "__" + str(item.get("tool", ""))
                arguments = item.get("arguments")
                if not isinstance(arguments, dict):
                    arguments = {
                        key: item[key] for key in ("command", "cwd", "changes", "query", "path") if key in item
                    }
                if item_id not in self._tool_started:
                    self._tool_started.add(item_id)
                    self._tool_names[item_id] = name
                    await self._emit(
                        EventType.TOOL_STARTED,
                        {
                            "callId": item_id,
                            "name": name,
                            "arguments": arguments,
                            "execution": "runtime",
                        },
                    )
                if method == "item/completed" and item_id not in self._tool_finished:
                    self._tool_finished.add(item_id)
                    failed = item.get("status") in {"failed", "declined"} or item.get("success") is False
                    failed = failed or item.get("exitCode") not in {None, 0}
                    await self._emit(
                        EventType.TOOL_FAILED if failed else EventType.TOOL_COMPLETED,
                        {
                            "callId": item_id,
                            "name": name,
                            "value": item,
                            "error": {"code": "native_tool_failed"} if failed else None,
                            "content": [TextBlock(text=item["aggregatedOutput"]).model_dump(mode="json", by_alias=True)]
                            if isinstance(item.get("aggregatedOutput"), str)
                            else [],
                        },
                    )
        elif method == "thread/tokenUsage/updated":
            total = params.get("tokenUsage", {}).get("total", {})
            counters = dict(self._state.token_total)
            for key in (
                "inputTokens", "outputTokens", "totalTokens", "cachedInputTokens",
                "reasoningOutputTokens", "cacheWriteInputTokens",
            ):
                if key not in total:
                    continue
                value = total[key]
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise ValueError(f"Codex usage counter {key} must be a non-negative integer")
                # A duplicate/older notification must not move the persisted
                # resume baseline backwards. Omitted counters retain their
                # previous total instead of becoming newly chargeable later.
                counters[key] = max(value, counters.get(key, 0))
            self._state.token_total = counters
            self._adapter._save_binding(self._state)
            usage = {
                key: max(0, value - self._usage_base.get(key, 0)) for key, value in self._state.token_total.items()
            }
            # HarnessEventBuilder emits cumulative=False. Subtract the last
            # reported notification, not the execution's initial thread total.
            self._usage_base = dict(self._state.token_total)
            if "reasoningOutputTokens" in usage:
                usage["reasoningTokens"] = usage.pop("reasoningOutputTokens")
            if "cacheWriteInputTokens" in usage:
                usage["cacheWriteTokens"] = usage.pop("cacheWriteInputTokens")
            if any(usage.values()):
                await self._events_queue.put(self._builder.usage(usage))

    async def _interrupt(self) -> None:
        if self._turn_id is not None:
            await self._state.rpc.request(
                "turn/interrupt",
                {
                    "threadId": self._state.ref.runtime_session_id,
                    "turnId": self._turn_id,
                },
                timeout_seconds=5,
            )

    async def _abort(self) -> None:
        with contextlib.suppress(Exception):
            await self._interrupt()
        # An unobserved terminal leaves unknown native state. Close, never reuse it.
        self._state.closing = True
        await self._state.rpc.close()

    async def send_tool_result(self, result: ToolResult) -> None:
        raise RuntimeError("Codex uses native tools and does not accept Application ToolResult")

    async def respond(self, response: InteractionResponse) -> None:
        raise RuntimeError("Codex adapter does not support live interaction")

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        raise RuntimeError("Codex adapter does not support steer")

    async def cancel(self, reason: CancelReason) -> None:
        if not isinstance(reason, CancelReason):
            raise TypeError("Codex cancel requires a CancelReason")
        if self._closed:
            return
        self._cancelled = True
        await self._begun.wait()
        if self._turn_id is None or self._draining_terminal_tools:
            self._task.cancel()
        else:
            with contextlib.suppress(Exception):
                await self._interrupt()
        try:
            await asyncio.wait_for(asyncio.shield(self._task), 7)
        except TimeoutError:
            self._task.cancel()
            await self._task

    async def close(self) -> None:
        if not self._closed:
            await self.cancel(CancelReason())


class CodexCliRuntimeAdapter:
    def __init__(self, config: CodexCliRuntimeConfig | None = None) -> None:
        self._config = config or CodexCliRuntimeConfig()
        self._instance_id = new_id("runtime")
        self._sessions: dict[str, _SessionState] = {}
        self._closed_sessions = session_identity_map()
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._execution_slots = asyncio.Semaphore(self._config.max_concurrency)
        self._closing = False
        self._close_task: asyncio.Task[None] | None = None
        self._cached_version: str | None = None

    async def describe(self) -> RuntimeDescriptor:
        return RuntimeDescriptor(
            name="codex-cli",
            adapter_version="1.1.0",
            runtime_version=await self._version(),
            capabilities=RuntimeCapabilities(
                input_modalities=(Modality.TEXT,),
                output_modalities=(Modality.TEXT,),
                tool_calling=True,
                application_tool_bridge=False,
                cancel=True,
                resume=True,
                data_coverage=DataCoverage(
                    messages=MessageCoverage.FINAL, tool_calls=DetailCoverage.AGGREGATE, usage=UsageCoverage.NORMALIZED
                ),
            ),
        )

    def _state_path(self, spec: RuntimeSessionSpec) -> Path:
        home = Path(self._config.codex_home or os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))
        root = Path(self._config.state_directory) if self._config.state_directory else home / "areal-agent-runtime"
        path = root / hashlib.sha256(spec.session_id.encode()).hexdigest()
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
        return path.resolve()

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("Codex Runtime is closing")
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        if spec.workspace.mount_hint is None:
            raise ValueError("Codex requires a mounted workspace")
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Codex Runtime is closing")
            existing = self._sessions.get(spec.session_id)
            if existing is not None:
                if existing.closing:
                    raise RuntimeError("Codex session is no longer usable; close it before native resume")
                require_same_runtime_session_spec(existing.spec, spec)
                return existing.ref
            directory = self._state_path(spec)
            binding = directory / "binding.json"
            digest = self._binding_digest(spec)
            thread_id: str | None = None
            token_total: dict[str, int] = {}
            if spec.resume:
                if not binding.is_file():
                    raise ValueError("Codex native resume requires an existing session binding")
                record = json.loads(binding.read_text(encoding="utf-8"))
                if record.get("digest") != digest or not isinstance(record.get("threadId"), str):
                    raise ValueError("Codex native resume does not match the immutable session binding")
                thread_id = record["threadId"]
                counters = record.get("tokenTotal", {})
                if isinstance(counters, dict):
                    token_total = {
                        key: value for key, value in counters.items()
                        if isinstance(value, int) and not isinstance(value, bool) and value >= 0
                    }
            elif binding.exists():
                raise ValueError("Codex session already exists; use resume to preserve its native history")
            skill_root = directory / "skills" / spec.agent_environment.digest
            skills = materialize_skills(spec.agent_environment, skill_root)
            rpc, bridge = await self._start_process(spec)
            try:
                await rpc.request(
                    "initialize",
                    {
                        "clientInfo": {"name": "areal_agent_runtime", "version": "1.1.0"},
                        "capabilities": {"experimentalApi": True},
                    },
                )
                await rpc.notify("initialized")
                extra_roots = [str(skill_root.resolve())] if skills else []
                extra_roots.extend(_skill_directories(self._config.skill_directories))
                await rpc.request("skills/extraRoots/set", {"extraRoots": extra_roots})
                catalog = await rpc.request("skills/list", {"cwds": [spec.workspace.mount_hint], "forceReload": True})
                verify_selected_skills(catalog, skills)
                params: dict[str, Any] = {
                    "cwd": spec.workspace.mount_hint,
                    "approvalPolicy": self._config.approval_policy,
                    "sandbox": self._config.sandbox,
                }
                if spec.model or self._config.model:
                    params["model"] = spec.model or self._config.model
                if self._config.base_url or spec.provider or self._config.provider:
                    params["modelProvider"] = self._provider(spec)
                instructions = "\n\n".join(
                    item.content if isinstance(item.content, str) else json.dumps(item.content, ensure_ascii=False)
                    for item in spec.agent_environment.system_prompts
                )
                if instructions:
                    params["developerInstructions"] = instructions
                if thread_id is None:
                    params.update({"ephemeral": False, "allowProviderModelFallback": False})
                    result = await rpc.request("thread/start", params)
                else:
                    params.update({"threadId": thread_id, "excludeTurns": True})
                    result = await rpc.request("thread/resume", params)
                for identity in ("model", "modelProvider"):
                    if identity in params and result.get(identity) != params[identity]:
                        raise RuntimeError("Codex selected a different model/provider than the session requested")
                actual_id = result["thread"]["id"]
                if (
                    not isinstance(actual_id, str)
                    or not actual_id
                    or (thread_id is not None and actual_id != thread_id)
                ):
                    raise RuntimeError("Codex returned an unexpected native thread identity")
                ref = RuntimeSessionRef(session_id=spec.session_id, runtime_session_id=actual_id)
                state = _SessionState(
                    spec=spec, ref=ref, rpc=rpc, skills=skills, bridge=bridge, token_total=token_total
                )
                rpc.notification = lambda method, params: (
                    state.channel.notification(method, params) if state.channel else None
                )

                def failed(error: Exception) -> None:
                    state.closing = True
                    if state.channel is not None:
                        state.channel.failure(error)

                rpc.failure = failed
                # Initialization awaits native RPCs while adapter shutdown may
                # start. Never publish a new owned session after close took its snapshot.
                if self._closing:
                    raise RuntimeError("Codex Runtime is closing")
                if thread_id is None:
                    self._save_binding(state)
                self._sessions[spec.session_id] = state
                return ref
            except BaseException:
                await rpc.close()
                if bridge is not None:
                    await bridge.close()
                raise

    def _provider(self, spec: RuntimeSessionSpec) -> str:
        return spec.provider or self._config.provider or "areal"

    def _save_binding(self, state: _SessionState) -> None:
        binding = self._state_path(state.spec) / "binding.json"
        temporary = binding.with_suffix("." + new_id("write") + ".tmp")
        try:
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                json.dump(
                    {
                        "digest": self._binding_digest(state.spec),
                        "threadId": state.ref.runtime_session_id,
                        "tokenTotal": state.token_total,
                    },
                    stream,
                )
            temporary.replace(binding)
        finally:
            temporary.unlink(missing_ok=True)

    def _binding_digest(self, spec: RuntimeSessionSpec) -> str:
        identity = {
            "session": runtime_session_binding_digest(spec),
            "model": self._config.model,
            "provider": self._config.provider,
            "baseUrl": self._config.base_url,
            "protocol": self._config.model_protocol,
            "codexHome": self._config.codex_home,
            "skillDirectories": self._config.skill_directories,
            "sandbox": self._config.sandbox,
            "approvalPolicy": self._config.approval_policy,
        }
        return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()

    async def _start_process(self, spec: RuntimeSessionSpec) -> tuple[CodexRpc, Any]:
        environment = os.environ.copy()
        if self._config.codex_home:
            environment["CODEX_HOME"] = self._config.codex_home
        if self._config.api_key_env and not environment.get(self._config.api_key_env):
            raise ValueError("Codex apiKeyEnv is not present in the process environment")
        overrides: dict[str, Any] = {"features.multi_agent": False, "features.skill_mcp_dependency_install": False}
        bridge = None
        base_url, api_key_env = self._config.base_url, self._config.api_key_env
        if self._config.model_protocol == "anthropic":
            from areal_agent_runtime.adapters.codex_cli.anthropic_bridge import AnthropicResponsesBridge

            model = spec.model or self._config.model
            if model is None:
                raise ValueError("Anthropic Codex provider requires an explicit model")
            assert base_url is not None and api_key_env is not None
            endpoint = _messages_endpoint(base_url)
            bridge = AnthropicResponsesBridge(
                endpoint=endpoint,
                api_key=environment[api_key_env],
                model=model,
                max_tokens=self._config.max_tokens,
                extra_body=self._config.model_parameters,
            )
            await bridge.start()
            base_url = bridge.base_url
            api_key_env = "AREAL_CODEX_LOCAL_BRIDGE_TOKEN"
            # The Anthropic credential is only held by the local bridge, never the Codex process.
            assert self._config.api_key_env is not None
            environment.pop(self._config.api_key_env, None)
            environment[api_key_env] = bridge.bearer_token
            overrides["web_search"] = "disabled"
        if base_url:
            provider = self._provider(spec)
            overrides["model_provider"] = provider
            definition: dict[str, Any] = {
                "name": provider,
                "base_url": base_url,
                "wire_api": "responses",
                "requires_openai_auth": False,
                "supports_websockets": False,
            }
            if api_key_env:
                definition["env_key"] = api_key_env
            overrides[f"model_providers.{provider}"] = definition
        if api_key_env:
            # `set` composes with both modern native `filters` and legacy
            # `exclude` policies. The provider keeps its process credential,
            # but commands receive an empty value, even with inherit=all.
            overrides[f"shell_environment_policy.set.{api_key_env}"] = ""
        command = [self._config.codex_bin]
        for key, value in overrides.items():
            command.extend(("-c", key + "=" + _toml(value)))
        command.append("app-server")
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=spec.workspace.mount_hint,
                env=environment,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                limit=16 * 1024 * 1024,
            )
        except BaseException:
            if bridge is not None:
                await bridge.close()
            raise
        return CodexRpc(process), bridge

    async def _verify_skills(self, state: _SessionState) -> None:
        result = await state.rpc.request(
            "skills/list", {"cwds": [state.spec.workspace.mount_hint], "forceReload": True}
        )
        verify_selected_skills(result, state.skills)
        # Files belong to the immutable snapshot. Detect edits by native tools before reuse.
        materialize_skills(
            state.spec.agent_environment,
            self._state_path(state.spec) / "skills" / state.spec.agent_environment.digest,
        )

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Codex Runtime is closing")
        if any(not isinstance(block, TextBlock) for block in request.input):
            raise ValueError("Codex adapter currently supports text input only")
        lock = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with lock:
            state = self._sessions.get(request.session_id)
            if state is None or state.closing:
                raise LookupError("Codex session is not open")
            require_session_environment(state.spec, request)
            if state.channel is not None:
                raise RuntimeError("Codex allows one active turn per native thread")
            channel = CodexCliExecutionChannel(self, state, request)
            state.channel = channel
            return channel

    async def close_session(self, session: RuntimeSessionRef) -> None:
        lock = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with lock:
            state = self._sessions.get(session.session_id)
            if state is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("Codex session reference is not owned by this adapter")
            if state.ref != session:
                raise ValueError("Codex session reference does not match the open session")
            self._closed_sessions[session.session_id] = session
            state.closing = True
            if state.channel is not None:
                await state.channel.close()
            await state.rpc.close()
            if state.bridge is not None:
                await state.bridge.close()
            self._sessions.pop(session.session_id)

    async def health(self) -> HealthStatus:
        if self._closing:
            return HealthStatus(status="unhealthy", details={"reason": "runtime_closing"})
        try:
            version = await self._version()
        except (OSError, RuntimeError, TimeoutError):
            return HealthStatus(status="unhealthy", details={"reason": "codex_unavailable"})
        if self._config.api_key_env:
            status = "healthy" if os.environ.get(self._config.api_key_env) else "unhealthy"
        else:
            status = "healthy"  # Native Codex config can use OAuth, env keys or unauthenticated local providers.
        return HealthStatus(status=status, details={"version": version, "transport": "app-server"})

    async def close(self) -> None:
        if self._close_task is None or (self._close_task.done() and (
            self._sessions or self._close_task.cancelled() or self._close_task.exception() is not None
        )):
            self._closing = True
            self._close_task = asyncio.create_task(self._close(), name="codex-runtime-close")
        await asyncio.shield(self._close_task)

    async def _close(self) -> None:
        results = await asyncio.gather(
            *(self.close_session(state.ref) for state in tuple(self._sessions.values())),
            return_exceptions=True,
        )
        errors = [result for result in results if isinstance(result, BaseException)]
        if errors:
            raise BaseExceptionGroup("Codex session cleanup failed", errors)
        self._closed_sessions.close()

    async def _version(self) -> str:
        if self._cached_version is not None:
            return self._cached_version
        executable = self._config.codex_bin
        if os.path.sep not in executable and shutil.which(executable) is None:
            raise FileNotFoundError("Codex executable was not found")
        process = await asyncio.create_subprocess_exec(executable, "--version", stdout=-1, stderr=-1)
        try:
            stdout, _ = await asyncio.wait_for(process.communicate(), 10)
        except BaseException:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.wait()
            raise
        if process.returncode != 0:
            raise RuntimeError("codex --version failed")
        self._cached_version = stdout.decode("utf-8", errors="replace").strip() or "unknown"
        return self._cached_version


def _toml(value: Any) -> str:
    if isinstance(value, dict):
        return "{" + ",".join(json.dumps(key) + "=" + _toml(item) for key, item in value.items()) + "}"
    return json.dumps(value, ensure_ascii=False)


def _skill_directories(paths: tuple[str, ...]) -> list[str]:
    return [str(Path(path).resolve(strict=True)) for path in paths]


def _messages_endpoint(base_url: str) -> str:
    parsed = urlparse(base_url)
    path = parsed.path.rstrip("/")
    if not path.endswith("/messages"):
        path += "/messages" if path.endswith("/v1") else "/v1/messages"
    return parsed._replace(path=path).geturl()
