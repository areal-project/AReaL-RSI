"""Public read/query surface for the Runtime data plane."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import cast

from areal_agent_runtime.contracts.base import require_optional_trimmed
from areal_agent_runtime.contracts.content import AssetRef
from areal_agent_runtime.contracts.data import (
    AgentAttemptState,
    CanonicalObservation,
    CheckpointState,
    DataAnnotation,
    DataClassification,
    DataRunState,
    ExecutionState,
    InteractionObservation,
    InteractionState,
    LifecycleObservation,
    MessageObservation,
    ModelCallObservation,
    ModelCallState,
    ObservationPage,
    RawEventObservation,
    RunPage,
    SessionState,
    StreamingSignalObservation,
    ToolCallObservation,
    ToolCallState,
    TrajectoryPurpose,
    TrajectoryView,
    UsageObservation,
)
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import AnnotationStorePort, AssetStorePort, StateStorePort
from areal_agent_runtime.contracts.product import RunSnapshot, RunStatus
from areal_agent_runtime.kernel.data import (
    CanonicalObservationProjector,
    canonical_asset_ids,
    governance_allows_external,
)
from areal_agent_runtime.kernel.state_queries import iter_events, iter_run_snapshots

_TERMINAL_RUN_STATUSES = {RunStatus.COMPLETED, RunStatus.FAILED, RunStatus.CANCELLED}


class InMemoryAnnotationStore:
    """Reference append-only store with idempotent annotation identities."""

    def __init__(self) -> None:
        self._items: dict[str, list[DataAnnotation]] = {}
        self._by_id: dict[str, DataAnnotation] = {}
        self._lock = asyncio.Lock()

    async def append(self, annotation: DataAnnotation) -> None:
        durable = DataAnnotation.model_validate(
            annotation.model_dump(mode="json", by_alias=True)
        )
        async with self._lock:
            previous = self._by_id.get(durable.annotation_id)
            if previous is not None:
                if previous == durable:
                    return
                raise ValueError(
                    f"annotationId already exists with different content: {durable.annotation_id}"
                )
            self._by_id[durable.annotation_id] = durable
            self._items.setdefault(durable.run_id, []).append(durable)

    async def list(self, run_id: str) -> tuple[DataAnnotation, ...]:
        async with self._lock:
            return tuple(self._items.get(run_id, ()))


class RuntimeDataClient:
    """Stable data-plane facade over internal EventLog/Store SPIs.

    Observations are deterministic projections of committed events, so a
    failed external sink never changes query truth.  The client exposes no
    Store internals and can be backed by a future SQL implementation without
    changing Harness integrations.
    """

    def __init__(
        self,
        state: StateStorePort,
        *,
        annotations: AnnotationStorePort | None = None,
        assets: AssetStorePort | None = None,
        max_materialized_events: int = 10_000,
        max_materialized_bytes: int = 16 * 1024 * 1024,
    ) -> None:
        for name, value in (("max_materialized_events", max_materialized_events),
                            ("max_materialized_bytes", max_materialized_bytes)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        self._state = state
        self._annotations = annotations or InMemoryAnnotationStore()
        self._assets = assets
        self._projector = CanonicalObservationProjector()
        self._max_materialized_events = max_materialized_events
        self._max_materialized_bytes = max_materialized_bytes

    async def get_run_snapshot(self, run_id: str) -> RunSnapshot:
        """Read Run identity/status without materializing historical observations."""
        snapshot = await self._state.get_run(run_id)
        if snapshot is None:
            raise KeyError(run_id)
        return snapshot

    def _check_materialization(self, count: int, size: int) -> None:
        if count > self._max_materialized_events or size > self._max_materialized_bytes:
            raise ContractError(ErrorInfo(
                code="DATA_QUERY_LIMIT_EXCEEDED", category=ErrorCategory.INVALID_REQUEST,
                message="Data query exceeds its materialization budget; use paginated observations or streaming export",
            ))

    async def _bounded_events(self, run_id: str) -> tuple[RunEvent, ...]:
        result: list[RunEvent] = []
        size = 0
        async for event in iter_events(self._state, run_id):
            size += len(event.model_dump_json().encode("utf-8"))
            self._check_materialization(len(result) + 1, size)
            result.append(event)
        return tuple(result)

    async def query_runs(
        self,
        *,
        session_id: str | None = None,
        tenant_id: str | None = None,
        project_id: str | None = None,
        status: RunStatus | None = None,
        cursor: int = 0,
        limit: int = 50,
        include_confidential: bool = True,
        after_run_id: str | None = None,
    ) -> RunPage:
        _validate_page(cursor, limit)
        session_id = require_optional_trimmed(session_id, "run query sessionId")
        tenant_id = require_optional_trimmed(tenant_id, "run query tenantId")
        project_id = require_optional_trimmed(project_id, "run query projectId")
        after_run_id = require_optional_trimmed(after_run_id, "run query afterRunId")
        if after_run_id is not None and cursor:
            raise ValueError("run query must use either afterRunId or offset cursor")
        states: list[DataRunState] = []
        matched = size = 0
        has_more = False
        async for snapshot in iter_run_snapshots(self._state, after_run_id=after_run_id):
            if session_id is not None and snapshot.session_id != session_id:
                continue
            if tenant_id is not None and snapshot.context.tenant_id != tenant_id:
                continue
            if project_id is not None and snapshot.context.project_id != project_id:
                continue
            if status is not None and snapshot.status != status:
                continue
            matched += 1
            if matched <= cursor:
                continue
            if len(states) == limit:
                has_more = True
                break
            state = await self.get_run_state(snapshot.run_id, include_confidential=include_confidential)
            size += len(state.model_dump_json().encode("utf-8"))
            self._check_materialization(len(states) + 1, size)
            states.append(state)
        next_cursor = cursor + len(states) if has_more else None
        return RunPage(runs=tuple(states), next_cursor=next_cursor)

    async def list_observations(
        self,
        run_id: str,
        *,
        after: int = -1,
        limit: int = 200,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> ObservationPage:
        _validate_after_limit(after, limit)
        if await self._state.get_run(run_id) is None:
            raise KeyError(run_id)
        page_events: list[RunEvent] = []
        has_more = False
        size = 0
        async for event in iter_events(self._state, run_id, after=after):
            if not governance_allows_external(
                event,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            ):
                continue
            if len(page_events) == limit:
                has_more = True
                break
            size += len(event.model_dump_json().encode("utf-8"))
            self._check_materialization(len(page_events) + 1, size)
            page_events.append(event)
        observations = tuple(self._projector.project(event) for event in page_events)
        consumed_through = page_events[-1].sequence if page_events else after
        return ObservationPage(
            observations=observations,
            next_cursor=consumed_through if has_more else None,
        )

    def subscribe_observations(
        self,
        run_id: str,
        *,
        after: int = -1,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> AsyncIterator[CanonicalObservation]:
        return self._subscribe(run_id, after, include_restricted, include_confidential)

    async def _subscribe(
        self,
        run_id: str,
        after: int,
        include_restricted: bool,
        include_confidential: bool,
    ) -> AsyncIterator[CanonicalObservation]:
        if isinstance(after, bool) or not isinstance(after, int) or after < -1:
            raise ValueError("observation cursor must be an integer of at least -1")
        if await self._state.get_run(run_id) is None:
            raise KeyError(run_id)
        async for event in self._state.stream_events(run_id, after=after):
            if governance_allows_external(
                event,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            ):
                yield self._projector.project(event)

    async def get_run_state(
        self,
        run_id: str,
        *,
        include_confidential: bool = True,
    ) -> DataRunState:
        snapshot = await self._state.get_run(run_id)
        if snapshot is None:
            raise KeyError(run_id)
        events = await self._bounded_events(run_id)
        observations = tuple(self._projector.project(event) for event in events)
        executions, attempts = _reduce_execution_state(events, observations)
        state = DataRunState(
            run_id=run_id,
            session_id=snapshot.session_id,
            status=snapshot.status.value,
            revision=snapshot.last_sequence,
            context=snapshot.context,
            environment_id=snapshot.environment_id,
            workspace_id=snapshot.workspace_id,
            checkpoints=_run_checkpoints(events),
            agent_attempts=attempts,
            executions=executions,
        )
        return state if include_confidential else _without_confidential_state_details(state)

    async def get_session_state(
        self,
        session_id: str,
        *,
        tenant_id: str | None = None,
        project_id: str | None = None,
    ) -> SessionState:
        validated_session_id = require_optional_trimmed(session_id, "session state sessionId")
        tenant_id = require_optional_trimmed(tenant_id, "session state tenantId")
        project_id = require_optional_trimmed(project_id, "session state projectId")
        assert validated_session_id is not None
        session_id = validated_session_id
        run_ids: list[str] = []
        active_run_ids: list[str] = []
        size = 0
        revision = -1
        async for snapshot in iter_run_snapshots(self._state):
            if snapshot.session_id != session_id:
                continue
            if tenant_id is not None and snapshot.context.tenant_id != tenant_id:
                continue
            if project_id is not None and snapshot.context.project_id != project_id:
                continue
            size += len(snapshot.run_id.encode("utf-8"))
            self._check_materialization(len(run_ids) + 1, size)
            run_ids.append(snapshot.run_id)
            if snapshot.status not in _TERMINAL_RUN_STATUSES:
                active_run_ids.append(snapshot.run_id)
            revision = max(revision, snapshot.last_sequence)
        if not run_ids:
            raise KeyError(session_id)
        return SessionState(
            session_id=session_id,
            revision=revision,
            run_ids=tuple(run_ids),
            active_run_ids=tuple(active_run_ids),
        )

    async def get_trajectory_view(
        self,
        run_id: str,
        *,
        purpose: TrajectoryPurpose,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> TrajectoryView:
        snapshot = await self._state.get_run(run_id)
        if snapshot is None:
            raise KeyError(run_id)
        events = await self._bounded_events(run_id)
        observations = tuple(
            observation
            for event in events
            if governance_allows_external(
                event,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            )
            for observation in (self._projector.project(event),)
            if _included_for_purpose(observation, purpose)
        )
        annotations = tuple(
            annotation
            for annotation in await self._annotations.list(run_id)
            if _annotation_is_visible(
                annotation,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            )
        )
        return TrajectoryView(
            run_id=run_id,
            session_id=snapshot.session_id,
            purpose=purpose,
            observations=observations,
            annotations=annotations,
            # Token-level trainability is established only by the explicit
            # TrainingTrajectoryProjector, never inferred from model text.
            trainable=False,
        )

    async def append_annotation(self, annotation: DataAnnotation) -> None:
        snapshot = await self._state.get_run(annotation.run_id)
        if snapshot is None:
            raise KeyError(annotation.run_id)
        observations = tuple(
            self._projector.project(event)
            for event in await self._bounded_events(annotation.run_id)
        )
        execution_ids = {
            item.lineage.execution_id
            for item in observations
            if item.lineage.execution_id is not None
        }
        model_call_executions = _target_executions(
            observations,
            target="model_call_id",
        )
        interaction_executions = _target_executions(
            observations,
            target="interaction_id",
        )
        if annotation.execution_id is not None and annotation.execution_id not in execution_ids:
            raise ValueError("annotation executionId does not belong to the Run")
        if annotation.model_call_id is not None:
            model_execution = model_call_executions.get(annotation.model_call_id)
            if model_execution is None:
                raise ValueError("annotation modelCallId does not belong to the Run")
            if model_execution != annotation.execution_id:
                raise ValueError("annotation modelCallId does not belong to executionId")
        if annotation.interaction_id is not None:
            interaction_execution = interaction_executions.get(annotation.interaction_id)
            if interaction_execution is None:
                raise ValueError("annotation interactionId does not belong to the Run")
            if interaction_execution != annotation.execution_id:
                raise ValueError("annotation interactionId does not belong to executionId")
        await self._annotations.append(annotation)

    async def list_annotations(
        self,
        run_id: str,
        *,
        include_restricted: bool = True,
        include_confidential: bool = True,
    ) -> tuple[DataAnnotation, ...]:
        if await self._state.get_run(run_id) is None:
            raise KeyError(run_id)
        return tuple(
            annotation
            for annotation in await self._annotations.list(run_id)
            if _annotation_is_visible(
                annotation,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            )
        )

    async def get_run_asset(
        self,
        run_id: str,
        asset_id: str,
        *,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> AssetRef | None:
        """Return an Asset only when a visible fact in ``run_id`` references it.

        The legacy unscoped ``get_asset``/``resolve_asset`` methods remain for
        trusted in-process callers. Remote transports must use this run-scoped
        variant to avoid turning content-addressed identifiers into a
        cross-tenant enumeration surface.
        """

        validated_run_id = require_optional_trimmed(run_id, "asset runId")
        validated_asset_id = require_optional_trimmed(asset_id, "assetId")
        assert validated_run_id is not None and validated_asset_id is not None
        run_id, asset_id = validated_run_id, validated_asset_id
        if await self._state.get_run(run_id) is None:
            raise KeyError(run_id)
        async for event in iter_events(self._state, run_id):
            if asset_id in canonical_asset_ids(event) and governance_allows_external(
                event,
                include_restricted=include_restricted,
                include_confidential=include_confidential,
            ):
                return await self.get_asset(asset_id)
        return None

    async def resolve_run_asset(
        self,
        run_id: str,
        asset_id: str,
        *,
        ttl_seconds: int = 300,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> str:
        ref = await self.get_run_asset(
            run_id,
            asset_id,
            include_restricted=include_restricted,
            include_confidential=include_confidential,
        )
        if ref is None:
            raise FileNotFoundError(f"Asset is not visible from Run {run_id}: {asset_id}")
        return await self.resolve_asset(asset_id, ttl_seconds=ttl_seconds)

    def open_run_asset(
        self,
        run_id: str,
        asset_id: str,
        *,
        include_restricted: bool = False,
        include_confidential: bool = True,
    ) -> AsyncIterator[bytes]:
        """Stream an Asset only through a visible, typed reference in one Run."""

        return self._open_run_asset(
            run_id,
            asset_id,
            include_restricted=include_restricted,
            include_confidential=include_confidential,
        )

    async def _open_run_asset(
        self,
        run_id: str,
        asset_id: str,
        *,
        include_restricted: bool,
        include_confidential: bool,
    ) -> AsyncIterator[bytes]:
        ref = await self.get_run_asset(
            run_id,
            asset_id,
            include_restricted=include_restricted,
            include_confidential=include_confidential,
        )
        if ref is None:
            raise FileNotFoundError(f"Asset is not visible from Run {run_id}: {asset_id}")
        assert self._assets is not None
        async for chunk in self._assets.open(ref.asset_id):
            yield chunk

    async def resolve_asset(self, asset_id: str, *, ttl_seconds: int = 300) -> str:
        if self._assets is None:
            raise RuntimeError("RuntimeDataClient has no AssetStore binding")
        return await self._assets.resolve(asset_id, ttl_seconds=ttl_seconds)

    async def get_asset(self, asset_id: str) -> AssetRef | None:
        if self._assets is None:
            raise RuntimeError("RuntimeDataClient has no AssetStore binding")
        return await self._assets.get(asset_id)


def _reduce_execution_state(
    events: tuple[RunEvent, ...],
    observations: tuple[CanonicalObservation, ...],
) -> tuple[tuple[ExecutionState, ...], tuple[AgentAttemptState, ...]]:
    builders: dict[str, dict[str, object]] = {}
    attempt_builders: dict[str, dict[str, object]] = {}

    for event, observation in zip(events, observations, strict=True):
        execution_id = event.execution_id
        if execution_id is None:
            continue
        attempt_id = event.agent_attempt_id or f"aat_projection_{execution_id}"
        builder = builders.setdefault(
            execution_id,
            {
                "agent_attempt_id": attempt_id,
                "agent_id": event.agent_id,
                "status": "pending",
                "models": {},
                "tools": {},
                "interactions": {},
                "checkpoints": [],
                "error": None,
            },
        )
        attempt = attempt_builders.setdefault(
            attempt_id,
            {
                "execution_id": execution_id,
                "agent_id": event.agent_id,
                "status": "running",
            },
        )
        payload = observation.payload
        if isinstance(payload, LifecycleObservation):
            if event.type in {
                EventType.AGENT_STARTED, EventType.AGENT_COMPLETED,
                EventType.AGENT_FAILED, EventType.AGENT_CANCELLED,
            } and event.agent_id != builder["agent_id"]:
                # Hybrid children share their parent's executionId and attempt.
                # Their lifecycle is visible in observations, but cannot close
                # or restart the Application-owned execution/attempt.
                continue
            if event.type in {EventType.EXECUTION_STARTED, EventType.AGENT_STARTED}:
                builder["status"] = "running"
                attempt["status"] = "running"
            elif event.type in {EventType.EXECUTION_COMPLETED, EventType.AGENT_COMPLETED}:
                builder["status"] = "completed"
                attempt["status"] = "completed"
            elif event.type in {EventType.EXECUTION_FAILED, EventType.AGENT_FAILED}:
                builder["status"] = "failed"
                builder["error"] = payload.error
                attempt["status"] = "failed"
            elif event.type == EventType.AGENT_CANCELLED:
                builder["status"] = "cancelled"
                attempt["status"] = "cancelled"
            if event.type == EventType.WORKSPACE_CHECKPOINTED:
                checkpoint_id = event.data.get("checkpointId")
                if isinstance(checkpoint_id, str) and checkpoint_id:
                    checkpoints = builder["checkpoints"]
                    assert isinstance(checkpoints, list)
                    checkpoints.append(
                        CheckpointState(
                            checkpoint_id=checkpoint_id,
                            kind="workspace",
                            digest=_optional_text(event.data.get("digest")),
                            locator=_optional_text(event.data.get("locator")),
                        )
                    )
        elif isinstance(payload, ModelCallObservation):
            model_id = observation.lineage.model_call_id
            if model_id is not None:
                models = builder["models"]
                assert isinstance(models, dict)
                models[model_id] = ModelCallState(
                    model_call_id=model_id,
                    execution_id=execution_id,
                    status=("running" if payload.phase == "started" else payload.phase),
                    provider=payload.provider,
                    model=payload.model,
                    finish_reason=payload.finish_reason,
                    error=payload.error,
                )
        elif isinstance(payload, ToolCallObservation):
            tool_id = observation.lineage.tool_call_id
            if tool_id is not None:
                tools = builder["tools"]
                assert isinstance(tools, dict)
                tools[tool_id] = ToolCallState(
                    tool_call_id=tool_id,
                    execution_id=execution_id,
                    name=payload.name,
                    status=("running" if payload.phase == "started" else payload.phase),
                    model_call_id=observation.lineage.model_call_id,
                    error=payload.error,
                )
        elif isinstance(payload, InteractionObservation):
            interaction_id = observation.lineage.interaction_id
            if interaction_id is not None:
                interactions = builder["interactions"]
                assert isinstance(interactions, dict)
                interactions[interaction_id] = InteractionState(
                    interaction_id=interaction_id,
                    execution_id=execution_id,
                    kind=payload.interaction_kind,
                    status="pending" if payload.phase == "required" else "resolved",
                    terminal=payload.terminal,
                )
                if payload.phase == "required" and not payload.terminal:
                    builder["status"] = "waiting"
                elif payload.phase == "resolved" and builder["status"] == "waiting":
                    builder["status"] = (
                        "waiting"
                        if payload.pending_interactions is not None
                        and payload.pending_interactions > 0
                        else "running"
                    )

    executions = tuple(
        ExecutionState(
            execution_id=execution_id,
            agent_attempt_id=str(builder["agent_attempt_id"]),
            agent_id=builder["agent_id"] if isinstance(builder["agent_id"], str) else None,
            status=str(builder["status"]),  # type: ignore[arg-type]
            model_calls=tuple(cast(dict[str, ModelCallState], builder["models"]).values()),
            tool_calls=tuple(cast(dict[str, ToolCallState], builder["tools"]).values()),
            interactions=tuple(cast(dict[str, InteractionState], builder["interactions"]).values()),
            checkpoints=tuple(builder["checkpoints"]),  # type: ignore[arg-type]
            error=builder["error"] if isinstance(builder["error"], ErrorInfo) else None,
        )
        for execution_id, builder in builders.items()
    )
    attempts = tuple(
        AgentAttemptState(
            agent_attempt_id=attempt_id,
            execution_id=str(builder["execution_id"]),
            agent_id=builder["agent_id"] if isinstance(builder["agent_id"], str) else None,
            status=str(builder["status"]),  # type: ignore[arg-type]
        )
        for attempt_id, builder in attempt_builders.items()
    )
    return executions, attempts


def _optional_text(value: object) -> str | None:
    return value if isinstance(value, str) else None


def _run_checkpoints(events: tuple[RunEvent, ...]) -> tuple[CheckpointState, ...]:
    checkpoints: dict[str, CheckpointState] = {}
    for event in events:
        if event.type != EventType.WORKSPACE_CHECKPOINTED:
            continue
        checkpoint_id = event.data.get("checkpointId")
        if not isinstance(checkpoint_id, str) or not checkpoint_id:
            continue
        checkpoints[checkpoint_id] = CheckpointState(
            checkpoint_id=checkpoint_id,
            kind="workspace",
            digest=_optional_text(event.data.get("digest")),
            locator=_optional_text(event.data.get("locator")),
        )
    return tuple(checkpoints.values())


def _included_for_purpose(
    observation: CanonicalObservation,
    purpose: TrajectoryPurpose,
) -> bool:
    payload = observation.payload
    if purpose == TrajectoryPurpose.AUDIT:
        return True
    if purpose == TrajectoryPurpose.CONVERSATION:
        return isinstance(payload, (MessageObservation, ToolCallObservation, InteractionObservation))
    if purpose == TrajectoryPurpose.EVALUATION:
        return not isinstance(payload, (StreamingSignalObservation, RawEventObservation))
    return isinstance(
        payload,
        (MessageObservation, ModelCallObservation, ToolCallObservation, UsageObservation),
    )


def _validate_page(cursor: int, limit: int) -> None:
    if isinstance(cursor, bool) or not isinstance(cursor, int) or cursor < 0:
        raise ValueError("run cursor must be a non-negative integer")
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1_000:
        raise ValueError("page limit must be an integer between 1 and 1000")


def _validate_after_limit(after: int, limit: int) -> None:
    if isinstance(after, bool) or not isinstance(after, int) or after < -1:
        raise ValueError("observation cursor must be an integer of at least -1")
    _validate_page(0, limit)


def _target_executions(
    observations: tuple[CanonicalObservation, ...],
    *,
    target: str,
) -> dict[str, str]:
    result: dict[str, str] = {}
    for observation in observations:
        target_id = getattr(observation.lineage, target)
        execution_id = observation.lineage.execution_id
        if target_id is None or execution_id is None:
            continue
        previous = result.setdefault(target_id, execution_id)
        if previous != execution_id:
            raise ValueError(
                f"canonical {target} has conflicting execution lineage: {target_id}"
            )
    return result


def _annotation_is_visible(
    annotation: DataAnnotation,
    *,
    include_restricted: bool,
    include_confidential: bool,
) -> bool:
    classification = annotation.governance.classification
    if classification == DataClassification.RESTRICTED:
        return include_restricted
    if classification == DataClassification.CONFIDENTIAL:
        return include_confidential or include_restricted
    return True


def _without_confidential_state_details(state: DataRunState) -> DataRunState:
    """Keep lifecycle state while removing details sourced from confidential facts."""

    return state.model_copy(
        update={
            "checkpoints": tuple(
                checkpoint.model_copy(update={"locator": None})
                for checkpoint in state.checkpoints
            ),
            "executions": tuple(
                execution.model_copy(
                    update={
                        "error": None,
                        "model_calls": tuple(
                            model_call.model_copy(update={"error": None})
                            for model_call in execution.model_calls
                        ),
                        "tool_calls": tuple(
                            tool_call.model_copy(update={"error": None})
                            for tool_call in execution.tool_calls
                        ),
                        "checkpoints": tuple(
                            checkpoint.model_copy(update={"locator": None})
                            for checkpoint in execution.checkpoints
                        ),
                    }
                )
                for execution in state.executions
            ),
        }
    )
