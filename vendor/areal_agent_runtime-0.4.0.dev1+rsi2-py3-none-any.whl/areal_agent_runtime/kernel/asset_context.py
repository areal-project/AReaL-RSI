"""Task-local provenance for configured asset placement; never an authorization input."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from contextvars import ContextVar

_asset_context: ContextVar[Mapping[str, str] | None] = ContextVar("areal_asset_write_context", default=None)


def get_asset_write_context() -> dict[str, str]:
    """Return a defensive copy of the Application-owned placement context."""

    return dict(_asset_context.get() or {})


@contextmanager
def asset_write_context(*, run_id: str, profile_id: str | None = None, agent_id: str | None = None) -> Iterator[None]:
    values = {"run_id": run_id}
    if profile_id is not None:
        values["profile_id"] = profile_id
    if agent_id is not None:
        values["agent_id"] = agent_id
    token = _asset_context.set(values)
    try:
        yield
    finally:
        _asset_context.reset(token)
