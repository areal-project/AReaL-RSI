"""Deterministic resolution of AgentEnvironmentSpec into a Session snapshot."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from areal_agent_runtime.application.tool_gateway import RegisteredTool, ToolGateway
from areal_agent_runtime.contracts.content import ContentBlock, JsonBlock, ReasoningBlock, TextBlock
from areal_agent_runtime.contracts.environment import (
    AgentEnvironmentLayer,
    AgentEnvironmentSnapshot,
    AgentEnvironmentSpec,
    ExtensionSpec,
    InlineResourceSource,
    McpProviderBinding,
    McpSourceSpec,
    McpTransport,
    PromptResolutionMode,
    ResolvedMcpSourceSnapshot,
    ResolvedResourceSnapshot,
    ResolvedToolSourceSnapshot,
    ResourceCategory,
    ResourceLayer,
    ResourceSource,
    RuntimeIdentitySnapshot,
    ToolCatalogEntrySnapshot,
    ToolSourceSpec,
)
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import LoadedResource, ResourceLoaderPort
from areal_agent_runtime.contracts.runtime import RuntimeDescriptor


@dataclass(frozen=True, slots=True)
class AgentEnvironmentPolicy:
    allow_stdio_mcp: bool = False
    allowed_mcp_http_origins: tuple[str, ...] = ()
    allow_insecure_loopback_http: bool = False
    allowed_invocation_source_providers: tuple[str, ...] = ()
    allowed_invocation_tool_names: tuple[str, ...] = ()
    allowed_invocation_permissions: tuple[str, ...] = ()
    supported_extensions: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for name, value in (
            ("allow_stdio_mcp", self.allow_stdio_mcp),
            ("allow_insecure_loopback_http", self.allow_insecure_loopback_http),
        ):
            if not isinstance(value, bool):
                raise TypeError(f"{name} must be a boolean")
        if not isinstance(self.allowed_mcp_http_origins, tuple):
            raise TypeError("allowed_mcp_http_origins must be a tuple")
        normalized_origins = tuple(
            _validate_policy_origin(
                origin,
                allow_insecure_loopback_http=self.allow_insecure_loopback_http,
            )
            for origin in self.allowed_mcp_http_origins
        )
        if len(normalized_origins) != len(set(normalized_origins)):
            raise ValueError("allowed_mcp_http_origins must not contain duplicates")
        object.__setattr__(self, "allowed_mcp_http_origins", normalized_origins)
        for name in (
            "allowed_invocation_source_providers",
            "allowed_invocation_tool_names",
            "allowed_invocation_permissions",
            "supported_extensions",
        ):
            values = getattr(self, name)
            if not isinstance(values, tuple) or any(
                not isinstance(value, str) or not value or value != value.strip() for value in values
            ):
                raise ValueError(f"{name} must contain only trimmed non-empty strings")
            if len(values) != len(set(values)):
                raise ValueError(f"{name} must not contain duplicates")


class AgentEnvironmentResolver:
    """Resolve all sources once; callers persist the returned immutable snapshot by Session."""

    def __init__(
        self,
        loader: ResourceLoaderPort,
        tools: ToolGateway,
        *,
        policy: AgentEnvironmentPolicy | None = None,
    ) -> None:
        self._loader = loader
        self._tools = tools
        self._policy = policy or AgentEnvironmentPolicy()
        self._mcp_origins = frozenset(_origin(value) for value in self._policy.allowed_mcp_http_origins)
        self._host_extensions = frozenset(ExtensionSpec(key=key).key for key in self._policy.supported_extensions)
        self._invocation_providers = frozenset(self._policy.allowed_invocation_source_providers)
        self._invocation_tools = frozenset(self._policy.allowed_invocation_tool_names)
        self._invocation_permissions = frozenset(self._policy.allowed_invocation_permissions)

    async def resolve(
        self,
        spec: AgentEnvironmentSpec,
        *,
        runtime: RuntimeDescriptor,
        release_system: tuple[ContentBlock, ...] = (),
        release_tool_names: tuple[str, ...] = (),
        release_environment: AgentEnvironmentLayer | None = None,
        release_id: str = "profile",
        release_version: str = "1.0.0",
        invocation_instructions: tuple[ContentBlock, ...] = (),
    ) -> AgentEnvironmentSnapshot:
        release_tool_sources = (
            ()
            if spec.prompt_resolution == PromptResolutionMode.REPLACE
            else await self._release_tool_sources(
                release_tool_names,
                release_id=release_id,
                release_version=release_version,
            )
        )
        composed = self._compose(
            spec,
            release_system=release_system,
            release_tool_sources=release_tool_sources,
            release_environment=release_environment or AgentEnvironmentLayer(),
            release_id=release_id,
            release_version=release_version,
            invocation_instructions=invocation_instructions,
        )
        self._validate_extensions(composed, runtime)
        layers = (
            (ResourceLayer.BUILTIN, composed.builtin),
            (ResourceLayer.RELEASE_PROFILE, composed.release_profile),
            (ResourceLayer.HOST_MOUNT, composed.host_mount),
            (ResourceLayer.INVOCATION, composed.invocation),
        )
        prompts = await self._resolve_resources(
            self._select(layers, "system_prompts", composed.prompt_resolution),
            ResourceCategory.SYSTEM_PROMPT,
        )
        skills = await self._resolve_resources(
            self._select(layers, "skills", composed.prompt_resolution),
            ResourceCategory.SKILL,
        )
        tool_sources = await self._resolve_tool_sources(
            self._select(layers, "tool_sources", composed.prompt_resolution)
        )
        mcp_sources = await self._resolve_mcp_sources(self._select(layers, "mcp_sources", composed.prompt_resolution))
        selected = await self._select_tools(tool_sources, mcp_sources)
        catalog = tuple(self._tool_snapshot(item) for item in selected)
        runtime_snapshot = self._runtime_snapshot(runtime)
        spec_digest = _digest(composed.model_dump(mode="json", by_alias=True))
        return AgentEnvironmentSnapshot.create(
            spec_digest=spec_digest,
            prompt_resolution=composed.prompt_resolution,
            system_prompts=prompts,
            skills=skills,
            tool_sources=tool_sources,
            mcp_sources=mcp_sources,
            tool_catalog=catalog,
            runtime=runtime_snapshot,
            extensions=composed.extensions,
        )

    async def validate_persisted(
        self,
        snapshot: AgentEnvironmentSnapshot,
        *,
        runtime: RuntimeDescriptor,
    ) -> None:
        """Fail closed when a resumed Session's installed dependencies drift."""

        snapshot.assert_integrity()
        mismatches: list[str] = []
        if snapshot.runtime != self._runtime_snapshot(runtime):
            mismatches.append("runtime")

        for item in snapshot.tool_catalog:
            try:
                current = await self._tools.registered(item.spec.name)
            except Exception:
                current = None
            if current is None:
                mismatches.append(f"tool:{item.spec.name}:missing")
                continue
            if current.provider_name != item.provider:
                mismatches.append(f"tool:{item.spec.name}:provider")
            if current.provider_version != item.provider_version:
                mismatches.append(f"tool:{item.spec.name}:providerVersion")
            if current.spec != item.spec:
                mismatches.append(f"tool:{item.spec.name}:spec")
            if _digest(current.spec.input_schema) != item.schema_sha256:
                mismatches.append(f"tool:{item.spec.name}:schema")

        for source in snapshot.mcp_sources:
            try:
                current_version = self._tools.provider_version(source.provider)
                current_binding = self._tools.mcp_binding(source.provider)
                expected_binding = McpProviderBinding(
                    server_id=source.server_id,
                    transport=source.transport,
                    endpoint=source.endpoint,
                    executable_sha256=(source.executable.sha256 if source.executable is not None else None),
                    secret_refs=source.secret_refs,
                )
            except Exception:
                mismatches.append(f"mcp:{source.server_id}:missing")
                continue
            if current_version != source.provider_version:
                mismatches.append(f"mcp:{source.server_id}:providerVersion")
            if current_binding != expected_binding:
                mismatches.append(f"mcp:{source.server_id}:binding")

        if mismatches:
            dependencies = sorted(set(mismatches))
            raise ContractError(
                ErrorInfo(
                    code="SESSION_ENVIRONMENT_DEPENDENCY_MISMATCH",
                    category=ErrorCategory.CONFLICT,
                    message=(
                        "The persisted Agent environment no longer matches installed dependencies; open a new Session"
                    ),
                    details={"dependencies": dependencies},
                )
            )

    @staticmethod
    def _compose(
        spec: AgentEnvironmentSpec,
        *,
        release_system: tuple[ContentBlock, ...],
        release_tool_sources: tuple[ToolSourceSpec, ...],
        release_environment: AgentEnvironmentLayer,
        release_id: str,
        release_version: str,
        invocation_instructions: tuple[ContentBlock, ...],
    ) -> AgentEnvironmentSpec:
        invocation_prompts = tuple(
            _inline_prompt(f"invocation:legacy-instruction:{index}", block)
            for index, block in enumerate(invocation_instructions)
        )
        if spec.prompt_resolution == PromptResolutionMode.REPLACE:
            # External-only mode must not even bind or hash Distribution
            # defaults.  This keeps the effective snapshot independent from a
            # ARealAgentRuntime bundle the caller explicitly replaced.
            return spec.model_copy(
                update={
                    "builtin": AgentEnvironmentLayer(),
                    "release_profile": AgentEnvironmentLayer(),
                    "invocation": _merge_layer(
                        spec.invocation,
                        AgentEnvironmentLayer(system_prompts=invocation_prompts),
                    ),
                }
            )
        release_prompts = tuple(
            _inline_prompt(
                f"distribution:{release_id}:prompt:{index}",
                block,
                version=release_version,
            )
            for index, block in enumerate(release_system)
        )
        return spec.model_copy(
            update={
                "release_profile": _merge_layer(
                    _merge_layer(
                        AgentEnvironmentLayer(
                            system_prompts=release_prompts,
                            tool_sources=release_tool_sources,
                        ),
                        release_environment,
                    ),
                    spec.release_profile,
                ),
                "invocation": _merge_layer(
                    spec.invocation,
                    AgentEnvironmentLayer(system_prompts=invocation_prompts),
                ),
            }
        )

    async def _release_tool_sources(
        self,
        tool_names: tuple[str, ...],
        *,
        release_id: str,
        release_version: str,
    ) -> tuple[ToolSourceSpec, ...]:
        """Bind trusted Distribution names to concrete providers and permissions."""

        sources: list[ToolSourceSpec] = []
        for index, name in enumerate(dict.fromkeys(tool_names)):
            registered = await self._tools.registered(name)
            if registered is None:
                raise LookupError(f"ToolProvider is missing required tool: {name}")
            sources.append(
                ToolSourceSpec(
                    source=InlineResourceSource(
                        resource_id=f"distribution:{release_id}:tool:{index}",
                        version=release_version,
                        media_type="application/json",
                        content={"profile": release_id, "tool": name},
                    ),
                    provider=registered.provider_name,
                    tool_names=(name,),
                    allowed_permissions=registered.spec.permissions,
                )
            )
        return tuple(sources)

    @staticmethod
    def _select(
        layers: tuple[tuple[ResourceLayer, AgentEnvironmentLayer], ...],
        field: str,
        mode: PromptResolutionMode,
    ) -> tuple[tuple[ResourceLayer, object], ...]:
        candidates = tuple((layer, item) for layer, value in layers for item in getattr(value, field))
        if mode == PromptResolutionMode.MERGE:
            return _deduplicate(candidates)
        if mode == PromptResolutionMode.REPLACE:
            return _deduplicate(
                tuple(
                    (layer, item)
                    for layer, item in candidates
                    if layer in {ResourceLayer.HOST_MOUNT, ResourceLayer.INVOCATION}
                )
            )
        for layer in reversed(tuple(ResourceLayer)):
            selected = tuple(item for item in candidates if item[0] == layer)
            if selected:
                return _deduplicate(selected)
        return ()

    async def _resolve_resources(
        self,
        selected: tuple[tuple[ResourceLayer, object], ...],
        category: ResourceCategory,
    ) -> tuple[ResolvedResourceSnapshot, ...]:
        resolved: list[ResolvedResourceSnapshot] = []
        for layer, raw in selected:
            source = raw
            if not isinstance(source, (InlineResourceSource,)) and not hasattr(source, "resource_id"):
                raise TypeError(f"invalid {category.value} ResourceSource")
            resolved.append(await self._resolve_resource(source, category, layer))  # type: ignore[arg-type]
        return tuple(resolved)

    async def _resolve_tool_sources(
        self,
        selected: tuple[tuple[ResourceLayer, object], ...],
    ) -> tuple[ResolvedToolSourceSnapshot, ...]:
        result: list[ResolvedToolSourceSnapshot] = []
        for layer, raw in selected:
            if not isinstance(raw, ToolSourceSpec):
                raise TypeError("invalid ToolSourceSpec")
            self._validate_invocation_source(
                layer,
                provider=raw.provider,
                tool_names=raw.tool_names,
                permissions=raw.allowed_permissions,
            )
            try:
                resource = await self._resolve_resource(raw.source, ResourceCategory.TOOL_SOURCE, layer)
                _reject_embedded_secrets(resource.content, path="toolSource")
            except PermissionError:
                raise
            except Exception:
                if raw.required:
                    raise
                continue
            result.append(
                ResolvedToolSourceSnapshot(
                    resource=resource,
                    provider=raw.provider,
                    provider_version=self._tools.provider_version(raw.provider),
                    tool_names=raw.tool_names,
                    allowed_permissions=raw.allowed_permissions,
                    required=raw.required,
                )
            )
        return tuple(result)

    async def _resolve_mcp_sources(
        self,
        selected: tuple[tuple[ResourceLayer, object], ...],
    ) -> tuple[ResolvedMcpSourceSnapshot, ...]:
        result: list[ResolvedMcpSourceSnapshot] = []
        for layer, raw in selected:
            if not isinstance(raw, McpSourceSpec):
                raise TypeError("invalid McpSourceSpec")
            self._validate_invocation_source(
                layer,
                provider=raw.provider,
                tool_names=raw.tool_names,
                permissions=raw.allowed_permissions,
            )
            try:
                endpoint = self._validate_mcp(raw)
                binding = self._tools.mcp_binding(raw.provider)
                self._validate_mcp_binding(raw, endpoint, binding)
                resource = await self._resolve_resource(raw.source, ResourceCategory.MCP_SOURCE, layer)
                _reject_embedded_secrets(resource.content)
                executable = (
                    await self._resolve_resource(raw.executable, ResourceCategory.MCP_SOURCE, layer)
                    if raw.executable is not None
                    else None
                )
            except PermissionError:
                raise
            except Exception:
                if raw.required:
                    raise
                continue
            result.append(
                ResolvedMcpSourceSnapshot(
                    resource=resource,
                    server_id=raw.server_id,
                    provider=raw.provider,
                    provider_version=self._tools.provider_version(raw.provider),
                    transport=raw.transport,
                    endpoint=endpoint,
                    executable=executable,
                    arguments=raw.arguments,
                    secret_refs=raw.secret_refs,
                    tool_names=raw.tool_names,
                    allowed_permissions=raw.allowed_permissions,
                    required=raw.required,
                )
            )
        return tuple(result)

    async def _resolve_resource(
        self,
        source: ResourceSource,
        category: ResourceCategory,
        layer: ResourceLayer,
    ) -> ResolvedResourceSnapshot:
        loaded = await self._loader.load(source)
        return ResolvedResourceSnapshot(
            resource_id=source.resource_id,
            category=category,
            layer=layer,
            kind=source.kind,
            version=loaded.version or f"sha256:{loaded.sha256}",
            media_type=loaded.media_type,
            sha256=loaded.sha256,
            locator=loaded.locator,
            content=loaded.content,
        )

    async def _select_tools(
        self,
        tool_sources: tuple[ResolvedToolSourceSnapshot, ...],
        mcp_sources: tuple[ResolvedMcpSourceSnapshot, ...],
    ) -> tuple[RegisteredTool, ...]:
        selected: dict[str, RegisteredTool] = {}
        for source in (*tool_sources, *mcp_sources):
            try:
                entries = await self._tools.select(((source.provider, source.tool_names, source.allowed_permissions),))
            except PermissionError:
                raise
            except Exception:
                if source.required:
                    raise
                continue
            selected.update({entry.spec.name: entry for entry in entries})
        return tuple(selected[name] for name in sorted(selected))

    def _validate_invocation_source(
        self,
        layer: ResourceLayer,
        *,
        provider: str,
        tool_names: tuple[str, ...],
        permissions: tuple[str, ...],
    ) -> None:
        """Require Host-owned authorization in addition to caller-declared selection."""

        if layer != ResourceLayer.INVOCATION:
            return
        if provider not in self._invocation_providers:
            raise ContractError(
                ErrorInfo(
                    code="INVOCATION_SOURCE_FORBIDDEN",
                    category=ErrorCategory.PERMISSION,
                    message=(f"Invocation Tool/MCP source provider is not allowed by Host policy: {provider}"),
                )
            )
        denied_tools = sorted(set(tool_names).difference(self._invocation_tools))
        if denied_tools:
            raise ContractError(
                ErrorInfo(
                    code="INVOCATION_SOURCE_FORBIDDEN",
                    category=ErrorCategory.PERMISSION,
                    message=(
                        "Invocation Tool/MCP source requests tools not allowed by Host policy: "
                        + ", ".join(denied_tools)
                    ),
                )
            )
        denied_permissions = sorted(set(permissions).difference(self._invocation_permissions))
        if denied_permissions:
            raise ContractError(
                ErrorInfo(
                    code="INVOCATION_SOURCE_FORBIDDEN",
                    category=ErrorCategory.PERMISSION,
                    message=(
                        "Invocation Tool/MCP source requests permissions not allowed by Host policy: "
                        + ", ".join(denied_permissions)
                    ),
                )
            )

    @staticmethod
    def _tool_snapshot(tool: RegisteredTool) -> ToolCatalogEntrySnapshot:
        return ToolCatalogEntrySnapshot(
            provider=tool.provider_name,
            provider_version=tool.provider_version,
            spec=tool.spec,
            schema_sha256=_digest(tool.spec.input_schema),
        )

    @staticmethod
    def _runtime_snapshot(runtime: RuntimeDescriptor) -> RuntimeIdentitySnapshot:
        return RuntimeIdentitySnapshot(
            name=runtime.name,
            runtime_version=runtime.runtime_version,
            adapter_version=runtime.adapter_version,
            capabilities_sha256=_digest(runtime.capabilities.model_dump(mode="json", by_alias=True)),
        )

    def _validate_mcp(self, source: McpSourceSpec) -> str | None:
        if source.transport == McpTransport.STDIO:
            if not self._policy.allow_stdio_mcp:
                raise PermissionError("untrusted Agent environment cannot enable arbitrary MCP stdio")
            return None
        assert source.endpoint is not None
        try:
            parsed = urlsplit(source.endpoint)
            # Accessing port performs validation that urlsplit intentionally
            # defers (for example, out-of-range or non-numeric ports).
            _ = parsed.port
        except ValueError as exc:
            raise PermissionError("MCP HTTP endpoint is not a valid URL") from exc
        if (
            parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or any(character.isspace() for character in source.endpoint)
        ):
            raise PermissionError("MCP endpoint credentials/query/fragment are forbidden; use SecretRef")
        loopback = parsed.scheme == "http" and (parsed.hostname or "") in {"127.0.0.1", "localhost", "::1"}
        if parsed.scheme != "https" and not (loopback and self._policy.allow_insecure_loopback_http):
            raise PermissionError("MCP HTTP endpoint must use HTTPS")
        try:
            origin = _origin(source.endpoint)
        except ValueError as exc:
            raise PermissionError("MCP HTTP endpoint is not a valid origin") from exc
        if not self._mcp_origins or origin not in self._mcp_origins:
            raise PermissionError(f"MCP endpoint origin is not allowed: {origin}")
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))

    @staticmethod
    def _validate_mcp_binding(
        source: McpSourceSpec,
        endpoint: str | None,
        binding: McpProviderBinding,
    ) -> None:
        expected_secrets = {(item.name, item.provider, item.key, item.version) for item in source.secret_refs}
        actual_secrets = {(item.name, item.provider, item.key, item.version) for item in binding.secret_refs}
        mismatches: list[str] = []
        if binding.server_id != source.server_id:
            mismatches.append("serverId")
        if binding.transport != source.transport:
            mismatches.append("transport")
        if binding.endpoint != endpoint:
            mismatches.append("endpoint")
        executable_sha256 = source.executable.expected_sha256 if source.executable is not None else None
        if binding.executable_sha256 != executable_sha256:
            mismatches.append("executableSha256")
        if actual_secrets != expected_secrets:
            mismatches.append("secretRefs")
        if mismatches:
            raise PermissionError("MCP source does not match installed provider binding: " + ", ".join(mismatches))

    def _validate_extensions(self, spec: AgentEnvironmentSpec, runtime: RuntimeDescriptor) -> None:
        for item in spec.extensions:
            _reject_embedded_secrets(item.value, path=f"extensions.{item.key}")
        supported = {*runtime.capabilities.extensions, *self._host_extensions}
        missing = sorted(item.key for item in spec.extensions if item.required and item.key not in supported)
        if missing:
            raise ContractError(
                ErrorInfo(
                    code="RUNTIME_EXTENSION_MISSING",
                    category=ErrorCategory.INVALID_REQUEST,
                    message=f"Runtime is missing required extension(s): {', '.join(missing)}",
                    details={"extensions": missing},
                )
            )


def _inline_prompt(
    resource_id: str,
    block: ContentBlock,
    *,
    version: str = "1.0.0",
) -> InlineResourceSource:
    if isinstance(block, (TextBlock, ReasoningBlock)):
        content = block.text
        media_type = "text/plain"
    elif isinstance(block, JsonBlock):
        content = block.value
        media_type = "application/json"
    else:
        content = block.model_dump(mode="json", by_alias=True)
        media_type = "application/json"
    return InlineResourceSource(
        resource_id=resource_id,
        version=version,
        media_type=media_type,
        content=content,
    )


def _merge_layer(left: AgentEnvironmentLayer, right: AgentEnvironmentLayer) -> AgentEnvironmentLayer:
    return AgentEnvironmentLayer(
        system_prompts=(*left.system_prompts, *right.system_prompts),
        skills=(*left.skills, *right.skills),
        tool_sources=(*left.tool_sources, *right.tool_sources),
        mcp_sources=(*left.mcp_sources, *right.mcp_sources),
    )


def _deduplicate(
    values: tuple[tuple[ResourceLayer, object], ...],
) -> tuple[tuple[ResourceLayer, object], ...]:
    result: dict[str, tuple[ResourceLayer, object]] = {}
    for layer, item in values:
        source = getattr(item, "source", item)
        key = str(getattr(source, "resource_id", repr(item)))
        # Reinsert overrides so merge order remains low -> high priority, even
        # when a higher layer replaces an earlier resource id.
        result.pop(key, None)
        result[key] = (layer, item)
    return tuple(result.values())


def _digest(value: object) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _origin(value: str) -> str:
    parsed = urlsplit(value)
    if not parsed.scheme or not parsed.hostname:
        raise ValueError("origin must include scheme and host")
    port = f":{parsed.port}" if parsed.port is not None else ""
    return f"{parsed.scheme.lower()}://{parsed.hostname.lower()}{port}"


def _validate_policy_origin(
    value: str,
    *,
    allow_insecure_loopback_http: bool,
) -> str:
    if not isinstance(value, str) or not value or any(character.isspace() for character in value):
        raise ValueError("MCP origin must be a non-empty URL without whitespace")
    try:
        parsed = urlsplit(value)
    except ValueError as exc:
        raise ValueError("MCP origin is not a valid URL") from exc
    if (
        parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
    ):
        raise ValueError("MCP origin must not contain credentials, a path, query, or fragment")
    try:
        origin = _origin(value)
    except ValueError as exc:
        raise ValueError("MCP origin has an invalid port") from exc
    if parsed.scheme == "https":
        return origin
    loopback = (parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}
    if parsed.scheme == "http" and loopback and allow_insecure_loopback_http:
        return origin
    raise ValueError("MCP origins require HTTPS unless loopback HTTP is explicitly allowed")


def _reject_embedded_secrets(value: object, *, path: str = "mcpSource") -> None:
    sensitive = {
        "authorization",
        "password",
        "secret",
        "token",
        "apikey",
        "api_key",
        "access_token",
        "auth_token",
        "client_secret",
    }
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            credential_key = normalized in sensitive or normalized.endswith(
                ("password", "secret", "token", "apikey", "_api_key")
            )
            if credential_key and item is not None and item != "":
                raise PermissionError(f"{path}.{key} embeds a credential; use SecretRef")
            _reject_embedded_secrets(item, path=f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _reject_embedded_secrets(item, path=f"{path}[{index}]")


class InlineResourceLoader:
    """Safe default for embedded tests; deployment Hosts inject full logical bindings."""

    async def load(self, source: ResourceSource) -> LoadedResource:
        if not isinstance(source, InlineResourceSource):
            raise LookupError(f"ResourceSource kind={source.kind} requires HostResourceBindings")
        encoded = (
            source.content.encode("utf-8")
            if isinstance(source.content, str)
            else json.dumps(
                source.content,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode("utf-8")
        )
        digest = hashlib.sha256(encoded).hexdigest()
        if source.expected_sha256 is not None and digest.lower() != source.expected_sha256.lower():
            raise ValueError(f"resource digest mismatch: {source.resource_id}")
        return LoadedResource(
            content=source.content,
            media_type=source.media_type,
            sha256=digest,
            version=source.version,
            locator=f"inline://{source.resource_id}",
        )
