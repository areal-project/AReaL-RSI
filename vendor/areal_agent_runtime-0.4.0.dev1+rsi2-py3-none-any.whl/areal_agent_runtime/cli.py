"""Command line entrypoint for the reference ARealAgentRuntime Host."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import ssl
import sys
from pathlib import Path

from areal_agent_runtime import __version__
from areal_agent_runtime.adapters.remote import RuntimeWireServer
from areal_agent_runtime.bootstrap import (
    BootstrapConfig,
    RuntimeServiceBootstrapConfig,
    RuntimeWireListenConfig,
    build_composition,
    build_runtime_service,
)
from areal_agent_runtime.configuration import load_project_configuration


def main() -> None:
    parser = argparse.ArgumentParser(prog="areal-agent-runtime")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subcommands = parser.add_subparsers(dest="command", required=True)
    serve = subcommands.add_parser("serve", help="Start a configured Native or OpenAI-compatible Host")
    serve.add_argument(
        "--config",
        required=True,
        help="BootstrapConfig JSON, or a directory containing the four canonical YAML files",
    )
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8080)
    serve_runtime = subcommands.add_parser(
        "serve-runtime",
        help="Expose one configured Runtime Adapter over Runtime Wire v1",
    )
    serve_runtime.add_argument("--config", required=True, help="Path to a RuntimeServiceBootstrapConfig JSON file")
    invoke_arca = subcommands.add_parser(
        "invoke-arca",
        help="Invoke a configured ARCA/serverless Host using one JSON request",
    )
    invoke_arca.add_argument(
        "--config",
        required=True,
        help="ARCA BootstrapConfig JSON, or a directory containing the four canonical YAML files",
    )
    invoke_arca.add_argument("--request", default="-", help="Request JSON file, or '-' for stdin")
    invoke_arca.add_argument("--pretty", action="store_true")
    validate = subcommands.add_parser("validate", help="Validate configuration offline without loading plugins")
    validate.add_argument(
        "--config", required=True, help="Bootstrap/Runtime Service JSON, or a four-file project directory"
    )
    validate.add_argument("--json", action="store_true", help="Emit a machine-readable validation report")
    validate.add_argument(
        "--kind",
        choices=("auto", "bootstrap", "runtime-service"),
        default="auto",
        help="Use runtime-service when a service JSON omits wire; auto detects JSON containing wire",
    )
    args = parser.parse_args()
    try:
        if args.command == "serve":
            asyncio.run(_serve(Path(args.config), args.host, args.port))
        elif args.command == "serve-runtime":
            asyncio.run(_serve_runtime(Path(args.config)))
        elif args.command == "invoke-arca":
            asyncio.run(_invoke_arca(Path(args.config), args.request, pretty=args.pretty))
        elif args.command == "validate":
            from areal_agent_runtime.config_validation import validate_configuration

            report = asyncio.run(validate_configuration(Path(args.config), kind=args.kind))
            payload = report.to_dict()
            if args.json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(
                    f"{'PASS' if report.valid else 'FAIL'} ({report.config_kind}): "
                    f"{len(report.errors)} errors, {len(report.warnings)} warnings, "
                    f"{len(report.skipped_checks)} skipped checks"
                )
                for group in ("errors", "warnings", "skippedChecks"):
                    for issue in payload[group]:
                        location = ".".join(str(part) for part in issue["location"]) or "<root>"
                        print(f"{group}: {issue['file']}:{location} [{issue['code']}] {issue['message']}")
            raise SystemExit(0 if report.valid else 1)
    except KeyboardInterrupt:
        # asyncio.run translates a second-stage SIGINT into KeyboardInterrupt
        # after the server has already completed its graceful shutdown.
        return


async def _serve(path: Path, host: str, port: int) -> None:
    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover - optional dependency guard
        raise RuntimeError("Install areal-agent-runtime[api] to run the HTTP server") from exc
    config = await _load_application_config(path)
    composition = await build_composition(config)
    try:
        server = uvicorn.Server(
            uvicorn.Config(
                composition.create_http_app(),
                host=host,
                port=port,
                log_level="info",
            )
        )
        await server.serve()
    finally:
        await composition.close()


async def _serve_runtime(path: Path) -> None:
    raw = await asyncio.to_thread(path.read_text, encoding="utf-8")
    config = RuntimeServiceBootstrapConfig.model_validate(json.loads(raw))
    composition = await build_runtime_service(config)
    server: RuntimeWireServer | None = None
    try:
        default_workspace_root = await asyncio.to_thread(
            lambda: str(Path(config.data_root).expanduser().resolve() / "wire-workspaces")
        )
        server = RuntimeWireServer(
            composition.runtime,
            auth_token=_wire_auth_token(config.wire),
            max_frame_bytes=config.wire.max_frame_bytes,
            asset_store=composition.asset_store,
            workspace_root=(
                config.wire.workspace_root
                or default_workspace_root
            )
            if config.wire.workspace_transfer
            else None,
        )
        tls_context = await _server_ssl_context(config.wire)
        _validate_wire_security(config.wire, tls_context)
        host, port = await server.start_tcp(config.wire.host, config.wire.port, ssl_context=tls_context)
        print(f"ARealAgentRuntime Runtime Wire listening on {host}:{port}")
        await asyncio.Future()
    finally:
        if server is not None:
            await server.close()
        await composition.close()


async def _invoke_arca(path: Path, request_path: str, *, pretty: bool) -> None:
    config = await _load_application_config(path)
    if config.host.kind != "arca":
        raise ValueError("invoke-arca requires host.kind='arca'")
    if request_path == "-":
        raw_request = await asyncio.to_thread(sys.stdin.read)
    else:
        raw_request = await asyncio.to_thread(Path(request_path).read_text, encoding="utf-8")
    payload = json.loads(raw_request)
    if not isinstance(payload, dict):
        raise ValueError("ARCA request must be a JSON object")
    composition = await build_composition(config)
    try:
        response = await composition.create_arca_host().invoke(payload)
    finally:
        await composition.close()
    print(
        json.dumps(
            response,
            ensure_ascii=False,
            indent=2 if pretty else None,
            separators=None if pretty else (",", ":"),
        )
    )


async def _load_application_config(path: Path) -> BootstrapConfig:
    resolved, is_directory = await asyncio.to_thread(
        lambda: (path.expanduser().resolve(), path.expanduser().resolve().is_dir())
    )
    if is_directory or resolved.name in {
        "release.yaml",
        "composition.yaml",
        "workflow.yaml",
        "agents.yaml",
    }:
        return await load_project_configuration(resolved if is_directory else resolved.parent)
    raw = await asyncio.to_thread(resolved.read_text, encoding="utf-8")
    return BootstrapConfig.model_validate(json.loads(raw))


def _wire_auth_token(config: RuntimeWireListenConfig) -> str | None:
    if config.auth_token_env:
        token = os.environ.get(config.auth_token_env)
        if not token:
            raise ValueError(f"environment variable {config.auth_token_env!r} is empty or missing")
        return token
    return config.auth_token


async def _server_ssl_context(config: RuntimeWireListenConfig) -> ssl.SSLContext | None:
    if (config.tls_cert_file is None) != (config.tls_key_file is None):
        raise ValueError("tls_cert_file and tls_key_file must be configured together")
    if config.tls_cert_file is None or config.tls_key_file is None:
        return None
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    await asyncio.to_thread(context.load_cert_chain, config.tls_cert_file, config.tls_key_file)
    if config.tls_client_ca_file is not None:
        await asyncio.to_thread(context.load_verify_locations, config.tls_client_ca_file)
        context.verify_mode = (
            ssl.CERT_REQUIRED
            if config.tls_require_client_cert
            else ssl.CERT_OPTIONAL
        )
    return context


def _validate_wire_security(
    config: RuntimeWireListenConfig,
    tls_context: ssl.SSLContext | None,
) -> None:
    loopback = config.host in {"127.0.0.1", "::1", "localhost"}
    if not loopback and tls_context is None and not config.allow_insecure:
        raise ValueError(
            "Refusing plaintext Runtime Wire on a non-loopback address; configure TLS or set allow_insecure"
        )
