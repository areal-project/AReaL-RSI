"""Portable references to request-scoped knowledge bundles."""

from __future__ import annotations

from pydantic import Field, JsonValue, field_validator

from areal_agent_runtime.contracts.base import ContractModel, require_optional_trimmed


class KnowledgeRef(ContractModel):
    """Logical knowledge identity; never a caller-controlled filesystem path."""

    source: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    name: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    revision: str | None = Field(default=None, max_length=128)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("revision")
    @classmethod
    def validate_revision(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Knowledge revision")
