"""Stable SDK surface for third-party Agent Runtime (Harness) adapters.

Adapter authors should import contracts from this module instead of depending
on internal package paths.  Implement ``AgentRuntimePort`` and the returned
``ExecutionChannel``, then run ``verify_runtime`` before publishing.
"""

from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot
from areal_agent_runtime.contracts.runtime import (
    AgentRef,
    AgentRuntimePort,
    CancelReason,
    ExecutionChannel,
    ExecutionPolicy,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolCall,
    ToolResult,
    WorkspaceRef,
    normalize_finish_reason,
    normalize_token_usage,
)
from areal_agent_runtime.contracts.version import RUNTIME_API_VERSION, RUNTIME_WIRE_API_VERSION
from areal_agent_runtime.harness_sdk.events import HarnessEventBuilder
from areal_agent_runtime.plugin_sdk import (
    Plugin,
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)
from areal_agent_runtime.testing import (
    RuntimeConformanceCase,
    RuntimeConformanceError,
    RuntimeConformanceReport,
    analyze_data_coverage,
    verify_runtime,
)

HarnessAdapterPort = AgentRuntimePort

__all__ = [
    "AgentEnvironmentSnapshot",
    "AgentRef",
    "AgentRuntimePort",
    "CancelReason",
    "ContentBlock",
    "ExecutionChannel",
    "ExecutionPolicy",
    "ExecutionRequest",
    "HarnessAdapterPort",
    "HealthStatus",
    "HarnessEventBuilder",
    "InteractionResponse",
    "Modality",
    "Plugin",
    "PluginContext",
    "PluginEntrypoints",
    "PluginManifest",
    "PortKey",
    "RuntimeCapabilities",
    "RUNTIME_API_VERSION",
    "RuntimeConformanceCase",
    "RuntimeConformanceError",
    "RuntimeConformanceReport",
    "RuntimeDescriptor",
    "RuntimeEvent",
    "RuntimeSessionRef",
    "RuntimeSessionSpec",
    "RUNTIME_WIRE_API_VERSION",
    "ToolCall",
    "ToolResult",
    "WorkspaceRef",
    "analyze_data_coverage",
    "normalize_finish_reason",
    "normalize_token_usage",
    "verify_runtime",
]
