"""Defensive reads across the untrusted ``AssetStorePort`` adapter boundary."""

from __future__ import annotations

import hashlib

from areal_agent_runtime.contracts.ports import AssetStorePort

MAX_RUNTIME_ASSET_BYTES = 32 * 1024 * 1024
DEFAULT_MAX_RUNTIME_ASSET_BYTES = MAX_RUNTIME_ASSET_BYTES


async def read_asset_bytes(
    store: AssetStorePort,
    asset_id: str,
    *,
    expected_media_type: str,
    max_bytes: int,
    aggregate_max_bytes: int | None = None,
) -> bytes:
    """Read one immutable asset while enforcing its canonical descriptor.

    Runtime adapters are plugin boundaries.  They must not trust a custom store
    to honor ``AssetStorePort`` merely because it is structurally compatible.
    The early descriptor checks avoid loading a known-oversized object, while
    the streaming checks protect against missing or dishonest metadata.
    """

    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 1:
        raise ValueError("max_bytes must be a positive integer")
    if aggregate_max_bytes is not None and (
        isinstance(aggregate_max_bytes, bool)
        or not isinstance(aggregate_max_bytes, int)
        or aggregate_max_bytes < max_bytes
    ):
        raise ValueError("aggregate_max_bytes must be an integer no smaller than max_bytes")

    def limit_error() -> ValueError:
        if aggregate_max_bytes is not None and aggregate_max_bytes != max_bytes:
            return ValueError(
                "Assets exceed the configured aggregate "
                f"{aggregate_max_bytes}-byte Runtime input limit"
            )
        return ValueError(
            f"Asset exceeds the configured {max_bytes}-byte Runtime input limit: {asset_id}"
        )

    descriptor = await store.get(asset_id)
    if descriptor is None:
        raise FileNotFoundError(f"Unknown asset: {asset_id}")
    if descriptor.asset_id != asset_id:
        raise ValueError(f"AssetStore returned a descriptor for the wrong asset: {asset_id}")
    if descriptor.media_type != expected_media_type:
        raise ValueError(
            f"Asset media type mismatch for {asset_id}: "
            f"expected {expected_media_type}, got {descriptor.media_type}"
        )
    if descriptor.size is not None and descriptor.size > max_bytes:
        raise limit_error()

    payload = bytearray()
    digest = hashlib.sha256()
    async for chunk in store.open(asset_id):
        if not isinstance(chunk, bytes):
            raise TypeError("AssetStore.open() must yield bytes")
        if len(payload) + len(chunk) > max_bytes:
            raise limit_error()
        payload.extend(chunk)
        digest.update(chunk)

    if descriptor.size is not None and descriptor.size != len(payload):
        raise ValueError(f"Asset size does not match its immutable descriptor: {asset_id}")
    if descriptor.sha256 is not None and descriptor.sha256.lower() != digest.hexdigest():
        raise ValueError(f"Asset digest does not match its immutable descriptor: {asset_id}")
    return bytes(payload)
