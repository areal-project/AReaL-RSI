"""Expose a local AgentRuntimePort over ARealAgentRuntime Runtime Wire Protocol v1."""

from __future__ import annotations

import asyncio
import contextlib
import hmac
import ssl
from typing import Any

from areal_agent_runtime.adapters.remote.assets import RuntimeWireAssetBridge
from areal_agent_runtime.adapters.remote.workspaces import (
    RuntimeWireWorkspaceServer,
    ServerWorkspaceState,
)
from areal_agent_runtime.compatibility import (
    dump_runtime_descriptor_v1,
    dump_runtime_event_v1,
    runtime_client_supports_data_v1,
)
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    AgentRuntimePort,
    CancelReason,
    ExecutionChannel,
    ExecutionRequest,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolExecution,
    require_session_environment,
)
from areal_agent_runtime.contracts.wire import (
    ExecutionAccepted,
    ExecutionCancelParams,
    ExecutionInteractionResponseParams,
    ExecutionStartParams,
    ExecutionSteerParams,
    ExecutionToolResultParams,
    RuntimeAuthenticateParams,
    RuntimeAuthenticateResult,
    RuntimeEventNotification,
    RuntimeNegotiateParams,
    RuntimeNegotiateResult,
    SessionCloseParams,
    SessionCloseResult,
    SessionOpenParams,
    SessionOpenResult,
)
from areal_agent_runtime.transports.jsonrpc import JsonRpcPeer, JsonRpcProtocolError


class RuntimeWireConnection:
    def __init__(
        self,
        runtime: AgentRuntimePort,
        peer: JsonRpcPeer,
        *,
        auth_token: str | None = None,
        max_frame_bytes: int = 16 * 1024 * 1024,
        asset_store: AssetStorePort | None = None,
        workspace_root: str | None = None,
        claimed_session_ids: set[str] | None = None,
        claimed_runtime_session_ids: set[str] | None = None,
        claimed_execution_ids: set[str] | None = None,
    ) -> None:
        self._runtime = runtime
        self._peer = peer
        self._auth_token = auth_token
        self._authenticated = auth_token is None
        self._negotiated = False
        self._data_v1 = False
        self._max_frame_bytes = max_frame_bytes
        self._asset_bridge = RuntimeWireAssetBridge(peer, asset_store) if asset_store is not None else None
        self._workspace_bridge = (
            RuntimeWireWorkspaceServer(asset_store, workspace_root)
            if asset_store is not None and workspace_root is not None
            else None
        )
        self._workspace_states: dict[str, tuple[ServerWorkspaceState, str]] = {}
        self._channels: dict[str, ExecutionChannel] = {}
        self._execution_sessions: dict[str, str] = {}
        self._sessions: dict[str, RuntimeSessionRef] = {}
        self._session_specs: dict[str, RuntimeSessionSpec] = {}
        # These registries are owned by RuntimeWireServer and shared by every
        # connection.  A canonical session is a single-owner capability: two
        # clients must never receive handles to the same underlying Runtime
        # session merely because an adapter implements idempotent open_session.
        self._claimed_session_ids = claimed_session_ids if claimed_session_ids is not None else set()
        self._claimed_runtime_session_ids = (
            claimed_runtime_session_ids if claimed_runtime_session_ids is not None else set()
        )
        self._claimed_execution_ids = claimed_execution_ids if claimed_execution_ids is not None else set()
        self._pumps: set[asyncio.Task[None]] = set()
        self._cleanup_errors: list[BaseException] = []
        self._close_lock = asyncio.Lock()
        self._closing = False
        self._closed = False
        peer.on_request("runtime.authenticate", self._authenticate)
        peer.on_request("runtime.negotiate", self._negotiate)
        peer.on_request("runtime.describe", self._describe)
        peer.on_request("runtime.health", self._health)
        peer.on_request("session.open", self._open_session)
        peer.on_request("session.close", self._close_session)
        peer.on_request("execution.start", self._start_execution)
        peer.on_request("execution.tool_result", self._tool_result)
        peer.on_request("execution.interaction_response", self._interaction_response)
        peer.on_request("execution.steer", self._steer)
        peer.on_request("execution.cancel", self._cancel)

    async def start(self) -> None:
        await self._peer.start()

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                if self._asset_bridge is not None:
                    self._asset_bridge.close()
                return
            self._closing = True
            errors: list[BaseException] = []
            # Stop request dispatch before walking mutable connection state.
            try:
                await self._peer.close()
            except BaseException as exc:
                errors.append(exc)
            for pump in tuple(self._pumps):
                pump.cancel()
            if self._pumps:
                pump_results = await asyncio.gather(*self._pumps, return_exceptions=True)
                errors.extend(
                    result
                    for result in pump_results
                    if isinstance(result, BaseException) and not isinstance(result, asyncio.CancelledError)
                )
            errors.extend(self._cleanup_errors)
            self._cleanup_errors.clear()
            channels = tuple(self._channels.values())
            if channels:
                channel_results = await asyncio.gather(
                    *(channel.close() for channel in channels),
                    return_exceptions=True,
                )
                errors.extend(result for result in channel_results if isinstance(result, BaseException))
            sessions = tuple(self._sessions.values())
            execution_ids = tuple(self._execution_sessions)
            self._sessions.clear()
            self._session_specs.clear()
            self._execution_sessions.clear()
            for execution_id in execution_ids:
                self._claimed_execution_ids.discard(execution_id)
            for session in sessions:
                try:
                    await self._runtime.close_session(session)
                except BaseException as exc:
                    # Keep the server-wide claim quarantined. Reissuing an
                    # idempotent open against a session that failed to close
                    # could hand another client the same live capability.
                    errors.append(exc)
                    continue
                self._release_session_claim(session)
            workspace_states = tuple(state for state, _workspace_id in self._workspace_states.values())
            self._workspace_states.clear()
            if workspace_states and self._workspace_bridge is not None:
                workspace_results = await asyncio.gather(
                    *(self._workspace_bridge.discard(state) for state in workspace_states),
                    return_exceptions=True,
                )
                errors.extend(result for result in workspace_results if isinstance(result, BaseException))
            if self._asset_bridge is not None:
                try:
                    self._asset_bridge.close()
                except BaseException as exc:
                    errors.append(exc)
            self._closed = True
            if errors:
                raise BaseExceptionGroup("Runtime Wire connection failed to close cleanly", errors)

    async def _describe(self, _params: Any) -> Any:
        self._require_ready()
        descriptor = await self._runtime.describe()
        if not self._data_v1:
            return dump_runtime_descriptor_v1(descriptor)
        return descriptor.model_dump(mode="json", by_alias=True)

    async def _health(self, _params: Any) -> Any:
        self._require_ready()
        health = await self._runtime.health()
        return health.model_dump(mode="json", by_alias=True)

    async def _open_session(self, params: Any) -> Any:
        self._require_ready()
        request = SessionOpenParams.model_validate(params)
        spec = request.spec
        if spec.session_id in self._claimed_session_ids:
            raise JsonRpcProtocolError(
                -32043,
                f"Session is already open: {spec.session_id}",
            )
        # There is no await between the membership check and add, so this is
        # an atomic reservation with respect to all asyncio connections served
        # by this RuntimeWireServer event loop.
        self._claimed_session_ids.add(spec.session_id)
        workspace_state: ServerWorkspaceState | None = None
        try:
            if request.workspace_snapshot is not None:
                if self._workspace_bridge is None or self._asset_bridge is None or not self._asset_bridge.enabled:
                    raise JsonRpcProtocolError(
                        -32040,
                        "Runtime Wire workspace transfer was not negotiated",
                    )
                local_asset_id = await self._asset_bridge.materialize_asset(request.workspace_snapshot.asset_id)
                spec, workspace_state = await self._workspace_bridge.import_initial(
                    spec,
                    local_asset_id,
                )
            session = await self._runtime.open_session(spec)
        except BaseException as open_error:
            cleanup_error: BaseException | None = None
            if workspace_state is not None and self._workspace_bridge is not None:
                try:
                    await self._workspace_bridge.discard(workspace_state)
                except BaseException as exc:
                    cleanup_error = exc
            self._claimed_session_ids.discard(request.spec.session_id)
            if cleanup_error is not None:
                raise BaseExceptionGroup(
                    "Runtime Wire session open failed and workspace cleanup also failed",
                    [open_error, cleanup_error],
                ) from None
            raise
        if session.session_id != request.spec.session_id:
            safe_to_close = (
                session.session_id not in self._claimed_session_ids
                and session.runtime_session_id not in self._claimed_runtime_session_ids
            )
            closed = False
            if safe_to_close:
                try:
                    await self._runtime.close_session(session)
                    closed = True
                except BaseException:
                    self._claimed_session_ids.add(session.session_id)
                    self._claimed_runtime_session_ids.add(session.runtime_session_id)
            if closed:
                self._claimed_session_ids.discard(request.spec.session_id)
            else:
                # The requested canonical ID remains quarantined because the
                # misbehaving Runtime may have allocated an uncloseable session.
                self._claimed_session_ids.add(request.spec.session_id)
                self._claimed_session_ids.add(session.session_id)
                self._claimed_runtime_session_ids.add(session.runtime_session_id)
            if workspace_state is not None and self._workspace_bridge is not None:
                await self._workspace_bridge.discard(workspace_state)
            raise JsonRpcProtocolError(
                -32042,
                "Runtime returned a session with a mismatched canonical sessionId",
            )
        if session.runtime_session_id in self._claimed_runtime_session_ids:
            # Do not close this handle: a broken Runtime may have aliased it to
            # another connection's live session.  Quarantine the new canonical
            # ID and fail closed instead of disrupting the existing owner.
            if workspace_state is not None and self._workspace_bridge is not None:
                await self._workspace_bridge.discard(workspace_state)
            raise JsonRpcProtocolError(
                -32043,
                "Runtime returned a duplicate runtimeSessionId",
            )
        self._sessions[session.session_id] = session
        self._session_specs[session.session_id] = spec
        self._claimed_runtime_session_ids.add(session.runtime_session_id)
        if workspace_state is not None:
            self._workspace_states[session.session_id] = (
                workspace_state,
                spec.workspace.workspace_id,
            )
        return SessionOpenResult(session=session).model_dump(mode="json", by_alias=True)

    async def _close_session(self, params: Any) -> Any:
        self._require_ready()
        request = SessionCloseParams.model_validate(params)
        owned = self._sessions.get(request.session.session_id)
        if owned is None or owned != request.session:
            raise JsonRpcProtocolError(
                -32044,
                "Session does not belong to this Runtime Wire connection",
            )
        if owned.session_id in self._execution_sessions.values():
            raise JsonRpcProtocolError(
                -32047,
                "Session cannot be closed while an execution is active",
            )
        workspace = self._workspace_states.get(owned.session_id)
        snapshot = None
        if workspace is not None:
            if self._workspace_bridge is None or self._asset_bridge is None:
                raise RuntimeError("Runtime Wire workspace transfer state is inconsistent")
            state, workspace_id = workspace
            # Snapshot first and retain the isolated workspace until the
            # underlying Runtime session has closed successfully. A transient
            # AssetStore failure can therefore be retried without data loss.
            snapshot = await self._workspace_bridge.export_final(
                state,
                workspace_id=workspace_id,
            )
            self._asset_bridge.allow_asset(snapshot.asset_id)
        await self._runtime.close_session(owned)
        self._sessions.pop(owned.session_id, None)
        self._session_specs.pop(owned.session_id, None)
        self._release_session_claim(owned)
        if workspace is not None:
            assert self._workspace_bridge is not None
            state, _workspace_id = workspace
            try:
                await self._workspace_bridge.discard(state)
            except Exception:
                # Cleanup is retryable from connection.close(); do not hide a
                # valid final snapshot from the Host after the session closed.
                pass
            else:
                self._workspace_states.pop(owned.session_id, None)
        return SessionCloseResult(workspace_snapshot=snapshot).model_dump(
            mode="json",
            by_alias=True,
        )

    async def _start_execution(self, params: Any) -> Any:
        self._require_ready()
        request = ExecutionStartParams.model_validate(params).request
        session = self._sessions.get(request.session_id)
        spec = self._session_specs.get(request.session_id)
        if session is None or spec is None:
            raise JsonRpcProtocolError(
                -32044,
                "Execution session does not belong to this Runtime Wire connection",
            )
        if request.workspace.workspace_id != spec.workspace.workspace_id:
            raise JsonRpcProtocolError(
                -32045,
                "Execution workspaceId does not match the opened session",
            )
        request = request.model_copy(update={"workspace": spec.workspace})
        try:
            require_session_environment(spec, request)
        except ValueError as exc:
            raise JsonRpcProtocolError(-32045, str(exc)) from exc
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            request = request.model_copy(
                update={"input": await self._asset_bridge.materialize_content(request.input)}
            )
        if request.execution_id in self._claimed_execution_ids:
            raise JsonRpcProtocolError(-32011, "Execution already exists")
        self._claimed_execution_ids.add(request.execution_id)
        try:
            channel = await self._runtime.execute(request)
        except BaseException:
            self._claimed_execution_ids.discard(request.execution_id)
            raise
        self._channels[request.execution_id] = channel
        self._execution_sessions[request.execution_id] = request.session_id
        pump = asyncio.create_task(self._pump(request, channel))
        self._pumps.add(pump)
        pump.add_done_callback(self._pumps.discard)
        return ExecutionAccepted(execution_id=request.execution_id).model_dump(mode="json", by_alias=True)

    async def _pump(self, request: ExecutionRequest, channel: ExecutionChannel) -> None:
        expected_sequence = 0
        last_notified_sequence = -1
        runtime_instance_id: str | None = None
        execution_started = False
        terminal: RuntimeEvent | None = None
        try:
            async for event in channel.events():
                if event.execution_id != request.execution_id:
                    raise JsonRpcProtocolError(
                        -32046,
                        "Runtime emitted an event for a different execution",
                    )
                if runtime_instance_id is None:
                    runtime_instance_id = event.runtime_instance_id
                elif event.runtime_instance_id != runtime_instance_id:
                    raise JsonRpcProtocolError(
                        -32046,
                        "Runtime instance changed within an active execution: "
                        f"{runtime_instance_id} -> {event.runtime_instance_id}",
                    )
                if event.runtime_sequence != expected_sequence:
                    raise JsonRpcProtocolError(
                        -32046,
                        f"Runtime sequence must be contiguous from zero; expected "
                        f"{expected_sequence}, received {event.runtime_sequence}",
                    )
                expected_sequence += 1
                if event.runtime_sequence == 0 and event.type != EventType.EXECUTION_STARTED:
                    raise JsonRpcProtocolError(
                        -32046,
                        "Runtime sequence zero must be execution.started",
                    )
                if event.type == EventType.EXECUTION_STARTED:
                    if execution_started:
                        raise JsonRpcProtocolError(
                            -32046,
                            "Runtime emitted execution.started more than once",
                        )
                    execution_started = True
                if terminal is not None:
                    raise JsonRpcProtocolError(
                        -32046,
                        "Runtime emitted an event after its terminal event",
                    )
                if event.type in {
                    EventType.EXECUTION_COMPLETED,
                    EventType.EXECUTION_FAILED,
                }:
                    terminal = event
                    continue
                await self._notify_event(request, event)
                last_notified_sequence = event.runtime_sequence
            if terminal is None:
                raise JsonRpcProtocolError(
                    -32046,
                    "Runtime event stream ended without exactly one terminal event",
                )
            await self._notify_event(request, terminal)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            failure_runtime_instance_id = runtime_instance_id or "runtime-wire"
            if last_notified_sequence < 0:
                started = RuntimeEvent(
                    runtime_instance_id=failure_runtime_instance_id,
                    runtime_sequence=0,
                    execution_id=request.execution_id,
                    agent_id=request.agent.agent_id,
                    parent_agent_id=request.agent.parent_agent_id,
                    type=EventType.EXECUTION_STARTED,
                    data={"synthetic": True, "source": "runtime-wire"},
                )
                try:
                    await self._peer.notify(
                        "runtime.event",
                        RuntimeEventNotification(event=started).model_dump(
                            mode="json",
                            by_alias=True,
                        ),
                    )
                except Exception:
                    pass
                else:
                    last_notified_sequence = 0
            failure = RuntimeEvent(
                runtime_instance_id=failure_runtime_instance_id,
                runtime_sequence=last_notified_sequence + 1,
                execution_id=request.execution_id,
                agent_id=request.agent.agent_id,
                parent_agent_id=request.agent.parent_agent_id,
                type=EventType.EXECUTION_FAILED,
                data={
                    "reason": "runtime_wire_protocol_failure",
                    "detail": str(exc) or type(exc).__name__,
                },
            )
            with contextlib.suppress(Exception):
                await self._peer.notify(
                    "runtime.event",
                    RuntimeEventNotification(event=failure).model_dump(
                        mode="json",
                        by_alias=True,
                    ),
                )
            try:
                await channel.cancel(
                    CancelReason(
                        code="runtime_wire_protocol_failure",
                        message=str(exc) or type(exc).__name__,
                    )
                )
            except BaseException as cleanup_error:
                self._remember_cleanup_failure("protocol cancellation", cleanup_error)
        finally:
            self._channels.pop(request.execution_id, None)
            self._execution_sessions.pop(request.execution_id, None)
            self._claimed_execution_ids.discard(request.execution_id)
            try:
                await channel.close()
            except BaseException as cleanup_error:
                self._remember_cleanup_failure("execution channel close", cleanup_error)

    async def _notify_event(
        self,
        request: ExecutionRequest,
        event: RuntimeEvent,
    ) -> None:
        snapshot = None
        if _is_external_tool_request(event, request):
            workspace = self._workspace_states.get(request.session_id)
            if workspace is not None:
                if self._workspace_bridge is None or self._asset_bridge is None:
                    raise RuntimeError("Runtime Wire workspace transfer state is inconsistent")
                state, workspace_id = workspace
                snapshot = await self._workspace_bridge.export_current(
                    state,
                    workspace_id=workspace_id,
                )
                self._asset_bridge.allow_asset(snapshot.asset_id)
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            self._asset_bridge.allow_json(event.data)
        params = RuntimeEventNotification(event=event, workspace_snapshot=snapshot)
        payload = params.model_dump(mode="json", by_alias=True)
        if not self._data_v1:
            payload["event"] = dump_runtime_event_v1(event)
        await self._peer.notify("runtime.event", payload)

    async def _tool_result(self, params: Any) -> Any:
        self._require_ready()
        request = ExecutionToolResultParams.model_validate(params)
        session_id = self._execution_sessions.get(request.execution_id)
        if session_id is None:
            raise JsonRpcProtocolError(
                -32012,
                f"Execution not active: {request.execution_id}",
            )
        workspace = self._workspace_states.get(session_id)
        if workspace is not None:
            if (
                request.workspace_snapshot is None
                or self._workspace_bridge is None
                or self._asset_bridge is None
                or not self._asset_bridge.enabled
            ):
                raise JsonRpcProtocolError(
                    -32041,
                    "Runtime Wire tool result omitted the negotiated workspace snapshot",
                )
            state, _workspace_id = workspace
            local_asset_id = await self._asset_bridge.materialize_asset(request.workspace_snapshot.asset_id)
            await self._workspace_bridge.import_update(state, local_asset_id)
        elif request.workspace_snapshot is not None:
            raise JsonRpcProtocolError(
                -32041,
                "Unexpected Runtime Wire workspace snapshot",
            )
        result = request.result
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            result = result.model_copy(
                update={
                    "content": await self._asset_bridge.materialize_content(result.content),
                    "value": await self._asset_bridge.materialize_json(result.value),
                }
            )
        await self._channel(request.execution_id).send_tool_result(result)
        return {}

    async def _interaction_response(self, params: Any) -> Any:
        self._require_ready()
        request = ExecutionInteractionResponseParams.model_validate(params)
        response = request.response
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            response = response.model_copy(
                update={"response": await self._asset_bridge.materialize_json(response.response)}
            )
        await self._channel(request.execution_id).respond(response)
        return {}

    async def _steer(self, params: Any) -> Any:
        self._require_ready()
        request = ExecutionSteerParams.model_validate(params)
        input = request.input
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            input = await self._asset_bridge.materialize_content(input)
        await self._channel(request.execution_id).steer(input)
        return {}

    async def _cancel(self, params: Any) -> Any:
        self._require_ready()
        request = ExecutionCancelParams.model_validate(params)
        await self._channel(request.execution_id).cancel(request.reason)
        return {}

    def _channel(self, execution_id: str) -> ExecutionChannel:
        channel = self._channels.get(execution_id)
        if channel is None:
            raise JsonRpcProtocolError(-32012, f"Execution not active: {execution_id}")
        return channel

    async def _authenticate(self, params: Any) -> Any:
        request = RuntimeAuthenticateParams.model_validate(params)
        if self._auth_token is None or not hmac.compare_digest(request.token, self._auth_token):
            raise JsonRpcProtocolError(-32001, "Runtime authentication failed")
        self._authenticated = True
        return RuntimeAuthenticateResult().model_dump(mode="json", by_alias=True)

    async def _negotiate(self, params: Any) -> Any:
        self._require_authenticated()
        if self._negotiated:
            raise JsonRpcProtocolError(-32002, "Runtime protocol was already negotiated")
        request = RuntimeNegotiateParams.model_validate(params)
        self._data_v1 = runtime_client_supports_data_v1(request.client_name)
        descriptor = await self._runtime.describe()
        if descriptor.runtime_api_version not in request.supported_runtime_api_versions:
            raise JsonRpcProtocolError(
                -32002,
                f"No compatible Runtime API version: {descriptor.runtime_api_version}",
            )
        negotiated_limit = min(self._max_frame_bytes, request.max_frame_bytes)
        asset_transfer = request.asset_transfer and self._asset_bridge is not None
        if asset_transfer:
            self._asset_bridge.enable()
        self._peer.set_max_frame_bytes_after_next_send(negotiated_limit)
        self._negotiated = True
        workspace_transfer = request.workspace_transfer and asset_transfer and self._workspace_bridge is not None
        result = RuntimeNegotiateResult(
            runtime_api_version=descriptor.runtime_api_version,
            max_frame_bytes=negotiated_limit,
            asset_transfer=asset_transfer,
            workspace_transfer=workspace_transfer,
            descriptor=descriptor,
        ).model_dump(mode="json", by_alias=True)
        if not self._data_v1:
            result["descriptor"] = dump_runtime_descriptor_v1(descriptor)
        return result

    def _require_authenticated(self) -> None:
        if not self._authenticated:
            raise JsonRpcProtocolError(-32001, "Runtime authentication required")

    def _require_ready(self) -> None:
        if self._closing:
            raise JsonRpcProtocolError(-32000, "Runtime Wire connection is closing")
        self._require_authenticated()
        if not self._negotiated:
            raise JsonRpcProtocolError(-32002, "Runtime protocol negotiation required")

    def _release_session_claim(self, session: RuntimeSessionRef) -> None:
        self._claimed_session_ids.discard(session.session_id)
        self._claimed_runtime_session_ids.discard(session.runtime_session_id)

    def _remember_cleanup_failure(self, stage: str, error: BaseException) -> None:
        error.add_note(f"Runtime Wire cleanup stage: {stage}")
        self._cleanup_errors.append(error)


def _is_external_tool_request(
    event: RuntimeEvent,
    request: ExecutionRequest,
) -> bool:
    if event.type != EventType.TOOL_REQUESTED or not isinstance(event.data, dict):
        return False
    execution = event.data.get("execution")
    if execution in {
        ToolExecution.APPLICATION,
        ToolExecution.REMOTE,
        ToolExecution.APPLICATION.value,
        ToolExecution.REMOTE.value,
    }:
        return True
    name = event.data.get("name")
    return isinstance(name, str) and any(
        tool.name == name and tool.execution in {ToolExecution.APPLICATION, ToolExecution.REMOTE}
        for tool in request.tools
    )


class RuntimeWireServer:
    def __init__(
        self,
        runtime: AgentRuntimePort,
        *,
        auth_token: str | None = None,
        max_frame_bytes: int = 16 * 1024 * 1024,
        asset_store: AssetStorePort | None = None,
        workspace_root: str | None = None,
    ) -> None:
        if isinstance(max_frame_bytes, bool) or not isinstance(max_frame_bytes, int) or max_frame_bytes < 1024:
            raise ValueError("max_frame_bytes must be an integer of at least 1024")
        if auth_token is not None and (not isinstance(auth_token, str) or not auth_token.strip()):
            raise ValueError("auth_token must be a non-blank string when provided")
        if workspace_root is not None and (not isinstance(workspace_root, str) or not workspace_root.strip()):
            raise ValueError("workspace_root must be a non-blank string when provided")
        if workspace_root is not None and asset_store is None:
            raise ValueError("workspace_root requires an AssetStore")
        self._runtime = runtime
        self._auth_token = auth_token
        self._max_frame_bytes = max_frame_bytes
        self._asset_store = asset_store
        self._workspace_root = workspace_root
        self._server: asyncio.Server | None = None
        self._connections: set[RuntimeWireConnection] = set()
        self._connection_tasks: set[asyncio.Task[None]] = set()
        self._claimed_session_ids: set[str] = set()
        self._claimed_runtime_session_ids: set[str] = set()
        self._claimed_execution_ids: set[str] = set()
        self._connection_cleanup_errors: list[BaseException] = []
        self._close_lock = asyncio.Lock()
        self._closed = False

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None or not self._server.sockets:
            raise RuntimeError("Runtime wire server is not started")
        host, port, *_ = self._server.sockets[0].getsockname()
        return str(host), int(port)

    async def start_tcp(
        self,
        host: str = "127.0.0.1",
        port: int = 0,
        *,
        ssl_context: ssl.SSLContext | None = None,
    ) -> tuple[str, int]:
        if self._closed:
            raise RuntimeError("Runtime wire server is closed")
        if self._server is not None:
            raise RuntimeError("Runtime wire server is already started")
        if not isinstance(host, str) or not host.strip() or host != host.strip():
            raise ValueError("host must be a non-blank, trimmed string")
        if isinstance(port, bool) or not isinstance(port, int) or not 0 <= port <= 65535:
            raise ValueError("port must be an integer between 0 and 65535")
        self._server = await asyncio.start_server(
            self._accept,
            host,
            port,
            ssl=ssl_context,
            limit=self._max_frame_bytes + 1,
        )
        return self.address

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            errors = list(self._connection_cleanup_errors)
            self._connection_cleanup_errors.clear()
            if self._server is not None:
                self._server.close()
            connections = tuple(self._connections)
            if connections:
                results = await asyncio.gather(
                    *(connection.close() for connection in connections),
                    return_exceptions=True,
                )
                errors.extend(result for result in results if isinstance(result, BaseException))
            self._connections.clear()
            if self._server is not None:
                try:
                    await self._server.wait_closed()
                except BaseException as exc:
                    errors.append(exc)
            connection_tasks = tuple(
                task
                for task in self._connection_tasks
                if task is not asyncio.current_task()
            )
            if connection_tasks:
                task_results = await asyncio.gather(*connection_tasks, return_exceptions=True)
                errors.extend(result for result in task_results if isinstance(result, BaseException))
            errors.extend(self._connection_cleanup_errors)
            self._connection_cleanup_errors.clear()
            # The listener is now closed and every connection has been given a
            # cleanup attempt, so quarantined claims cannot affect this server.
            self._claimed_session_ids.clear()
            self._claimed_runtime_session_ids.clear()
            self._claimed_execution_ids.clear()
            self._closed = True
            if errors:
                raise BaseExceptionGroup("Runtime wire server failed to close cleanly", errors)

    async def _accept(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        accept_task = asyncio.current_task()
        if accept_task is not None:
            self._connection_tasks.add(accept_task)
        peer = JsonRpcPeer(reader, writer, max_frame_bytes=self._max_frame_bytes)
        connection = RuntimeWireConnection(
            self._runtime,
            peer,
            auth_token=self._auth_token,
            max_frame_bytes=self._max_frame_bytes,
            asset_store=self._asset_store,
            workspace_root=self._workspace_root,
            claimed_session_ids=self._claimed_session_ids,
            claimed_runtime_session_ids=self._claimed_runtime_session_ids,
            claimed_execution_ids=self._claimed_execution_ids,
        )
        self._connections.add(connection)
        try:
            await connection.start()
            await peer.wait_closed()
        finally:
            self._connections.discard(connection)
            try:
                await connection.close()
            except Exception as exc:
                self._connection_cleanup_errors.append(exc)
            finally:
                if accept_task is not None:
                    self._connection_tasks.discard(accept_task)
