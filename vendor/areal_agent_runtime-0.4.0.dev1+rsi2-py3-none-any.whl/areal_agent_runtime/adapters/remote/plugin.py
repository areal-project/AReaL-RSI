"""Plugin SPI packaging for a Runtime Wire client."""

from __future__ import annotations

import asyncio
import ipaddress
import math
import os
import re
import ssl
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.remote.client import RemoteRuntimeAdapter
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class RemoteRuntimePlugin:
    manifest = PluginManifest(
        name="remote-runtime",
        version="1.0.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.remote.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("network.runtime",),
    )

    def __init__(self) -> None:
        self.runtime: RemoteRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        host = _required_string(config.get("host"), "host")
        port = _required_port(config.get("port"))
        tls_context = await _client_ssl_context(config)
        allow_insecure = _boolean(config.get("allowInsecure"), False, "allowInsecure")
        if tls_context is None and not allow_insecure and not _is_loopback_host(host):
            raise ValueError(
                "remote runtime plaintext connections are limited to loopback; "
                "configure TLS or explicitly set allowInsecure"
            )
        token = _secret(config, "authToken", "authTokenEnv")
        timeout_seconds = _positive_number(config.get("connectTimeoutSeconds"), 30.0)
        max_frame_bytes = _positive_integer(config.get("maxFrameBytes"), 16 * 1024 * 1024)
        async with asyncio.timeout(timeout_seconds):
            self.runtime = await RemoteRuntimeAdapter.connect_tcp(
                host,
                port,
                ssl_context=tls_context,
                server_hostname=_optional_string(config.get("serverHostname")),
                auth_token=token,
                max_frame_bytes=max_frame_bytes,
                asset_store=_optional_asset_store(context),
                workspace_transfer=_boolean(
                    config.get("workspaceTransfer"),
                    True,
                    "workspaceTransfer",
                ),
            )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Remote Runtime plugin is not configured")
        health = await self.runtime.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "Remote Runtime is unhealthy"))

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> RemoteRuntimePlugin:
    return RemoteRuntimePlugin()


async def _client_ssl_context(config: dict[str, JsonValue]) -> ssl.SSLContext | None:
    enabled = config.get("tls", False)
    if not isinstance(enabled, bool):
        raise ValueError("remote runtime config tls must be a boolean")
    if not enabled:
        tls_only = ("caFile", "clientCertFile", "clientKeyFile", "serverHostname")
        if any(config.get(key) is not None for key in tls_only):
            raise ValueError("remote runtime TLS files/serverHostname require tls=true")
        return None
    ca_file = _optional_string(config.get("caFile"))
    context = await asyncio.to_thread(ssl.create_default_context, cafile=ca_file)
    cert_file = _optional_string(config.get("clientCertFile"))
    key_file = _optional_string(config.get("clientKeyFile"))
    if (cert_file is None) != (key_file is None):
        raise ValueError("clientCertFile and clientKeyFile must be configured together")
    if cert_file is not None and key_file is not None:
        await asyncio.to_thread(context.load_cert_chain, cert_file, key_file)
    return context


def _secret(config: dict[str, JsonValue], direct_key: str, env_key: str) -> str | None:
    if config.get(direct_key) is not None and config.get(env_key) is not None:
        raise ValueError(f"configure either {direct_key} or {env_key}, not both")
    env_name = _optional_string(config.get(env_key))
    if env_name is not None:
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", env_name) is None:
            raise ValueError(f"{env_key} must contain a valid environment variable name")
        value = os.environ.get(env_name)
        if not value:
            raise ValueError(f"environment variable {env_name!r} is empty or missing")
        return value
    return _optional_string(config.get(direct_key))


def _required_string(value: JsonValue | None, name: str) -> str:
    parsed = _optional_string(value)
    if parsed is None:
        raise ValueError(f"remote runtime config {name} is required")
    return parsed


def _required_port(value: JsonValue | None) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= 65535:
        raise ValueError("remote runtime config port must be an integer between 1 and 65535")
    return value


def _positive_number(value: JsonValue | None, default: float) -> float:
    if value is None:
        return default
    if (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        and value > 0
    ):
        return float(value)
    raise ValueError("connectTimeoutSeconds must be a positive number")


def _positive_integer(value: JsonValue | None, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, int) and not isinstance(value, bool) and value >= 1024:
        return value
    raise ValueError("maxFrameBytes must be an integer of at least 1024")


def _boolean(value: JsonValue | None, default: bool, name: str) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    raise ValueError(f"{name} must be a boolean")


def _optional_string(value: JsonValue | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip() or value != value.strip():
        raise ValueError("remote runtime string values must be non-blank and trimmed")
    return value


def _is_loopback_host(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))
