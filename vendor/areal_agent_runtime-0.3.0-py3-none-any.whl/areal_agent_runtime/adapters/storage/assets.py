"""Content-addressed local AssetStore with durable metadata."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import stat
import tempfile
from collections.abc import AsyncIterator
from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.contracts.base import require_media_type
from areal_agent_runtime.contracts.content import AssetLocator, AssetRef


class FileSystemAssetStore:
    """Store immutable media bytes separately from protocol/event payloads."""

    def __init__(
        self,
        root: str | Path,
        *,
        read_chunk_size: int = 1024 * 1024,
        max_asset_bytes: int = 256 * 1024 * 1024,
        max_metadata_bytes: int = 1024 * 1024,
    ) -> None:
        if isinstance(read_chunk_size, bool) or not isinstance(read_chunk_size, int) or read_chunk_size < 1:
            raise ValueError("read_chunk_size must be a positive integer")
        if isinstance(max_asset_bytes, bool) or not isinstance(max_asset_bytes, int) or max_asset_bytes < 1:
            raise ValueError("max_asset_bytes must be a positive integer")
        if isinstance(max_metadata_bytes, bool) or not isinstance(max_metadata_bytes, int) or max_metadata_bytes < 1:
            raise ValueError("max_metadata_bytes must be a positive integer")
        self._root = Path(root).expanduser().resolve()
        self._blobs = self._root / "blobs"
        self._metadata = self._root / "metadata"
        self._read_chunk_size = read_chunk_size
        self._max_asset_bytes = max_asset_bytes
        self._max_metadata_bytes = max_metadata_bytes
        self._write_lock = asyncio.Lock()
        self._blobs.mkdir(parents=True, exist_ok=True)
        self._metadata.mkdir(parents=True, exist_ok=True)

    async def put(
        self,
        chunks: AsyncIterator[bytes],
        *,
        media_type: str,
        metadata: dict[str, JsonValue] | None = None,
    ) -> AssetRef:
        require_media_type(media_type)
        if len(media_type) > 255:
            raise ValueError("media_type must not exceed 255 characters")
        descriptor, temporary_name = tempfile.mkstemp(prefix="asset-", dir=self._root)
        digest = hashlib.sha256()
        size = 0
        try:
            with os.fdopen(descriptor, "wb") as handle:
                async for chunk in chunks:
                    if not isinstance(chunk, bytes):
                        raise TypeError("AssetStore chunks must be bytes")
                    if size + len(chunk) > self._max_asset_bytes:
                        raise ValueError(f"AssetStore payload exceeds max_asset_bytes={self._max_asset_bytes}")
                    handle.write(chunk)
                    digest.update(chunk)
                    size += len(chunk)
                handle.flush()
                os.fsync(handle.fileno())

            sha256 = digest.hexdigest()
            # A retry of the same immutable descriptor must produce the same
            # AssetRef. This is required when a publisher has accepted an
            # artifact but the canonical ToolResult commit is interrupted.
            # Include media type and metadata so one byte blob can still have
            # distinct, immutable provenance records.
            identity = json.dumps(
                {
                    "sha256": sha256,
                    "mediaType": media_type,
                    "metadata": metadata or {},
                },
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            asset_id = f"asset_{hashlib.sha256(identity.encode('utf-8')).hexdigest()}"
            ref = AssetRef(
                asset_id=asset_id,
                media_type=media_type,
                size=size,
                sha256=sha256,
                locator=AssetLocator(value=asset_id),
                metadata=metadata or {},
            )
            async with self._write_lock:
                blob = self._blob_path(sha256)
                if blob.exists() and await asyncio.to_thread(self._blob_matches, blob, sha256, size):
                    await asyncio.to_thread(Path(temporary_name).unlink, missing_ok=True)
                else:
                    os.replace(temporary_name, blob)
                    self._fsync_directory(self._blobs)
                await asyncio.to_thread(self._write_metadata, ref)
            return ref
        except BaseException:
            await asyncio.to_thread(Path(temporary_name).unlink, missing_ok=True)
            raise

    def open(self, asset_id: str) -> AsyncIterator[bytes]:
        return self._open(asset_id)

    async def _open(self, asset_id: str) -> AsyncIterator[bytes]:
        ref = await self.get(asset_id)
        if ref is None or ref.sha256 is None:
            raise FileNotFoundError(f"Unknown asset: {asset_id}")
        path = self._blob_path(ref.sha256)
        handle = await asyncio.to_thread(self._open_verified_blob, path, ref.sha256, ref.size)
        try:
            while chunk := await asyncio.to_thread(handle.read, self._read_chunk_size):
                yield chunk
        finally:
            await asyncio.to_thread(handle.close)

    async def get(self, asset_id: str) -> AssetRef | None:
        path = self._metadata_path(asset_id)
        try:
            payload = await asyncio.to_thread(self._read_metadata, path)
        except FileNotFoundError:
            return None
        ref = AssetRef.model_validate(_strict_json_object(payload))
        if ref.asset_id != asset_id or ref.locator.scheme != "asset" or ref.locator.value != asset_id:
            raise ValueError(f"Corrupt AssetStore metadata for {asset_id}")
        return ref

    async def resolve(self, asset_id: str, *, ttl_seconds: int = 300) -> str:
        if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int) or ttl_seconds < 1:
            raise ValueError("ttl_seconds must be a positive integer")
        del ttl_seconds  # Local file URLs do not expire; remote stores may sign them.
        ref = await self.get(asset_id)
        if ref is None or ref.sha256 is None:
            raise FileNotFoundError(f"Unknown asset: {asset_id}")
        path = self._blob_path(ref.sha256)
        handle = await asyncio.to_thread(self._open_verified_blob, path, ref.sha256, ref.size)
        await asyncio.to_thread(handle.close)
        return path.as_uri()

    def _blob_path(self, sha256: str) -> Path:
        return self._blobs / sha256

    def _metadata_path(self, asset_id: str) -> Path:
        safe_name = hashlib.sha256(asset_id.encode("utf-8")).hexdigest()
        return self._metadata / f"{safe_name}.json"

    def _write_metadata(self, ref: AssetRef) -> None:
        target = self._metadata_path(ref.asset_id)
        payload = (
            json.dumps(
                ref.model_dump(mode="json", by_alias=True),
                ensure_ascii=False,
                sort_keys=True,
                allow_nan=False,
            )
            + "\n"
        )
        if len(payload.encode("utf-8")) > self._max_metadata_bytes:
            raise ValueError(f"AssetStore metadata exceeds max_metadata_bytes={self._max_metadata_bytes}")
        descriptor, temporary_name = tempfile.mkstemp(prefix="metadata-", dir=self._metadata)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, target)
            self._fsync_directory(self._metadata)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise

    def _blob_matches(self, path: Path, expected_sha256: str, expected_size: int) -> bool:
        try:
            handle = self._open_verified_blob(path, expected_sha256, expected_size)
            handle.close()
            return True
        except OSError:
            return False
        except ValueError:
            return False

    def _open_verified_blob(
        self,
        path: Path,
        expected_sha256: str,
        expected_size: int | None,
    ):  # type: ignore[no-untyped-def]
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags)
        try:
            status = os.fstat(descriptor)
            if not stat.S_ISREG(status.st_mode):
                raise ValueError(f"AssetStore blob is not a regular file: {path}")
            if expected_size is not None and status.st_size != expected_size:
                raise ValueError(f"AssetStore blob size mismatch: {path}")
            if status.st_size > self._max_asset_bytes:
                raise ValueError(f"AssetStore blob exceeds max_asset_bytes={self._max_asset_bytes}")
            digest = hashlib.sha256()
            while chunk := os.read(descriptor, self._read_chunk_size):
                digest.update(chunk)
            if digest.hexdigest() != expected_sha256:
                raise ValueError(f"AssetStore blob digest mismatch: {path}")
            os.lseek(descriptor, 0, os.SEEK_SET)
            handle = os.fdopen(descriptor, "rb")
            descriptor = -1
            return handle
        finally:
            if descriptor >= 0:
                os.close(descriptor)

    def _read_metadata(self, path: Path) -> str:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags)
        try:
            status = os.fstat(descriptor)
            if not stat.S_ISREG(status.st_mode):
                raise ValueError(f"AssetStore metadata is not a regular file: {path}")
            if status.st_size > self._max_metadata_bytes:
                raise ValueError(f"AssetStore metadata exceeds max_metadata_bytes={self._max_metadata_bytes}")
            payload = bytearray()
            while chunk := os.read(descriptor, min(self._read_chunk_size, self._max_metadata_bytes + 1)):
                payload.extend(chunk)
                if len(payload) > self._max_metadata_bytes:
                    raise ValueError(f"AssetStore metadata exceeds max_metadata_bytes={self._max_metadata_bytes}")
            return bytes(payload).decode("utf-8")
        finally:
            os.close(descriptor)

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _strict_json_object(payload: str) -> dict[str, object]:
    def reject_constant(value: str) -> None:
        raise ValueError(f"non-finite JSON number is not allowed: {value}")

    def unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON object key: {key}")
            result[key] = value
        return result

    decoded = json.loads(
        payload,
        parse_constant=reject_constant,
        object_pairs_hook=unique_object,
    )
    if not isinstance(decoded, dict):
        raise ValueError("AssetStore metadata must be a JSON object")
    return decoded
