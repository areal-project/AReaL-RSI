"""Claude Code's native agent loop through the official Claude Agent SDK.

Each execution owns a client connection; subsequent executions resume the same
durable Claude session. Resolved skills use native plugins and the Skill tool.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import dataclasses
import hashlib
import json
import math
import shutil
import sys
import uuid
import weakref
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from enum import Enum
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Literal

from areal_agent_runtime.adapters._asset_io import (
    DEFAULT_MAX_RUNTIME_ASSET_BYTES,
    MAX_RUNTIME_ASSET_BYTES,
    read_asset_bytes,
)
from areal_agent_runtime.adapters._event_buffer import RuntimeEventBuffer, RuntimeEventBufferOverflow
from areal_agent_runtime.adapters._identity_index import session_identity_map
from areal_agent_runtime.adapters.claude_sdk.skills import ClaudeSkillPlugin, materialize_skills, resolved_system_prompt
from areal_agent_runtime.adapters.mcp.gateway import (
    APPLICATION_TOOL_MCP_PROTOCOL,
    APPLICATION_TOOL_MCP_SERVER_NAME,
    ApplicationMcpTool,
    ApplicationToolMcpEndpoint,
    ApplicationToolMcpGateway,
)
from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    ContentBlock,
    FileRefBlock,
    ImageRefBlock,
    JsonBlock,
    ReasoningBlock,
    TextBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.data import (
    DataCoverage,
    DetailCoverage,
    MessageCoverage,
    RawEventCoverage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ChildEventProjection,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionRequest,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolExecution,
    ToolResult,
    normalize_token_usage,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
    runtime_session_binding_digest,
)
from areal_agent_runtime.kernel.ids import new_id

_END = object()
_TERMINAL_ASK_USER_TOOLS = frozenset(
    {
        "mcp__harness__ask_user",
        "ask_user",
        "ask_user_question",
        "AskUserQuestion",
    }
)
ClaudeQuery = Callable[..., AsyncIterator[Any]]
ClaudeOptionsFactory = Callable[[RuntimeSessionSpec, str, ExecutionRequest], object]
_MAX_VENDOR_JSON_BYTES = 1024 * 1024
_MAX_VENDOR_JSON_DEPTH = 64


@dataclass(slots=True)
class _ClaudeSessionState:
    spec: RuntimeSessionSpec
    ref: RuntimeSessionRef
    vendor_session_id: str
    skill_plugin: ClaudeSkillPlugin | None = None
    has_history: bool = False
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    active: bool = False
    closed: bool = False
    channel: ExecutionChannel | None = None


@dataclass(slots=True)
class _ClaudeToolCallState:
    fingerprint: str
    future: asyncio.Future[ToolResult]


class _ClaudeExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        *,
        runtime_instance_id: str,
        request: ExecutionRequest,
        query_fn: ClaudeQuery,
        prompt: AsyncIterator[dict[str, Any]],
        options: object,
        execution_slots: asyncio.Semaphore,
        bridge: ApplicationToolMcpGateway | None = None,
        bridged_tools: tuple[ApplicationMcpTool, ...] = (),
        on_finish: Callable[[], None] | None = None,
        on_session_established: Callable[[], None] | None = None,
    ) -> None:
        self._runtime_instance_id = runtime_instance_id
        self._request = request
        self._query_fn = query_fn
        self._prompt = prompt
        self._options = options
        self._execution_slots = execution_slots
        self._queue = RuntimeEventBuffer(_END)
        self._sequence = 0
        self._ended = False
        self._terminal = False
        self._saw_root_message = False
        self._saw_root_public_text = False
        self._saw_root_thinking = False
        self._started_children: dict[str, str] = {}
        self._terminal_children: set[str] = set()
        self._bridge = bridge
        self._on_finish = on_finish
        self._on_session_established = on_session_established
        self._bridged_by_canonical = {tool.canonical_name: tool for tool in bridged_tools}
        self._bridged_runtime_names = {
            _claude_mcp_public_tool_name(tool.exposed_name) for tool in bridged_tools
        }
        self._bridged_vendor_call_ids: set[str] = set()
        self._observed_tool_names: dict[str, str] = {}
        self._pending_native_tools: dict[str, tuple[str, str | None]] = {}
        self._tool_calls: dict[str, _ClaudeToolCallState] = {}
        if bridge is not None:
            bridge.bind(request.session_id, self)
        self._task = asyncio.create_task(self._queue.run_producer(self._run), name=f"claude-sdk:{request.execution_id}")
        self._task.add_done_callback(self._finish_cancelled_before_start)
        self._task.add_done_callback(self._queue.producer_done)

    def _finish_cancelled_before_start(self, task: asyncio.Task[None]) -> None:
        # Cancelling a task before its first scheduling skips the coroutine's
        # finally block, but the Channel still owns its session/bridge binding.
        if not self._ended and task.cancelled():
            try:
                if self._sequence == 0:
                    self._emit(EventType.EXECUTION_STARTED, {"vendor": "claude"})
                self._emit(EventType.EXECUTION_FAILED, {"vendor": "claude", "reason": "cancelled"})
            except RuntimeEventBufferOverflow:
                pass
            finally:
                self._finish_channel()

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        while True:
            item = await self._queue.get()
            if item is _END:
                return
            if isinstance(item, RuntimeEvent):
                yield item

    def _emit(
        self,
        event_type: EventType,
        data: Any,
        *,
        agent_id: str | None = None,
        parent_agent_id: str | None = None,
        ignorable: bool = False,
    ) -> None:
        if self._ended:
            return
        effective_agent_id = agent_id or self._request.agent.agent_id
        event_data = data
        if effective_agent_id != self._request.agent.agent_id and isinstance(data, dict):
            event_data = {**data, "parentExecutionId": self._request.execution_id}
            group_id = self._request.metadata.get("parallelGroupId")
            if isinstance(group_id, str) and group_id:
                event_data["groupId"] = group_id
        event = RuntimeEvent(
            runtime_instance_id=self._runtime_instance_id,
            runtime_sequence=self._sequence,
            execution_id=self._request.execution_id,
            agent_id=effective_agent_id,
            parent_agent_id=(parent_agent_id if agent_id is not None else self._request.agent.parent_agent_id),
            type=event_type,
            data=event_data,
            ignorable=ignorable,
        )
        self._sequence += 1
        self._queue.put_nowait(event)

    def _child_agent(self, parent_tool_use_id: object) -> tuple[str, str | None]:
        if parent_tool_use_id is None:
            return self._request.agent.agent_id, self._request.agent.parent_agent_id
        parent_tool_use_id = _vendor_identity(parent_tool_use_id, "parent_tool_use_id")
        child_id = f"claude:{parent_tool_use_id}"
        if child_id not in self._started_children:
            self._start_child(
                child_id,
                parent_agent_id=self._request.agent.agent_id,
                data={
                    "runtimeAgentId": child_id,
                    "parentToolUseId": parent_tool_use_id,
                    "vendor": "claude",
                },
            )
        elif child_id in self._terminal_children:
            raise ValueError(f"Claude emitted a message for terminal child: {child_id}")
        return child_id, self._request.agent.agent_id

    def _start_child(
        self,
        child_id: str,
        *,
        parent_agent_id: str,
        data: dict[str, Any],
    ) -> None:
        if child_id in self._started_children:
            raise ValueError(f"Claude started child more than once: {child_id}")
        if child_id == self._request.agent.agent_id or child_id == parent_agent_id:
            raise ValueError("Claude child identity collides with its parent")
        self._started_children[child_id] = parent_agent_id
        self._emit(
            EventType.AGENT_STARTED,
            data,
            agent_id=child_id,
            parent_agent_id=parent_agent_id,
        )

    def _finish_child(self, child_id: str, event_type: EventType, data: dict[str, Any]) -> None:
        if child_id not in self._started_children or child_id in self._terminal_children:
            raise ValueError(f"Claude finished an unknown or terminal child: {child_id}")
        self._fail_pending_native_tools(
            "cancelled" if event_type == EventType.AGENT_CANCELLED else str(data.get("reason") or "child_ended"),
            agent_id=child_id,
        )
        self._emit(
            event_type,
            data,
            agent_id=child_id,
            parent_agent_id=self._started_children[child_id],
        )
        self._terminal_children.add(child_id)

    def _active_children(self) -> tuple[str, ...]:
        return tuple(child for child in self._started_children if child not in self._terminal_children)

    def _fail_pending_native_tools(self, reason: str, *, agent_id: str | None = None) -> None:
        for call_id, (owner, parent) in tuple(self._pending_native_tools.items()):
            if agent_id is not None and owner != agent_id:
                continue
            self._pending_native_tools.pop(call_id)
            self._emit(
                EventType.TOOL_FAILED,
                {
                    "callId": call_id,
                    "name": self._observed_tool_names[call_id],
                    "error": ErrorInfo(
                        code="CLAUDE_NATIVE_TOOL_CANCELLED" if reason == "cancelled" else "CLAUDE_NATIVE_TOOL_ABORTED",
                        category=ErrorCategory.CANCELLED if reason == "cancelled" else ErrorCategory.UNAVAILABLE,
                        message=f"No native tool result was observed before Claude ended: {reason}",
                        details={"synthetic": True, "reason": reason},
                    ).model_dump(mode="json", by_alias=True),
                },
                agent_id=owner,
                parent_agent_id=parent,
            )

    def _terminate_active_children(self, event_type: EventType, reason: str) -> None:
        for child_id in reversed(self._active_children()):
            self._finish_child(
                child_id,
                event_type,
                {"vendor": "claude", "reason": reason, "synthetic": True},
            )

    def _map_message(self, message: object) -> None:
        kind = type(message).__name__
        if kind == "ResultMessage" or (kind == "SystemMessage" and getattr(message, "subtype", None) == "init"):
            if self._on_session_established is not None:
                self._on_session_established()

        if kind == "StreamEvent":
            self._map_stream_event(message)
            return

        if kind == "AssistantMessage":
            agent_id, parent_id = self._child_agent(getattr(message, "parent_tool_use_id", None))
            terminal_interaction = self._terminal_interaction(getattr(message, "content", ()))
            if terminal_interaction is not None:
                self._fail_pending_native_tools("terminal_interaction")
                self._emit(
                    EventType.INTERACTION_REQUIRED,
                    terminal_interaction.model_dump(mode="json", by_alias=True),
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
                self._terminate_active_children(
                    EventType.AGENT_COMPLETED,
                    "terminal_interaction",
                )
                self._emit(
                    EventType.EXECUTION_COMPLETED,
                    {"vendor": "claude", "finishReason": "interaction"},
                )
                self._terminal = True
                return
            canonical: list[ContentBlock] = []
            for block in getattr(message, "content", ()):
                block_kind = type(block).__name__
                if block_kind == "TextBlock":
                    text = _vendor_text(getattr(block, "text", None), "TextBlock.text")
                    canonical.append(TextBlock(text=text))
                    if agent_id == self._request.agent.agent_id and text.strip():
                        self._saw_root_public_text = True
                elif block_kind == "ThinkingBlock":
                    if agent_id == self._request.agent.agent_id:
                        self._saw_root_thinking = True
                    self._emit(
                        EventType.REASONING_DELTA,
                        {
                            "text": _vendor_text(
                                getattr(block, "thinking", None),
                                "ThinkingBlock.thinking",
                            ),
                            "final": True,
                        },
                        agent_id=agent_id,
                        parent_agent_id=parent_id,
                    )
                elif block_kind in {"ToolUseBlock", "ServerToolUseBlock"}:
                    name = _vendor_identity(getattr(block, "name", None), "ToolUseBlock.name")
                    vendor_call_id = _vendor_identity(getattr(block, "id", None), "ToolUseBlock.id")
                    if name in self._bridged_runtime_names:
                        self._bridged_vendor_call_ids.add(vendor_call_id)
                        continue
                    arguments = _jsonable(getattr(block, "input", {}))
                    if not isinstance(arguments, dict):
                        raise ValueError("Claude ToolUseBlock.input must be a JSON object")
                    self._observed_tool_names[vendor_call_id] = name
                    self._pending_native_tools[vendor_call_id] = (agent_id, parent_id)
                    self._emit(
                        EventType.TOOL_REQUESTED,
                        {
                            "callId": vendor_call_id,
                            "name": name,
                            "arguments": arguments,
                            "execution": "runtime",
                        },
                        agent_id=agent_id,
                        parent_agent_id=parent_id,
                    )
                elif block_kind in {"ToolResultBlock", "ServerToolResultBlock"}:
                    vendor_call_id = _vendor_identity(
                        getattr(block, "tool_use_id", None),
                        "ToolResultBlock.tool_use_id",
                    )
                    if vendor_call_id in self._bridged_vendor_call_ids:
                        self._bridged_vendor_call_ids.discard(vendor_call_id)
                        continue
                    is_error = _tool_result_is_error(getattr(block, "is_error", None))
                    result = _jsonable(getattr(block, "content", None))
                    self._pending_native_tools.pop(vendor_call_id, None)
                    self._emit(
                        EventType.TOOL_FAILED if is_error else EventType.TOOL_COMPLETED,
                        {
                            "callId": vendor_call_id,
                            "name": self._observed_tool_names.get(vendor_call_id),
                            "result": result,
                        },
                        agent_id=agent_id,
                        parent_agent_id=parent_id,
                    )
            if canonical:
                if agent_id == self._request.agent.agent_id:
                    self._saw_root_message = True
                    event_type = EventType.MESSAGE_COMPLETED
                else:
                    event_type = EventType.AGENT_MESSAGE
                self._emit(
                    event_type,
                    {"content": [item.model_dump(mode="json", by_alias=True) for item in canonical]},
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
            usage = getattr(message, "usage", None)
            if usage is not None:
                self._emit_usage(
                    usage,
                    extras={"model": getattr(message, "model", None)},
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
            error = getattr(message, "error", None)
            if error is not None:
                self._emit(
                    EventType.WARNING_RAISED,
                    {"vendor": "claude", "error": _vendor_text(error, "AssistantMessage.error")},
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
            return

        if kind == "UserMessage":
            agent_id, parent_id = self._child_agent(getattr(message, "parent_tool_use_id", None))
            raw_content = getattr(message, "content", None)
            blocks = () if isinstance(raw_content, str) else (raw_content or ())
            for block in blocks:
                if type(block).__name__ != "ToolResultBlock":
                    continue
                vendor_call_id = _vendor_identity(
                    getattr(block, "tool_use_id", None),
                    "ToolResultBlock.tool_use_id",
                )
                if vendor_call_id in self._bridged_vendor_call_ids:
                    self._bridged_vendor_call_ids.discard(vendor_call_id)
                    continue
                is_error = _tool_result_is_error(getattr(block, "is_error", None))
                result = _jsonable(getattr(block, "content", None))
                self._pending_native_tools.pop(vendor_call_id, None)
                self._emit(
                    EventType.TOOL_FAILED if is_error else EventType.TOOL_COMPLETED,
                    {
                        "callId": vendor_call_id,
                        "name": self._observed_tool_names.get(vendor_call_id),
                        "result": result,
                    },
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
            return

        if kind in {"TaskStartedMessage", "TaskProgressMessage", "TaskNotificationMessage", "TaskUpdatedMessage"}:
            self._map_task_message(message, kind)
            return

        if kind == "ResultMessage":
            usage = getattr(message, "usage", None)
            if usage is not None:
                self._emit_usage(
                    usage,
                    extras={
                        "costUsd": getattr(message, "total_cost_usd", None),
                        "turns": getattr(message, "num_turns", None),
                    },
                )
            result_text = getattr(message, "result", None)
            if isinstance(result_text, str) and result_text and not self._saw_root_message:
                self._saw_root_message = True
                self._saw_root_public_text = bool(result_text.strip())
                self._emit(
                    EventType.MESSAGE_COMPLETED,
                    {"content": [TextBlock(text=result_text).model_dump(mode="json", by_alias=True)]},
                )
            failed = _vendor_bool(getattr(message, "is_error", False), "ResultMessage.is_error")
            missing_public_text = not failed and self._saw_root_thinking and not self._saw_root_public_text
            if missing_public_text:
                failed = True
            terminal_reason = getattr(message, "terminal_reason", None)
            if terminal_reason is not None:
                terminal_reason = _vendor_identity(terminal_reason, "ResultMessage.terminal_reason")
            if terminal_reason is not None and terminal_reason.startswith("aborted"):
                failed = True
            self._fail_pending_native_tools("runtime_failed" if failed else "result_message_without_tool_result")
            self._terminate_active_children(
                EventType.AGENT_FAILED if failed else EventType.AGENT_COMPLETED,
                "final_text_missing" if missing_public_text else (
                    terminal_reason or ("runtime_failed" if failed else "parent_completed")
                ),
            )
            self._emit(
                EventType.EXECUTION_FAILED if failed else EventType.EXECUTION_COMPLETED,
                {
                    "vendor": "claude",
                    "subtype": getattr(message, "subtype", None),
                    "stopReason": getattr(message, "stop_reason", None),
                    "terminalReason": terminal_reason,
                    "errors": _jsonable(getattr(message, "errors", None)),
                    **({
                        "reason": "final_text_missing",
                        "message": "Claude returned reasoning without a public final response",
                    } if missing_public_text else {}),
                },
            )
            self._terminal = True
            return

        if kind == "RateLimitEvent":
            info = getattr(message, "rate_limit_info", None)
            self._emit(EventType.WARNING_RAISED, {"vendor": "claude", "rateLimit": _jsonable(info)})
            return

        self._emit(
            EventType.RUNTIME_STATUS,
            {"vendor": "claude", "messageType": kind, "data": _jsonable(message)},
            ignorable=True,
        )

    @staticmethod
    def _terminal_interaction(content: object) -> InteractionRequest | None:
        if not isinstance(content, (list, tuple)):
            return None
        for block in content:
            if type(block).__name__ not in {"ToolUseBlock", "ServerToolUseBlock"}:
                continue
            name = _vendor_identity(getattr(block, "name", None), "interaction tool name")
            request = getattr(block, "input", None)
            interaction_id = _vendor_identity(getattr(block, "id", None), "interaction id")
            if name not in _TERMINAL_ASK_USER_TOOLS or not interaction_id or not isinstance(request, dict):
                continue
            items = request.get("items")
            if not isinstance(items, list) or not items:
                continue
            return InteractionRequest(
                interaction_id=interaction_id,
                kind="ask_user",
                request=request,
                terminal=True,
                commit_barrier=True,
            )
        return None

    def _map_stream_event(self, message: object) -> None:
        raw = getattr(message, "event", None)
        if not isinstance(raw, dict):
            return
        agent_id, parent_id = self._child_agent(getattr(message, "parent_tool_use_id", None))
        if raw.get("type") == "content_block_delta":
            delta = raw.get("delta")
            if isinstance(delta, dict) and delta.get("type") == "text_delta":
                text = _vendor_text(delta.get("text"), "text_delta.text")
                if agent_id == self._request.agent.agent_id and text.strip():
                    self._saw_root_public_text = True
                self._emit(
                    EventType.MESSAGE_DELTA,
                    {"delta": {"type": "text", "text": text}},
                    agent_id=agent_id,
                    parent_agent_id=parent_id,
                )
                return
            if isinstance(delta, dict) and delta.get("type") in {"thinking_delta", "signature_delta"}:
                text = delta.get("thinking") or delta.get("text") or ""
                if text:
                    if agent_id == self._request.agent.agent_id:
                        self._saw_root_thinking = True
                    self._emit(
                        EventType.REASONING_DELTA,
                        {"text": _vendor_text(text, "thinking_delta.text")},
                        agent_id=agent_id,
                        parent_agent_id=parent_id,
                    )
                return
        if raw.get("type") == "message_delta" and isinstance(raw.get("usage"), dict):
            self._emit_usage(
                raw["usage"],
                extras={"streamEventType": "message_delta"},
                agent_id=agent_id,
                parent_agent_id=parent_id,
            )

    def _emit_usage(
        self,
        usage: object,
        *,
        extras: dict[str, Any],
        agent_id: str | None = None,
        parent_agent_id: str | None = None,
    ) -> None:
        raw = _jsonable(usage)
        normalized = normalize_token_usage(raw, scope="execution")
        if normalized is not None:
            self._emit(
                EventType.USAGE_UPDATED,
                {"usage": normalized.model_dump(mode="json", by_alias=True)},
                agent_id=agent_id,
                parent_agent_id=parent_agent_id,
            )
        self._emit(
            EventType.RAW_EVENT_RECORDED,
            {
                "producer": "claude-agent-sdk",
                "vendorEventType": "usage",
                "runtimeInstanceId": self._runtime_instance_id,
                "runtimeSequence": self._sequence,
                "reason": "unsupported-event",
                "payload": {"usage": raw, **extras},
            },
            agent_id=agent_id,
            parent_agent_id=parent_agent_id,
            ignorable=True,
        )

    def _map_task_message(self, message: object, kind: str) -> None:
        task_id = _vendor_identity(getattr(message, "task_id", None), f"{kind}.task_id")
        child_id = f"claude-task:{task_id}"
        parent = self._request.agent.agent_id
        if kind == "TaskStartedMessage":
            self._start_child(
                child_id,
                parent_agent_id=parent,
                data={
                    "runtimeAgentId": child_id,
                    "description": _vendor_text(
                        getattr(message, "description", ""),
                        "TaskStartedMessage.description",
                    ),
                    "vendor": "claude",
                },
            )
            return
        if child_id not in self._started_children:
            self._start_child(
                child_id,
                parent_agent_id=parent,
                data={"runtimeAgentId": child_id, "vendor": "claude", "synthetic": True},
            )
        elif child_id in self._terminal_children:
            raise ValueError(f"Claude emitted {kind} for terminal child: {child_id}")
        if kind == "TaskProgressMessage":
            self._emit(
                EventType.RUNTIME_STATUS,
                {"vendor": "claude", "task": _jsonable(message)},
                agent_id=child_id,
                parent_agent_id=parent,
                ignorable=True,
            )
            return
        status = getattr(message, "status", None)
        if status is None and kind == "TaskUpdatedMessage":
            patch = getattr(message, "patch", None)
            status = patch.get("status") if isinstance(patch, dict) else None
        if status not in {"completed", "failed", "stopped", "killed"}:
            return
        event_type = {
            "completed": EventType.AGENT_COMPLETED,
            "failed": EventType.AGENT_FAILED,
            "stopped": EventType.AGENT_CANCELLED,
            "killed": EventType.AGENT_CANCELLED,
        }[status]
        self._finish_child(
            child_id,
            event_type,
            {"vendor": "claude", "status": status, "data": _jsonable(message)},
        )

    async def _run(self) -> None:
        try:
            self._emit(EventType.EXECUTION_STARTED, {"vendor": "claude"})
            async with self._execution_slots:
                messages = self._query_fn(prompt=self._prompt, options=self._options)
                try:
                    async for message in messages:
                        self._map_message(message)
                        if self._terminal:
                            break
                finally:
                    close_messages = getattr(messages, "aclose", None)
                    if callable(close_messages):
                        await close_messages()
            if not self._terminal:
                self._fail_pending_native_tools("result_message_missing")
                self._terminate_active_children(
                    EventType.AGENT_FAILED,
                    "result_message_missing",
                )
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"vendor": "claude", "reason": "result_message_missing"},
                )
        except asyncio.CancelledError:
            if not self._terminal and self._queue.error is None:
                self._fail_pending_native_tools("cancelled")
                self._terminate_active_children(EventType.AGENT_CANCELLED, "cancelled")
                self._emit(EventType.EXECUTION_FAILED, {"vendor": "claude", "reason": "cancelled"})
        except Exception as exc:
            if not self._terminal and self._queue.error is None:
                self._fail_pending_native_tools("runtime_error")
                self._terminate_active_children(EventType.AGENT_FAILED, "runtime_error")
                self._emit(
                    EventType.EXECUTION_FAILED,
                    {"vendor": "claude", "reason": "runtime_error", "message": str(exc) or type(exc).__name__},
                )
        finally:
            self._finish_channel()

    def _finish_channel(self) -> None:
        if self._ended:
            return
        for call_id, state in self._tool_calls.items():
            if not state.future.done():
                state.future.set_result(
                    ToolResult(
                        call_id=call_id,
                        error=ErrorInfo(
                            code="CLAUDE_TOOL_BRIDGE_CLOSED",
                            category=ErrorCategory.UNAVAILABLE,
                            message="Claude execution ended before the application tool returned",
                            retryable=True,
                        ),
                    )
                )
        if self._bridge is not None:
            self._bridge.unbind(self._request.session_id, self)
        if self._on_finish is not None:
            self._on_finish()
        self._ended = True
        self._queue.put_nowait(_END)

    async def send_tool_result(self, result: ToolResult) -> None:
        if not isinstance(result, ToolResult):
            raise TypeError("Claude send_tool_result requires a ToolResult")
        state = self._tool_calls.get(result.call_id)
        if state is None:
            raise LookupError(f"Unknown Claude application tool call: {result.call_id}")
        if state.future.done():
            completed = state.future.result()
            if completed == result or (
                completed.error is not None
                and completed.error.code == "CLAUDE_TOOL_BRIDGE_CLOSED"
            ):
                return
            raise RuntimeError(f"Claude application tool call already completed: {result.call_id}")
        state.future.set_result(result)

    async def invoke_application_tool(
        self,
        *,
        call_id: str,
        name: str,
        arguments: dict[str, object],
        agent_id: str | None,
    ) -> ToolResult:
        try:
            call_id = _vendor_identity(call_id, "application tool callId")
            name = _vendor_identity(name, "application tool name")
            if agent_id is not None:
                agent_id = _vendor_identity(agent_id, "application tool agentId")
            fingerprint = _application_tool_fingerprint(name, arguments, agent_id)
        except (TypeError, ValueError) as exc:
            return ToolResult(
                call_id=(
                    call_id
                    if isinstance(call_id, str) and call_id and call_id == call_id.strip()
                    else "invalid-claude-call"
                ),
                error=ErrorInfo(
                    code="CLAUDE_TOOL_CALL_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=str(exc) or type(exc).__name__,
                ),
            )
        if self._ended:
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="CLAUDE_TOOL_BRIDGE_CLOSED",
                    category=ErrorCategory.UNAVAILABLE,
                    message="Claude execution is no longer accepting Application tool calls",
                    retryable=True,
                ),
            )
        tool = self._bridged_by_canonical.get(name)
        if tool is None:
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="CLAUDE_TOOL_NOT_BRIDGED",
                    category=ErrorCategory.PERMISSION,
                    message=f"Claude requested a tool outside the active Application catalog: {name}",
                ),
            )
        effective_agent_id = agent_id or self._request.agent.agent_id
        if effective_agent_id != self._request.agent.agent_id and (
            effective_agent_id not in self._started_children
            or effective_agent_id in self._terminal_children
        ):
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="CLAUDE_TOOL_AGENT_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=(
                        "Claude attributed an Application tool call to an inactive agent: "
                        f"{effective_agent_id}"
                    ),
                ),
            )
        existing = self._tool_calls.get(call_id)
        if existing is not None:
            if existing.fingerprint != fingerprint:
                return ToolResult(
                    call_id=call_id,
                    error=ErrorInfo(
                        code="CLAUDE_TOOL_CALL_CONFLICT",
                        category=ErrorCategory.PROTOCOL,
                        message=f"Claude reused application tool call id with different input: {call_id}",
                    ),
                )
            return await asyncio.shield(existing.future)
        future: asyncio.Future[ToolResult] = asyncio.get_running_loop().create_future()
        self._tool_calls[call_id] = _ClaudeToolCallState(
            fingerprint=fingerprint,
            future=future,
        )
        self._emit(
            EventType.TOOL_REQUESTED,
            {
                "callId": call_id,
                "name": name,
                "arguments": arguments,
                "execution": tool.execution.value,
                "context": {
                    "runtimeToolName": _claude_mcp_public_tool_name(tool.exposed_name),
                    "vendor": "claude",
                },
            },
            agent_id=effective_agent_id,
            parent_agent_id=(
                self._request.agent.parent_agent_id
                if effective_agent_id == self._request.agent.agent_id
                else self._started_children[effective_agent_id]
            ),
        )
        return await asyncio.shield(future)

    async def respond(self, response: InteractionResponse) -> None:
        raise NotImplementedError("Claude query binding does not expose interactive approval responses")

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        raise NotImplementedError("Claude query binding is unidirectional")

    async def cancel(self, reason: CancelReason) -> None:
        if not self._task.done():
            self._task.cancel()

    async def close(self) -> None:
        if not self._task.done():
            self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        self._tool_calls.clear()


class ClaudeAgentSDKRuntimeAdapter:
    def __init__(
        self,
        *,
        asset_store: AssetStorePort | None = None,
        base_options: object | None = None,
        query_fn: ClaudeQuery | None = None,
        options_factory: ClaudeOptionsFactory | None = None,
        application_tool_bridge: bool = False,
        max_concurrency: int = 8,
        max_input_asset_bytes: int = DEFAULT_MAX_RUNTIME_ASSET_BYTES,
        tool_bridge_call_timeout_seconds: float = 120.0,
        tool_bridge_max_concurrency: int = 16,
        tool_policy_mode: Literal["runtime-owned", "portable"] = "runtime-owned",
    ) -> None:
        if not isinstance(application_tool_bridge, bool):
            raise ValueError("application_tool_bridge must be a boolean")
        if tool_policy_mode not in {"runtime-owned", "portable"}:
            raise ValueError("tool_policy_mode must be 'runtime-owned' or 'portable'")
        self._tool_policy_mode = tool_policy_mode
        if isinstance(max_concurrency, bool) or not isinstance(max_concurrency, int) or max_concurrency < 1:
            raise ValueError("max_concurrency must be a positive integer")
        if (
            isinstance(max_input_asset_bytes, bool)
            or not isinstance(max_input_asset_bytes, int)
            or max_input_asset_bytes < 1
            or max_input_asset_bytes > MAX_RUNTIME_ASSET_BYTES
        ):
            raise ValueError(
                f"max_input_asset_bytes must be between one and {MAX_RUNTIME_ASSET_BYTES}"
            )
        if (
            isinstance(tool_bridge_call_timeout_seconds, bool)
            or not isinstance(tool_bridge_call_timeout_seconds, (int, float))
            or not math.isfinite(tool_bridge_call_timeout_seconds)
            or tool_bridge_call_timeout_seconds <= 0
        ):
            raise ValueError("tool_bridge_call_timeout_seconds must be a finite positive number")
        if (
            isinstance(tool_bridge_max_concurrency, bool)
            or not isinstance(tool_bridge_max_concurrency, int)
            or tool_bridge_max_concurrency < 1
        ):
            raise ValueError("tool_bridge_max_concurrency must be a positive integer")
        self._instance_id = new_id("runtime")
        self._asset_store = asset_store
        self._base_options = base_options
        self._query_fn = query_fn
        self._options_factory = options_factory
        self._max_input_asset_bytes = max_input_asset_bytes
        self._sessions: dict[str, _ClaudeSessionState] = {}
        self._closed_sessions = session_identity_map()
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._execution_slots = asyncio.Semaphore(max_concurrency)
        self._max_concurrency = max_concurrency
        self._close_lock = asyncio.Lock()
        self._closing = False
        self._closed = False
        self._mcp_tool_gateway = (
            ApplicationToolMcpGateway(
                asset_store=asset_store,
                call_timeout_seconds=tool_bridge_call_timeout_seconds,
                max_concurrency_per_session=tool_bridge_max_concurrency,
            )
            if application_tool_bridge
            else None
        )

    async def describe(self) -> RuntimeDescriptor:
        try:
            runtime_version = version("claude-agent-sdk")
        except PackageNotFoundError:
            runtime_version = "not-installed"
        return RuntimeDescriptor(
            name="claude-agent-sdk",
            adapter_version="1.1.0",
            runtime_version=runtime_version,
            capabilities=RuntimeCapabilities(
                input_modalities=(
                    (Modality.TEXT, Modality.IMAGE) if self._asset_store is not None else (Modality.TEXT,)
                ),
                output_modalities=(Modality.TEXT,),
                tool_calling=True,
                application_tool_bridge=self._mcp_tool_gateway is not None,
                cancel=True,
                steer=False,
                resume=True,
                interaction=True,
                live_interaction=False,
                native_multi_agent=True,
                child_event_projection=ChildEventProjection.FULL,
                native_graph_execution=False,
                data_coverage=DataCoverage(
                    messages=MessageCoverage.FINAL,
                    model_calls=DetailCoverage.NONE,
                    tool_calls=DetailCoverage.FULL,
                    usage=UsageCoverage.NORMALIZED,
                    child_agents=DetailCoverage.FULL,
                    raw_events=RawEventCoverage.FULL,
                ),
                extensions={
                    "com.anthropic.claude-agent-sdk/capabilities/v1": {
                        "binding": "ClaudeSDKClient",
                        "interactionModes": ["terminal"],
                        "sdkPlugins": True,
                        "runtimeOwnedTools": True,
                        "toolPolicyMode": self._tool_policy_mode,
                        "nativeSkills": "claude-code-plugin",
                        "maxConcurrency": self._max_concurrency,
                        "maxInputAssetBytes": self._max_input_asset_bytes,
                        "applicationToolBridgeTransport": (
                            APPLICATION_TOOL_MCP_PROTOCOL
                            if self._mcp_tool_gateway is not None
                            else "unavailable"
                        ),
                    },
                },
            ),
        )

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("Claude runtime is closing")
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Claude runtime is closing")
            existing = self._sessions.get(spec.session_id)
            if existing is not None:
                if existing.closed:
                    raise RuntimeError(f"Claude session is closing: {spec.session_id}")
                require_same_runtime_session_spec(existing.spec, spec)
                return existing.ref
            vendor_session_id = str(
                uuid.uuid5(
                    uuid.NAMESPACE_URL,
                    f"areal_agent_runtime:{runtime_session_binding_digest(spec)}",
                )
            )
            ref = RuntimeSessionRef(
                session_id=spec.session_id,
                runtime_session_id=new_id("claude_session"),
            )
            self._sessions[spec.session_id] = _ClaudeSessionState(
                spec=spec,
                ref=ref,
                vendor_session_id=vendor_session_id,
                skill_plugin=materialize_skills(
                    spec.agent_environment,
                    portable_native_tools=(
                        frozenset(entry.spec.name for entry in spec.agent_environment.tool_catalog
                                  if entry.spec.execution == ToolExecution.RUNTIME)
                        if self._tool_policy_mode == "portable" else None
                    ),
                ),
                has_history=spec.resume,
            )
            return ref

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Claude runtime is closing")
        outer = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with outer:
            try:
                session = self._sessions[request.session_id]
            except KeyError as exc:
                raise LookupError(
                    f"Claude session is not open: {request.session_id}"
                ) from exc
            async with session.lock:
                if self._closing or session.closed or self._sessions.get(request.session_id) is not session:
                    raise LookupError(f"Claude session is not open: {request.session_id}")
                require_session_environment(session.spec, request)
                if session.active:
                    raise RuntimeError(
                        f"Claude session already has an active execution: {request.session_id}"
                    )
                if session.skill_plugin is not None:
                    await asyncio.to_thread(session.skill_plugin.verify)
                query_fn = self._query_fn or _official_query()
                options = (
                    self._options_factory(session.spec, session.vendor_session_id, request)
                    if self._options_factory is not None
                    else _claude_options(self._base_options, session, request, self._tool_policy_mode)
                )
                endpoint: ApplicationToolMcpEndpoint | None = None
                try:
                    if self._mcp_tool_gateway is not None:
                        endpoint = await self._mcp_tool_gateway.open_session(
                            request.session_id,
                            request.tools,
                        )
                        options = _with_application_mcp(options, endpoint)
                    if self._tool_policy_mode == "portable":
                        options = _portable_tools(options, request, endpoint)
                    prompt = await _request_to_claude(
                        request,
                        session.vendor_session_id,
                        self._asset_store,
                        max_input_asset_bytes=self._max_input_asset_bytes,
                    )
                    session.active = True

                    def finish() -> None:
                        session.active = False
                        session.channel = None

                    channel = _ClaudeExecutionChannel(
                        runtime_instance_id=self._instance_id,
                        request=request,
                        query_fn=query_fn,
                        prompt=prompt,
                        options=options,
                        execution_slots=self._execution_slots,
                        bridge=self._mcp_tool_gateway,
                        bridged_tools=endpoint.tools if endpoint is not None else (),
                        on_finish=finish,
                        on_session_established=lambda: setattr(session, "has_history", True),
                    )
                    session.channel = channel
                    return channel
                except BaseException as exc:
                    session.active = False
                    session.channel = None
                    if endpoint is not None and self._mcp_tool_gateway is not None:
                        try:
                            await self._mcp_tool_gateway.close_session(request.session_id)
                        except BaseException as cleanup_exc:
                            exc.add_note(f"Claude MCP cleanup also failed: {cleanup_exc!r}")
                    raise

    async def close_session(self, session: RuntimeSessionRef) -> None:
        outer = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with outer:
            state = self._sessions.get(session.session_id)
            if state is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("Claude session reference is not owned by this adapter")
            if state.ref != session:
                raise ValueError("Claude session reference does not match the open session")
            async with state.lock:
                self._closed_sessions[session.session_id] = session
                state.closed = True
                errors: list[BaseException] = []
                if state.channel is not None:
                    try:
                        await state.channel.close()
                    except BaseException as exc:
                        errors.append(exc)
                if self._mcp_tool_gateway is not None:
                    try:
                        await self._mcp_tool_gateway.close_session(session.session_id)
                    except BaseException as exc:
                        errors.append(exc)
                if not errors and self._sessions.get(session.session_id) is state:
                    if state.skill_plugin is not None:
                        state.skill_plugin.close()
                    self._sessions.pop(session.session_id, None)
                if errors:
                    raise BaseExceptionGroup("Claude session cleanup failed", errors)

    async def health(self) -> HealthStatus:
        try:
            installed = version("claude-agent-sdk")
        except PackageNotFoundError:
            return HealthStatus(
                status="unhealthy",
                details={"reason": "optional_dependency_missing", "package": "claude-agent-sdk"},
            )
        return HealthStatus(status="healthy", details={"sdkVersion": installed})

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closing = True
            errors: list[BaseException] = []
            for state in tuple(self._sessions.values()):
                try:
                    await self.close_session(state.ref)
                except BaseException as exc:
                    errors.append(exc)
            if self._mcp_tool_gateway is not None:
                try:
                    await self._mcp_tool_gateway.close()
                except BaseException as exc:
                    errors.append(exc)
            if errors:
                raise BaseExceptionGroup("Claude runtime cleanup failed", errors)
            self._closed_sessions.close()
            self._closed = True


def _official_query() -> ClaudeQuery:
    try:
        from claude_agent_sdk import ClaudeSDKClient
    except ImportError as exc:  # pragma: no cover - exercised without the optional extra
        raise RuntimeError("Install areal-agent-runtime[claude] to use the Claude adapter") from exc
    async def query(*, prompt: Any, options: Any) -> AsyncIterator[Any]:
        # Own the client's lifetime explicitly. Closing the public query()
        # outer generator does not close its nested iterator in SDK 0.2.149.
        async with ClaudeSDKClient(options=options) as client:
            await client.query(prompt)
            messages = client.receive_response()
            try:
                async for message in messages:
                    yield message
            finally:
                close_messages = getattr(messages, "aclose", None)
                if close_messages is not None:
                    await close_messages()
    return query


def _claude_options(
    base_options: object | None,
    session: _ClaudeSessionState,
    request: ExecutionRequest,
    tool_policy_mode: str = "runtime-owned",
) -> object:
    try:
        from claude_agent_sdk import ClaudeAgentOptions
    except ImportError as exc:  # pragma: no cover - exercised without the optional extra
        raise RuntimeError("Install areal-agent-runtime[claude] to use the Claude adapter") from exc

    base = base_options if isinstance(base_options, ClaudeAgentOptions) else ClaudeAgentOptions()
    system = resolved_system_prompt(request.agent_environment)
    system_prompt: Any = (
        base.system_prompt if base.system_prompt is not None else {"type": "preset", "preset": "claude_code"}
    )
    if system:
        if isinstance(system_prompt, str):
            system_prompt = f"{system_prompt}\n\n{system}"
        elif isinstance(system_prompt, dict) and system_prompt.get("type") == "preset":
            system_prompt = dict(system_prompt)
            previous = str(system_prompt.get("append") or "")
            system_prompt["append"] = f"{previous}\n\n{system}".strip()
        else:
            system_prompt = system
    updates: dict[str, Any] = {
        "cwd": session.spec.workspace.mount_hint or base.cwd,
        "model": session.spec.model or base.model,
        "system_prompt": system_prompt,
        "include_partial_messages": True,
        "forward_subagent_text": True,
        "continue_conversation": False,
        "fork_session": False,
        "cli_path": base.cli_path or shutil.which("claude.exe" if sys.platform == "win32" else "claude"),
    }
    if tool_policy_mode == "portable":
        if base.plugins or base.mcp_servers:
            raise ValueError("Claude portable mode requires plugins and MCP sources through the resolved environment")
        updates.update(setting_sources=[], strict_mcp_config=True, skills=[])
    if session.skill_plugin is not None:
        updates["plugins"] = [*base.plugins, {"type": "local", "path": session.skill_plugin.path}]
        if tool_policy_mode == "portable":
            updates["skills"] = list(session.skill_plugin.names)
        elif base.skills is None or base.skills == "all":
            updates["skills"] = "all"
            updates["setting_sources"] = (
                list(base.setting_sources) if base.setting_sources is not None else ["user", "project", "local"]
            )
        else:
            updates["skills"] = list(dict.fromkeys([*base.skills, *session.skill_plugin.names]))
    if request.policy.max_turns is not None:
        updates["max_turns"] = request.policy.max_turns
    if session.has_history:
        updates["resume"] = session.vendor_session_id
        updates["session_id"] = None
    else:
        updates["session_id"] = session.vendor_session_id
        updates["resume"] = None
    return dataclasses.replace(base, **updates)


def _portable_tools(options: object, request: ExecutionRequest, endpoint: ApplicationToolMcpEndpoint | None) -> object:
    from claude_agent_sdk import ClaudeAgentOptions, HookMatcher

    if not isinstance(options, ClaudeAgentOptions):
        raise TypeError("Claude portable mode requires official ClaudeAgentOptions")
    native = {tool.name for tool in request.tools if tool.execution == ToolExecution.RUNTIME}
    if request.agent_environment.skills and "Skill" not in native:
        raise ValueError("Claude portable skills require an authorized runtime tool named 'Skill'")
    bridged = {_claude_mcp_public_tool_name(tool.exposed_name) for tool in endpoint.tools} if endpoint else set()
    allowed = frozenset(native | bridged)

    async def guard(data: Any, _tool_use_id: Any, _context: Any) -> Any:
        if data.get("tool_name") in allowed:
            return {}
        return {"hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": "ARealAgentRuntime did not authorize this tool for the session",
        }}

    hooks = dict(options.hooks or {})
    hooks["PreToolUse"] = [*(hooks.get("PreToolUse") or []), HookMatcher(hooks=[guard])]
    return dataclasses.replace(
        options,
        tools=sorted(native),
        allowed_tools=sorted(allowed),
        hooks=hooks,
    )


def _with_application_mcp(
    options: object,
    endpoint: ApplicationToolMcpEndpoint,
) -> object:
    """Inject one authenticated Session-scoped MCP server into SDK options."""

    server = {
        "type": "http",
        "url": endpoint.url,
        "headers": {"Authorization": f"Bearer {endpoint.bearer_token}"},
    }
    allowed = [_claude_mcp_public_tool_name(tool.exposed_name) for tool in endpoint.tools]
    if isinstance(options, dict):
        current_servers = options.get("mcp_servers", {})
        if not isinstance(current_servers, dict):
            raise ValueError(
                "Claude applicationToolBridge cannot merge a path-based mcp_servers option"
            )
        if endpoint.server_name in current_servers:
            raise ValueError(
                f"Claude MCP server name is reserved by ARealAgentRuntime: {endpoint.server_name}"
            )
        current_allowed = options.get("allowed_tools", [])
        if not isinstance(current_allowed, list) or not all(
            isinstance(item, str) for item in current_allowed
        ):
            raise ValueError("Claude allowed_tools must be a string list")
        return {
            **options,
            "mcp_servers": {**current_servers, endpoint.server_name: server},
            "allowed_tools": list(dict.fromkeys((*current_allowed, *allowed))),
        }

    if not dataclasses.is_dataclass(options) or isinstance(options, type):
        raise TypeError("Claude applicationToolBridge requires ClaudeAgentOptions-compatible options")
    current_servers = getattr(options, "mcp_servers", {})
    if not isinstance(current_servers, dict):
        raise ValueError(
            "Claude applicationToolBridge cannot merge a path-based mcp_servers option"
        )
    if endpoint.server_name in current_servers:
        raise ValueError(f"Claude MCP server name is reserved by ARealAgentRuntime: {endpoint.server_name}")
    current_allowed = getattr(options, "allowed_tools", [])
    if not isinstance(current_allowed, list) or not all(
        isinstance(item, str) for item in current_allowed
    ):
        raise ValueError("Claude allowed_tools must be a string list")
    return dataclasses.replace(
        options,
        mcp_servers={**current_servers, endpoint.server_name: server},
        allowed_tools=list(dict.fromkeys((*current_allowed, *allowed))),
    )


def _claude_mcp_public_tool_name(exposed_name: str) -> str:
    return f"mcp__{APPLICATION_TOOL_MCP_SERVER_NAME}__{exposed_name}"


async def _request_to_claude(
    request: ExecutionRequest,
    vendor_session_id: str,
    asset_store: AssetStorePort | None,
    *,
    max_input_asset_bytes: int,
) -> AsyncIterator[dict[str, Any]]:
    content: list[dict[str, Any]] = []
    total_asset_bytes = 0
    for block in request.input:
        if isinstance(block, TextBlock):
            content.append({"type": "text", "text": block.text})
        elif isinstance(block, ReasoningBlock):
            content.append({"type": "text", "text": block.text})
        elif isinstance(block, JsonBlock):
            content.append({"type": "text", "text": json.dumps(block.value, ensure_ascii=False)})
        elif isinstance(block, ImageRefBlock):
            if asset_store is None:
                raise ValueError("Claude image input requires an AssetStorePort")
            remaining = max_input_asset_bytes - total_asset_bytes
            if remaining < 1:
                raise ValueError(
                    f"Assets exceed the configured {max_input_asset_bytes}-byte Runtime input limit"
                )
            payload = await read_asset_bytes(
                asset_store,
                block.asset_id,
                expected_media_type=block.media_type,
                max_bytes=remaining,
                aggregate_max_bytes=max_input_asset_bytes,
            )
            total_asset_bytes += len(payload)
            content.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": block.media_type,
                        "data": base64.b64encode(payload).decode("ascii"),
                    },
                }
            )
        elif isinstance(block, (AudioRefBlock, VideoRefBlock, FileRefBlock)):
            raise ValueError(f"Claude adapter does not advertise support for {block.type}")
    async def prompt() -> AsyncIterator[dict[str, Any]]:
        yield {
            "type": "user",
            "message": {"role": "user", "content": content},
            "parent_tool_use_id": None,
            "session_id": vendor_session_id,
            "origin": {"kind": "human"},
        }

    return prompt()


def _plain_text(blocks: tuple[ContentBlock, ...]) -> str:
    parts: list[str] = []
    for block in blocks:
        if isinstance(block, (TextBlock, ReasoningBlock)):
            parts.append(block.text)
        elif isinstance(block, JsonBlock):
            parts.append(json.dumps(block.value, ensure_ascii=False))
    return "\n".join(part for part in parts if part)


def _vendor_identity(value: object, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or not value
        or value != value.strip()
        or "\x00" in value
    ):
        raise ValueError(f"Claude {field_name} must be a non-blank, trimmed string")
    return value


def _vendor_text(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"Claude {field_name} must be text")
    return value


def _vendor_bool(value: object, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"Claude {field_name} must be a boolean")
    return value


def _tool_result_is_error(value: object) -> bool:
    # Official SDK ToolResultBlock.is_error is optional; omission is success.
    return False if value is None else _vendor_bool(value, "ToolResultBlock.is_error")


def _application_tool_fingerprint(
    name: str,
    arguments: dict[str, object],
    agent_id: str | None,
) -> str:
    normalized_arguments = _jsonable(arguments)
    if not isinstance(normalized_arguments, dict):
        raise TypeError("Claude Application tool arguments must be a JSON object")
    encoded = json.dumps(
        {"name": name, "arguments": normalized_arguments, "agentId": agent_id},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _jsonable(value: object) -> Any:
    normalized = _jsonable_inner(value, depth=0, seen=set())
    encoded = json.dumps(
        normalized,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    if len(encoded) > _MAX_VENDOR_JSON_BYTES:
        raise ValueError("Claude SDK value exceeds the canonical event size limit")
    return normalized


def _jsonable_inner(value: object, *, depth: int, seen: set[int]) -> Any:
    if depth > _MAX_VENDOR_JSON_DEPTH:
        raise ValueError("Claude SDK value exceeds the canonical event depth limit")
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("Claude SDK value contains a non-finite number")
        return value
    if isinstance(value, Enum):
        return _jsonable_inner(value.value, depth=depth + 1, seen=seen)

    identity = id(value)
    if identity in seen:
        raise ValueError("Claude SDK value contains a reference cycle")
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        seen.add(identity)
        try:
            return {
                item.name: _jsonable_inner(
                    getattr(value, item.name),
                    depth=depth + 1,
                    seen=seen,
                )
                for item in dataclasses.fields(value)
            }
        finally:
            seen.remove(identity)
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("Claude SDK JSON objects must have string keys")
        seen.add(identity)
        try:
            return {
                key: _jsonable_inner(item, depth=depth + 1, seen=seen)
                for key, item in value.items()
            }
        finally:
            seen.remove(identity)
    if isinstance(value, (list, tuple)):
        seen.add(identity)
        try:
            return [
                _jsonable_inner(item, depth=depth + 1, seen=seen)
                for item in value
            ]
        finally:
            seen.remove(identity)
    if isinstance(value, (set, frozenset)):
        seen.add(identity)
        try:
            items = [
                _jsonable_inner(item, depth=depth + 1, seen=seen)
                for item in value
            ]
        finally:
            seen.remove(identity)
        return sorted(
            items,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ),
        )
    raise TypeError(f"Claude SDK value is not JSON-compatible: {type(value).__name__}")
