"""AgentRuntimePort client using the ARealAgentRuntime Runtime Wire Protocol."""

from __future__ import annotations

import asyncio
import contextlib
import ssl
from collections.abc import AsyncIterator
from typing import NoReturn

from areal_agent_runtime.adapters.remote.assets import RuntimeWireAssetBridge
from areal_agent_runtime.adapters.remote.workspaces import (
    ClientWorkspaceState,
    RuntimeWireWorkspaceClient,
)
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionResponse,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolResult,
    require_same_runtime_session_spec,
    require_session_environment,
)
from areal_agent_runtime.contracts.wire import (
    DATA_AWARE_RUNTIME_CLIENT_NAME,
    LEGACY_RUNTIME_CLIENT_NAME,
    ExecutionAccepted,
    ExecutionCancelParams,
    ExecutionInteractionResponseParams,
    ExecutionStartParams,
    ExecutionSteerParams,
    ExecutionToolResultParams,
    RuntimeAuthenticateParams,
    RuntimeAuthenticateResult,
    RuntimeEventNotification,
    RuntimeNegotiateParams,
    RuntimeNegotiateResult,
    SessionCloseParams,
    SessionCloseResult,
    SessionOpenParams,
    SessionOpenResult,
)
from areal_agent_runtime.transports.jsonrpc import JsonRpcPeer, JsonRpcProtocolError

_END = object()


class RemoteExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        peer: JsonRpcPeer,
        request: ExecutionRequest,
        asset_bridge: RuntimeWireAssetBridge | None = None,
        workspace_bridge: RuntimeWireWorkspaceClient | None = None,
        workspace_state: ClientWorkspaceState | None = None,
    ) -> None:
        self._peer = peer
        self._request = request
        self._asset_bridge = asset_bridge
        self._workspace_bridge = workspace_bridge
        self._workspace_state = workspace_state
        self.execution_id = request.execution_id
        self._queue: asyncio.Queue[RuntimeEvent | object] = asyncio.Queue(maxsize=1024)
        self._closed = False
        self._terminal = False
        self._last_sequence = -1
        self._runtime_instance_id: str | None = None
        self._execution_started = False

    async def push(self, event: RuntimeEvent) -> None:
        if self._terminal:
            raise JsonRpcProtocolError(-32046, "Runtime emitted an event after its terminal event")
        if event.execution_id != self.execution_id:
            raise JsonRpcProtocolError(
                -32046,
                f"Runtime emitted {event.execution_id} for execution {self.execution_id}",
            )
        if self._runtime_instance_id is None:
            self._runtime_instance_id = event.runtime_instance_id
        elif event.runtime_instance_id != self._runtime_instance_id:
            raise JsonRpcProtocolError(
                -32046,
                "Runtime instance changed within an active execution: "
                f"{self._runtime_instance_id} -> {event.runtime_instance_id}",
            )
        expected_sequence = self._last_sequence + 1
        if event.runtime_sequence != expected_sequence:
            raise JsonRpcProtocolError(
                -32046,
                f"Runtime sequence must be contiguous from zero; expected "
                f"{expected_sequence}, received {event.runtime_sequence}",
            )
        if event.runtime_sequence == 0 and event.type != EventType.EXECUTION_STARTED:
            raise JsonRpcProtocolError(
                -32046,
                "Runtime sequence zero must be execution.started",
            )
        if event.type == EventType.EXECUTION_STARTED:
            if self._execution_started:
                raise JsonRpcProtocolError(-32046, "Runtime emitted execution.started more than once")
            self._execution_started = True
        self._last_sequence = event.runtime_sequence
        await self._queue.put(event)
        if event.type in {EventType.EXECUTION_COMPLETED, EventType.EXECUTION_FAILED}:
            self._terminal = True
            await self._queue.put(_END)

    async def fail_disconnected(self) -> None:
        if self._terminal or self._closed:
            return
        await self._fail("runtime_wire_disconnected")

    async def fail_protocol(self, detail: str) -> None:
        if self._terminal or self._closed:
            return
        await self._fail("runtime_wire_protocol_failure", detail=detail)

    async def _fail(self, reason: str, *, detail: str | None = None) -> None:
        self._make_room_for_terminal(include_synthetic_start=not self._execution_started)
        runtime_instance_id = self._runtime_instance_id or "runtime-wire"
        if not self._execution_started:
            await self.push(
                RuntimeEvent(
                    runtime_instance_id=runtime_instance_id,
                    runtime_sequence=0,
                    execution_id=self._request.execution_id,
                    agent_id=self._request.agent.agent_id,
                    parent_agent_id=self._request.agent.parent_agent_id,
                    type=EventType.EXECUTION_STARTED,
                    data={"synthetic": True, "source": "runtime-wire"},
                )
            )
        data = {"reason": reason}
        if detail is not None:
            data["detail"] = detail
        await self.push(
            RuntimeEvent(
                runtime_instance_id=runtime_instance_id,
                runtime_sequence=self._last_sequence + 1,
                execution_id=self._request.execution_id,
                agent_id=self._request.agent.agent_id,
                parent_agent_id=self._request.agent.parent_agent_id,
                type=EventType.EXECUTION_FAILED,
                data=data,
            )
        )

    def _make_room_for_terminal(self, *, include_synthetic_start: bool) -> None:
        # A disconnected peer must not make adapter.close() wait forever when
        # an abandoned consumer left the bounded event queue full.
        required_slots = 3 if include_synthetic_start else 2
        while self._queue.qsize() > self._queue.maxsize - required_slots:
            with contextlib.suppress(asyncio.QueueEmpty):
                self._queue.get_nowait()

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        while True:
            item = await self._queue.get()
            if item is _END:
                return
            if isinstance(item, RuntimeEvent):
                yield item

    async def send_tool_result(self, result: ToolResult) -> None:
        snapshot = None
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            self._asset_bridge.allow_content(result.content)
            self._asset_bridge.allow_json(result.value)
        if self._workspace_state is not None:
            if self._workspace_bridge is None or self._asset_bridge is None or not self._asset_bridge.enabled:
                raise JsonRpcProtocolError(
                    -32041,
                    "Runtime Wire workspace synchronization is unavailable",
                )
            snapshot = await self._workspace_bridge.export_update(
                self._workspace_state,
                workspace_id=self._request.workspace.workspace_id,
            )
            self._asset_bridge.allow_asset(snapshot.asset_id)
        params = ExecutionToolResultParams(
            execution_id=self.execution_id,
            result=result,
            workspace_snapshot=snapshot,
        )
        await self._peer.request("execution.tool_result", params.model_dump(mode="json", by_alias=True))

    async def respond(self, response: InteractionResponse) -> None:
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            self._asset_bridge.allow_json(response.response)
        params = ExecutionInteractionResponseParams(execution_id=self.execution_id, response=response)
        await self._peer.request("execution.interaction_response", params.model_dump(mode="json", by_alias=True))

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            self._asset_bridge.allow_content(input)
        params = ExecutionSteerParams(execution_id=self.execution_id, input=input)
        await self._peer.request("execution.steer", params.model_dump(mode="json", by_alias=True))

    async def cancel(self, reason: CancelReason) -> None:
        params = ExecutionCancelParams(execution_id=self.execution_id, reason=reason)
        await self._peer.request("execution.cancel", params.model_dump(mode="json", by_alias=True))

    async def close(self) -> None:
        if not self._terminal and not self._closed:
            with contextlib.suppress(Exception):
                await self.cancel(
                    CancelReason(
                        code="execution_channel_closed",
                        message="Execution channel closed before a terminal event",
                    )
                )
        self._closed = True


class RemoteRuntimeAdapter:
    def __init__(
        self,
        peer: JsonRpcPeer,
        *,
        asset_store: AssetStorePort | None = None,
        workspace_transfer: bool = True,
    ) -> None:
        if not isinstance(workspace_transfer, bool):
            raise TypeError("workspace_transfer must be a boolean")
        self._peer = peer
        self._channels: dict[str, RemoteExecutionChannel] = {}
        self._watch_task: asyncio.Task[None] | None = None
        self._negotiation: RuntimeNegotiateResult | None = None
        self._asset_bridge = RuntimeWireAssetBridge(peer, asset_store) if asset_store is not None else None
        self._workspace_bridge = (
            RuntimeWireWorkspaceClient(asset_store) if asset_store is not None and workspace_transfer else None
        )
        self._workspace_states: dict[str, ClientWorkspaceState] = {}
        self._pending_workspace_snapshots: dict[str, str] = {}
        self._open_sessions: dict[str, RuntimeSessionRef] = {}
        self._open_session_specs: dict[str, RuntimeSessionSpec] = {}
        self._closed_sessions: dict[str, RuntimeSessionRef] = {}
        self._session_locks: dict[str, asyncio.Lock] = {}
        self._close_lock = asyncio.Lock()
        self._closed = False
        self._peer.on_notification("runtime.event", self._on_runtime_event_safely)

    @classmethod
    async def connect_tcp(
        cls,
        host: str,
        port: int,
        *,
        ssl_context: ssl.SSLContext | bool | None = None,
        server_hostname: str | None = None,
        auth_token: str | None = None,
        max_frame_bytes: int = 16 * 1024 * 1024,
        asset_store: AssetStorePort | None = None,
        workspace_transfer: bool = True,
        data_plane: bool = True,
    ) -> RemoteRuntimeAdapter:
        if not isinstance(host, str) or not host.strip() or host != host.strip():
            raise ValueError("host must be a non-blank, trimmed string")
        if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
            raise ValueError("port must be an integer between 1 and 65535")
        if auth_token is not None and (not isinstance(auth_token, str) or not auth_token.strip()):
            raise ValueError("auth_token must be a non-blank string when provided")
        if server_hostname is not None and (
            not isinstance(server_hostname, str)
            or not server_hostname.strip()
            or server_hostname != server_hostname.strip()
        ):
            raise ValueError("server_hostname must be a non-blank, trimmed string")
        if not isinstance(workspace_transfer, bool):
            raise TypeError("workspace_transfer must be a boolean")
        if not isinstance(data_plane, bool):
            raise TypeError("data_plane must be a boolean")
        if not ssl_context and server_hostname is not None:
            raise ValueError("server_hostname requires TLS")
        if isinstance(max_frame_bytes, bool) or not isinstance(max_frame_bytes, int) or max_frame_bytes < 1024:
            raise ValueError("max_frame_bytes must be an integer of at least 1024")
        reader, writer = await asyncio.open_connection(
            host,
            port,
            ssl=ssl_context,
            server_hostname=(server_hostname or host) if ssl_context else None,
            limit=max_frame_bytes + 1,
        )
        peer = JsonRpcPeer(reader, writer, max_frame_bytes=max_frame_bytes)
        adapter = cls(
            peer,
            asset_store=asset_store,
            workspace_transfer=workspace_transfer,
        )
        await peer.start()
        adapter._watch_task = asyncio.create_task(
            adapter._watch_connection(),
            name="areal_agent_runtime-runtime-wire-watch",
        )
        if auth_token is not None:
            try:
                params = RuntimeAuthenticateParams(token=auth_token)
                result = await peer.request(
                    "runtime.authenticate",
                    params.model_dump(mode="json", by_alias=True),
                )
                RuntimeAuthenticateResult.model_validate(result)
            except BaseException as connect_error:
                await _close_after_connect_failure(adapter, connect_error)
        try:
            negotiation = RuntimeNegotiateResult.model_validate(
                await peer.request(
                    "runtime.negotiate",
                    RuntimeNegotiateParams(
                        client_name=(
                            DATA_AWARE_RUNTIME_CLIENT_NAME
                            if data_plane
                            else LEGACY_RUNTIME_CLIENT_NAME
                        ),
                        max_frame_bytes=max_frame_bytes,
                        asset_transfer=adapter._asset_bridge is not None,
                        workspace_transfer=adapter._workspace_bridge is not None,
                    ).model_dump(mode="json", by_alias=True),
                )
            )
            if negotiation.max_frame_bytes > max_frame_bytes:
                raise JsonRpcProtocolError(
                    -32002,
                    "Runtime Wire peer increased the configured frame limit",
                )
            if negotiation.asset_transfer and adapter._asset_bridge is None:
                raise JsonRpcProtocolError(-32002, "Runtime Wire peer enabled unoffered asset transfer")
            if negotiation.workspace_transfer and adapter._workspace_bridge is None:
                raise JsonRpcProtocolError(
                    -32002,
                    "Runtime Wire peer enabled unoffered workspace transfer",
                )
            if negotiation.workspace_transfer and not negotiation.asset_transfer:
                raise JsonRpcProtocolError(
                    -32002,
                    "Runtime Wire workspace transfer requires asset transfer",
                )
            if negotiation.runtime_api_version != negotiation.descriptor.runtime_api_version:
                raise JsonRpcProtocolError(
                    -32002,
                    "Runtime Wire negotiation descriptor version mismatch",
                )
            peer.set_max_frame_bytes(negotiation.max_frame_bytes)
            adapter._negotiation = negotiation
            if negotiation.asset_transfer and adapter._asset_bridge is not None:
                adapter._asset_bridge.enable()
        except BaseException as connect_error:
            await _close_after_connect_failure(adapter, connect_error)
        return adapter

    async def describe(self) -> RuntimeDescriptor:
        self._require_open()
        if self._negotiation is not None:
            return self._negotiation.descriptor
        result = await self._peer.request("runtime.describe", {})
        return RuntimeDescriptor.model_validate(result)

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        self._require_open()
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if spec.session_id in self._pending_workspace_snapshots:
                raise RuntimeError(f"Remote session still has a pending final workspace import: {spec.session_id}")
            existing = self._open_sessions.get(spec.session_id)
            if existing is not None:
                require_same_runtime_session_spec(
                    self._open_session_specs[spec.session_id],
                    spec,
                )
                return existing
            session = await self._open_session_locked(spec)
            self._open_sessions[session.session_id] = session
            self._open_session_specs[session.session_id] = spec
            self._closed_sessions.pop(session.session_id, None)
            return session

    async def _open_session_locked(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        wire_spec = spec
        snapshot = None
        workspace_state = None
        if self._negotiation is not None and self._negotiation.workspace_transfer and spec.workspace.mount_hint:
            if self._workspace_bridge is None or self._asset_bridge is None:
                raise RuntimeError("Runtime Wire workspace transfer is not configured")
            wire_spec, snapshot, workspace_state = await self._workspace_bridge.export(spec)
            self._asset_bridge.allow_asset(snapshot.asset_id)
        params = SessionOpenParams(spec=wire_spec, workspace_snapshot=snapshot)
        result = await self._peer.request("session.open", params.model_dump(mode="json", by_alias=True))
        session = SessionOpenResult.model_validate(result).session
        if session.session_id != spec.session_id:
            await self._peer.close()
            raise JsonRpcProtocolError(
                -32042,
                "Runtime Wire returned a session with a mismatched canonical sessionId",
            )
        if workspace_state is not None:
            self._workspace_states[session.session_id] = workspace_state
        return session

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        self._require_open()
        if request.session_id not in self._open_sessions:
            raise LookupError(f"Remote session is not open: {request.session_id}")
        if request.session_id in self._pending_workspace_snapshots:
            raise RuntimeError(f"Remote session is finalizing its workspace: {request.session_id}")
        require_session_environment(self._open_session_specs[request.session_id], request)
        if request.execution_id in self._channels:
            raise RuntimeError(f"Remote execution is already active: {request.execution_id}")
        if self._asset_bridge is not None and self._asset_bridge.enabled:
            self._asset_bridge.allow_content(request.input)
            self._asset_bridge.allow_content(request.system)
        workspace_state = self._workspace_states.get(request.session_id)
        wire_request = request
        if workspace_state is not None:
            wire_request = request.model_copy(
                update={"workspace": request.workspace.model_copy(update={"mount_hint": None})}
            )
        channel = RemoteExecutionChannel(
            self._peer,
            request,
            self._asset_bridge,
            self._workspace_bridge,
            workspace_state,
        )
        self._channels[request.execution_id] = channel
        params = ExecutionStartParams(request=wire_request)
        try:
            result = await self._peer.request(
                "execution.start",
                params.model_dump(mode="json", by_alias=True),
            )
        except BaseException:
            self._channels.pop(request.execution_id, None)
            raise
        accepted = ExecutionAccepted.model_validate(result)
        if not accepted.accepted or accepted.execution_id != request.execution_id:
            self._channels.pop(request.execution_id, None)
            await self._peer.close()
            raise JsonRpcProtocolError(-32010, "Runtime rejected execution")
        return channel

    async def close_session(self, session: RuntimeSessionRef) -> None:
        self._require_open()
        lock = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with lock:
            already_closed = self._closed_sessions.get(session.session_id)
            if already_closed is not None:
                if already_closed != session:
                    raise ValueError("Remote session handle does not match the closed session")
                return
            owned = self._open_sessions.get(session.session_id)
            if owned is None:
                raise LookupError(f"Remote session is not open: {session.session_id}")
            if owned != session:
                raise ValueError("Remote session handle does not match the active session")
            state = self._workspace_states.get(session.session_id)
            remote_asset_id = self._pending_workspace_snapshots.get(session.session_id)
            if remote_asset_id is None:
                params = SessionCloseParams(session=session)
                result = SessionCloseResult.model_validate(
                    await self._peer.request(
                        "session.close",
                        params.model_dump(mode="json", by_alias=True),
                    )
                )
                if state is None:
                    if result.workspace_snapshot is not None:
                        await self._peer.close()
                        raise JsonRpcProtocolError(
                            -32041,
                            "Runtime Wire returned an unexpected final workspace snapshot",
                        )
                    self._mark_session_closed(session)
                    return
                if result.workspace_snapshot is None or self._workspace_bridge is None or self._asset_bridge is None:
                    await self._peer.close()
                    raise JsonRpcProtocolError(
                        -32041,
                        "Runtime Wire omitted the negotiated final workspace snapshot",
                    )
                remote_asset_id = result.workspace_snapshot.asset_id
                # Persist protocol progress in memory before touching the Host
                # workspace. A failed local import retries from this immutable
                # peer asset without issuing session.close twice.
                self._pending_workspace_snapshots[session.session_id] = remote_asset_id
            if self._workspace_bridge is None or self._asset_bridge is None or state is None:
                raise RuntimeError("Runtime Wire final workspace state is inconsistent")
            local_asset_id = await self._asset_bridge.materialize_asset(remote_asset_id)
            await self._workspace_bridge.import_final(state, local_asset_id)
            self._workspace_states.pop(session.session_id, None)
            self._pending_workspace_snapshots.pop(session.session_id, None)
            self._mark_session_closed(session)

    def _mark_session_closed(self, session: RuntimeSessionRef) -> None:
        self._open_sessions.pop(session.session_id, None)
        self._open_session_specs.pop(session.session_id, None)
        self._closed_sessions[session.session_id] = session

    async def health(self) -> HealthStatus:
        self._require_open()
        return HealthStatus.model_validate(await self._peer.request("runtime.health", {}))

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            await self._peer.close()
            if self._watch_task is not None and self._watch_task is not asyncio.current_task():
                await self._watch_task
            self._workspace_states.clear()
            self._pending_workspace_snapshots.clear()
            self._open_sessions.clear()
            self._open_session_specs.clear()
            self._closed_sessions.clear()
            self._session_locks.clear()
            self._closed = True

    def _require_open(self) -> None:
        if self._closed:
            raise RuntimeError("Remote runtime adapter is closed")

    async def _on_runtime_event(self, params: object) -> None:
        notification = RuntimeEventNotification.model_validate(params)
        event = notification.event
        channel = self._channels.get(event.execution_id)
        if channel is None:
            raise JsonRpcProtocolError(
                -32046,
                f"Runtime emitted an event for an inactive execution: {event.execution_id}",
            )
        workspace_state = self._workspace_states.get(channel._request.session_id)
        if workspace_state is not None and _is_external_tool_request(
            event,
            channel._request,
        ):
            if (
                notification.workspace_snapshot is None
                or self._workspace_bridge is None
                or self._asset_bridge is None
                or not self._asset_bridge.enabled
            ):
                await self._fail_workspace_sync(
                    channel,
                    event,
                    "Runtime Wire omitted the negotiated tool-boundary workspace snapshot",
                )
                return
            try:
                local_asset_id = await self._asset_bridge.materialize_asset(notification.workspace_snapshot.asset_id)
                await self._workspace_bridge.import_snapshot(
                    workspace_state,
                    local_asset_id,
                )
            except Exception as exc:
                await self._fail_workspace_sync(channel, event, str(exc) or type(exc).__name__)
                return
        try:
            if self._asset_bridge is not None and self._asset_bridge.enabled:
                event = event.model_copy(update={"data": await self._asset_bridge.materialize_json(event.data)})
        except Exception as exc:
            await self._fail_workspace_sync(channel, event, str(exc) or type(exc).__name__)
            return
        await channel.push(event)
        if event.type in {EventType.EXECUTION_COMPLETED, EventType.EXECUTION_FAILED}:
            self._channels.pop(event.execution_id, None)

    async def _on_runtime_event_safely(self, params: object) -> None:
        try:
            await self._on_runtime_event(params)
        except Exception as exc:
            # JsonRpcPeer deliberately isolates notification handlers.  Runtime
            # events are not optional observers, though: silently dropping a
            # malformed one would leave every affected execution hanging.
            detail = str(exc) or type(exc).__name__
            channels = tuple(self._channels.values())
            self._channels.clear()
            if channels:
                await asyncio.gather(*(channel.fail_protocol(detail) for channel in channels))
            await self._peer.close()

    async def _fail_workspace_sync(
        self,
        channel: RemoteExecutionChannel,
        event: RuntimeEvent,
        detail: str,
    ) -> None:
        # Terminate the local channel first. A peer which remains connected but
        # stops answering requests must not keep the Application run hanging.
        await channel.push(
            RuntimeEvent(
                runtime_instance_id=event.runtime_instance_id,
                runtime_sequence=event.runtime_sequence,
                execution_id=event.execution_id,
                agent_id=event.agent_id,
                parent_agent_id=event.parent_agent_id,
                type="execution.failed",
                data={
                    "reason": "runtime_wire_workspace_sync_failed",
                    "detail": detail,
                },
            )
        )
        self._channels.pop(event.execution_id, None)
        with contextlib.suppress(Exception):
            async with asyncio.timeout(1.0):
                await channel.cancel(
                    CancelReason(
                        code="runtime_wire_bridge_failure",
                        message=detail,
                    )
                )

    async def _watch_connection(self) -> None:
        await self._peer.wait_closed()
        channels = tuple(self._channels.values())
        self._channels.clear()
        if channels:
            await asyncio.gather(*(channel.fail_disconnected() for channel in channels))


async def _close_after_connect_failure(
    adapter: RemoteRuntimeAdapter,
    connect_error: BaseException,
) -> NoReturn:
    try:
        await adapter.close()
    except BaseException as cleanup_error:
        raise BaseExceptionGroup(
            "Runtime Wire connection setup failed and cleanup also failed",
            [connect_error, cleanup_error],
        ) from None
    raise connect_error.with_traceback(connect_error.__traceback__)


def _is_external_tool_request(
    event: RuntimeEvent,
    request: ExecutionRequest,
) -> bool:
    if event.type.value != "tool.requested" or not isinstance(event.data, dict):
        return False
    execution = event.data.get("execution")
    if execution in {"application", "remote"}:
        return True
    name = event.data.get("name")
    return isinstance(name, str) and any(
        tool.name == name and tool.execution.value in {"application", "remote"} for tool in request.tools
    )
