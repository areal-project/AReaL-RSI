"""Optional loopback Responses transport for an Anthropic Messages provider.

Codex owns the agent loop and every tool execution. This bridge translates only
model requests/results; it never grants tools, executes them or stores a second
conversation. Unsupported hosted/stateful API features are rejected explicitly.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import hmac
import json
import math
import secrets
import socket
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

MAX_BYTES = 16 * 1024 * 1024
_PARAMETERS = frozenset(
    {
        "temperature",
        "top_p",
        "top_k",
        "min_p",
        "presence_penalty",
        "repetition_penalty",
        "reasoning_effort",
        "stop_sequences",
        "thinking",
    }
)


class ProviderProtocolError(ValueError):
    """A safe error message containing no input text, credentials or responses."""


class ReasoningEnvelope:
    """Authenticate/encrypt original vendor thinking for native durable resume.

    The key is domain-separated from the configured provider credential. Codex
    keeps only the opaque encrypted_content, never a provider credential. The
    same route/model/credential can resume it after a bridge process restart.
    """

    def __init__(self, *, api_key: str, endpoint: str, model: str) -> None:
        from cryptography.fernet import Fernet

        domain = json.dumps(["areal.codex.anthropic.reasoning/v1", endpoint, model]).encode()
        self._fernet = Fernet(base64.urlsafe_b64encode(hmac.digest(api_key.encode(), domain, "sha256")))

    def encode(self, block: dict[str, Any]) -> str:
        self._validate(block)
        return self._fernet.encrypt(json.dumps(block, ensure_ascii=False, allow_nan=False).encode()).decode()

    def decode(self, token: Any) -> dict[str, Any]:
        from cryptography.fernet import InvalidToken

        try:
            raw = self._fernet.decrypt(_text(token, "encrypted_content").encode())
            block = _object(json.loads(raw), "thinking block")
        except (InvalidToken, UnicodeError, json.JSONDecodeError) as exc:
            raise ProviderProtocolError("reasoning envelope does not match this provider binding") from exc
        self._validate(block)
        return block

    @staticmethod
    def _validate(block: dict[str, Any]) -> None:
        if block.get("type") == "thinking":
            _text(block.get("thinking"), "thinking")
            if "signature" in block:
                _text(block["signature"], "thinking.signature")
        elif block.get("type") == "redacted_thinking":
            _text(block.get("data"), "redacted_thinking.data")
        else:
            raise ProviderProtocolError("reasoning envelope must contain a vendor thinking block")


@dataclass(frozen=True)
class _Tool:
    name: str
    kind: str
    namespace: str | None = None


def _object(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProviderProtocolError(f"{field} must be an object")
    return value


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ProviderProtocolError(f"{field} must be text")
    return value


def _wire_name(tool: _Tool) -> str:
    if not tool.name or tool.namespace == "":
        raise ProviderProtocolError("tool and namespace names must not be empty")
    name = f"{tool.namespace}__{tool.name}" if tool.namespace else tool.name
    if len(name) <= 64 and all(c.isascii() and (c.isalnum() or c in "_-") for c in name):
        return name
    return "tool_" + hashlib.sha256(name.encode()).hexdigest()[:40]


def _tools(definitions: Any) -> tuple[list[dict[str, Any]], dict[str, _Tool]]:
    converted: list[dict[str, Any]] = []
    identities: dict[str, _Tool] = {}

    def add(items: Any, namespace: str | None = None) -> None:
        if not isinstance(items, list):
            raise ProviderProtocolError("tools must be an array")
        for candidate in items:
            item = _object(candidate, "tool")
            kind = _text(item.get("type"), "tool.type")
            if kind == "namespace" and namespace is None:
                add(item.get("tools"), _text(item.get("name"), "namespace.name"))
                continue
            if kind not in {"function", "custom"}:
                raise ProviderProtocolError("Anthropic bridge supports only function and custom tools")
            identity = _Tool(_text(item.get("name"), "tool.name"), kind, namespace)
            wire = _wire_name(identity)
            if wire in identities:
                raise ProviderProtocolError("duplicate or colliding tool names")
            identities[wire] = identity
            description = _text(item.get("description", ""), "tool.description")
            if kind == "custom":
                # Messages has no constrained free-form decoder. The native
                # Codex tool still validates its input before executing it.
                schema = {"type": "object", "properties": {"input": {"type": "string"}}, "required": ["input"]}
                description += "\nReturn the exact free-form tool input in the input field."
                if item.get("format"):
                    description += "\nTool input format: " + json.dumps(item["format"], ensure_ascii=False)
            else:
                schema = _object(item.get("parameters", {"type": "object", "properties": {}}), "parameters")
            converted.append({"name": wire, "description": description, "input_schema": schema})

    add(definitions)
    return converted, identities


def _content(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, str):
        return [{"type": "text", "text": value}] if value else []
    if not isinstance(value, list):
        raise ProviderProtocolError("message content must be text or an array")
    result: list[dict[str, Any]] = []
    for part in value:
        part = _object(part, "content part")
        if part.get("type") in ("input_text", "output_text", "text"):
            text = _text(part.get("text"), "content.text")
            if text:
                result.append({"type": "text", "text": text})
        elif part.get("type") == "input_image":
            url = _text(part.get("image_url"), "image_url")
            if url.startswith("data:") and ";base64," in url:
                header, data = url.split(";base64,", 1)
                media = header[5:]
                if media not in {"image/png", "image/jpeg", "image/gif", "image/webp"}:
                    raise ProviderProtocolError("unsupported input image type")
                source = {"type": "base64", "media_type": media, "data": data}
            elif url.startswith("https://"):
                source = {"type": "url", "url": url}
            else:
                raise ProviderProtocolError("image requires an inline data URL or HTTPS URL")
            result.append({"type": "image", "source": source})
        else:
            raise ProviderProtocolError("unsupported Responses content part")
    return result


def to_anthropic(
    request: dict[str, Any],
    *,
    model: str,
    max_tokens: int,
    extra_body: dict[str, Any],
    reasoning: ReasoningEnvelope | None = None,
) -> tuple[dict[str, Any], dict[str, _Tool]]:
    if request.get("previous_response_id") or request.get("conversation"):
        raise ProviderProtocolError("Anthropic bridge requires explicit conversation history")
    if request.get("model") is not None and _text(request["model"], "model") != model:
        raise ProviderProtocolError("model does not match the configured provider binding")
    text_options = _object(request.get("text") or {}, "text")
    text_format = _object(text_options.get("format") or {}, "text.format")
    if text_format.get("type", "text") != "text":
        raise ProviderProtocolError("structured response formats are not supported by this provider bridge")
    tools, identities = _tools(request.get("tools", []))
    system: list[dict[str, Any]] = []
    instructions = request.get("instructions")
    if instructions:
        system.append({"type": "text", "text": _text(instructions, "instructions")})
    messages: list[dict[str, Any]] = []

    def append(role: str, blocks: list[dict[str, Any]]) -> None:
        if not blocks:
            return
        if messages and messages[-1]["role"] == role:
            messages[-1]["content"].extend(blocks)
        else:
            messages.append({"role": role, "content": blocks})

    items = request.get("input", [])
    if isinstance(items, str):
        items = [{"role": "user", "content": items}]
    if not isinstance(items, list):
        raise ProviderProtocolError("input must be text or an array")
    for candidate in items:
        item = _object(candidate, "input item")
        kind = _text(item.get("type", "message"), "input.type")
        if kind == "message":
            role = _text(item.get("role"), "message.role")
            blocks = _content(item.get("content", []))
            if role in {"system", "developer"}:
                if any(block["type"] != "text" for block in blocks):
                    raise ProviderProtocolError("system instructions must contain text only")
                system.extend(blocks)
            elif role in {"user", "assistant"}:
                append(role, blocks)
            else:
                raise ProviderProtocolError("unsupported message role")
        elif kind in {"function_call", "custom_tool_call"}:
            identity = _Tool(
                _text(item.get("name"), "call.name"),
                "custom" if kind == "custom_tool_call" else "function",
                item.get("namespace"),
            )
            if kind == "custom_tool_call":
                arguments = {"input": _text(item.get("input"), "call.input")}
            else:
                try:
                    arguments = json.loads(_text(item.get("arguments"), "call.arguments"))
                except json.JSONDecodeError as exc:
                    raise ProviderProtocolError("function arguments must be valid JSON") from exc
                arguments = _object(arguments, "call.arguments")
            append(
                "assistant",
                [
                    {
                        "type": "tool_use",
                        "id": _text(item.get("call_id"), "call_id"),
                        "name": _wire_name(identity),
                        "input": arguments,
                    }
                ],
            )
        elif kind in {"function_call_output", "custom_tool_call_output"}:
            output = item.get("output", "")
            append(
                "user",
                [
                    {
                        "type": "tool_result",
                        "tool_use_id": _text(item.get("call_id"), "call_id"),
                        "content": _content(output) if isinstance(output, list) else _text(output, "tool output"),
                    }
                ],
            )
        elif kind == "reasoning":
            if item.get("encrypted_content") and reasoning is not None:
                append("assistant", [reasoning.decode(item["encrypted_content"])])
            elif item.get("encrypted_content") or item.get("summary") or item.get("content"):
                raise ProviderProtocolError("opaque or nonempty reasoning history cannot cross provider protocols")
        else:
            raise ProviderProtocolError("unsupported Responses input item")
    if not messages:
        raise ProviderProtocolError("at least one conversation message is required")
    requested_max = request.get("max_output_tokens")
    if requested_max is not None:
        if isinstance(requested_max, bool) or not isinstance(requested_max, int) or requested_max < 1:
            raise ProviderProtocolError("max_output_tokens must be a positive integer")
        max_tokens = min(max_tokens, requested_max)
    payload = {"model": model, "max_tokens": max_tokens, "messages": messages, "stream": False, **extra_body}
    for parameter in ("temperature", "top_p"):
        if parameter in request and parameter not in extra_body:
            payload[parameter] = request[parameter]
    parallel = request.get("parallel_tool_calls", True)
    if not isinstance(parallel, bool):
        raise ProviderProtocolError("parallel_tool_calls must be boolean")
    if request.get("background") or request.get("max_tool_calls") is not None:
        raise ProviderProtocolError("background execution and max_tool_calls are not supported by this provider bridge")
    if system:
        payload["system"] = system
    choice = request.get("tool_choice", "auto")
    if choice != "none" and tools:
        payload["tools"] = tools
        if isinstance(choice, str) and choice in {"auto", "required"}:
            payload["tool_choice"] = {"type": "auto" if choice == "auto" else "any"}
        elif isinstance(choice, dict) and choice.get("type") in ("function", "custom"):
            identity = _Tool(_text(choice.get("name"), "tool_choice.name"), choice["type"], choice.get("namespace"))
            wire = _wire_name(identity)
            if wire not in identities:
                raise ProviderProtocolError("tool choice is not in the declared tool catalog")
            payload["tool_choice"] = {"type": "tool", "name": wire}
        else:
            raise ProviderProtocolError("unsupported tool_choice")
        if not parallel:
            payload["tool_choice"]["disable_parallel_tool_use"] = True
    elif choice not in ("auto", "none"):
        raise ProviderProtocolError("tool_choice requires a declared tool catalog")
    return payload, identities


def from_anthropic(
    message: dict[str, Any],
    identities: dict[str, _Tool],
    *,
    model: str,
    response_id: str,
    reasoning: ReasoningEnvelope | None = None,
) -> dict[str, Any]:
    if message.get("type") != "message" or message.get("role") != "assistant":
        raise ProviderProtocolError("provider returned an invalid assistant message")
    content = message.get("content")
    if not isinstance(content, list):
        raise ProviderProtocolError("provider returned invalid content")
    output: list[dict[str, Any]] = []
    for part in content:
        part = _object(part, "provider content")
        if part.get("type") == "text":
            output.append(
                {
                    "id": "msg_" + uuid.uuid4().hex,
                    "type": "message",
                    "role": "assistant",
                    "status": "completed",
                    "content": [
                        {"type": "output_text", "text": _text(part.get("text"), "provider text"), "annotations": []}
                    ],
                }
            )
        elif part.get("type") in ("thinking", "redacted_thinking") and reasoning is not None:
            output.append(
                {
                    "id": "rs_" + uuid.uuid4().hex,
                    "type": "reasoning",
                    "summary": [],
                    "content": (
                        [{"type": "reasoning_text", "text": part["thinking"]}] if part["type"] == "thinking" else []
                    ),
                    "encrypted_content": reasoning.encode(part),
                }
            )
        elif part.get("type") == "tool_use":
            tool = identities.get(_text(part.get("name"), "provider tool name"))
            if tool is None:
                raise ProviderProtocolError("provider called an undeclared tool")
            arguments = _object(part.get("input"), "provider tool input")
            item = {
                "id": "call_" + uuid.uuid4().hex,
                "type": "custom_tool_call" if tool.kind == "custom" else "function_call",
                "status": "completed",
                "call_id": _text(part.get("id"), "provider tool id"),
                "name": tool.name,
            }
            if tool.namespace:
                item["namespace"] = tool.namespace
            if tool.kind == "custom":
                item["input"] = _text(arguments.get("input"), "custom tool input")
            else:
                item["arguments"] = json.dumps(arguments, ensure_ascii=False, allow_nan=False)
            output.append(item)
        else:
            raise ProviderProtocolError("provider returned an unsupported content type")
    if not output:
        raise ProviderProtocolError("provider returned no text or tool calls")
    stop = message.get("stop_reason")
    if stop not in {"end_turn", "tool_use", "stop_sequence", "max_tokens"}:
        raise ProviderProtocolError("provider returned an unsupported stop reason")
    usage = _object(message.get("usage", {}), "provider usage")
    counts: dict[str, int] = {}
    for key in ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"):
        value = usage.get(key, 0)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ProviderProtocolError("provider returned invalid usage")
        counts[key] = value
    input_tokens = counts["input_tokens"] + counts["cache_read_input_tokens"] + counts["cache_creation_input_tokens"]
    return {
        "id": response_id,
        "object": "response",
        "created_at": int(time.time()),
        "status": "incomplete" if stop == "max_tokens" else "completed",
        "model": model,
        "output": output,
        "error": None,
        "incomplete_details": {"reason": "max_output_tokens"} if stop == "max_tokens" else None,
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": counts["output_tokens"],
            "total_tokens": input_tokens + counts["output_tokens"],
            "input_tokens_details": {"cached_tokens": counts["cache_read_input_tokens"]},
        },
    }


def response_events(response: dict[str, Any]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for index, item in enumerate(response["output"]):
        initial = {**item, "status": "in_progress"}
        if item["type"] in {"message", "reasoning"}:
            initial["content"] = []
        else:
            initial["input" if item["type"] == "custom_tool_call" else "arguments"] = ""
        events.append({"type": "response.output_item.added", "output_index": index, "item": initial})
        common = {"item_id": item["id"], "output_index": index}
        if item["type"] == "reasoning":
            for part_index, part in enumerate(item["content"]):
                events.append(
                    {
                        "type": "response.reasoning_text.delta",
                        **common,
                        "content_index": part_index,
                        "delta": part["text"],
                    }
                )
                events.append(
                    {
                        "type": "response.reasoning_text.done",
                        **common,
                        "content_index": part_index,
                        "text": part["text"],
                    }
                )
        elif item["type"] == "message":
            for part_index, part in enumerate(item["content"]):
                part_common = {**common, "content_index": part_index}
                events.extend(
                    [
                        {"type": "response.content_part.added", **part_common, "part": {**part, "text": ""}},
                        {"type": "response.output_text.delta", **part_common, "delta": part["text"]},
                        {"type": "response.output_text.done", **part_common, "text": part["text"]},
                        {"type": "response.content_part.done", **part_common, "part": part},
                    ]
                )
        else:
            custom = item["type"] == "custom_tool_call"
            kind = "custom_tool_call_input" if custom else "function_call_arguments"
            field = "input" if custom else "arguments"
            events.extend(
                [
                    {"type": f"response.{kind}.delta", **common, "delta": item[field]},
                    {"type": f"response.{kind}.done", **common, field: item[field]},
                ]
            )
        events.append({"type": "response.output_item.done", "output_index": index, "item": item})
    events.append(
        {
            "type": "response.completed" if response["status"] == "completed" else "response.incomplete",
            "response": response,
        }
    )
    return events


class AnthropicResponsesBridge:
    def __init__(
        self,
        *,
        endpoint: str,
        api_key: str,
        model: str,
        max_tokens: int = 4096,
        extra_body: dict[str, Any] | None = None,
        timeout_seconds: float = 120.0,
    ) -> None:
        url = urlsplit(endpoint)
        if url.scheme not in {"http", "https"} or not url.netloc or url.username or url.password or url.fragment:
            raise ValueError("Anthropic endpoint must be an HTTP(S) URL without embedded credentials")
        if not api_key or "\n" in api_key or "\r" in api_key or not model:
            raise ValueError("Anthropic model and credential must be configured")
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1:
            raise ValueError("max_tokens must be a positive integer")
        if extra_body and set(extra_body).difference(_PARAMETERS):
            raise ValueError("model parameters may contain only supported sampling fields")
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be finite and positive")
        if extra_body and "thinking" in extra_body:
            thinking = extra_body["thinking"]
            if not isinstance(thinking, dict):
                raise ValueError("thinking must be an Anthropic thinking configuration")
            if thinking.get("type") in {"disabled", "adaptive"}:
                valid = set(thinking) == {"type"}
            elif thinking.get("type") == "enabled":
                budget = thinking.get("budget_tokens")
                valid = (
                    set(thinking) == {"type", "budget_tokens"}
                    and isinstance(budget, int)
                    and not isinstance(budget, bool)
                    and 1024 <= budget < max_tokens
                )
            else:
                valid = False
            if not valid:
                raise ValueError("thinking must be disabled, adaptive, or enabled with a valid budget_tokens")
        self._endpoint, self._api_key, self._model = endpoint, api_key, model
        self._reasoning = ReasoningEnvelope(api_key=api_key, endpoint=endpoint, model=model)
        self._max_tokens, self._extra_body = max_tokens, dict(extra_body or {})
        self._timeout = timeout_seconds
        self._token = secrets.token_urlsafe(32)
        self._server: Any = None
        self._task: asyncio.Task[None] | None = None
        self._client: Any = None
        self._socket: socket.socket | None = None
        self._base_url: str | None = None

    @property
    def base_url(self) -> str:
        if self._base_url is None:
            raise RuntimeError("Anthropic Responses bridge is not running")
        return self._base_url

    @property
    def bearer_token(self) -> str:
        return self._token

    async def start(self) -> None:
        if self._task is not None:
            return
        import httpx
        import uvicorn
        from fastapi import FastAPI, Request
        from starlette.responses import JSONResponse, StreamingResponse

        app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
        self._client = httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=False,
            trust_env=urlsplit(self._endpoint).hostname not in {"localhost", "127.0.0.1", "::1"},
        )

        async def upstream(payload: dict[str, Any]) -> dict[str, Any]:
            async with self._client.stream(
                "POST",
                self._endpoint,
                json=payload,
                headers={
                    "Authorization": "Bearer " + self._api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
            ) as reply:
                if reply.status_code != 200:
                    raise ProviderProtocolError(f"Anthropic provider returned HTTP {reply.status_code}")
                raw = bytearray()
                async for chunk in reply.aiter_bytes():
                    if len(raw) + len(chunk) > MAX_BYTES:
                        raise ProviderProtocolError("Anthropic response exceeds the bridge size limit")
                    raw.extend(chunk)
            try:
                return _object(json.loads(raw), "provider response")
            except (UnicodeError, json.JSONDecodeError) as exc:
                raise ProviderProtocolError("Anthropic provider returned invalid JSON") from exc

        async def respond(request: Request) -> Any:
            if not hmac.compare_digest(request.headers.get("authorization", ""), "Bearer " + self._token):
                return JSONResponse({"error": {"message": "unauthorized"}}, status_code=401)
            raw = bytearray()
            async for chunk in request.stream():
                if len(raw) + len(chunk) > MAX_BYTES:
                    return JSONResponse({"error": {"message": "request too large"}}, status_code=413)
                raw.extend(chunk)
            try:
                body = _object(json.loads(raw), "request")
                payload, identities = to_anthropic(
                    body,
                    model=self._model,
                    max_tokens=self._max_tokens,
                    extra_body=self._extra_body,
                    reasoning=self._reasoning,
                )
            except (UnicodeError, json.JSONDecodeError, ProviderProtocolError) as exc:
                message = str(exc) if isinstance(exc, ProviderProtocolError) else "invalid request JSON"
                return JSONResponse({"error": {"message": message, "type": "invalid_request_error"}}, status_code=400)
            response_id = "resp_" + uuid.uuid4().hex

            async def stream() -> AsyncIterator[bytes]:
                sequence = 0

                def emit(event: dict[str, Any]) -> bytes:
                    nonlocal sequence
                    event["sequence_number"] = sequence
                    sequence += 1
                    return (
                        "event: " + event["type"] + "\ndata: " + json.dumps(event, ensure_ascii=False) + "\n\n"
                    ).encode()

                pending = {
                    "id": response_id,
                    "object": "response",
                    "status": "in_progress",
                    "created_at": int(time.time()),
                    "model": self._model,
                    "output": [],
                }
                yield emit({"type": "response.created", "response": pending})
                yield emit({"type": "response.in_progress", "response": pending})
                try:
                    response = from_anthropic(
                        await upstream(payload),
                        identities,
                        model=self._model,
                        response_id=response_id,
                        reasoning=self._reasoning,
                    )
                    for event in response_events(response):
                        yield emit(event)
                except (ProviderProtocolError, httpx.HTTPError) as exc:
                    message = (
                        str(exc) if isinstance(exc, ProviderProtocolError) else "Anthropic provider transport failed"
                    )
                    yield emit(
                        {
                            "type": "response.failed",
                            "response": {
                                **pending,
                                "status": "failed",
                                "error": {"code": "provider_error", "message": message},
                            },
                        }
                    )

            if body.get("stream", False):
                return StreamingResponse(stream(), media_type="text/event-stream")
            try:
                result = from_anthropic(
                    await upstream(payload),
                    identities,
                    model=self._model,
                    response_id=response_id,
                    reasoning=self._reasoning,
                )
                return JSONResponse(result)
            except (ProviderProtocolError, httpx.HTTPError) as exc:
                message = str(exc) if isinstance(exc, ProviderProtocolError) else "Anthropic provider transport failed"
                return JSONResponse({"error": {"message": message, "type": "provider_error"}}, status_code=502)

        # Assign the actual type: postponed local annotations are not available
        # to FastAPI's module-global annotation resolver.
        respond.__annotations__["request"] = Request
        app.add_api_route("/v1/responses", respond, methods=["POST"])
        app.add_api_route("/responses", respond, methods=["POST"])
        try:
            listener = socket.socket()
            self._socket = listener
            listener.bind(("127.0.0.1", 0))
            listener.listen(128)
            self._server = uvicorn.Server(uvicorn.Config(app, log_level="error", access_log=False, lifespan="off"))
            self._task = asyncio.create_task(self._server.serve(sockets=[listener]), name="codex:anthropic-provider")
            async with asyncio.timeout(10):
                while not self._server.started:
                    if self._task.done():
                        await self._task
                        raise RuntimeError("Anthropic Responses bridge stopped during startup")
                    await asyncio.sleep(0.01)
            self._base_url = f"http://127.0.0.1:{listener.getsockname()[1]}/v1"
        except BaseException as error:
            try:
                await self.close()
            except BaseException as cleanup_error:
                error.add_note(f"bridge cleanup also failed: {type(cleanup_error).__name__}")
            raise

    async def close(self) -> None:
        self._base_url = None
        try:
            if self._server is not None:
                self._server.should_exit = True
            if self._task is not None:
                try:
                    await asyncio.wait_for(asyncio.shield(self._task), timeout=5)
                except (TimeoutError, asyncio.CancelledError):
                    self._task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await self._task
                    raise
        finally:
            self._task = None
            self._server = None
            try:
                if self._client is not None:
                    await self._client.aclose()
            finally:
                self._client = None
                if self._socket is not None:
                    self._socket.close()
                    self._socket = None
