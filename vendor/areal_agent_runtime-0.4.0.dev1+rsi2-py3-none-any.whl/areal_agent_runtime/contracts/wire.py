"""Typed payloads for ARealAgentRuntime Runtime Wire Protocol v1."""

from __future__ import annotations

from typing import Literal

from pydantic import ConfigDict, Field, StrictBool, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel, require_trimmed
from areal_agent_runtime.contracts.content import AssetRef, ContentBlock
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ExecutionRequest,
    InteractionResponse,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolResult,
)
from areal_agent_runtime.contracts.version import (
    RUNTIME_API_VERSION,
    RUNTIME_WIRE_API_VERSION,
    RuntimeApiVersion,
    RuntimeWireApiVersion,
)

LEGACY_RUNTIME_CLIENT_NAME = "areal_agent_runtime-runtime-client"
DATA_AWARE_RUNTIME_CLIENT_NAME = f"{LEGACY_RUNTIME_CLIENT_NAME}+data-v1"


class RuntimeNegotiateParams(ContractModel):
    model_config = ConfigDict(
        json_schema_extra={
            "allOf": [
                {
                    "if": {
                        "properties": {"workspaceTransfer": {"const": True}},
                        "required": ["workspaceTransfer"],
                    },
                    "then": {
                        "properties": {"assetTransfer": {"const": True}},
                        "required": ["assetTransfer"],
                    },
                }
            ]
        }
    )

    wire_api_version: RuntimeWireApiVersion = RUNTIME_WIRE_API_VERSION
    supported_runtime_api_versions: tuple[RuntimeApiVersion, ...] = Field(
        default=(RUNTIME_API_VERSION,),
        min_length=1,
    )
    # The historical value remains accepted. The suffix is carried in the
    # existing opaque identity field so a new client can safely connect to an
    # old strict-v1 server without adding an unknown negotiation property.
    client_name: str = Field(default=DATA_AWARE_RUNTIME_CLIENT_NAME, min_length=1)
    max_frame_bytes: StrictInt = Field(default=16 * 1024 * 1024, ge=1024)
    asset_transfer: StrictBool = False
    workspace_transfer: StrictBool = False

    @field_validator("client_name")
    @classmethod
    def validate_client_name(cls, value: str) -> str:
        return require_trimmed(value, "Runtime Wire clientName")

    @field_validator("supported_runtime_api_versions")
    @classmethod
    def validate_versions(
        cls,
        value: tuple[RuntimeApiVersion, ...],
    ) -> tuple[RuntimeApiVersion, ...]:
        if len(value) != len(set(value)):
            raise ValueError("supportedRuntimeApiVersions must not contain duplicates")
        return value

    @model_validator(mode="after")
    def validate_transfers(self) -> RuntimeNegotiateParams:
        if self.workspace_transfer and not self.asset_transfer:
            raise ValueError("workspaceTransfer requires assetTransfer")
        return self


class RuntimeNegotiateResult(ContractModel):
    model_config = RuntimeNegotiateParams.model_config

    wire_api_version: RuntimeWireApiVersion = RUNTIME_WIRE_API_VERSION
    runtime_api_version: RuntimeApiVersion = RUNTIME_API_VERSION
    max_frame_bytes: StrictInt = Field(ge=1024)
    asset_transfer: StrictBool = False
    workspace_transfer: StrictBool = False
    descriptor: RuntimeDescriptor

    @model_validator(mode="after")
    def validate_negotiation(self) -> RuntimeNegotiateResult:
        if self.workspace_transfer and not self.asset_transfer:
            raise ValueError("workspaceTransfer requires assetTransfer")
        if self.runtime_api_version != self.descriptor.runtime_api_version:
            raise ValueError("negotiated Runtime API version must match descriptor")
        return self


class AssetReadParams(ContractModel):
    asset_id: str = Field(min_length=1)
    offset: StrictInt = Field(default=0, ge=0)
    max_bytes: StrictInt = Field(default=512 * 1024, ge=1, le=4 * 1024 * 1024)

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "Asset read assetId")


class AssetReadResult(ContractModel):
    asset: AssetRef
    offset: StrictInt = Field(ge=0)
    data_base64: str
    eof: StrictBool


class WorkspaceSnapshot(ContractModel):
    asset_id: str = Field(min_length=1)

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str) -> str:
        return require_trimmed(value, "Workspace snapshot assetId")


class SessionOpenParams(ContractModel):
    spec: RuntimeSessionSpec
    workspace_snapshot: WorkspaceSnapshot | None = None


class RuntimeAuthenticateParams(ContractModel):
    token: str = Field(min_length=1)

    @field_validator("token")
    @classmethod
    def validate_token(cls, value: str) -> str:
        return require_trimmed(value, "Runtime authentication token")


class RuntimeAuthenticateResult(ContractModel):
    authenticated: Literal[True] = True

    @field_validator("authenticated", mode="before")
    @classmethod
    def validate_authenticated(cls, value: object) -> object:
        if value is not True:
            raise ValueError("authenticated must be true")
        return value


class SessionOpenResult(ContractModel):
    session: RuntimeSessionRef


class SessionCloseParams(ContractModel):
    session: RuntimeSessionRef


class SessionCloseResult(ContractModel):
    workspace_snapshot: WorkspaceSnapshot | None = None


class ExecutionStartParams(ContractModel):
    request: ExecutionRequest


class ExecutionAccepted(ContractModel):
    execution_id: str = Field(min_length=1)
    accepted: Literal[True] = True

    @field_validator("accepted", mode="before")
    @classmethod
    def validate_accepted(cls, value: object) -> object:
        if value is not True:
            raise ValueError("accepted must be true")
        return value

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str) -> str:
        return require_trimmed(value, "Accepted executionId")


class ExecutionToolResultParams(ContractModel):
    execution_id: str = Field(min_length=1)
    result: ToolResult
    workspace_snapshot: WorkspaceSnapshot | None = None

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str) -> str:
        return require_trimmed(value, "Tool result executionId")


class ExecutionInteractionResponseParams(ContractModel):
    execution_id: str = Field(min_length=1)
    response: InteractionResponse

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str) -> str:
        return require_trimmed(value, "Interaction response executionId")


class ExecutionSteerParams(ContractModel):
    execution_id: str = Field(min_length=1)
    input: tuple[ContentBlock, ...] = Field(min_length=1)

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str) -> str:
        return require_trimmed(value, "Steer executionId")


class ExecutionCancelParams(ContractModel):
    execution_id: str = Field(min_length=1)
    reason: CancelReason

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str) -> str:
        return require_trimmed(value, "Cancel executionId")


class RuntimeEventNotification(ContractModel):
    event: RuntimeEvent
    workspace_snapshot: WorkspaceSnapshot | None = None
