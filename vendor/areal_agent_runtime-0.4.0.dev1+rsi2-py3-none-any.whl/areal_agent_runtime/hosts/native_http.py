"""Native HTTP/SSE Host for container and embedded deployments."""

import json
from dataclasses import dataclass
from typing import Any

from areal_agent_runtime.application import ARealAgentRuntime
from areal_agent_runtime.compatibility import (
    dump_event_api_v1,
    dump_product_run_snapshot_v1,
    dump_runtime_descriptor_v1,
)
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.product import (
    CancelRunCommand,
    StartRunCommand,
    SteerRunCommand,
    SubmitInteractionCommand,
)


@dataclass(frozen=True, slots=True)
class NativeHttpHostConfig:
    max_asset_bytes: int = 32 * 1024 * 1024
    max_request_bytes: int = 32 * 1024 * 1024
    title: str = "ARealAgentRuntime Runtime"

    def __post_init__(self) -> None:
        for name, value in (
            ("max_asset_bytes", self.max_asset_bytes),
            ("max_request_bytes", self.max_request_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if not isinstance(self.title, str) or not self.title.strip():
            raise ValueError("title must not be empty")


def create_http_app(
    application: ARealAgentRuntime,
    *,
    asset_store: AssetStorePort | None = None,
    config: NativeHttpHostConfig | None = None,
):
    """Create a FastAPI projection without leaking HTTP types into Application."""

    try:
        from fastapi import FastAPI, Request
        from fastapi.exceptions import RequestValidationError
        from fastapi.responses import JSONResponse, StreamingResponse
    except ImportError as exc:  # pragma: no cover - optional dependency guard
        raise RuntimeError("Install areal-agent-runtime[api] to use the Native HTTP Host") from exc

    effective = config or NativeHttpHostConfig()
    app = FastAPI(title=effective.title)
    app.add_middleware(_RequestBodyLimitMiddleware, max_bytes=effective.max_request_bytes)

    @app.exception_handler(ContractError)
    async def contract_error(_request: Request, exc: ContractError):
        status = {
            ErrorCategory.INVALID_REQUEST: 400,
            ErrorCategory.AUTHENTICATION: 401,
            ErrorCategory.PERMISSION: 403,
            ErrorCategory.NOT_FOUND: 404,
            ErrorCategory.CONFLICT: 409,
            ErrorCategory.RATE_LIMIT: 429,
            ErrorCategory.TIMEOUT: 504,
            ErrorCategory.UNAVAILABLE: 503,
        }.get(exc.info.category, 500)
        if exc.info.code == "REQUEST_TOO_LARGE":
            status = 413
        return JSONResponse(
            status_code=status,
            content={"error": exc.info.model_dump(mode="json", by_alias=True)},
        )

    @app.exception_handler(RequestValidationError)
    async def request_validation_error(_request: Request, _exc: RequestValidationError):
        info = ErrorInfo(
            code="REQUEST_INVALID",
            category=ErrorCategory.INVALID_REQUEST,
            message="Request does not match the Product API contract",
        )
        return JSONResponse(status_code=400, content={"error": info.model_dump(mode="json", by_alias=True)})

    @app.get("/healthz")
    async def health() -> dict[str, str]:
        return {"status": "healthy"}

    @app.get("/readyz")
    async def ready():
        runtimes = await application.list_runtimes()
        return {"ready": bool(runtimes), "runtimes": len(runtimes)}

    @app.get("/v1/capabilities")
    async def capabilities():
        runtimes = await application.list_runtimes()
        return {
            "profiles": [
                profile.model_dump(mode="json", by_alias=True)
                for profile in application.list_profiles()
            ],
            "runtimes": [dump_runtime_descriptor_v1(item) for item in runtimes],
        }

    @app.get("/v1/profiles")
    async def profiles():
        return {
            "data": [profile.model_dump(mode="json", by_alias=True) for profile in application.list_profiles()]
        }

    @app.get("/v1/runtimes")
    async def runtimes():
        descriptors = await application.list_runtimes()
        return {"data": [dump_runtime_descriptor_v1(item) for item in descriptors]}

    @app.post("/v1/assets", status_code=201)
    async def upload_asset(request: Request):
        if asset_store is None:
            return JSONResponse(status_code=501, content={"error": {"code": "ASSET_STORE_DISABLED"}})
        declared_length = request.headers.get("content-length")
        if declared_length is not None:
            try:
                parsed_length = int(declared_length)
            except ValueError:
                return JSONResponse(status_code=400, content={"error": {"code": "ASSET_LENGTH_INVALID"}})
            if parsed_length < 0:
                return JSONResponse(status_code=400, content={"error": {"code": "ASSET_LENGTH_INVALID"}})
            if parsed_length == 0:
                return JSONResponse(status_code=400, content={"error": {"code": "ASSET_EMPTY"}})
            if parsed_length > effective.max_asset_bytes:
                return JSONResponse(status_code=413, content={"error": {"code": "ASSET_TOO_LARGE"}})
        media_type = request.headers.get("content-type", "application/octet-stream").split(";", 1)[0].strip().lower()
        if not media_type or len(media_type) > 255 or any(character.isspace() for character in media_type):
            return JSONResponse(status_code=400, content={"error": {"code": "ASSET_MEDIA_TYPE_INVALID"}})

        stream = request.stream()
        first = b""
        async for candidate in stream:
            if candidate:
                first = candidate
                break
        if not first:
            return JSONResponse(status_code=400, content={"error": {"code": "ASSET_EMPTY"}})
        if len(first) > effective.max_asset_bytes:
            return JSONResponse(status_code=413, content={"error": {"code": "ASSET_TOO_LARGE"}})

        async def chunks():
            total = len(first)
            yield first
            async for chunk in stream:
                if not chunk:
                    continue
                total += len(chunk)
                if total > effective.max_asset_bytes:
                    raise _AssetUploadTooLarge
                yield chunk

        try:
            ref = await asset_store.put(
                chunks(),
                media_type=media_type,
                metadata={"source": "native-http"},
            )
        except _AssetUploadTooLarge:
            return JSONResponse(status_code=413, content={"error": {"code": "ASSET_TOO_LARGE"}})
        return ref.model_dump(mode="json", by_alias=True)

    @app.post("/v1/runs", status_code=202)
    async def start_run(command: StartRunCommand):
        ref = await application.start_run(command)
        return ref.model_dump(mode="json", by_alias=True)

    @app.get("/v1/runs/{run_id}")
    async def get_run(run_id: str):
        snapshot = await application.get_run(run_id)
        return dump_product_run_snapshot_v1(snapshot)

    @app.get("/v1/runs/{run_id}/events")
    async def stream_events(run_id: str, after: int | None = None):
        await application.get_run(run_id)

        async def event_stream():
            async for event in application.stream_events(run_id, after):
                wire_event = dump_event_api_v1(event)
                payload = json.dumps(
                    wire_event,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                # Keep the SSE event name and JSON payload type on the same
                # frozen v1 projection.  A new internal event must not leak
                # through the SSE header after its body was down-projected.
                yield f"id: {event.sequence}\nevent: {wire_event['type']}\ndata: {payload}\n\n"

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    @app.post("/v1/runs/{run_id}/interactions", status_code=202)
    async def submit_interaction(run_id: str, command: SubmitInteractionCommand):
        _require_same_run(run_id, command.run_id)
        await application.submit_interaction(command)
        return {"accepted": True}

    @app.post("/v1/runs/{run_id}/steer", status_code=202)
    async def steer_run(run_id: str, command: SteerRunCommand):
        _require_same_run(run_id, command.run_id)
        await application.steer_run(command)
        return {"accepted": True}

    @app.post("/v1/runs/{run_id}/cancel", status_code=202)
    async def cancel_run(run_id: str, command: CancelRunCommand):
        _require_same_run(run_id, command.run_id)
        await application.cancel_run(command)
        return {"accepted": True}

    return app


def _require_same_run(path_run_id: str, body_run_id: str) -> None:
    if path_run_id != body_run_id:
        raise ContractError(
            ErrorInfo(
                code="RUN_ID_MISMATCH",
                category=ErrorCategory.INVALID_REQUEST,
                message="Path runId does not match request body runId",
            )
        )


class _AssetUploadTooLarge(Exception):
    pass


class _RequestBodyLimitMiddleware:
    """Bound Product JSON bodies before FastAPI allocates or parses them."""

    def __init__(self, app: Any, *, max_bytes: int) -> None:
        self._app = app
        self._max_bytes = max_bytes

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if (
            scope.get("type") != "http"
            or scope.get("method") not in {"POST", "PUT", "PATCH"}
            or scope.get("path") == "/v1/assets"
        ):
            await self._app(scope, receive, send)
            return

        content_lengths = [
            value
            for name, value in scope.get("headers", ())
            if name.lower() == b"content-length"
        ]
        if content_lengths:
            try:
                if len(content_lengths) != 1:
                    raise ValueError
                declared = int(content_lengths[0].decode("ascii"))
                if declared < 0:
                    raise ValueError
            except (UnicodeDecodeError, ValueError):
                await self._reject(send, 400, "REQUEST_LENGTH_INVALID", "Content-Length is invalid")
                return
            if declared > self._max_bytes:
                await self._reject(send, 413, "REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
                return

        body = bytearray()
        while True:
            message = await receive()
            if message.get("type") == "http.disconnect":
                return
            if message.get("type") != "http.request":
                continue
            body.extend(message.get("body", b""))
            if len(body) > self._max_bytes:
                await self._reject(send, 413, "REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
                return
            if not message.get("more_body", False):
                break

        if self._is_product_json_route(str(scope.get("path") or "")):
            try:
                json.loads(bytes(body), parse_constant=_reject_json_constant)
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError, RecursionError):
                await self._reject(send, 400, "REQUEST_JSON_INVALID", "request body must be valid JSON")
                return

        delivered = False

        async def replay() -> dict[str, Any]:
            nonlocal delivered
            if not delivered:
                delivered = True
                return {"type": "http.request", "body": bytes(body), "more_body": False}
            return await receive()

        await self._app(scope, replay, send)

    @staticmethod
    def _is_product_json_route(path: str) -> bool:
        if path == "/v1/runs":
            return True
        return path.startswith("/v1/runs/") and path.rsplit("/", 1)[-1] in {
            "interactions",
            "steer",
            "cancel",
        }

    @staticmethod
    async def _reject(send: Any, status: int, code: str, message: str) -> None:
        info = ErrorInfo(code=code, category=ErrorCategory.INVALID_REQUEST, message=message)
        body = json.dumps(
            {"error": info.model_dump(mode="json", by_alias=True)},
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


def _reject_json_constant(_value: str) -> None:
    raise ValueError("non-finite JSON numbers are not accepted")
