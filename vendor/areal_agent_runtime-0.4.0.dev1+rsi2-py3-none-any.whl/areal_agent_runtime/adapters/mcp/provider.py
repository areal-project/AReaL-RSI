"""Generic MCP to canonical ToolProviderPort translation."""

from __future__ import annotations

import asyncio
import base64
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Protocol
from urllib.parse import urlsplit

from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    FileRefBlock,
    ImageRefBlock,
    JsonBlock,
    TextBlock,
)
from areal_agent_runtime.contracts.environment import McpProviderBinding, McpTransport, SecretRef
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import (
    HealthStatus,
    ToolCall,
    ToolExecution,
    ToolResult,
    ToolSpec,
)

_SERVER_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
_HEADER_NAME_RE = re.compile(r"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")
_MAX_TOOL_NAME_CHARS = 512
_MAX_TOOL_DESCRIPTION_CHARS = 64 * 1024
_MAX_TOOL_SCHEMA_BYTES = 1024 * 1024
_MAX_JSON_DEPTH = 64


class McpClient(Protocol):
    async def list_tools(self) -> tuple[object, ...]: ...

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> object: ...


@dataclass(frozen=True, slots=True)
class GenericMcpConfig:
    url: str
    server_name: str = "mcp"
    headers: dict[str, str] = field(default_factory=dict, repr=False)
    allowed_tools: tuple[str, ...] = ()
    timeout_seconds: float = 120.0
    verify_tls: bool = True
    secret_refs: tuple[SecretRef, ...] = ()
    max_tools: int = 1024
    max_content_items: int = 256
    max_result_bytes: int = 16 * 1024 * 1024
    max_asset_bytes: int = 8 * 1024 * 1024

    def __post_init__(self) -> None:
        if (
            not isinstance(self.url, str)
            or not self.url
            or self.url != self.url.strip()
            or len(self.url) > 4096
        ):
            raise ValueError("MCP url must be a non-empty, trimmed URL")
        try:
            parsed = urlsplit(self.url)
            port = parsed.port
        except ValueError as exc:
            raise ValueError("MCP url is invalid") from exc
        if (
            parsed.scheme not in {"http", "https"}
            or parsed.hostname is None
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
            or port is not None and not 1 <= port <= 65535
        ):
            raise ValueError("MCP url must be a credential-free HTTP(S) endpoint")
        if not isinstance(self.server_name, str) or _SERVER_NAME_RE.fullmatch(self.server_name) is None:
            raise ValueError("MCP server_name must be a canonical identifier")
        if not isinstance(self.headers, dict) or any(
            not isinstance(key, str)
            or _HEADER_NAME_RE.fullmatch(key) is None
            or not isinstance(value, str)
            or "\r" in value
            or "\n" in value
            for key, value in self.headers.items()
        ):
            raise ValueError("MCP headers must contain safe HTTP header names and values")
        if (
            not isinstance(self.allowed_tools, tuple)
            or any(
                not isinstance(item, str)
                or not item
                or item != item.strip()
                or len(item) > _MAX_TOOL_NAME_CHARS
                for item in self.allowed_tools
            )
            or len(self.allowed_tools) != len(set(self.allowed_tools))
        ):
            raise ValueError("MCP allowed_tools must contain unique non-empty strings")
        if (
            isinstance(self.timeout_seconds, bool)
            or not isinstance(self.timeout_seconds, (int, float))
            or not math.isfinite(self.timeout_seconds)
            or self.timeout_seconds <= 0
        ):
            raise ValueError("MCP timeout_seconds must be finite and positive")
        if not isinstance(self.verify_tls, bool):
            raise ValueError("MCP verify_tls must be a boolean")
        if not isinstance(self.secret_refs, tuple) or any(
            not isinstance(item, SecretRef) for item in self.secret_refs
        ):
            raise ValueError("MCP secret_refs must contain SecretRef values")
        secret_names = [item.name for item in self.secret_refs]
        if len(secret_names) != len(set(secret_names)):
            raise ValueError("MCP secret_refs must have unique names")
        for name, value in (
            ("max_tools", self.max_tools),
            ("max_content_items", self.max_content_items),
            ("max_result_bytes", self.max_result_bytes),
            ("max_asset_bytes", self.max_asset_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"MCP {name} must be a positive integer")
        if self.max_asset_bytes > self.max_result_bytes:
            raise ValueError("MCP max_asset_bytes cannot exceed max_result_bytes")


class OfficialStreamableHttpMcpClient:
    """Small official MCP SDK binding; no MCP SDK objects cross this Adapter."""

    def __init__(self, config: GenericMcpConfig) -> None:
        self._config = config

    async def list_tools(self) -> tuple[object, ...]:
        async with asyncio.timeout(self._config.timeout_seconds):
            async with self._http_client() as http_client:
                from mcp import ClientSession
                from mcp.client.streamable_http import streamable_http_client

                async with streamable_http_client(
                    self._config.url,
                    http_client=http_client,
                ) as streams:
                    read, write = streams[:2]
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        response = await session.list_tools()
                        return tuple(response.tools)

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> object:
        async with asyncio.timeout(self._config.timeout_seconds):
            async with self._http_client() as http_client:
                from mcp import ClientSession
                from mcp.client.streamable_http import streamable_http_client

                async with streamable_http_client(
                    self._config.url,
                    http_client=http_client,
                ) as streams:
                    read, write = streams[:2]
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        return await session.call_tool(name, arguments=arguments)

    def _http_client(self):
        try:
            import httpx2
        except ImportError as exc:  # pragma: no cover - optional dependency guard
            raise RuntimeError("Install areal-agent-runtime[mcp] to use the MCP adapter") from exc
        return httpx2.AsyncClient(
            headers=self._config.headers,
            timeout=self._config.timeout_seconds,
            verify=self._config.verify_tls,
            follow_redirects=False,
            trust_env=False,
        )


class GenericMcpToolProvider:
    """Expose one installed MCP server as canonical, permissioned tools."""

    def __init__(
        self,
        client: McpClient,
        *,
        server_name: str,
        allowed_tools: tuple[str, ...] = (),
        asset_store: AssetStorePort | None = None,
        permissions: tuple[str, ...] | None = None,
        binding: McpProviderBinding | None = None,
        max_tools: int = 1024,
        max_content_items: int = 256,
        max_result_bytes: int = 16 * 1024 * 1024,
        max_asset_bytes: int = 8 * 1024 * 1024,
    ) -> None:
        if not isinstance(server_name, str) or _SERVER_NAME_RE.fullmatch(server_name) is None:
            raise ValueError("MCP server_name must be a canonical identifier")
        for name, value in (
            ("max_tools", max_tools),
            ("max_content_items", max_content_items),
            ("max_result_bytes", max_result_bytes),
            ("max_asset_bytes", max_asset_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"MCP {name} must be a positive integer")
        if max_asset_bytes > max_result_bytes:
            raise ValueError("MCP max_asset_bytes cannot exceed max_result_bytes")
        if (
            not isinstance(allowed_tools, tuple)
            or any(
                not isinstance(item, str)
                or not item
                or item != item.strip()
                or len(item) > _MAX_TOOL_NAME_CHARS
                for item in allowed_tools
            )
            or len(allowed_tools) != len(set(allowed_tools))
        ):
            raise ValueError("MCP allowed_tools must contain unique canonical names")
        if permissions is not None and (
            not isinstance(permissions, tuple)
            or any(
                not isinstance(item, str) or not item or item != item.strip()
                for item in permissions
            )
            or len(permissions) != len(set(permissions))
        ):
            raise ValueError("MCP permissions must contain unique trimmed names")
        if binding is not None and binding.server_id != server_name:
            raise ValueError("MCP binding serverId must match server_name")
        self._client = client
        self._server_name = server_name
        self._allowed = frozenset(allowed_tools)
        self._assets = asset_store
        self._permissions = (
            permissions
            if permissions is not None
            else (
                ("network.mcp", "asset.write")
                if asset_store is not None
                else ("network.mcp",)
            )
        )
        self._binding = binding
        self._max_tools = max_tools
        self._max_content_items = max_content_items
        self._max_result_bytes = max_result_bytes
        self._max_asset_bytes = max_asset_bytes
        self._raw_names: dict[str, str] = {}
        self._catalog: tuple[ToolSpec, ...] | None = None
        self._catalog_lock = asyncio.Lock()

    def mcp_binding(self) -> McpProviderBinding:
        if self._binding is None:
            raise RuntimeError("GenericMcpToolProvider has no installed source binding")
        return self._binding

    async def list_tools(self) -> tuple[ToolSpec, ...]:
        if self._catalog is not None:
            return self._catalog
        async with self._catalog_lock:
            if self._catalog is not None:
                return self._catalog
            discovered = await self._client.list_tools()
            if not isinstance(discovered, (list, tuple)):
                raise _McpProtocolError("MCP tools/list did not return a tool list")
            if len(discovered) > self._max_tools:
                raise _McpProtocolError(f"MCP tools/list exceeds {self._max_tools} tools")
            tools: list[ToolSpec] = []
            raw_names: dict[str, str] = {}
            matched_allowed: set[str] = set()
            for item in discovered:
                raw_name_value = _field(item, "name")
                if (
                    not isinstance(raw_name_value, str)
                    or not raw_name_value
                    or raw_name_value != raw_name_value.strip()
                    or len(raw_name_value) > _MAX_TOOL_NAME_CHARS
                    or any(ord(character) < 32 or ord(character) == 127 for character in raw_name_value)
                ):
                    raise _McpProtocolError("MCP tools/list returned an invalid tool name")
                raw_name = raw_name_value
                canonical_name = self._canonical_name(raw_name)
                matches = {raw_name, canonical_name}.intersection(self._allowed)
                if self._allowed and not matches:
                    continue
                matched_allowed.update(matches)
                schema = _field(item, "inputSchema")
                if schema is None:
                    schema = _field(item, "input_schema")
                if schema is None:
                    schema = {"type": "object"}
                if not isinstance(schema, dict):
                    raise _McpProtocolError(f"MCP tool {raw_name} has a non-object input schema")
                normalized_schema = _jsonable(
                    schema,
                    max_bytes=_MAX_TOOL_SCHEMA_BYTES,
                    label=f"MCP tool schema for {raw_name}",
                )
                if not isinstance(normalized_schema, dict):
                    raise _McpProtocolError(f"MCP tool {raw_name} has a non-object input schema")
                description_value = _field(item, "description")
                if description_value is None:
                    description = ""
                elif isinstance(description_value, str) and len(description_value) <= _MAX_TOOL_DESCRIPTION_CHARS:
                    description = description_value
                else:
                    raise _McpProtocolError(f"MCP tool {raw_name} has an invalid description")
                if canonical_name in raw_names:
                    raise _McpProtocolError(f"MCP tools/list repeats canonical tool {canonical_name}")
                raw_names[canonical_name] = raw_name
                tools.append(
                    ToolSpec(
                        name=canonical_name,
                        description=description,
                        input_schema=normalized_schema,
                        execution=ToolExecution.REMOTE,
                        permissions=self._permissions,
                    )
                )
            missing_allowed = sorted(self._allowed.difference(matched_allowed))
            if missing_allowed:
                raise _McpProtocolError(
                    "MCP tools/list omitted configured allowed tools: " + ", ".join(missing_allowed)
                )
            self._raw_names = raw_names
            self._catalog = tuple(sorted(tools, key=lambda tool: tool.name))
            return self._catalog

    async def invoke(self, call: ToolCall) -> ToolResult:
        try:
            await self.list_tools()
            raw_name = self._raw_names.get(call.name)
            if raw_name is None:
                return ToolResult(
                    call_id=call.call_id,
                    error=ErrorInfo(
                        code="MCP_TOOL_NOT_FOUND",
                        category=ErrorCategory.NOT_FOUND,
                        message=f"MCP tool is not discovered or allowed: {call.name}",
                    ),
                )
            response = await self._client.call_tool(raw_name, call.arguments)
            budget = _ResultBudget(self._max_result_bytes)
            content = await self._content(response, budget)
            structured = _field(response, "structuredContent")
            if structured is None:
                structured = _field(response, "structured_content")
            structured = _jsonable(
                structured,
                max_bytes=budget.remaining,
                label="MCP structured result",
            )
            budget.consume(_json_size(structured), "MCP structured result")
            is_error_value = _field(response, "isError")
            if is_error_value is None:
                is_error_value = _field(response, "is_error")
            if is_error_value is None:
                is_error = False
            elif isinstance(is_error_value, bool):
                is_error = is_error_value
            else:
                raise _McpProtocolError("MCP tools/call returned a non-boolean isError")
            return ToolResult(
                call_id=call.call_id,
                content=content,
                value=structured,
                error=(
                    ErrorInfo(
                        code="MCP_TOOL_FAILED",
                        category=ErrorCategory.INTERNAL,
                        message=(
                            _content_text(content)
                            or f"Remote MCP tool failed: {call.name}"
                        ),
                    )
                    if is_error
                    else None
                ),
            )
        except _McpProtocolError as exc:
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="MCP_PROTOCOL_INVALID",
                    category=ErrorCategory.PROTOCOL,
                    message=str(exc),
                    details={"server": self._server_name, "tool": call.name},
                ),
            )
        except Exception as exc:
            return ToolResult(
                call_id=call.call_id,
                error=ErrorInfo(
                    code="MCP_TRANSPORT_FAILED",
                    category=ErrorCategory.UNAVAILABLE,
                    message=str(exc) or type(exc).__name__,
                    retryable=True,
                    details={"server": self._server_name, "tool": call.name},
                ),
            )

    async def health(self) -> HealthStatus:
        try:
            tools = await self.list_tools()
        except Exception as exc:
            return HealthStatus(
                status="unhealthy",
                details={"server": self._server_name, "reason": str(exc) or type(exc).__name__},
            )
        return HealthStatus(
            status="healthy",
            details={"server": self._server_name, "tools": len(tools)},
        )

    async def refresh(self) -> None:
        async with self._catalog_lock:
            self._catalog = None
            self._raw_names.clear()

    async def _content(self, response: object, budget: _ResultBudget) -> tuple[object, ...]:
        raw_content = _field(response, "content")
        if raw_content is None:
            return ()
        if not isinstance(raw_content, (list, tuple)):
            raise _McpProtocolError("MCP tools/call returned non-list content")
        if len(raw_content) > self._max_content_items:
            raise _McpProtocolError(
                f"MCP tools/call exceeds {self._max_content_items} content items"
            )
        blocks: list[object] = []
        for item in raw_content:
            kind_value = _field(item, "type")
            if not isinstance(kind_value, str) or not kind_value:
                raise _McpProtocolError("MCP content item has no valid type")
            kind = kind_value
            if kind == "text":
                text = _field(item, "text")
                if not isinstance(text, str):
                    raise _McpProtocolError("MCP text content must contain a string")
                budget.consume(len(text.encode("utf-8")), "MCP text content")
                blocks.append(TextBlock(text=text))
            elif kind in {"image", "audio"}:
                data = _field(item, "data")
                media_type_value = _field(item, "mimeType") or _field(item, "mime_type")
                if media_type_value is not None and not isinstance(media_type_value, str):
                    raise _McpProtocolError("MCP media content has an invalid MIME type")
                media_type = media_type_value or ""
                if not isinstance(data, str):
                    raise _McpProtocolError("MCP media content must contain base64 data")
                if self._assets is None:
                    normalized = _jsonable(
                        item,
                        max_bytes=budget.remaining,
                        label="MCP media content",
                    )
                    budget.consume(_json_size(normalized), "MCP media content")
                    blocks.append(JsonBlock(value=normalized, schema_name="mcp.content"))
                    continue
                raw = self._decode_asset(data)
                budget.consume(len(raw), "MCP media asset")
                ref = await self._assets.put(
                    _one_chunk(raw),
                    media_type=media_type or ("image/png" if kind == "image" else "audio/mpeg"),
                    metadata={"source": "mcp", "server": self._server_name},
                )
                if kind == "image":
                    blocks.append(ImageRefBlock(asset_id=ref.asset_id, media_type=ref.media_type))
                else:
                    blocks.append(AudioRefBlock(asset_id=ref.asset_id, media_type=ref.media_type))
            elif kind == "resource":
                resource = _field(item, "resource")
                text = _field(resource, "text")
                blob = _field(resource, "blob")
                media_type_value = _field(resource, "mimeType") or _field(resource, "mime_type")
                if media_type_value is not None and not isinstance(media_type_value, str):
                    raise _McpProtocolError("MCP resource has an invalid MIME type")
                media_type = media_type_value or "application/octet-stream"
                if isinstance(text, str) and isinstance(blob, str):
                    raise _McpProtocolError("MCP resource cannot contain both text and blob")
                if isinstance(text, str):
                    budget.consume(len(text.encode("utf-8")), "MCP text resource")
                    blocks.append(TextBlock(text=text))
                elif isinstance(blob, str) and self._assets is not None:
                    raw = self._decode_asset(blob)
                    budget.consume(len(raw), "MCP blob resource")
                    ref = await self._assets.put(
                        _one_chunk(raw),
                        media_type=media_type,
                        metadata={"source": "mcp", "server": self._server_name},
                    )
                    blocks.append(FileRefBlock(asset_id=ref.asset_id, media_type=ref.media_type))
                else:
                    normalized = _jsonable(
                        item,
                        max_bytes=budget.remaining,
                        label="MCP resource content",
                    )
                    budget.consume(_json_size(normalized), "MCP resource content")
                    blocks.append(JsonBlock(value=normalized, schema_name="mcp.resource"))
            else:
                normalized = _jsonable(
                    item,
                    max_bytes=budget.remaining,
                    label="MCP extension content",
                )
                budget.consume(_json_size(normalized), "MCP extension content")
                blocks.append(JsonBlock(value=normalized, schema_name="mcp.content"))
        return tuple(blocks)

    def _decode_asset(self, value: str) -> bytes:
        max_encoded = ((self._max_asset_bytes + 2) // 3) * 4
        if len(value) > max_encoded:
            raise _McpProtocolError(
                f"MCP asset exceeds {self._max_asset_bytes} decoded bytes"
            )
        try:
            raw = base64.b64decode(value, validate=True)
        except (ValueError, TypeError) as exc:
            raise _McpProtocolError("MCP asset is not valid base64") from exc
        if len(raw) > self._max_asset_bytes:
            raise _McpProtocolError(
                f"MCP asset exceeds {self._max_asset_bytes} decoded bytes"
            )
        return raw

    def _canonical_name(self, raw_name: str) -> str:
        prefix = f"mcp__{self._server_name}__"
        canonical = raw_name if raw_name.startswith(prefix) else f"{prefix}{raw_name}"
        if len(canonical) > _MAX_TOOL_NAME_CHARS:
            raise _McpProtocolError("Canonical MCP tool name exceeds the size limit")
        return canonical


def streamable_http_binding(config: GenericMcpConfig) -> McpProviderBinding:
    return McpProviderBinding(
        server_id=config.server_name,
        transport=McpTransport.STREAMABLE_HTTP,
        endpoint=config.url,
        secret_refs=config.secret_refs,
    )


def _field(value: object, name: str) -> object:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def _jsonable(value: object, *, max_bytes: int, label: str) -> Any:
    def normalize(item: object, depth: int, active: set[int]) -> Any:
        if depth > _MAX_JSON_DEPTH:
            raise _McpProtocolError(f"{label} exceeds {_MAX_JSON_DEPTH} JSON levels")
        if item is None or isinstance(item, (str, bool, int)):
            return item
        if isinstance(item, float):
            if not math.isfinite(item):
                raise _McpProtocolError(f"{label} contains a non-finite number")
            return item
        if hasattr(item, "model_dump"):
            item = item.model_dump(mode="json", by_alias=True)
        if not isinstance(item, (dict, list, tuple)):
            raise _McpProtocolError(f"{label} contains a non-JSON value")
        identity = id(item)
        if identity in active:
            raise _McpProtocolError(f"{label} contains a reference cycle")
        active.add(identity)
        try:
            if isinstance(item, dict):
                result: dict[str, Any] = {}
                for key, child in item.items():
                    if not isinstance(key, str):
                        raise _McpProtocolError(f"{label} contains a non-string object key")
                    result[key] = normalize(child, depth + 1, active)
                return result
            return [normalize(child, depth + 1, active) for child in item]
        finally:
            active.remove(identity)

    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 0:
        raise _McpProtocolError(f"{label} exceeds the remaining result budget")
    normalized = normalize(value, 0, set())
    if _json_size(normalized) > max_bytes:
        raise _McpProtocolError(f"{label} exceeds {max_bytes} bytes")
    return normalized


def _json_size(value: object) -> int:
    return len(
        json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
    )


@dataclass(slots=True)
class _ResultBudget:
    remaining: int

    def consume(self, size: int, label: str) -> None:
        if size > self.remaining:
            raise _McpProtocolError(f"{label} exceeds the MCP result byte limit")
        self.remaining -= size


class _McpProtocolError(RuntimeError):
    pass


def _content_text(content: tuple[object, ...]) -> str:
    return "\n".join(block.text for block in content if isinstance(block, TextBlock))


async def _one_chunk(value: bytes):
    yield value
