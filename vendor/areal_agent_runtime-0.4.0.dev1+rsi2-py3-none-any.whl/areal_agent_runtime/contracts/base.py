"""Shared rules for every versioned wire model."""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict

_MEDIA_TYPE = re.compile(
    r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+/[!#$%&'*+.^_`|~0-9A-Za-z-]+"
    r"(?:[ \t]*;[^\r\n]+)?$"
)


def to_camel(value: str) -> str:
    head, *tail = value.split("_")
    return head + "".join(part[:1].upper() + part[1:] for part in tail)


class ContractModel(BaseModel):
    """Immutable, finite-JSON and alias-stable base for protocol DTOs.

    Pydantic's global ``strict=True`` is intentionally not used here because
    JSON arrays must remain valid inputs for tuple-shaped wire fields.  Scalar
    protocol fields use ``StrictBool``/``StrictInt`` at their declarations.
    """

    model_config = ConfigDict(
        allow_inf_nan=False,
        alias_generator=to_camel,
        extra="forbid",
        frozen=True,
        populate_by_name=True,
        revalidate_instances="always",
        serialize_by_alias=True,
    )


def require_trimmed(value: str, field: str) -> str:
    """Reject identifiers that are empty or change when whitespace is trimmed."""

    if not value.strip() or value != value.strip():
        raise ValueError(f"{field} must be non-blank and trimmed")
    if any(ord(character) < 32 or ord(character) == 127 for character in value):
        raise ValueError(f"{field} must not contain control characters")
    return value


def require_optional_trimmed(value: str | None, field: str) -> str | None:
    if value is None:
        return None
    return require_trimmed(value, field)


def require_unique_trimmed(values: tuple[str, ...], field: str) -> tuple[str, ...]:
    for value in values:
        require_trimmed(value, field)
    if len(values) != len(set(values)):
        raise ValueError(f"{field} must not contain duplicates")
    return values


def require_media_type(value: str, *, prefix: str | None = None) -> str:
    """Validate one MIME media type while preserving declared parameters."""

    require_trimmed(value, "mediaType")
    if any(
        ord(character) == 127 or (ord(character) < 32 and character != "\t")
        for character in value
    ):
        raise ValueError("mediaType must not contain control characters")
    if _MEDIA_TYPE.fullmatch(value) is None:
        raise ValueError("mediaType must be a valid MIME media type")
    base_type = value.split(";", 1)[0].strip().lower()
    if prefix is not None and not base_type.startswith(f"{prefix.lower()}/"):
        raise ValueError(f"mediaType must use the {prefix}/ type")
    return value
