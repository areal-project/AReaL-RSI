"""Reference Runtime Adapter with no model or vendor dependency."""

from __future__ import annotations

import asyncio
import time
import weakref
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass

from pydantic import JsonValue, TypeAdapter

from areal_agent_runtime.adapters._identity_index import session_identity_map
from areal_agent_runtime.contracts.content import ContentBlock, TextBlock
from areal_agent_runtime.contracts.data import (
    DataCoverage,
    DetailCoverage,
    MessageCoverage,
    NormalizedUsage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.runtime import (
    CancelReason,
    ExecutionChannel,
    ExecutionRequest,
    HealthStatus,
    InteractionRequest,
    InteractionResponse,
    Modality,
    RuntimeCapabilities,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolResult,
    require_runtime_environment_identity,
    require_same_runtime_session_spec,
    require_session_environment,
)
from areal_agent_runtime.kernel.ids import new_id

ResponseFactory = Callable[[ExecutionRequest], tuple[ContentBlock, ...]]
_CONTENT_BLOCKS = TypeAdapter(tuple[ContentBlock, ...])


@dataclass(frozen=True, slots=True)
class FakeToolRequest:
    name: str
    arguments: dict[str, JsonValue]


@dataclass(frozen=True, slots=True)
class FakeInteractionRequest:
    interaction_id: str
    kind: str
    request: JsonValue
    terminal: bool = False
    commit_barrier: bool = False


def _default_response(request: ExecutionRequest) -> tuple[ContentBlock, ...]:
    return (TextBlock(text=f"fake runtime handled {len(request.input)} content block(s)"),)


class FakeExecutionChannel(ExecutionChannel):
    def __init__(
        self,
        *,
        runtime_instance_id: str,
        request: ExecutionRequest,
        response_factory: ResponseFactory,
        tool_request: FakeToolRequest | None = None,
        interaction_request: FakeInteractionRequest | None = None,
        provider: str = "fake",
        model: str = "fake-model",
        usage: NormalizedUsage | None = None,
        on_finish: Callable[[], None] | None = None,
    ) -> None:
        self._runtime_instance_id = runtime_instance_id
        self._request = request
        self._response_factory = response_factory
        self._tool_request = tool_request
        self._interaction_request = interaction_request
        self._provider = provider
        self._model = model
        self._usage = usage
        self._on_finish = on_finish
        self._cancelled = asyncio.Event()
        self._tool_result_received = asyncio.Event()
        self._interaction_response_received = asyncio.Event()
        self._closed = False
        self._started = False
        self._finished = False
        self._tool_requested = False
        self._active_interaction_id: str | None = None
        self._tool_result: ToolResult | None = None
        self._interaction_response: InteractionResponse | None = None
        self.tool_results: list[ToolResult] = []
        self.interactions: list[InteractionResponse] = []
        self.steers: list[tuple[ContentBlock, ...]] = []

    def events(self) -> AsyncIterator[RuntimeEvent]:
        return self._events()

    async def _events(self) -> AsyncIterator[RuntimeEvent]:
        if self._started:
            raise RuntimeError("Fake execution events may only be consumed once")
        self._started = True
        sequence = 0

        def event(event_type: EventType, data: object) -> RuntimeEvent:
            nonlocal sequence
            item = RuntimeEvent(
                runtime_instance_id=self._runtime_instance_id,
                runtime_sequence=sequence,
                execution_id=self._request.execution_id,
                agent_id=self._request.agent.agent_id,
                parent_agent_id=self._request.agent.parent_agent_id,
                type=event_type,
                data=data,
            )
            sequence += 1
            return item

        try:
            yield event(EventType.EXECUTION_STARTED, {})
            model_call_id = new_id("mcall")
            model_started_at = time.monotonic()
            model_attempt = 1
            yield event(
                EventType.MODEL_CALL_STARTED,
                {
                    "modelCallId": model_call_id,
                    "provider": self._provider,
                    "model": self._model,
                    "attempt": model_attempt,
                },
            )
            await asyncio.sleep(0)
            if self._cancelled.is_set():
                yield event(
                    EventType.MODEL_CALL_FAILED,
                    {
                        "modelCallId": model_call_id,
                        "provider": self._provider,
                        "model": self._model,
                        "attempt": model_attempt,
                        "durationSeconds": time.monotonic() - model_started_at,
                        "error": ErrorInfo(
                            code="FAKE_MODEL_CANCELLED",
                            category=ErrorCategory.CANCELLED,
                            message="Fake model call was cancelled",
                        ).model_dump(mode="json", by_alias=True),
                    },
                )
                yield event(EventType.EXECUTION_FAILED, {"reason": "cancelled"})
                return
            if self._tool_request is not None:
                selected = {tool.name: tool for tool in self._request.tools}
                spec = selected.get(self._tool_request.name)
                self._tool_requested = True
                yield event(
                    EventType.TOOL_REQUESTED,
                    {
                        "callId": "fake-call-1",
                        "name": self._tool_request.name,
                        "arguments": self._tool_request.arguments,
                        "execution": spec.execution.value if spec is not None else "application",
                        "modelCallId": model_call_id,
                    },
                )
                yield event(
                    EventType.MODEL_CALL_COMPLETED,
                    {
                        "modelCallId": model_call_id,
                        "provider": self._provider,
                        "model": self._model,
                        "attempt": model_attempt,
                        "finishReason": "tool_call",
                        "durationSeconds": time.monotonic() - model_started_at,
                    },
                )
                await self._wait_for_signal_or_cancel(self._tool_result_received)
                if self._cancelled.is_set():
                    yield event(EventType.EXECUTION_FAILED, {"reason": "cancelled"})
                    return
                # A tool continuation is a new logical model call, not a retry
                # of the prior provider request.
                model_attempt = 1
                model_call_id = new_id("mcall")
                model_started_at = time.monotonic()
                yield event(
                    EventType.MODEL_CALL_STARTED,
                    {
                        "modelCallId": model_call_id,
                        "provider": self._provider,
                        "model": self._model,
                        "attempt": model_attempt,
                    },
                )
            if self._interaction_request is not None:
                interaction = InteractionRequest(
                    interaction_id=self._interaction_request.interaction_id,
                    kind=self._interaction_request.kind,
                    request=self._interaction_request.request,
                    terminal=self._interaction_request.terminal,
                    commit_barrier=self._interaction_request.commit_barrier,
                )
                self._active_interaction_id = interaction.interaction_id
                yield event(
                    EventType.MODEL_CALL_COMPLETED,
                    {
                        "modelCallId": model_call_id,
                        "provider": self._provider,
                        "model": self._model,
                        "attempt": model_attempt,
                        "finishReason": "interaction",
                        "durationSeconds": time.monotonic() - model_started_at,
                    },
                )
                yield event(
                    EventType.INTERACTION_REQUIRED,
                    interaction.model_dump(mode="json", by_alias=True),
                )
                if interaction.terminal:
                    self._active_interaction_id = None
                    yield event(EventType.EXECUTION_COMPLETED, {"finishReason": "interaction"})
                    return
                await self._wait_for_signal_or_cancel(self._interaction_response_received)
                if self._cancelled.is_set():
                    yield event(EventType.EXECUTION_FAILED, {"reason": "cancelled"})
                    return
                self._active_interaction_id = None
                yield event(
                    EventType.INTERACTION_RESOLVED,
                    {"interactionId": interaction.interaction_id},
                )
                # A post-interaction continuation is likewise a new call.
                model_attempt = 1
                model_call_id = new_id("mcall")
                model_started_at = time.monotonic()
                yield event(
                    EventType.MODEL_CALL_STARTED,
                    {
                        "modelCallId": model_call_id,
                        "provider": self._provider,
                        "model": self._model,
                        "attempt": model_attempt,
                    },
                )
            content = _CONTENT_BLOCKS.validate_python(self._response_factory(self._request))
            message_id = new_id("msg")
            yield event(
                EventType.MESSAGE_COMPLETED,
                {
                    "content": [
                        block.model_dump(mode="json", by_alias=True) for block in content
                    ],
                    "messageId": message_id,
                    "modelCallId": model_call_id,
                    "role": "assistant",
                },
            )
            if self._usage is not None:
                yield event(
                    EventType.USAGE_UPDATED,
                    {
                        "modelCallId": model_call_id,
                        "usage": self._usage.model_dump(mode="json", by_alias=True),
                    },
                )
            yield event(
                EventType.MODEL_CALL_COMPLETED,
                {
                    "modelCallId": model_call_id,
                    "provider": self._provider,
                    "model": self._model,
                    "attempt": model_attempt,
                    "finishReason": "stop",
                    "durationSeconds": time.monotonic() - model_started_at,
                },
            )
            yield event(EventType.EXECUTION_COMPLETED, {})
        finally:
            self._finish()

    async def _wait_for_signal_or_cancel(self, signal: asyncio.Event) -> None:
        signal_wait = asyncio.create_task(signal.wait())
        cancel_wait = asyncio.create_task(self._cancelled.wait())
        _done, pending = await asyncio.wait(
            {signal_wait, cancel_wait},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

    def _finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        self._active_interaction_id = None
        if self._on_finish is not None:
            self._on_finish()

    async def send_tool_result(self, result: ToolResult) -> None:
        if not isinstance(result, ToolResult):
            raise TypeError("Fake send_tool_result requires a ToolResult")
        if not self._tool_requested or result.call_id != "fake-call-1":
            raise LookupError(f"Unknown Fake tool call: {result.call_id}")
        if self._tool_result is not None:
            if self._tool_result == result:
                return
            raise ValueError(f"Conflicting Fake tool result: {result.call_id}")
        self._tool_result = result
        self.tool_results.append(result)
        self._tool_result_received.set()

    async def respond(self, response: InteractionResponse) -> None:
        if not isinstance(response, InteractionResponse):
            raise TypeError("Fake respond requires an InteractionResponse")
        if response.interaction_id != self._active_interaction_id:
            raise LookupError(f"Unknown Fake interaction: {response.interaction_id}")
        if self._interaction_response is not None:
            if self._interaction_response == response:
                return
            raise ValueError(f"Conflicting Fake interaction response: {response.interaction_id}")
        self._interaction_response = response
        self.interactions.append(response)
        self._interaction_response_received.set()

    async def steer(self, input: tuple[ContentBlock, ...]) -> None:
        _CONTENT_BLOCKS.validate_python(input)
        if self._finished:
            raise RuntimeError("Fake execution is no longer accepting steer input")
        self.steers.append(input)

    async def cancel(self, reason: CancelReason) -> None:
        if not isinstance(reason, CancelReason):
            raise TypeError("Fake cancel requires a CancelReason")
        self._cancelled.set()

    async def close(self) -> None:
        self._closed = True
        self._cancelled.set()
        self._tool_result_received.set()
        self._interaction_response_received.set()
        self._finish()


class FakeRuntimeAdapter:
    def __init__(
        self,
        *,
        capabilities: RuntimeCapabilities | None = None,
        response_factory: ResponseFactory = _default_response,
        tool_request: FakeToolRequest | None = None,
        interaction_request: FakeInteractionRequest | None = None,
        provider: str = "fake",
        model: str = "fake-model",
        usage: NormalizedUsage | None = None,
    ) -> None:
        self._instance_id = new_id("runtime")
        self._capabilities = capabilities or RuntimeCapabilities(
            input_modalities=(Modality.TEXT, Modality.IMAGE, Modality.AUDIO, Modality.VIDEO, Modality.FILE),
            output_modalities=(Modality.TEXT,),
            tool_calling=True,
            application_tool_bridge=True,
            cancel=True,
            steer=True,
            resume=True,
            interaction=True,
            live_interaction=True,
            data_coverage=DataCoverage(
                messages=MessageCoverage.FINAL,
                model_calls=DetailCoverage.FULL,
                tool_calls=(
                    DetailCoverage.FULL if tool_request is not None else DetailCoverage.NONE
                ),
                usage=(UsageCoverage.NORMALIZED if usage is not None else UsageCoverage.NONE),
            ),
        )
        self._response_factory = response_factory
        self._tool_request = tool_request
        self._interaction_request = interaction_request
        self._provider = provider
        self._model = model
        self._usage = usage
        self.sessions: dict[str, RuntimeSessionRef] = {}
        self._session_specs: dict[str, RuntimeSessionSpec] = {}
        self._closed_sessions = session_identity_map()
        self._closing_sessions: set[str] = set()
        self._session_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )
        self._active_channels: dict[str, set[FakeExecutionChannel]] = {}
        self._close_lock = asyncio.Lock()
        self._closing = False
        self._closed = False
        self.session_specs: list[RuntimeSessionSpec] = []
        self.requests: list[ExecutionRequest] = []
        self.channels: list[FakeExecutionChannel] = []

    async def describe(self) -> RuntimeDescriptor:
        return RuntimeDescriptor(
            name="fake",
            adapter_version="1.1.0",
            runtime_version="1.0.0",
            capabilities=self._capabilities,
        )

    async def open_session(self, spec: RuntimeSessionSpec) -> RuntimeSessionRef:
        if self._closing:
            raise RuntimeError("Fake runtime is closing")
        require_runtime_environment_identity(await self.describe(), spec.agent_environment)
        lock = self._session_locks.setdefault(spec.session_id, asyncio.Lock())
        async with lock:
            if self._closing:
                raise RuntimeError("Fake runtime is closing")
            self.session_specs.append(spec)
            existing = self.sessions.get(spec.session_id)
            if existing is not None:
                if spec.session_id in self._closing_sessions:
                    raise RuntimeError(f"Fake session is closing: {spec.session_id}")
                require_same_runtime_session_spec(
                    self._session_specs[spec.session_id],
                    spec,
                )
                return existing
            session = RuntimeSessionRef(
                session_id=spec.session_id,
                runtime_session_id=new_id("fake_session"),
            )
            self.sessions[spec.session_id] = session
            self._session_specs[spec.session_id] = spec
            self._active_channels[spec.session_id] = set()
            return session

    async def execute(self, request: ExecutionRequest) -> ExecutionChannel:
        if self._closing:
            raise RuntimeError("Fake runtime is closing")
        lock = self._session_locks.setdefault(request.session_id, asyncio.Lock())
        async with lock:
            try:
                spec = self._session_specs[request.session_id]
            except KeyError as exc:
                raise LookupError(f"Fake session is not open: {request.session_id}") from exc
            if self._closing or request.session_id in self._closing_sessions:
                raise LookupError(f"Fake session is not open: {request.session_id}")
            require_session_environment(spec, request)
            self.requests.append(request)
            active = self._active_channels[request.session_id]

            def finish() -> None:
                active.discard(channel)

            channel = FakeExecutionChannel(
                runtime_instance_id=self._instance_id,
                request=request,
                response_factory=self._response_factory,
                tool_request=self._tool_request,
                interaction_request=self._interaction_request,
                provider=self._provider,
                model=self._model,
                usage=self._usage,
                on_finish=finish,
            )
            active.add(channel)
            self.channels.append(channel)
            return channel

    async def close_session(self, session: RuntimeSessionRef) -> None:
        lock = self._session_locks.setdefault(session.session_id, asyncio.Lock())
        async with lock:
            existing = self.sessions.get(session.session_id)
            if existing is None:
                if self._closed_sessions.get(session.session_id) == session:
                    return
                raise LookupError("Fake session reference is not owned by this adapter")
            if existing != session:
                raise ValueError("Fake session reference does not match the open session")
            self._closed_sessions[session.session_id] = session
            self._closing_sessions.add(session.session_id)
            errors: list[BaseException] = []
            for channel in tuple(self._active_channels.get(session.session_id, ())):
                try:
                    await channel.close()
                except BaseException as exc:
                    errors.append(exc)
            if not errors and self.sessions.get(session.session_id) == session:
                self.sessions.pop(session.session_id, None)
                self._session_specs.pop(session.session_id, None)
                self._active_channels.pop(session.session_id, None)
                self._closing_sessions.discard(session.session_id)
            if errors:
                raise BaseExceptionGroup("Fake session cleanup failed", errors)

    async def health(self) -> HealthStatus:
        if self._closing:
            return HealthStatus(status="unhealthy", details={"reason": "runtime_closing"})
        return HealthStatus(status="healthy")

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closing = True
            errors: list[BaseException] = []
            for session in tuple(self.sessions.values()):
                try:
                    await self.close_session(session)
                except BaseException as exc:
                    errors.append(exc)
            if errors:
                raise BaseExceptionGroup("Fake runtime cleanup failed", errors)
            self._closed_sessions.close()
            self._closed = True
