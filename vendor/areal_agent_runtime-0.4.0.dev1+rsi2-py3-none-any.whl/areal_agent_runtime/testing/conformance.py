"""Vendor-neutral Runtime Adapter conformance checks."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass

from areal_agent_runtime.contracts.content import ContentBlock, TextBlock
from areal_agent_runtime.contracts.data import (
    CheckpointCoverage,
    CoverageDimensionReport,
    DataCoverage,
    DataCoverageReport,
    DetailCoverage,
    MessageCoverage,
    RawEventCoverage,
    TrainingSignalCoverage,
    UsageCoverage,
)
from areal_agent_runtime.contracts.environment import (
    AgentEnvironmentSnapshot,
    PromptResolutionMode,
    ResolvedResourceSnapshot,
    ResourceCategory,
    ResourceLayer,
    RuntimeIdentitySnapshot,
)
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.runtime import (
    AgentRef,
    AgentRuntimePort,
    ExecutionPolicy,
    ExecutionRequest,
    Modality,
    RuntimeCheckpoint,
    RuntimeCheckpointPort,
    RuntimeDescriptor,
    RuntimeEvent,
    RuntimeSessionRef,
    RuntimeSessionSpec,
    ToolExecution,
    ToolResult,
    UsageUpdatedEventData,
    WorkspaceRef,
    runtime_session_binding_digest,
)
from areal_agent_runtime.contracts.version import RUNTIME_API_VERSION
from areal_agent_runtime.kernel.ids import new_id


class RuntimeConformanceError(AssertionError):
    pass


@dataclass(frozen=True, slots=True)
class RuntimeConformanceCase:
    input: tuple[ContentBlock, ...] = (TextBlock(text="conformance probe"),)
    required_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    workspace: WorkspaceRef = WorkspaceRef(workspace_id="conformance-workspace")
    model: str | None = None
    provider: str | None = None
    agent_environment: AgentEnvironmentSnapshot | None = None


@dataclass(frozen=True, slots=True)
class RuntimeConformanceReport:
    descriptor: RuntimeDescriptor
    events: tuple[RuntimeEvent, ...]
    coverage: DataCoverageReport
    # Callback delivery evidence, not Runtime events or durable Application facts.
    tool_results: tuple[ToolResult, ...] = ()


async def verify_runtime(
    runtime: AgentRuntimePort,
    case: RuntimeConformanceCase | None = None,
    *,
    require_complete_coverage: bool = False,
    timeout_seconds: float = 60.0,
    cleanup_timeout_seconds: float = 5.0,
    tool_result_handler: Callable[[RuntimeEvent], Awaitable[ToolResult]] | None = None,
) -> RuntimeConformanceReport:
    """Exercise a Runtime with a bounded probe and bounded per-resource cleanup.

    A tool fixture supplies ``tool_result_handler`` and an authorized environment
    in ``case``. Its replies are returned separately as ``report.tool_results``;
    they do not prove Application authorization, commit-before-reply or storage.
    Use a real Application integration test for those boundaries. Without a
    handler, Application-owned tool requests fail immediately instead of waiting
    indefinitely. Runtime-owned tools complete in the Runtime event stream.
    """
    for name, value in (("timeout_seconds", timeout_seconds),
                        ("cleanup_timeout_seconds", cleanup_timeout_seconds)):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be a positive finite number")
    deadline = asyncio.timeout(timeout_seconds)
    try:
        async with deadline:
            return await _verify_runtime(
                runtime, case, require_complete_coverage=require_complete_coverage,
                cleanup_timeout_seconds=cleanup_timeout_seconds,
                tool_result_handler=tool_result_handler,
            )
    except TimeoutError as exc:
        if deadline.expired():
            raise RuntimeConformanceError(f"Runtime conformance timed out after {timeout_seconds} seconds") from exc
        raise


async def _verify_runtime(
    runtime: AgentRuntimePort,
    case: RuntimeConformanceCase | None,
    *,
    require_complete_coverage: bool,
    cleanup_timeout_seconds: float,
    tool_result_handler: Callable[[RuntimeEvent], Awaitable[ToolResult]] | None,
) -> RuntimeConformanceReport:
    """Run the portable minimum gate every third-party Runtime must pass.

    ``require_complete_coverage`` is an opt-in release gate. The default stays
    behavior-compatible with Runtime v1: optional capabilities that a generic
    probe did not exercise are reported as unverified. Adapter-specific release
    fixtures should enable the strict gate after arranging inputs that exercise
    every non-``none`` declaration.
    """

    probe = case or RuntimeConformanceCase()
    descriptor = await runtime.describe()
    if descriptor.runtime_api_version != RUNTIME_API_VERSION:
        raise RuntimeConformanceError(
            f"runtimeApiVersion must be {RUNTIME_API_VERSION}, got {descriptor.runtime_api_version}"
        )
    missing = set(probe.required_modalities).difference(descriptor.capabilities.input_modalities)
    if missing:
        missing_names = sorted(item.value for item in missing)
        raise RuntimeConformanceError(f"descriptor is missing input modalities: {missing_names}")
    health = await runtime.health()
    if health.status == "unhealthy":
        raise RuntimeConformanceError(f"runtime is unhealthy: {health.details}")

    run_id = new_id("run")
    session_id = new_id("session")
    execution_id = new_id("execution")
    environment = probe.agent_environment or _conformance_environment(descriptor)
    environment.assert_integrity()
    spec = RuntimeSessionSpec(
        session_id=session_id,
        workspace=probe.workspace,
        model=probe.model,
        provider=probe.provider,
        agent_environment=environment,
    )
    session: RuntimeSessionRef | None = await runtime.open_session(spec)
    channel = None
    report: RuntimeConformanceReport | None = None
    operation_error: BaseException | None = None
    try:
        if not isinstance(session, RuntimeSessionRef):
            raise RuntimeConformanceError("open_session must return a RuntimeSessionRef")
        if session.session_id != session_id:
            raise RuntimeConformanceError("open_session changed the canonical sessionId")
        request = ExecutionRequest(
            run_id=run_id,
            execution_id=execution_id,
            session_id=session_id,
            agent=AgentRef(agent_id="agent_conformance", role="conformance_probe"),
            input=probe.input,
            agent_environment=environment,
            workspace=probe.workspace,
            policy=ExecutionPolicy(),
        )
        channel = await runtime.execute(request)
        collected: list[RuntimeEvent] = []
        delivered: list[ToolResult] = []
        call_ids: set[str] = set()
        selected_tools = {tool.name: tool for tool in environment.tools}
        async for event in channel.events():
            collected.append(event)
            if event.execution_id != execution_id:
                raise RuntimeConformanceError("event escaped its execution scope")
            if event.type != EventType.TOOL_REQUESTED:
                continue
            data = _event_data(event)
            call_id = data.get("callId")
            if not isinstance(call_id, str) or not call_id or call_id in call_ids:
                raise RuntimeConformanceError("tool.requested has a missing or duplicate callId")
            call_ids.add(call_id)
            if not descriptor.capabilities.tool_calling:
                raise RuntimeConformanceError("tool.requested requires the toolCalling capability")
            name = data.get("name")
            tool_spec = selected_tools.get(name) if isinstance(name, str) else None
            declared_execution = data.get("execution")
            if tool_spec is not None and declared_execution is not None and declared_execution != tool_spec.execution:
                raise RuntimeConformanceError("tool.requested execution ownership conflicts with its case ToolSpec")
            ownership = tool_spec.execution if tool_spec is not None else declared_execution
            if ownership == ToolExecution.RUNTIME:
                # Native tool observations terminate in the Runtime stream.
                # A supplied callback must never become a second executor.
                continue
            if ownership is None:
                # Match the Application v1 legacy rule: an uncatalogued tool
                # without explicit ownership is only a native observation,
                # even on a Harness that also supports Application tools.
                # Never call a fixture for it; missing replies time out.
                continue
            if tool_spec is None or tool_spec.execution not in {ToolExecution.APPLICATION, ToolExecution.REMOTE}:
                raise RuntimeConformanceError("tool.requested is not in the case environment Application tool catalog")
            if not descriptor.capabilities.application_tool_bridge:
                raise RuntimeConformanceError("Application-owned tool.requested requires applicationToolBridge")
            if tool_result_handler is None:
                raise RuntimeConformanceError(
                    "tool.requested requires tool_result_handler and an authorized case environment"
                )
            result = await tool_result_handler(event)
            if not isinstance(result, ToolResult) or result.call_id != call_id:
                raise RuntimeConformanceError("tool_result_handler must return ToolResult with the requested callId")
            await channel.send_tool_result(result)
            delivered.append(result)
        events = tuple(collected)
        _verify_events(events, execution_id, agent_id=request.agent.agent_id)
        coverage = analyze_data_coverage(
            descriptor.capabilities.data_coverage, events, application_tool_results=tuple(delivered),
        )
        coverage_issues = [
            issue
            for dimension in coverage.dimensions
            for issue in dimension.issues
        ]
        checkpoint_coverage = descriptor.capabilities.data_coverage.checkpoint
        if checkpoint_coverage != CheckpointCoverage.NONE:
            checkpoint_issues: list[str] = []
            if not isinstance(runtime, RuntimeCheckpointPort):
                checkpoint_issues.append(
                    f"checkpoint={checkpoint_coverage.value} requires "
                    "RuntimeCheckpointPort export/import"
                )
            else:
                checkpoint = await runtime.export_checkpoint(session)
                if not isinstance(checkpoint, RuntimeCheckpoint):
                    checkpoint_issues.append(
                        "checkpoint export must return RuntimeCheckpoint"
                    )
                elif checkpoint.format != checkpoint_coverage.value:
                    checkpoint_issues.append(
                        f"checkpoint={checkpoint_coverage.value} exported "
                        f"format={checkpoint.format}"
                    )
                elif checkpoint.session_id != spec.session_id:
                    checkpoint_issues.append(
                        "portable checkpoint changed the canonical sessionId"
                    )
                elif checkpoint.binding_digest != runtime_session_binding_digest(spec):
                    checkpoint_issues.append(
                        "portable checkpoint bindingDigest does not match the Session"
                    )
                if not checkpoint_issues:
                    await runtime.close_session(session)
                    session = None
                    imported = await runtime.import_checkpoint(
                        spec.model_copy(update={"resume": True}),
                        checkpoint,
                    )
                    if not isinstance(imported, RuntimeSessionRef):
                        checkpoint_issues.append(
                            "checkpoint import must return RuntimeSessionRef"
                        )
                    else:
                        session = imported
                        if imported.session_id != spec.session_id:
                            checkpoint_issues.append(
                                "portable checkpoint import changed the canonical sessionId"
                            )
                        else:
                            round_trip = await runtime.export_checkpoint(imported)
                            if (
                                not isinstance(round_trip, RuntimeCheckpoint)
                                or round_trip.format != checkpoint_coverage.value
                                or round_trip.binding_digest != checkpoint.binding_digest
                                or round_trip.schema_ref != checkpoint.schema_ref
                                or round_trip.entries != checkpoint.entries
                            ):
                                checkpoint_issues.append(
                                    f"{checkpoint_coverage.value} checkpoint export/import "
                                    "did not preserve state"
                                )
            coverage_issues.extend(checkpoint_issues)
            if not checkpoint_issues:
                coverage = coverage.model_copy(
                    update={
                        "dimensions": tuple(
                            item.model_copy(
                                update={
                                    "observed": checkpoint_coverage.value,
                                    "exercised": True,
                                    "verified": True,
                                }
                            )
                            if item.dimension == "checkpoint"
                            else item
                            for item in coverage.dimensions
                        )
                    }
                )
        if coverage_issues:
            raise RuntimeConformanceError(
                "data coverage declaration is not satisfied: " + "; ".join(coverage_issues)
            )
        if require_complete_coverage and not coverage.complete:
            unverified = [
                f"{item.dimension}={item.declared}"
                for item in coverage.dimensions
                if item.declared != "none" and not item.verified
            ]
            raise RuntimeConformanceError(
                "data coverage declaration was not fully exercised: "
                + ", ".join(unverified)
            )
        report = RuntimeConformanceReport(
            descriptor=descriptor,
            events=events,
            coverage=coverage,
            tool_results=tuple(delivered),
        )
    except BaseException as exc:
        operation_error = exc

    cleanup_errors: list[BaseException] = []
    if channel is not None:
        try:
            async with asyncio.timeout(cleanup_timeout_seconds):
                await channel.close()
        except BaseException as exc:
            cleanup_errors.append(exc)
    if session is not None:
        try:
            async with asyncio.timeout(cleanup_timeout_seconds):
                await runtime.close_session(session)
        except BaseException as exc:
            cleanup_errors.append(exc)

    if operation_error is not None:
        if cleanup_errors:
            raise BaseExceptionGroup(
                "Runtime conformance failed and cleanup also failed",
                [operation_error, *cleanup_errors],
            ) from None
        raise operation_error.with_traceback(operation_error.__traceback__)
    if cleanup_errors:
        raise BaseExceptionGroup("Runtime conformance cleanup failed", cleanup_errors)
    if report is None:  # pragma: no cover - every branch above assigns or raises
        raise RuntimeConformanceError("Runtime conformance produced no report")
    return report


def _conformance_environment(descriptor: RuntimeDescriptor) -> AgentEnvironmentSnapshot:
    prompt = "Follow the Runtime Contract conformance probe."
    capabilities = descriptor.capabilities.model_dump(mode="json", by_alias=True)
    return AgentEnvironmentSnapshot.create(
        spec_digest=hashlib.sha256(b"areal_agent_runtime-runtime-conformance-environment/v1").hexdigest(),
        prompt_resolution=PromptResolutionMode.REPLACE,
        system_prompts=(
            ResolvedResourceSnapshot(
                resource_id="conformance:system-prompt",
                category=ResourceCategory.SYSTEM_PROMPT,
                layer=ResourceLayer.INVOCATION,
                kind="inline",
                version="1.0.0",
                media_type="text/plain",
                sha256=hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                locator="inline://conformance:system-prompt",
                content=prompt,
            ),
        ),
        runtime=RuntimeIdentitySnapshot(
            name=descriptor.name,
            runtime_version=descriptor.runtime_version,
            adapter_version=descriptor.adapter_version,
            capabilities_sha256=hashlib.sha256(
                json.dumps(
                    capabilities,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest(),
        ),
    )


def _verify_events(events: tuple[RuntimeEvent, ...], execution_id: str, *, agent_id: str) -> None:
    if not events:
        raise RuntimeConformanceError("runtime emitted no events")
    started = [event for event in events if event.type == EventType.EXECUTION_STARTED]
    if len(started) != 1 or events[0] is not started[0]:
        raise RuntimeConformanceError("execution must begin with exactly one execution.started")
    if events[0].agent_id != agent_id or events[0].parent_agent_id is not None:
        raise RuntimeConformanceError("execution.started changed the requested Agent identity")
    sequences = [event.runtime_sequence for event in events]
    if sequences != list(range(len(events))):
        raise RuntimeConformanceError(f"runtimeSequence must be contiguous from zero: {sequences}")
    mismatched = [event.execution_id for event in events if event.execution_id != execution_id]
    if mismatched:
        raise RuntimeConformanceError(f"events escaped their execution scope: {mismatched}")
    terminal = [
        event
        for event in events
        if event.type in {EventType.EXECUTION_COMPLETED, EventType.EXECUTION_FAILED}
    ]
    if len(terminal) != 1:
        raise RuntimeConformanceError(f"execution must emit exactly one terminal event, got {len(terminal)}")
    if events[-1] is not terminal[0]:
        raise RuntimeConformanceError("execution terminal event must be last")


def analyze_data_coverage(
    declared: DataCoverage,
    events: tuple[RuntimeEvent, ...],
    *,
    application_tool_results: tuple[ToolResult, ...] = (),
) -> DataCoverageReport:
    """Compare a machine-readable declaration with actually emitted facts.

    A dimension can remain unexercised by the portable smoke probe.  That is
    reported as such, not silently called verified.  Contradictions in an
    exercised dimension are issues and fail ``verify_runtime``.
    """

    model_started: dict[str, RuntimeEvent] = {}
    model_terminal: dict[str, RuntimeEvent] = {}
    tool_requested: dict[str, RuntimeEvent] = {}
    tool_terminal: dict[str, RuntimeEvent] = {}
    message_ids: set[str] = set()
    message_events: list[RuntimeEvent] = []
    message_delta_events: list[RuntimeEvent] = []
    completed_messages = 0
    message_deltas = 0
    usage_events = 0
    normalized_usage_events = 0
    raw_full = 0
    raw_reference = 0
    child_started: set[str] = set()
    child_terminal: set[str] = set()
    model_issues: list[str] = []
    message_issues: list[str] = []
    tool_issues: list[str] = []
    usage_issues: list[str] = []
    child_issues: list[str] = []
    root_agent = events[0].agent_id if events else None

    for event in events:
        data = _event_data(event)
        if event.type == EventType.MODEL_CALL_STARTED:
            model_id = _identity(data.get("modelCallId"))
            if model_id is not None:
                if model_id in model_started:
                    model_issues.append(f"modelCallId started twice: {model_id}")
                model_started[model_id] = event
        elif event.type in {EventType.MODEL_CALL_COMPLETED, EventType.MODEL_CALL_FAILED}:
            model_id = _identity(data.get("modelCallId"))
            if model_id is not None:
                if model_id in model_terminal:
                    model_issues.append(f"modelCallId terminated twice: {model_id}")
                model_terminal[model_id] = event
                started = model_started.get(model_id)
                if started is not None:
                    for field in ("provider", "model", "attempt"):
                        if _event_data(started).get(field) != data.get(field):
                            model_issues.append(
                                f"modelCallId changed {field} before terminal: {model_id}"
                            )
        elif event.type in {EventType.MESSAGE_COMPLETED, EventType.AGENT_MESSAGE}:
            completed_messages += 1
            message_events.append(event)
            message_id = _identity(data.get("messageId"))
            if message_id is not None:
                if message_id in message_ids:
                    message_issues.append(f"messageId reused: {message_id}")
                message_ids.add(message_id)
            _require_known_model_lineage(data, model_started, "message", message_issues)
        elif event.type == EventType.MESSAGE_DELTA:
            message_deltas += 1
            message_delta_events.append(event)
            _require_known_model_lineage(data, model_started, "message delta", message_issues)
        elif event.type == EventType.USAGE_UPDATED:
            usage_events += 1
            try:
                UsageUpdatedEventData.model_validate(data)
            except ValueError:
                usage_issues.append(
                    "usage event uses the legacy untyped shape; emit normalized usage plus raw data"
                )
            else:
                normalized_usage_events += 1
                _require_known_model_lineage(
                    data,
                    model_started,
                    "usage",
                    usage_issues,
                )
        elif event.type == EventType.TOOL_REQUESTED:
            call_id = _identity(data.get("callId"))
            if call_id is not None:
                if call_id in tool_requested:
                    tool_issues.append(f"tool call requested twice: {call_id}")
                tool_requested[call_id] = event
            _require_known_model_lineage(data, model_started, "tool call", tool_issues)
        elif event.type in {EventType.TOOL_COMPLETED, EventType.TOOL_FAILED}:
            call_id = _identity(data.get("callId"))
            if call_id is not None:
                if call_id in tool_terminal:
                    tool_issues.append(f"tool call terminated twice: {call_id}")
                tool_terminal[call_id] = event
                requested = tool_requested.get(call_id)
                if requested is not None:
                    for field in ("name", "modelCallId"):
                        terminal_value = data.get(field)
                        requested_value = _event_data(requested).get(field)
                        if requested_value is not None and terminal_value is None:
                            tool_issues.append(
                                f"tool call lost {field} before terminal: {call_id}"
                            )
                        elif terminal_value is not None and terminal_value != requested_value:
                            tool_issues.append(
                                f"tool call changed {field} before terminal: {call_id}"
                            )
        elif event.type == EventType.RAW_EVENT_RECORDED or not isinstance(event.type, EventType):
            if data.get("storage") == "asset-ref" and isinstance(data.get("assetId"), str):
                raw_reference += 1
            else:
                raw_full += 1

        if event.agent_id != root_agent:
            if event.type == EventType.AGENT_STARTED:
                child_started.add(event.agent_id)
            if event.type in {
                EventType.AGENT_COMPLETED,
                EventType.AGENT_FAILED,
                EventType.AGENT_CANCELLED,
            }:
                child_terminal.add(event.agent_id)
            if event.parent_agent_id is None:
                child_issues.append(f"child event lacks parentAgentId: {event.agent_id}")

    # Application-owned tools complete outside the Runtime stream. Test replies
    # are evidence only for those request/result pairs; never synthesize events.
    external_terminals: set[str] = set()
    for result in application_tool_results:
        if not isinstance(result, ToolResult):
            raise TypeError("application_tool_results must contain ToolResult values")
        if result.call_id not in tool_requested:
            tool_issues.append(f"Application tool result has no request: {result.call_id}")
        if result.call_id in external_terminals:
            tool_issues.append(f"Application tool result delivered twice: {result.call_id}")
        external_terminals.add(result.call_id)
    for call_id in sorted(set(tool_terminal) & external_terminals):
        tool_issues.append(f"tool call terminated by both Runtime and Application: {call_id}")
    completed_tool_ids = set(tool_terminal) | external_terminals

    for model_id in sorted(set(model_started).difference(model_terminal)):
        model_issues.append(f"modelCallId lacks terminal event: {model_id}")
    for model_id in sorted(set(model_terminal).difference(model_started)):
        model_issues.append(f"modelCallId terminal lacks start: {model_id}")
    for call_id in sorted(set(tool_terminal).difference(tool_requested)):
        tool_issues.append(f"tool terminal lacks request: {call_id}")
    for call_id in sorted(set(tool_requested).difference(completed_tool_ids)):
        tool_issues.append(f"tool request lacks terminal: {call_id}")
    for child_id in sorted(child_terminal.difference(child_started)):
        child_issues.append(f"child terminal lacks start: {child_id}")
    for child_id in sorted(child_started.difference(child_terminal)):
        child_issues.append(f"child start lacks terminal: {child_id}")

    if declared.messages == MessageCoverage.FULL:
        for event in message_events:
            event_data = _event_data(event)
            if _identity(event_data.get("messageId")) is None:
                message_issues.append("messages=full requires producer messageId")
            if model_started and _identity(event_data.get("modelCallId")) is None:
                message_issues.append("messages=full requires modelCallId when model calls are exposed")
        for event in message_delta_events:
            event_data = _event_data(event)
            message_id = _identity(event_data.get("messageId"))
            if message_id is None:
                message_issues.append("messages=full requires messageId on message deltas")
            elif message_id not in message_ids:
                message_issues.append(
                    f"message delta has no matching durable message: {message_id}"
                )
            if model_started and _identity(event_data.get("modelCallId")) is None:
                message_issues.append(
                    "messages=full requires modelCallId on message deltas when model calls are exposed"
                )
        if message_deltas and not completed_messages:
            message_issues.append("message deltas lack a durable completed message")

    if declared.tool_calls == DetailCoverage.FULL and model_started:
        for event in (*tool_requested.values(), *tool_terminal.values()):
            if _identity(_event_data(event).get("modelCallId")) is None:
                tool_issues.append(
                    "toolCalls=full requires modelCallId when model calls are exposed"
                )

    message_full_evidence = bool(message_events) and all(
        _identity(_event_data(event).get("messageId")) is not None
        and (
            not model_started
            or _identity(_event_data(event).get("modelCallId")) in model_started
        )
        for event in message_events
    )
    observed_messages = (
        MessageCoverage.NONE
        if completed_messages == 0 and message_deltas == 0
        else (
            MessageCoverage.FULL
            if message_full_evidence and not message_issues
            else MessageCoverage.FINAL
        )
    )
    observed_models = (
        DetailCoverage.NONE
        if not model_started and not model_terminal
        else (
            DetailCoverage.FULL
            if model_started
            and set(model_started) == set(model_terminal)
            and not model_issues
            else DetailCoverage.AGGREGATE
        )
    )
    observed_tools = (
        DetailCoverage.NONE
        if not tool_requested and not tool_terminal
        else (
            DetailCoverage.FULL
            if tool_requested and set(tool_requested) == completed_tool_ids and not tool_issues
            else DetailCoverage.AGGREGATE
        )
    )
    observed_usage = (
        UsageCoverage.NORMALIZED
        if normalized_usage_events
        else UsageCoverage.NONE
    )
    observed_children = (
        DetailCoverage.NONE
        if not child_started and not child_terminal
        else (
            DetailCoverage.FULL
            if child_started and child_started == child_terminal
            else DetailCoverage.AGGREGATE
        )
    )
    observed_raw = (
        RawEventCoverage.FULL
        if raw_full
        else (RawEventCoverage.REFERENCE if raw_reference else RawEventCoverage.NONE)
    )

    reports = (
        _dimension(
            "messages",
            declared.messages.value,
            observed_messages.value,
            completed_messages > 0 or message_deltas > 0,
            _rank_message(declared.messages),
            _rank_message(observed_messages),
            message_issues,
        ),
        _dimension(
            "modelCalls",
            declared.model_calls.value,
            observed_models.value,
            bool(model_started or model_terminal),
            _rank_detail(declared.model_calls),
            _rank_detail(observed_models),
            model_issues,
        ),
        _dimension(
            "toolCalls",
            declared.tool_calls.value,
            observed_tools.value,
            bool(tool_requested or tool_terminal),
            _rank_detail(declared.tool_calls),
            _rank_detail(observed_tools),
            tool_issues,
        ),
        _dimension(
            "usage",
            declared.usage.value,
            observed_usage.value,
            bool(usage_events),
            _rank_usage(declared.usage),
            _rank_usage(observed_usage),
            usage_issues,
        ),
        _dimension(
            "childAgents",
            declared.child_agents.value,
            observed_children.value,
            bool(child_started or child_terminal),
            _rank_detail(declared.child_agents),
            _rank_detail(observed_children),
            child_issues,
        ),
        CoverageDimensionReport(
            dimension="checkpoint",
            declared=declared.checkpoint.value,
            observed="none",
            exercised=False,
            verified=declared.checkpoint == CheckpointCoverage.NONE,
        ),
        _dimension(
            "rawEvents",
            declared.raw_events.value,
            observed_raw.value,
            bool(raw_full or raw_reference),
            _rank_raw(declared.raw_events),
            _rank_raw(observed_raw),
            [],
        ),
        CoverageDimensionReport(
            dimension="trainingSignals",
            declared=declared.training_signals.value,
            observed=TrainingSignalCoverage.NONE.value,
            exercised=False,
            verified=declared.training_signals == TrainingSignalCoverage.NONE,
            issues=(
                (
                    "trainingSignals cannot be declared without a training-record conformance source"
                ),
            )
            if declared.training_signals != TrainingSignalCoverage.NONE
            else (),
        ),
    )
    return DataCoverageReport(declared=declared, dimensions=reports)


def _dimension(
    name: str,
    declared: str,
    observed: str,
    exercised: bool,
    declared_rank: int,
    observed_rank: int,
    lineage_issues: list[str],
) -> CoverageDimensionReport:
    issues: list[str] = []
    if exercised and observed_rank < declared_rank:
        issues.append(f"{name} declared {declared}, observed only {observed}")
    if declared_rank == 0 and observed_rank > 0:
        issues.append(f"{name} declared none but emitted {observed} data")
    relevant_terms = {
        "messages": ("message", "modelCallId"),
        "modelCalls": ("modelCallId",),
        "toolCalls": ("tool", "modelCallId"),
        "usage": ("usage", "modelCallId"),
        "childAgents": ("child",),
        "rawEvents": (),
    }.get(name, ())
    issues.extend(
        issue
        for issue in lineage_issues
        if any(term in issue for term in relevant_terms)
    )
    return CoverageDimensionReport(
        dimension=name,  # type: ignore[arg-type]
        declared=declared,
        observed=observed,
        exercised=exercised,
        verified=not issues and (exercised or declared_rank == 0),
        issues=tuple(dict.fromkeys(issues)),
    )


def _require_known_model_lineage(
    data: Mapping[str, object],
    model_started: dict[str, RuntimeEvent],
    label: str,
    issues: list[str],
) -> None:
    model_id = _identity(data.get("modelCallId"))
    if model_id is not None and model_id not in model_started:
        issues.append(f"{label} references unknown modelCallId: {model_id}")


def _event_data(event: RuntimeEvent) -> Mapping[str, object]:
    if isinstance(event.data, dict):
        return event.data
    return {}


def _identity(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _rank_message(value: MessageCoverage) -> int:
    return {MessageCoverage.NONE: 0, MessageCoverage.FINAL: 1, MessageCoverage.FULL: 2}[value]


def _rank_detail(value: DetailCoverage) -> int:
    return {DetailCoverage.NONE: 0, DetailCoverage.AGGREGATE: 1, DetailCoverage.FULL: 2}[value]


def _rank_usage(value: UsageCoverage) -> int:
    return {UsageCoverage.NONE: 0, UsageCoverage.NORMALIZED: 1, UsageCoverage.TOKEN_LEVEL: 2}[value]


def _rank_raw(value: RawEventCoverage) -> int:
    return {RawEventCoverage.NONE: 0, RawEventCoverage.REFERENCE: 1, RawEventCoverage.FULL: 2}[value]
