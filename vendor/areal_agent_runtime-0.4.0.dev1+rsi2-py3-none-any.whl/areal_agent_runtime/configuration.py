"""Four-file project configuration compiled into the compatibility bootstrap.

Responsibilities stay separate:

* ``release.yaml``: Distribution identity, defaults and exposed profiles.
* ``composition.yaml``: installed Adapters/Plugins, Host and deployment policy.
* ``workflow.yaml``: orchestration DAGs and join policy.
* ``agents.yaml``: reusable Agent profiles.

``plugin.yaml`` remains inside each plugin package and a RunRequest remains a
single invocation; neither is folded into these project files.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Literal, TypeVar

from pydantic import Field, StrictInt, model_validator

from areal_agent_runtime.application.profiles import WorkflowProfile
from areal_agent_runtime.application.workflow import (
    AgentGraph,
    AgentInputMode,
    AgentProfile,
    DynamicAgentPolicy,
    MultiAgentOwnership,
    ParallelGroup,
    WorkflowAgent,
    WorkspaceAccess,
)
from areal_agent_runtime.bootstrap import (
    AssetStorageBootstrapConfig,
    BootstrapConfig,
    HostBootstrapConfig,
    PluginBootstrapConfig,
    RuntimeBootstrapConfig,
    ToolBindingBootstrapConfig,
)
from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.environment import AgentEnvironmentLayer, AgentEnvironmentSpec
from areal_agent_runtime.contracts.runtime import Modality


class AgentProfileDefinition(AgentProfile):
    """Configuration spelling of the canonical trusted AgentProfile."""


class AgentsConfiguration(ContractModel):
    schema_version: Literal["areal.agent-runtime.agents/v1"] = "areal.agent-runtime.agents/v1"
    agents: tuple[AgentProfileDefinition, ...]

    @model_validator(mode="after")
    def validate_unique(self) -> AgentsConfiguration:
        values = [agent.agent_profile_id for agent in self.agents]
        if len(values) != len(set(values)):
            raise ValueError("agents.yaml repeats agentProfileId values")
        return self


class WorkflowNodeDefinition(ContractModel):
    agent_id: str = Field(min_length=1)
    agent_profile_id: str = Field(min_length=1)
    depends_on: tuple[str, ...] = ()
    workspace_access: WorkspaceAccess = WorkspaceAccess.READ
    input_mode: AgentInputMode = AgentInputMode.ORIGINAL_AND_DEPENDENCIES
    system: tuple[ContentBlock, ...] = ()
    agent_environment: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    runtime_selector: str | None = None
    required_input_modalities: tuple[Modality, ...] = ()
    required_features: tuple[str, ...] = ()
    tool_names: tuple[str, ...] = ()
    merge_overlays: tuple[str, ...] = ()
    allow_runtime_subagents: bool | None = None


class WorkflowDefinition(ContractModel):
    workflow_id: str = Field(min_length=1)
    nodes: tuple[WorkflowNodeDefinition, ...] = Field(min_length=1)
    parallel_groups: tuple[ParallelGroup, ...] = ()
    coordinator_agent_id: str = "agent_root"
    max_concurrency: int = Field(default=4, ge=1)
    ownership: MultiAgentOwnership = MultiAgentOwnership.APPLICATION
    dynamic_policy: DynamicAgentPolicy | None = None


class WorkflowsConfiguration(ContractModel):
    schema_version: Literal["areal.agent-runtime.workflows/v1"] = "areal.agent-runtime.workflows/v1"
    workflows: tuple[WorkflowDefinition, ...]

    @model_validator(mode="after")
    def validate_unique(self) -> WorkflowsConfiguration:
        values = [workflow.workflow_id for workflow in self.workflows]
        if len(values) != len(set(values)):
            raise ValueError("workflow.yaml repeats workflowId values")
        return self


class ReleaseProfileDefinition(ContractModel):
    profile_id: str = Field(min_length=1)
    version: str | None = None
    role: str = Field(min_length=1)
    system: tuple[ContentBlock, ...] = ()
    agent_environment: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    required_input_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    required_features: tuple[str, ...] = ()
    max_stalled_actions: int | None = Field(default=None, ge=2, le=30)
    tool_names: tuple[str, ...] = ()
    workflow_id: str | None = None


class ReleaseConfiguration(ContractModel):
    schema_version: Literal["areal.agent-runtime.release/v1"] = "areal.agent-runtime.release/v1"
    release_id: str = Field(min_length=1)
    version: str = Field(min_length=1)
    agent_environment: AgentEnvironmentSpec = Field(default_factory=AgentEnvironmentSpec)
    profiles: tuple[ReleaseProfileDefinition, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_release_layers(self) -> ReleaseConfiguration:
        environment = self.agent_environment
        if environment.host_mount != AgentEnvironmentLayer() or environment.invocation != AgentEnvironmentLayer():
            raise ValueError("release.yaml may define builtin/releaseProfile resources, not hostMount/invocation")
        profile_ids = [profile.profile_id for profile in self.profiles]
        if len(profile_ids) != len(set(profile_ids)):
            raise ValueError("release.yaml repeats profileId values")
        return self


class CompositionConfiguration(ContractModel):
    schema_version: Literal["areal.agent-runtime.composition/v1"] = (
        "areal.agent-runtime.composition/v1"
    )
    data_root: str = ".areal-agent-runtime"
    runtimes: tuple[RuntimeBootstrapConfig, ...] = Field(min_length=1)
    host: HostBootstrapConfig = Field(default_factory=HostBootstrapConfig)
    storage: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.storage.plugin:create_plugin"
        )
    )
    state: PluginBootstrapConfig | None = None
    max_active_runs: StrictInt = Field(default=16, ge=1)
    data_query_max_events: StrictInt = Field(default=10_000, ge=1)
    data_query_max_bytes: StrictInt = Field(default=16 * 1024 * 1024, ge=1)
    max_recovery_events: StrictInt = Field(default=100_000, ge=1)
    max_recovery_bytes: StrictInt = Field(default=64 * 1024 * 1024, ge=1)
    assets: AssetStorageBootstrapConfig | None = None
    event_sinks: tuple[str, ...] | None = None
    environment: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.environment.plugin:create_plugin"
        )
    )
    workspace_tools: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.workspace.plugin:create_plugin"
        )
    )
    domain_tools: PluginBootstrapConfig | None = None
    knowledge_tools: PluginBootstrapConfig = Field(
        default_factory=lambda: PluginBootstrapConfig(
            entrypoint="areal_agent_runtime.adapters.knowledge.plugin:create_plugin"
        )
    )
    plugins: tuple[PluginBootstrapConfig, ...] = ()
    tool_bindings: tuple[ToolBindingBootstrapConfig, ...] = ()
    allowed_plugin_permissions: tuple[str, ...] | None = None
    allowed_tool_permissions: tuple[str, ...] | None = None

    @model_validator(mode="after")
    def validate_composition_layers(self) -> CompositionConfiguration:
        environment = self.host.agent_environment
        forbidden = {
            "builtin": environment.builtin,
            "releaseProfile": environment.release_profile,
            "invocation": environment.invocation,
        }
        populated = [name for name, layer in forbidden.items() if layer != AgentEnvironmentLayer()]
        if populated:
            raise ValueError(
                "composition.yaml Host may define only hostMount resources; found " + ", ".join(populated)
            )
        return self


async def load_project_configuration(directory: str | Path) -> BootstrapConfig:
    """Load and compile the four canonical YAML files from one directory."""

    root = await asyncio.to_thread(lambda: Path(directory).expanduser().resolve())
    release_raw, composition_raw, workflows_raw, agents_raw = await asyncio.gather(
        _read_yaml(root / "release.yaml"),
        _read_yaml(root / "composition.yaml"),
        _read_yaml(root / "workflow.yaml"),
        _read_yaml(root / "agents.yaml"),
    )
    release = ReleaseConfiguration.model_validate(release_raw)
    composition = CompositionConfiguration.model_validate(composition_raw)
    workflows = WorkflowsConfiguration.model_validate(workflows_raw)
    agents = AgentsConfiguration.model_validate(agents_raw)
    profiles = _compile_profiles(release, workflows, agents)
    host_environment = composition.host.agent_environment
    release_environment = release.agent_environment
    merged_environment = AgentEnvironmentSpec(
        prompt_resolution=release_environment.prompt_resolution,
        builtin=release_environment.builtin,
        release_profile=release_environment.release_profile,
        host_mount=host_environment.host_mount,
        extensions=tuple(
            {
                extension.key: extension
                for extension in (*release_environment.extensions, *host_environment.extensions)
            }.values()
        ),
    )
    host = composition.host.model_copy(update={"agent_environment": merged_environment})
    if host.default_profile not in {profile.profile_id for profile in profiles}:
        raise ValueError(f"Host defaultProfile is not exposed by release.yaml: {host.default_profile}")
    return BootstrapConfig(
        data_root=composition.data_root,
        runtimes=composition.runtimes,
        host=host,
        storage=composition.storage,
        state=composition.state,
        max_active_runs=composition.max_active_runs,
        data_query_max_events=composition.data_query_max_events,
        data_query_max_bytes=composition.data_query_max_bytes,
        max_recovery_events=composition.max_recovery_events,
        max_recovery_bytes=composition.max_recovery_bytes,
        assets=composition.assets,
        event_sinks=composition.event_sinks,
        environment=composition.environment,
        workspace_tools=composition.workspace_tools,
        domain_tools=composition.domain_tools,
        knowledge_tools=composition.knowledge_tools,
        plugins=composition.plugins,
        include_default_profiles=False,
        profile_overrides=profiles,
        tool_bindings=composition.tool_bindings,
        allowed_plugin_permissions=composition.allowed_plugin_permissions,
        allowed_tool_permissions=composition.allowed_tool_permissions,
    )


def _compile_profiles(
    release: ReleaseConfiguration,
    workflows: WorkflowsConfiguration,
    agents: AgentsConfiguration,
) -> tuple[WorkflowProfile, ...]:
    workflow_by_id = {workflow.workflow_id: workflow for workflow in workflows.workflows}
    agent_by_id = {agent.agent_profile_id: agent for agent in agents.agents}
    result: list[WorkflowProfile] = []
    for exposed in release.profiles:
        graph = None
        if exposed.workflow_id is not None:
            try:
                workflow = workflow_by_id[exposed.workflow_id]
            except KeyError as exc:
                raise ValueError(f"release profile references unknown workflow: {exposed.workflow_id}") from exc
            graph_agents: list[WorkflowAgent] = []
            for node in workflow.nodes:
                try:
                    agent = agent_by_id[node.agent_profile_id]
                except KeyError as exc:
                    raise ValueError(
                        f"workflow {workflow.workflow_id} references unknown agent profile: "
                        f"{node.agent_profile_id}"
                    ) from exc
                graph_agents.append(
                    WorkflowAgent(
                        agent_id=node.agent_id,
                        agent_profile_id=agent.agent_profile_id,
                        agent_profile_version=agent.version,
                        role=agent.role,
                        depends_on=node.depends_on,
                        system=(*agent.system, *node.system),
                        agent_environment=_merge_environment_layer(
                            agent.agent_environment,
                            node.agent_environment,
                        ),
                        runtime_selector=node.runtime_selector or agent.runtime_selector,
                        workspace_access=node.workspace_access,
                        input_mode=node.input_mode,
                        required_input_modalities=_ordered_union(
                            agent.required_input_modalities,
                            node.required_input_modalities,
                        ),
                        required_features=_ordered_union(
                            agent.required_features,
                            node.required_features,
                        ),
                        tool_names=_ordered_union(agent.tool_names, node.tool_names),
                        timeout_seconds=agent.timeout_seconds,
                        max_attempts=agent.max_attempts,
                        retry_backoff_seconds=agent.retry_backoff_seconds,
                        merge_overlays=node.merge_overlays,
                        allow_runtime_subagents=(
                            node.allow_runtime_subagents
                            if node.allow_runtime_subagents is not None
                            else agent.allow_runtime_subagents
                        ),
                    )
                )
            graph = AgentGraph(
                agents=tuple(graph_agents),
                parallel_groups=workflow.parallel_groups,
                coordinator_agent_id=workflow.coordinator_agent_id,
                max_concurrency=workflow.max_concurrency,
                ownership=workflow.ownership,
                dynamic_policy=workflow.dynamic_policy,
            )
        result.append(
            WorkflowProfile(
                profile_id=exposed.profile_id,
                version=exposed.version or release.version,
                role=exposed.role,
                system=exposed.system,
                agent_environment=exposed.agent_environment,
                required_input_modalities=exposed.required_input_modalities,
                required_features=exposed.required_features,
                max_stalled_actions=exposed.max_stalled_actions,
                tool_names=exposed.tool_names,
                agent_graph=graph,
                agent_profiles=tuple(agents.agents) if graph is not None and graph.dynamic_policy is not None else (),
            )
        )
    return tuple(result)


async def _read_yaml(path: Path) -> object:
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - declared core dependency guard
        raise RuntimeError("PyYAML is required for four-file project configuration") from exc
    try:
        text = await asyncio.to_thread(path.read_text, encoding="utf-8")
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Missing project configuration file: {path.name}") from exc
    try:
        payload = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in {path.name}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{path.name} must contain one YAML mapping")
    return payload


ValueT = TypeVar("ValueT")


def _ordered_union(left: tuple[ValueT, ...], right: tuple[ValueT, ...]) -> tuple[ValueT, ...]:
    return tuple(dict.fromkeys((*left, *right)))


def _merge_environment_layer(
    left: AgentEnvironmentLayer,
    right: AgentEnvironmentLayer,
) -> AgentEnvironmentLayer:
    return AgentEnvironmentLayer(
        system_prompts=(*left.system_prompts, *right.system_prompts),
        skills=(*left.skills, *right.skills),
        tool_sources=(*left.tool_sources, *right.tool_sources),
        mcp_sources=(*left.mcp_sources, *right.mcp_sources),
    )


__all__ = [
    "AgentProfileDefinition",
    "AgentsConfiguration",
    "CompositionConfiguration",
    "ReleaseConfiguration",
    "ReleaseProfileDefinition",
    "WorkflowDefinition",
    "WorkflowNodeDefinition",
    "WorkflowsConfiguration",
    "load_project_configuration",
]
