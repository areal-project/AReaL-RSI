"""Plugin packaging for the trusted local Codex CLI Runtime Adapter."""

from __future__ import annotations

import math
import os
from typing import Literal, cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.codex_cli.runtime import CodexCliRuntimeAdapter, CodexCliRuntimeConfig
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class CodexCliRuntimePlugin:
    manifest = PluginManifest(
        name="codex-cli-runtime",
        version="1.1.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.codex_cli.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("process.spawn", "workspace.read", "workspace.write", "network.model"),
        metadata={"areal.agent-runtime.bootstrap.profileBinding": True},
    )

    def __init__(self) -> None:
        self.runtime: CodexCliRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        model = _environment_string("AREAL_AGENT_RUNTIME_MODEL") or _string(config.get("model"), "model")
        self.runtime = CodexCliRuntimeAdapter(
            CodexCliRuntimeConfig(
                codex_bin=_string(config.get("codexBin"), "codexBin") or "codex",
                codex_home=_string(config.get("codexHome"), "codexHome"),
                model=model,
                provider=_string(config.get("provider"), "provider"),
                base_url=_string(config.get("baseUrl"), "baseUrl"),
                api_key_env=_string(config.get("apiKeyEnv"), "apiKeyEnv"),
                model_protocol=cast(
                    Literal["responses", "anthropic"],
                    _string(config.get("modelProtocol"), "modelProtocol") or "responses",
                ),
                max_tokens=_positive_int(config.get("maxTokens"), "maxTokens", 4096),
                model_parameters=_mapping(config.get("modelParameters")),
                state_directory=_string(config.get("stateDirectory"), "stateDirectory"),
                skill_directories=_strings(config.get("skillDirectories")),
                profile_binding=cast(
                    Literal["auto", "runtime-owned", "portable"],
                    _string(config.get("profileBinding"), "profileBinding") or "auto",
                ),
                application_tool_bridge=_boolean(config.get("applicationToolBridge")),
                sandbox=_sandbox(config.get("sandbox")),
                approval_policy=_approval_policy(config.get("approvalPolicy")),
                timeout_seconds=_positive_float(config.get("timeoutSeconds"), "timeoutSeconds", 300.0),
                max_concurrency=_positive_int(config.get("maxConcurrency"), "maxConcurrency", 2),
            )
        )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Codex CLI Runtime plugin is not configured")
        health = await self.runtime.health()
        if health.status == "unhealthy":
            raise RuntimeError(str(health.details.get("reason") or "Codex CLI unavailable"))

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> CodexCliRuntimePlugin:
    return CodexCliRuntimePlugin()


def _string(value: JsonValue | None, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"{field_name} must be a non-blank, trimmed string")
    return value


def _environment_string(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    if not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"environment variable {name} must be a non-blank, trimmed string")
    return value


def _sandbox(value: JsonValue | None) -> Literal["read-only", "workspace-write", "danger-full-access"]:
    if value is None:
        return "workspace-write"
    if not isinstance(value, str) or value not in {"read-only", "workspace-write", "danger-full-access"}:
        raise ValueError("sandbox must be read-only, workspace-write, or danger-full-access")
    return cast(Literal["read-only", "workspace-write", "danger-full-access"], value)


def _approval_policy(value: JsonValue | None) -> Literal["untrusted", "on-request", "never"]:
    if value is None:
        return "never"
    if not isinstance(value, str) or value not in {"untrusted", "on-request", "never"}:
        raise ValueError("approvalPolicy must be untrusted, on-request, or never")
    return cast(Literal["untrusted", "on-request", "never"], value)


def _positive_float(value: JsonValue | None, field_name: str, default: float) -> float:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{field_name} must be a positive number")
    return float(value)


def _positive_int(value: JsonValue | None, field_name: str, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _mapping(value: JsonValue | None) -> dict[str, JsonValue]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError("modelParameters must be an object")
    return value


def _strings(value: JsonValue | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ValueError("skillDirectories must be an array of directory paths")
    return tuple(cast(list[str], value))


def _boolean(value: JsonValue | None) -> bool:
    if value is None:
        return False
    if not isinstance(value, bool):
        raise ValueError("applicationToolBridge must be boolean")
    return value
