"""Canonical JSONL trajectory projection with multimodal asset provenance."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import sqlite3
import tempfile
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.kernel.data import (
    CanonicalObservationProjector,
    canonical_asset_ids,
    governance_allows_external,
)

TERMINAL_EVENTS = {
    EventType.RUN_COMPLETED,
    EventType.RUN_FAILED,
    EventType.RUN_CANCELLED,
}


@dataclass(frozen=True, slots=True)
class LiteralSecretRedactor:
    """Small injectable redactor; production Hosts can supply their run secret set."""

    secrets: tuple[str, ...]
    placeholder: str = "[REDACTED]"

    def __call__(self, value: JsonValue) -> JsonValue:
        return self._redact(value)

    def _redact(self, value: JsonValue) -> JsonValue:
        if isinstance(value, str):
            result = value
            for secret in self.secrets:
                if secret:
                    result = result.replace(secret, self.placeholder)
            return result
        if isinstance(value, list):
            return [self._redact(item) for item in value]
        if isinstance(value, dict):
            return {str(self._redact(str(key))): self._redact(item) for key, item in value.items()}
        return value


class JsonlTrajectorySink:
    """Project the canonical event log; never parse a vendor transcript."""

    def __init__(
        self,
        root: str | Path,
        *,
        asset_store: AssetStorePort | None = None,
        redactor: Callable[[JsonValue], JsonValue] | None = None,
        include_restricted: bool = False,
        max_record_bytes: int = 16 * 1024 * 1024,
    ) -> None:
        if isinstance(max_record_bytes, bool) or not isinstance(max_record_bytes, int) or max_record_bytes < 1:
            raise ValueError("max_record_bytes must be a positive integer")
        self._max_record_bytes = max_record_bytes
        self._root = Path(root).expanduser().resolve()
        self._asset_store = asset_store
        self._redactor = redactor
        self._include_restricted = include_restricted
        self._projector = CanonicalObservationProjector()
        self._root.mkdir(parents=True, exist_ok=True)

    async def consume(self, event: RunEvent) -> None:
        payload = event.model_dump(mode="json", by_alias=True)
        allowed = governance_allows_external(event, include_restricted=self._include_restricted)
        if not allowed:
            payload["data"] = {"redacted": True, "policyId": event.governance.policy_id}
        observation = self._projector.project(event) if allowed else None
        assets = {
            asset_id: self._redact(await self._asset_observation(event, asset_id))
            for asset_id in canonical_asset_ids(event) if allowed
        }
        # All filesystem work, including the process-shared lock, stays in one
        # worker. Cancellation may leave it running, but cannot release its
        # lock early or allow a replay to write concurrently.
        await run_blocking_io(
            self._consume_projection,
            event,
            self._redact(payload),
            observation.observation_id if observation is not None else None,
            self._redact(observation.model_dump(mode="json", by_alias=True)) if observation is not None else None,
            assets,
        )

    def _consume_projection(
        self,
        event: RunEvent,
        payload: JsonValue,
        observation_id: str | None,
        observation: JsonValue,
        assets: dict[str, JsonValue],
    ) -> None:
        # Validate the whole projection before publishing any of its files.
        # Anything acknowledged here must also be readable during index rebuild.
        for record in (payload, observation, *assets.values()):
            if record is not None and len(json.dumps(
                record, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
            ).encode("utf-8")) + 1 > self._max_record_bytes:
                raise ValueError("trajectory record exceeds max_record_bytes")
        with self._run_file_lock(event.run_id) as run_dir:
            assets_dir = run_dir / "assets"
            assets_dir.mkdir(parents=True, exist_ok=True)
            for attempt in range(2):
                try:
                    self._write_projection(run_dir, event, payload, observation_id, observation, assets)
                    break
                except sqlite3.DatabaseError as exc:
                    code = getattr(exc, "sqlite_errorcode", 0) & 0xFF
                    if attempt or code not in {sqlite3.SQLITE_CORRUPT, sqlite3.SQLITE_NOTADB}:
                        raise
                    # Only this disposable index is rebuilt. IO/permission/full
                    # disk failures propagate; canonical JSONL is never removed.
                    for suffix in ("", "-journal", "-wal", "-shm"):
                        (run_dir / f".projection-index.sqlite3{suffix}").unlink(missing_ok=True)

    def _write_projection(
        self, run_dir: Path, event: RunEvent, payload: JsonValue,
        observation_id: str | None, observation: JsonValue, assets: dict[str, JsonValue],
    ) -> None:
        assets_dir = run_dir / "assets"
        with self._projection_index(run_dir) as index:
            self._synchronize_index(run_dir, index)
            if not (run_dir / "episode.json").exists():
                episode: JsonValue = {
                    "schemaVersion": "areal.agent-runtime.trajectory/v1",
                    "runId": event.run_id, "sessionId": event.session_id,
                    "traceId": event.trace_id, "episodeId": event.episode_id,
                    "createdAt": event.time.isoformat(),
                }
                self._write_json_atomic(run_dir / "episode.json", self._redact(episode))
            inserted = self._index_event(index, payload)
            if inserted:
                self._append_jsonl(run_dir / "events.jsonl", payload)
            if observation_id is not None and index.execute(
                "INSERT OR IGNORE INTO observations VALUES (?)", (observation_id,),
            ).rowcount:
                self._append_jsonl(run_dir / "observations.jsonl", observation)
            for asset_id, asset in assets.items():
                if index.execute(
                    "INSERT OR IGNORE INTO assets VALUES (?, ?)", (event.event_id, asset_id),
                ).rowcount:
                    self._append_jsonl(assets_dir / "manifest.jsonl", asset)
            if event.type in TERMINAL_EVENTS:
                summary: JsonValue = {
                    "schemaVersion": "areal.agent-runtime.trajectory-summary/v1",
                    "runId": event.run_id, "sessionId": event.session_id,
                    "terminalEvent": event.type.value, "lastSequence": event.sequence,
                    "eventCount": index.execute("SELECT COUNT(*) FROM events").fetchone()[0],
                    "observationCount": index.execute("SELECT COUNT(*) FROM observations").fetchone()[0],
                    "uniqueAssetCount": index.execute("SELECT COUNT(DISTINCT asset_id) FROM assets").fetchone()[0],
                    "finishedAt": event.time.isoformat(),
                }
                self._write_json_atomic(run_dir / "summary.json", self._redact(summary))
            self._save_file_signatures(run_dir, index)

    async def flush(self, run_id: str) -> None:
        # consume persists before returning. This barrier also waits for any
        # cancelled consume's filesystem worker which is already in-flight.
        await run_blocking_io(self._flush, run_id)

    def _flush(self, run_id: str) -> None:
        with self._run_file_lock(run_id):
            pass

    @contextmanager
    def _run_file_lock(self, run_id: str) -> Iterator[Path]:
        if not run_id or run_id in {".", ".."} or Path(run_id).name != run_id:
            raise ValueError("trajectory run_id must be a non-empty path component")
        run_dir = self._root / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(run_dir / ".projection.lock", os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX)
            yield run_dir
        finally:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)

    async def health(self) -> HealthStatus:
        writable = self._root.exists() and os.access(self._root, os.W_OK)
        return HealthStatus(
            status="healthy" if writable else "unhealthy",
            details={"root": str(self._root), "writable": writable},
        )

    async def _asset_observation(self, event: RunEvent, asset_id: str) -> JsonValue:
        ref = await self._asset_store.get(asset_id) if self._asset_store is not None else None
        data = event.data if isinstance(event.data, dict) else {}
        return {
            "schemaVersion": "areal.agent-runtime.asset-observation/v1",
            "assetId": asset_id,
            "status": "available" if ref is not None else "unresolved",
            "asset": ref.model_dump(mode="json", by_alias=True) if ref is not None else None,
            "provenance": {
                "eventId": event.event_id,
                "sequence": event.sequence,
                "eventType": event.type.value,
                "executionId": event.execution_id,
                "agentAttemptId": event.agent_attempt_id,
                "agentId": event.agent_id,
                "modelCallId": data.get("modelCallId"),
                "toolCallId": data.get("callId"),
                "environmentId": event.environment_id,
                "agentEnvironmentId": event.agent_environment_id,
                "workspaceId": event.workspace_id,
            },
        }

    def _redact(self, value: JsonValue) -> JsonValue:
        return self._redactor(value) if self._redactor is not None else value

    _PROJECTION_FILES = ("events.jsonl", "observations.jsonl", "assets/manifest.jsonl")

    @staticmethod
    @contextmanager
    def _projection_index(run_dir: Path) -> Iterator[sqlite3.Connection]:
        # A disposable index, never a second event log: JSONL is fsynced first,
        # then index metadata commits. A crash between them causes a streamed
        # rebuild on the next delivery. No per-Run Python cache survives calls.
        path = run_dir / ".projection-index.sqlite3"
        index = sqlite3.connect(path)
        try:
            index.execute("PRAGMA synchronous = FULL")
            index.execute("PRAGMA cache_size = -2048")
            index.execute("PRAGMA temp_store = FILE")
            index.execute("CREATE TABLE IF NOT EXISTS events "
                          "(event_id TEXT PRIMARY KEY, sequence INTEGER UNIQUE, digest TEXT)")
            index.execute("CREATE TABLE IF NOT EXISTS observations (observation_id TEXT PRIMARY KEY)")
            index.execute("CREATE TABLE IF NOT EXISTS assets "
                          "(event_id TEXT, asset_id TEXT, PRIMARY KEY(event_id, asset_id))")
            index.execute("CREATE TABLE IF NOT EXISTS files (name TEXT PRIMARY KEY, signature TEXT)")
            index.commit()
            index.execute("BEGIN IMMEDIATE")
            yield index
            index.commit()
        except BaseException:
            index.rollback()
            raise
        finally:
            index.close()

    @staticmethod
    def _file_signature(path: Path) -> str:
        if not path.exists():
            return "missing"
        stat = path.stat()
        return f"{stat.st_dev}:{stat.st_ino}:{stat.st_size}:{stat.st_mtime_ns}:{stat.st_ctime_ns}"

    @classmethod
    def _save_file_signatures(cls, run_dir: Path, index: sqlite3.Connection) -> None:
        for relative in cls._PROJECTION_FILES:
            index.execute("INSERT OR REPLACE INTO files VALUES (?, ?)",
                          (relative, cls._file_signature(run_dir / relative)))

    def _synchronize_index(self, run_dir: Path, index: sqlite3.Connection) -> None:
        signatures = dict(index.execute("SELECT name, signature FROM files"))
        if all(signatures.get(relative) == self._file_signature(run_dir / relative)
               for relative in self._PROJECTION_FILES):
            return
        # File identity/size/timestamps changed outside a committed projection:
        # check the entire durable file, including complete corruption before
        # its tail. Rebuild one bounded JSON record at a time into SQLite.
        for table in ("events", "observations", "assets"):
            index.execute(f"DELETE FROM {table}")
        for relative in self._PROJECTION_FILES:
            path = run_dir / relative
            if not path.exists():
                continue
            for line in self._read_complete_lines(path, self._max_record_bytes):
                if not line.strip():
                    continue
                payload = json.loads(line)
                if not isinstance(payload, dict):
                    raise ValueError(f"corrupt trajectory record: {path}")
                if relative == "events.jsonl":
                    self._index_event(index, payload)
                elif relative == "observations.jsonl":
                    observation_id = payload.get("observationId")
                    if not isinstance(observation_id, str):
                        raise ValueError(f"corrupt canonical observation: {path}")
                    index.execute("INSERT OR IGNORE INTO observations VALUES (?)", (observation_id,))
                else:
                    event_id = payload.get("provenance", {}).get("eventId")
                    asset_id = payload.get("assetId")
                    if isinstance(event_id, str) and isinstance(asset_id, str):
                        index.execute("INSERT OR IGNORE INTO assets VALUES (?, ?)", (event_id, asset_id))

    @staticmethod
    def _index_event(index: sqlite3.Connection, payload: JsonValue) -> bool:
        if not isinstance(payload, dict):
            raise ValueError("corrupt trajectory event")
        event_id, sequence = payload.get("eventId"), payload.get("sequence")
        if not isinstance(event_id, str) or not isinstance(sequence, int) or isinstance(sequence, bool):
            raise ValueError("corrupt trajectory event identity")
        digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                           separators=(",", ":")).encode("utf-8")).hexdigest()
        existing = index.execute("SELECT event_id FROM events WHERE sequence = ?", (sequence,)).fetchone()
        if existing is not None and existing[0] != event_id:
            raise ValueError(f"trajectory sequence {sequence} already belongs to {existing[0]}, not {event_id}")
        previous = index.execute("SELECT digest FROM events WHERE event_id = ?", (event_id,)).fetchone()
        if previous is not None:
            if previous[0] != digest:
                raise ValueError(f"trajectory event {event_id} conflicts with its durable payload")
            return False
        index.execute("INSERT INTO events VALUES (?, ?, ?)", (event_id, sequence, digest))
        return True

    @staticmethod
    def _read_complete_lines(path: Path, max_bytes: int = 16 * 1024 * 1024) -> Iterator[str]:
        # Only a non-newline-terminated tail can be discarded. Complete invalid
        # records fail closed. readline has a byte budget even for broken files.
        with path.open("r+b") as handle:
            while True:
                offset = handle.tell()
                line = handle.readline(max_bytes + 1)
                if not line:
                    return
                if len(line) > max_bytes:
                    # An arbitrarily large interrupted tail is still a tail.
                    # Scan in bounded chunks to distinguish it from a complete
                    # oversized record, which must fail without deleting data.
                    chunk = line
                    while chunk and not chunk.endswith(b"\n"):
                        chunk = handle.readline(64 * 1024)
                    if chunk:
                        raise ValueError(f"trajectory record exceeds max_record_bytes: {path}")
                    handle.truncate(offset)
                    handle.flush()
                    os.fsync(handle.fileno())
                    return
                if not line.endswith(b"\n"):
                    handle.truncate(offset)
                    handle.flush()
                    os.fsync(handle.fileno())
                    return
                yield line.decode("utf-8")

    @staticmethod
    def _append_jsonl(path: Path, payload: JsonValue) -> None:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        JsonlTrajectorySink._fsync_directory(path.parent)

    @staticmethod
    def _write_json_atomic(path: Path, payload: JsonValue) -> None:
        descriptor, temporary_name = tempfile.mkstemp(prefix=f"{path.name}-", dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
            JsonlTrajectorySink._fsync_directory(path.parent)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise

    @staticmethod
    def _fsync_directory(path: Path) -> None:
        descriptor = os.open(path, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
