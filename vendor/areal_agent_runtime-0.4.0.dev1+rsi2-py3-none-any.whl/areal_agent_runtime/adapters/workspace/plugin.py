"""Plugin packaging for the portable workspace ToolProvider."""

from __future__ import annotations

import math

from pydantic import JsonValue

from areal_agent_runtime.adapters.workspace.tools import LocalWorkspaceToolProvider, WorkspaceToolConfig
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class LocalWorkspaceToolsPlugin:
    manifest = PluginManifest(
        name="local-workspace-tools",
        version="1.0.0",
        implements=(PortKey.TOOL_PROVIDER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.workspace.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("workspace.read", "workspace.write", "workspace.execute"),
    )

    def __init__(self) -> None:
        self.provider: LocalWorkspaceToolProvider | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        allowed = config.get("allowedCommands")
        if allowed is None:
            allowed_commands = WorkspaceToolConfig().allowed_commands
        elif not isinstance(allowed, list) or any(
            not isinstance(item, str) or not item.strip() or item != item.strip() for item in allowed
        ):
            raise ValueError("allowedCommands must contain trimmed non-empty strings")
        else:
            allowed_commands = tuple(allowed)
        self.provider = LocalWorkspaceToolProvider(
            WorkspaceToolConfig(
                max_read_bytes=_positive_integer(config.get("maxReadBytes"), 1024 * 1024),
                max_write_bytes=_positive_integer(config.get("maxWriteBytes"), 8 * 1024 * 1024),
                max_output_chars=_positive_integer(config.get("maxOutputChars"), 64 * 1024),
                max_results=_positive_integer(config.get("maxResults"), 500),
                max_scan_entries=_positive_integer(config.get("maxScanEntries"), 20_000),
                max_scan_depth=_positive_integer(config.get("maxScanDepth"), 64),
                allowed_commands=allowed_commands,
                command_timeout_seconds=_positive_number(config.get("commandTimeoutSeconds"), 120.0),
            )
        )
        context.provide(PortKey.TOOL_PROVIDER, self.provider)

    async def start(self) -> None:
        if self.provider is None:
            raise RuntimeError("Workspace tools plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.provider is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.provider.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> LocalWorkspaceToolsPlugin:
    return LocalWorkspaceToolsPlugin()


def _positive_number(value: JsonValue | None, default: float) -> float:
    if value is None:
        return default
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0
    ):
        raise ValueError("commandTimeoutSeconds must be a finite positive number")
    return float(value)


def _positive_integer(value: JsonValue | None, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("workspace limits must be positive integers")
    return value
