"""HTTP trajectory reporting projected from the durable canonical event log."""

from __future__ import annotations

import asyncio
import math
import weakref
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

from areal_agent_runtime.contracts.content import AssetRef
from areal_agent_runtime.contracts.data import CanonicalObservation
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import AssetStorePort, StateStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.kernel.data import (
    CanonicalObservationProjector,
    canonical_asset_ids,
    governance_allows_external,
)

TERMINAL_EVENTS = {
    EventType.RUN_COMPLETED,
    EventType.RUN_FAILED,
    EventType.RUN_CANCELLED,
}


class TrajectoryAssetObservation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    asset_id: str = Field(alias="assetId")
    status: Literal["available", "unresolved"]
    asset: AssetRef | None = None


class TrajectoryReportPayload(BaseModel):
    """Canonical report plus compatibility aliases consumed by external collectors."""

    model_config = ConfigDict(extra="forbid", frozen=True, populate_by_name=True)

    schema_version: Literal["areal.agent-runtime.trajectory-report/v1"] = Field(alias="schemaVersion")
    run_id: str = Field(alias="runId")
    turn_id: str | None = None
    trace_id: str | None = None
    episode_id: str | None = Field(default=None, alias="episodeId")
    session_id: str = Field(alias="sessionId")
    legacy_session_id: str = Field(
        validation_alias="legacySessionId",
        serialization_alias="session_id",
    )
    terminal_event: str = Field(alias="terminalEvent")
    trajectory: tuple[RunEvent, ...]
    observations: tuple[CanonicalObservation, ...] = ()
    assets: tuple[TrajectoryAssetObservation, ...]


class TrajectoryReportClient(Protocol):
    async def report(self, run_id: str, payload: dict[str, Any]) -> None: ...

    async def health(self) -> HealthStatus: ...


@dataclass(frozen=True, slots=True)
class TrajectoryHttpConfig:
    endpoint: str
    token: str | None = field(default=None, repr=False)
    headers: dict[str, str] = field(default_factory=dict)
    timeout_seconds: float = 30.0

    def __post_init__(self) -> None:
        if not isinstance(self.endpoint, str) or not self.endpoint:
            raise ValueError("Trajectory endpoint must not be empty")
        if self.token is not None and (not isinstance(self.token, str) or not self.token):
            raise ValueError("Trajectory token must be a non-empty string when provided")
        if not isinstance(self.headers, dict) or any(
            not isinstance(key, str) or not key or not isinstance(value, str)
            for key, value in self.headers.items()
        ):
            raise ValueError("Trajectory headers must contain non-empty string keys and string values")
        if (
            isinstance(self.timeout_seconds, bool)
            or not isinstance(self.timeout_seconds, (int, float))
            or not math.isfinite(self.timeout_seconds)
            or self.timeout_seconds <= 0
        ):
            raise ValueError("Trajectory timeout_seconds must be finite and positive")


class TrajectoryHttpClient:
    def __init__(self, config: TrajectoryHttpConfig) -> None:
        self._config = config

    async def report(self, run_id: str, payload: dict[str, Any]) -> None:
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover - optional dependency guard
            raise RuntimeError("Install areal-agent-runtime[integrations] to report trajectories") from exc
        headers = {
            "content-type": "application/json",
            "idempotency-key": f"areal_agent_runtime-trajectory:{run_id}",
            **self._config.headers,
        }
        if self._config.token:
            headers["authorization"] = f"Bearer {self._config.token}"
        async with httpx.AsyncClient(
            timeout=self._config.timeout_seconds,
            follow_redirects=False,
            trust_env=False,
        ) as client:
            response = await client.post(self._config.endpoint, json=payload, headers=headers)
            response.raise_for_status()

    async def health(self) -> HealthStatus:
        return HealthStatus(status="healthy", details={"configured": bool(self._config.endpoint)})


class HttpTrajectoryEventSink:
    """Report one idempotent multimodal episode after the Run becomes terminal.

    ``best_effort`` remains accepted for configuration compatibility. A failed
    flush always raises so the Publisher retains its durable delivery intent;
    the Publisher isolates that failure from the committed business Run.
    """

    def __init__(
        self,
        state_store: StateStorePort,
        client: TrajectoryReportClient,
        *,
        asset_store: AssetStorePort | None = None,
        best_effort: bool = True,
        max_attempts: int = 3,
        include_restricted: bool = False,
    ) -> None:
        if not isinstance(best_effort, bool):
            raise ValueError("best_effort must be a boolean")
        if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
            raise ValueError("max_attempts must be a positive integer")
        self._state = state_store
        self._client = client
        self._assets = asset_store
        self._best_effort = best_effort
        self._max_attempts = max_attempts
        self._include_restricted = include_restricted
        self._projector = CanonicalObservationProjector()
        self._terminal_runs: set[str] = set()
        self._reported: set[str] = set()
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._failures = 0
        self._last_error: str | None = None

    async def consume(self, event: RunEvent) -> None:
        if event.type in TERMINAL_EVENTS:
            self._terminal_runs.add(event.run_id)

    async def flush(self, run_id: str) -> None:
        if run_id not in self._terminal_runs or run_id in self._reported:
            return
        lock = self._locks.setdefault(run_id, asyncio.Lock())
        async with lock:
            if run_id in self._reported:
                return
            payload = await self._payload(run_id)
            try:
                await self._report_with_retry(run_id, payload)
            except Exception as exc:
                self._failures += 1
                self._last_error = str(exc) or type(exc).__name__
                # flush success is the EventSinkPort delivery acknowledgement.
                # Never report success for a failed upload: EventPublisher
                # already isolates sink errors from the committed business Run
                # and retains/retries its durable outbox. Keep best_effort as
                # an accepted legacy configuration flag, not a false ACK.
                raise
            else:
                self._reported.add(run_id)

    async def health(self) -> HealthStatus:
        upstream = await self._client.health()
        if self._failures:
            return HealthStatus(
                status="degraded",
                details={
                    "upstream": upstream.status,
                    "failures": self._failures,
                    "lastError": self._last_error,
                },
            )
        return upstream

    async def _report_with_retry(self, run_id: str, payload: dict[str, Any]) -> None:
        for attempt in range(1, self._max_attempts + 1):
            try:
                await self._client.report(run_id, payload)
                return
            except Exception:
                if attempt == self._max_attempts:
                    raise
                await asyncio.sleep(0.25 * (2 ** (attempt - 1)))

    async def _payload(self, run_id: str) -> dict[str, Any]:
        events = tuple([event async for event in self._state.stream_events(run_id)])
        if not events or events[-1].type not in TERMINAL_EVENTS:
            raise RuntimeError(f"trajectory flush requires a terminal event: {run_id}")
        asset_ids: set[str] = set()
        for event in events:
            if governance_allows_external(
                event,
                include_restricted=self._include_restricted,
                include_confidential=self._include_restricted,
            ):
                asset_ids.update(canonical_asset_ids(event))
        assets = []
        for asset_id in sorted(asset_ids):
            ref = await self._assets.get(asset_id) if self._assets is not None else None
            assets.append(
                {
                    "assetId": asset_id,
                    "status": "available" if ref is not None else "unresolved",
                    "asset": ref.model_dump(mode="json", by_alias=True) if ref is not None else None,
                }
            )
        queued = next((event for event in events if event.type == EventType.RUN_QUEUED), None)
        request = queued.data.get("request", {}) if queued is not None else {}
        metadata = request.get("metadata", {}) if isinstance(request, dict) else {}
        turn_id = metadata.get("turnId") if isinstance(metadata, dict) else None
        visible_events = tuple(
            event
            if governance_allows_external(
                event,
                include_restricted=self._include_restricted,
                include_confidential=self._include_restricted,
            )
            else event.model_copy(
                update={
                    "data": {
                        "redacted": True,
                        "policyId": event.governance.policy_id,
                    }
                }
            )
            for event in events
        )
        observations = tuple(
            self._projector.project(event)
            for event in events
            if governance_allows_external(
                event,
                include_restricted=self._include_restricted,
                include_confidential=self._include_restricted,
            )
        )
        report = TrajectoryReportPayload(
            schema_version="areal.agent-runtime.trajectory-report/v1",
            run_id=run_id,
            turn_id=turn_id if isinstance(turn_id, str) and turn_id else None,
            trace_id=events[0].trace_id,
            episode_id=events[0].episode_id,
            session_id=events[0].session_id,
            legacy_session_id=events[0].session_id,
            terminal_event=events[-1].type.value,
            trajectory=visible_events,
            observations=observations,
            assets=tuple(TrajectoryAssetObservation.model_validate(item) for item in assets),
        )
        return report.model_dump(mode="json", by_alias=True)
