"""Small allowlisted Plugin loader with reversible registrations."""

from __future__ import annotations

import asyncio
import inspect
import json
import math
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError
from pydantic import JsonValue

from areal_agent_runtime.contracts.version import PLUGIN_API_VERSION
from areal_agent_runtime.plugin_sdk.contracts import Plugin, PluginContext, PluginManifest, PortKey

_MAX_PLUGIN_CONFIG_BYTES = 1024 * 1024
_MAX_PLUGIN_SCHEMA_BYTES = 1024 * 1024
_MAX_JSON_DEPTH = 64


class ServiceRegistry:
    def __init__(self) -> None:
        self._services: dict[PortKey, dict[str, object]] = {}

    def scope(
        self,
        owner: str,
        allowed: tuple[PortKey, ...],
        bindings: dict[PortKey, str] | None = None,
    ) -> ScopedPluginContext:
        return ScopedPluginContext(
            registry=self,
            owner=owner,
            allowed=frozenset(allowed),
            bindings=dict(bindings or {}),
        )

    def get(self, key: PortKey, owner: str | None = None) -> object:
        providers = self._services.get(key, {})
        if owner is not None:
            try:
                return providers[owner]
            except KeyError as exc:
                raise LookupError(f"service not found: {key} from {owner}") from exc
        if len(providers) != 1:
            names = ", ".join(sorted(providers)) or "none"
            raise LookupError(f"service {key} needs an explicit provider; available: {names}")
        return next(iter(providers.values()))

    def providers(self, key: PortKey) -> tuple[str, ...]:
        return tuple(sorted(self._services.get(key, {})))

    def _provide(self, owner: str, key: PortKey, service: object) -> None:
        providers = self._services.setdefault(key, {})
        if owner in providers:
            raise ValueError(f"plugin {owner} already provides {key}")
        providers[owner] = service

    def _remove_owner(self, owner: str) -> None:
        empty: list[PortKey] = []
        for key, providers in self._services.items():
            providers.pop(owner, None)
            if not providers:
                empty.append(key)
        for key in empty:
            self._services.pop(key, None)


@dataclass(frozen=True)
class ScopedPluginContext(PluginContext):
    registry: ServiceRegistry
    owner: str
    allowed: frozenset[PortKey]
    bindings: dict[PortKey, str]

    def provide(self, key: PortKey, service: object) -> None:
        if key not in self.allowed:
            raise PermissionError(f"plugin {self.owner} did not declare {key} in its manifest")
        self.registry._provide(self.owner, key, service)

    def require(self, key: PortKey, owner: str | None = None) -> object:
        return self.registry.get(key, owner or self.bindings.get(key))

    def providers(self, key: PortKey) -> tuple[str, ...]:
        return self.registry.providers(key)

    def dispose(self) -> None:
        self.registry._remove_owner(self.owner)


@dataclass
class LoadedPlugin:
    plugin: Plugin
    context: ScopedPluginContext


@dataclass(frozen=True, slots=True)
class PluginPermissionPolicy:
    """Host-owned allowlist; ``None`` keeps trusted in-process loading permissive."""

    allowed: frozenset[str] | None = None

    def check(self, plugin_name: str, requested: tuple[str, ...]) -> None:
        if self.allowed is None:
            return
        denied = sorted(set(requested).difference(self.allowed))
        if denied:
            raise PermissionError(
                f"plugin {plugin_name} requests denied permissions: {', '.join(denied)}"
            )


class PluginManager:
    def __init__(
        self,
        registry: ServiceRegistry | None = None,
        *,
        permission_policy: PluginPermissionPolicy | None = None,
    ) -> None:
        self.registry = registry or ServiceRegistry()
        self._permission_policy = permission_policy or PluginPermissionPolicy()
        self._loaded: dict[str, LoadedPlugin] = {}
        self._order: list[str] = []
        self._lifecycle_lock = asyncio.Lock()

    @property
    def loaded(self) -> tuple[str, ...]:
        return tuple(self._order)

    def manifest(self, owner: str) -> PluginManifest:
        try:
            return self._loaded[owner].plugin.manifest
        except KeyError as exc:
            raise LookupError(f"plugin instance is not loaded: {owner}") from exc

    async def load(
        self,
        plugin: Plugin,
        config: dict[str, JsonValue] | None = None,
        *,
        instance_name: str | None = None,
        service_bindings: dict[PortKey, str] | None = None,
    ) -> None:
        async with self._lifecycle_lock:
            await self._load_locked(
                plugin,
                config,
                instance_name=instance_name,
                service_bindings=service_bindings,
            )

    async def _load_locked(
        self,
        plugin: Plugin,
        config: dict[str, JsonValue] | None,
        *,
        instance_name: str | None,
        service_bindings: dict[PortKey, str] | None,
    ) -> None:
        manifest = plugin.manifest
        if not isinstance(manifest, PluginManifest):
            raise TypeError("plugin manifest must be a PluginManifest")
        owner = instance_name or manifest.name
        if not isinstance(owner, str) or not owner.strip() or owner != owner.strip():
            raise ValueError("plugin instance name must be a non-blank, trimmed string")
        if manifest.api_version != PLUGIN_API_VERSION:
            raise ValueError(
                f"plugin {manifest.name} uses unsupported apiVersion={manifest.api_version}; "
                f"expected {PLUGIN_API_VERSION}"
            )
        self._permission_policy.check(manifest.name, manifest.permissions)
        if owner in self._loaded:
            raise ValueError(f"plugin instance already loaded: {owner}")
        loaded_packages = {loaded.plugin.manifest.name for loaded in self._loaded.values()}
        missing = [dependency for dependency in manifest.requires if dependency not in loaded_packages]
        if missing:
            raise ValueError(f"plugin {manifest.name} requires unloaded plugins: {', '.join(missing)}")
        bindings = self._validate_service_bindings(manifest.name, service_bindings)
        context = self.registry.scope(owner, manifest.implements, bindings)
        effective_config = config if config is not None else {}
        configure_attempted = False
        try:
            self._validate_config(plugin, effective_config)
            configure_attempted = True
            await plugin.configure(context, effective_config)
            missing_ports = [
                key
                for key in manifest.implements
                if owner not in self.registry.providers(key)
            ]
            if missing_ports:
                missing_ports_text = ", ".join(str(key) for key in missing_ports)
                raise ValueError(
                    f"plugin instance {owner} did not provide declared ports: {missing_ports_text}"
                )
            await plugin.start()
            health = await plugin.health()
            if health.status == "unhealthy":
                raise RuntimeError(
                    f"plugin instance {owner} is unhealthy after start: {health.details}"
                )
        except BaseException as load_error:
            cleanup_errors: list[BaseException] = []
            if configure_attempted:
                try:
                    await plugin.stop()
                except BaseException as exc:
                    cleanup_errors.append(exc)
            try:
                context.dispose()
            except BaseException as exc:  # pragma: no cover - defensive custom registry guard
                cleanup_errors.append(exc)
            if cleanup_errors:
                raise BaseExceptionGroup(
                    f"plugin instance {owner} failed to load and rollback also failed",
                    [load_error, *cleanup_errors],
                ) from None
            raise
        self._loaded[owner] = LoadedPlugin(plugin=plugin, context=context)
        self._order.append(owner)

    def _validate_service_bindings(
        self,
        plugin_name: str,
        service_bindings: dict[PortKey, str] | None,
    ) -> dict[PortKey, str]:
        bindings = dict(service_bindings or {})
        for key, provider in bindings.items():
            if not isinstance(key, PortKey):
                raise TypeError(f"plugin {plugin_name} service binding keys must be PortKey values")
            if not isinstance(provider, str) or not provider.strip() or provider != provider.strip():
                raise ValueError(
                    f"plugin {plugin_name} service binding owners must be non-blank, trimmed strings"
                )
            try:
                self.registry.get(key, provider)
            except LookupError as exc:
                raise ValueError(
                    f"plugin {plugin_name} binds unavailable service {key} from {provider}"
                ) from exc
        return bindings

    @staticmethod
    def _validate_config(plugin: Plugin, config: dict[str, JsonValue]) -> None:
        _validate_json_config(plugin.manifest.name, config)
        reference = plugin.manifest.config_schema
        if reference is None:
            return
        candidate = Path(reference)
        if candidate.is_absolute():
            raise ValueError(
                f"plugin {plugin.manifest.name} configSchema must be package-relative"
            )
        if ".." in candidate.parts:
            raise ValueError(
                f"plugin {plugin.manifest.name} configSchema escapes its package directory"
            )
        roots: list[Path] = []
        for plugin_type in inspect.getmro(type(plugin)):
            try:
                root = Path(inspect.getfile(plugin_type)).resolve().parent
            except (TypeError, OSError):
                continue
            if root not in roots:
                roots.append(root)
        schema_path = next(
            (
                path
                for root in roots
                if (path := (root / candidate).resolve()).is_relative_to(root) and path.is_file()
            ),
            None,
        )
        if schema_path is None:
            raise ValueError(
                f"plugin {plugin.manifest.name} configSchema is unreadable: {reference}"
            )
        try:
            payload = json.loads(
                _read_schema_text(schema_path),
                object_pairs_hook=_unique_json_object,
                parse_constant=_reject_json_constant,
            )
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError(
                f"plugin {plugin.manifest.name} configSchema is unreadable: {reference}"
            ) from exc
        if not isinstance(payload, dict):
            raise ValueError(f"plugin {plugin.manifest.name} configSchema must contain an object")
        _reject_external_schema_references(payload, plugin.manifest.name)
        try:
            Draft202012Validator.check_schema(payload)
            Draft202012Validator(payload).validate(config)
        except SchemaError as exc:
            raise ValueError(
                f"plugin {plugin.manifest.name} declares an invalid configSchema: {exc.message}"
            ) from exc
        except ValidationError as exc:
            location = ".".join(str(item) for item in exc.absolute_path) or "<root>"
            raise ValueError(
                f"plugin {plugin.manifest.name} config is invalid at {location}: {exc.message}"
            ) from exc

    async def stop_all(self) -> None:
        async with self._lifecycle_lock:
            await self._stop_all_locked()

    async def _stop_all_locked(self) -> None:
        errors: list[BaseException] = []
        for name in reversed(self._order):
            loaded = self._loaded.pop(name)
            try:
                await loaded.plugin.stop()
            except BaseException as exc:
                errors.append(exc)
            try:
                loaded.context.dispose()
            except BaseException as exc:  # pragma: no cover - defensive custom registry guard
                errors.append(exc)
        self._order.clear()
        if errors:
            raise BaseExceptionGroup("one or more plugins failed to stop", errors)


def _validate_json_config(plugin_name: str, config: object) -> None:
    def visit(value: object, depth: int, active: set[int]) -> None:
        if depth > _MAX_JSON_DEPTH:
            raise ValueError(f"plugin {plugin_name} config exceeds {_MAX_JSON_DEPTH} JSON levels")
        if value is None or isinstance(value, (bool, str, int)):
            return
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError(f"plugin {plugin_name} config contains a non-finite number")
            return
        if not isinstance(value, (dict, list)):
            raise TypeError(f"plugin {plugin_name} config must contain only JSON values")
        identity = id(value)
        if identity in active:
            raise ValueError(f"plugin {plugin_name} config contains a reference cycle")
        active.add(identity)
        try:
            if isinstance(value, dict):
                for key, item in value.items():
                    if not isinstance(key, str):
                        raise TypeError(f"plugin {plugin_name} config object keys must be strings")
                    visit(item, depth + 1, active)
            else:
                for item in value:
                    visit(item, depth + 1, active)
        finally:
            active.remove(identity)

    if not isinstance(config, dict):
        raise TypeError(f"plugin {plugin_name} config must be a JSON object")
    visit(config, 0, set())
    try:
        encoded = json.dumps(
            config,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"plugin {plugin_name} config is not valid JSON") from exc
    if len(encoded) > _MAX_PLUGIN_CONFIG_BYTES:
        raise ValueError(
            f"plugin {plugin_name} config exceeds {_MAX_PLUGIN_CONFIG_BYTES} bytes"
        )


def _read_schema_text(path: Path) -> str:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("plugin config schema is not a regular file")
        if before.st_size > _MAX_PLUGIN_SCHEMA_BYTES:
            raise ValueError("plugin config schema exceeds the size limit")
        chunks: list[bytes] = []
        remaining = _MAX_PLUGIN_SCHEMA_BYTES + 1
        while remaining:
            chunk = os.read(descriptor, min(64 * 1024, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        payload = b"".join(chunks)
        after = os.fstat(descriptor)
        identity = lambda value: (  # noqa: E731 - compact immutable stat projection
            value.st_dev,
            value.st_ino,
            value.st_mode,
            value.st_size,
            value.st_mtime_ns,
            value.st_ctime_ns,
        )
        if len(payload) > _MAX_PLUGIN_SCHEMA_BYTES:
            raise ValueError("plugin config schema exceeds the size limit")
        if len(payload) != before.st_size or identity(before) != identity(after):
            raise ValueError("plugin config schema changed while it was read")
        return payload.decode("utf-8")
    finally:
        os.close(descriptor)


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON number is not allowed: {value}")


def _reject_external_schema_references(value: object, plugin_name: str) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"$ref", "$dynamicRef"} and (
                not isinstance(item, str) or not item.startswith("#")
            ):
                raise ValueError(
                    f"plugin {plugin_name} configSchema must be self-contained; "
                    f"external {key} is not allowed"
                )
            _reject_external_schema_references(item, plugin_name)
    elif isinstance(value, list):
        for item in value:
            _reject_external_schema_references(item, plugin_name)
