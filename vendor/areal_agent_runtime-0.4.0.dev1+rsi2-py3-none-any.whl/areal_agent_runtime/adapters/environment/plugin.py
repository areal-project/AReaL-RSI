"""Plugin packaging for LocalEnvironmentAdapter."""

from __future__ import annotations

import math
from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters.environment.local import LocalEnvironmentAdapter
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class LocalEnvironmentPlugin:
    manifest = PluginManifest(
        name="local-environment",
        version="1.0.0",
        implements=(PortKey.ENVIRONMENT,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.environment.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("filesystem.read", "filesystem.write"),
    )

    def __init__(self) -> None:
        self.environment: LocalEnvironmentAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        configured_root = config.get("root")
        if configured_root is None:
            root = Path(".areal-agent-runtime/environment")
        elif isinstance(configured_root, str) and configured_root and configured_root == configured_root.strip():
            root = Path(configured_root)
        else:
            raise ValueError("root must be a trimmed non-empty path")
        allow_external_mounts = config.get("allowExternalMounts", False)
        if not isinstance(allow_external_mounts, bool):
            raise TypeError("allowExternalMounts must be a boolean")
        self.environment = LocalEnvironmentAdapter(
            root,
            allow_external_mounts=allow_external_mounts,
            allowed_external_mount_roots=_path_list(config.get("allowedExternalMountRoots")),
            lease_timeout_seconds=_positive_number(config.get("leaseTimeoutSeconds"), 30.0),
            max_workspace_entries=_positive_integer(config.get("maxWorkspaceEntries"), 100_000),
            max_workspace_bytes=_positive_integer(
                config.get("maxWorkspaceBytes"),
                2 * 1024 * 1024 * 1024,
            ),
        )
        context.provide(PortKey.ENVIRONMENT, self.environment)

    async def start(self) -> None:
        if self.environment is None:
            raise RuntimeError("Local environment plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.environment is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.environment.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> LocalEnvironmentPlugin:
    return LocalEnvironmentPlugin()


def _positive_number(value: JsonValue | None, default: float) -> float:
    if value is None:
        return default
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value <= 0:
        raise ValueError("leaseTimeoutSeconds must be a finite positive number")
    return float(value)


def _path_list(value: JsonValue | None) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item or item != item.strip() for item in value
    ):
        raise ValueError("allowedExternalMountRoots must be a list of trimmed non-empty paths")
    if len(value) != len(set(value)):
        raise ValueError("allowedExternalMountRoots must not contain duplicates")
    return tuple(value)


def _positive_integer(value: JsonValue | None, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("workspace limits must be positive integers")
    return value
