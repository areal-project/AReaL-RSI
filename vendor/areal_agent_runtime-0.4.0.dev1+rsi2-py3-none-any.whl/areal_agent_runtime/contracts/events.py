"""Canonical event log shared by Hosts, trajectories and replay."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import Field, JsonValue, StrictBool, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel, require_optional_trimmed, require_trimmed
from areal_agent_runtime.contracts.data import DataGovernance
from areal_agent_runtime.contracts.version import EVENT_API_VERSION, EventApiVersion


class EventType(StrEnum):
    RUN_QUEUED = "run.queued"
    RUN_STARTED = "run.started"
    RUN_RESUMED = "run.resumed"
    RUN_COMPLETED = "run.completed"
    RUN_FAILED = "run.failed"
    RUN_CANCELLED = "run.cancelled"
    EXECUTION_STARTED = "execution.started"
    EXECUTION_COMPLETED = "execution.completed"
    EXECUTION_FAILED = "execution.failed"
    MESSAGE_DELTA = "message.delta"
    MESSAGE_COMPLETED = "message.completed"
    REASONING_DELTA = "reasoning.delta"
    ASSET_CREATED = "asset.created"
    ASSET_ATTACHED = "asset.attached"
    TOOL_REQUESTED = "tool.requested"
    TOOL_STARTED = "tool.started"
    TOOL_PROGRESS = "tool.progress"
    TOOL_COMPLETED = "tool.completed"
    TOOL_FAILED = "tool.failed"
    INTERACTION_REQUIRED = "interaction.required"
    INTERACTION_RESOLVED = "interaction.resolved"
    AGENT_STARTED = "agent.started"
    AGENT_SCHEDULED = "agent.scheduled"
    AGENT_RETRY_SCHEDULED = "agent.retry.scheduled"
    AGENT_ENVIRONMENT_RESOLVED = "agent.environment.resolved"
    AGENT_MESSAGE = "agent.message"
    AGENT_COMPLETED = "agent.completed"
    AGENT_FAILED = "agent.failed"
    AGENT_CANCELLED = "agent.cancelled"
    ORCHESTRATOR_DECIDED = "orchestrator.decided"
    RUNTIME_GRAPH_SNAPSHOTTED = "runtime_graph.snapshotted"
    PARALLEL_GROUP_STARTED = "parallel_group.started"
    PARALLEL_GROUP_JOINED = "parallel_group.joined"
    PARALLEL_GROUP_FAILED = "parallel_group.failed"
    PARALLEL_GROUP_CANCELLED = "parallel_group.cancelled"
    ENVIRONMENT_CREATED = "environment.created"
    WORKSPACE_CHECKPOINTED = "workspace.checkpointed"
    SESSION_COMMITTED = "session.committed"
    USAGE_UPDATED = "usage.updated"
    MODEL_CALL_STARTED = "model_call.started"
    MODEL_CALL_COMPLETED = "model_call.completed"
    MODEL_CALL_FAILED = "model_call.failed"
    RAW_EVENT_RECORDED = "raw_event.recorded"
    RUNTIME_STATUS = "runtime.status"
    WARNING_RAISED = "warning.raised"


class EnvironmentCreatedEventData(ContractModel):
    """Typed payload for the authoritative Environment identity transition."""

    environment_id: str = Field(min_length=1)
    workspace_id: str = Field(min_length=1)
    mount_hint: str | None = None

    @field_validator("environment_id", "workspace_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "environment-created identity")

    @field_validator("mount_hint")
    @classmethod
    def validate_mount_hint(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "environment-created mountHint")


class RunEvent(ContractModel):
    api_version: EventApiVersion = EVENT_API_VERSION
    event_id: str = Field(min_length=1)
    sequence: StrictInt = Field(ge=0)
    time: datetime
    run_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    execution_id: str | None = None
    agent_attempt_id: str | None = None
    agent_id: str | None = None
    parent_agent_id: str | None = None
    causation_id: str | None = None
    correlation_id: str = Field(min_length=1)
    tenant_id: str | None = None
    project_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    episode_id: str | None = None
    environment_id: str | None = None
    agent_environment_id: str | None = None
    workspace_id: str | None = None
    type: EventType
    data: dict[str, JsonValue] = Field(default_factory=dict)
    ignorable: StrictBool = False
    governance: DataGovernance = Field(default_factory=DataGovernance)

    @field_validator("event_id", "run_id", "session_id", "correlation_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "RunEvent identity")

    @field_validator(
        "execution_id",
        "agent_attempt_id",
        "agent_id",
        "parent_agent_id",
        "causation_id",
        "tenant_id",
        "project_id",
        "trace_id",
        "span_id",
        "episode_id",
        "environment_id",
        "agent_environment_id",
        "workspace_id",
    )
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "RunEvent optional identity")

    @field_validator("time")
    @classmethod
    def validate_time(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("RunEvent time must include a timezone")
        return value

    @model_validator(mode="after")
    def validate_lineage(self) -> RunEvent:
        if self.agent_id is None and self.parent_agent_id is not None:
            raise ValueError("parentAgentId requires agentId")
        if self.agent_id is not None and self.parent_agent_id == self.agent_id:
            raise ValueError("RunEvent agent cannot be its own parent")
        if self.agent_attempt_id is not None and self.execution_id is None:
            raise ValueError("agentAttemptId requires executionId")
        return self
