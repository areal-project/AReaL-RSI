"""Standard MCP server gateway for Application-owned tools.

This is the opposite direction from :mod:`areal_agent_runtime.adapters.mcp.provider`:

* ``GenericMcpToolProvider`` makes an external MCP server callable by the
  ARealAgentRuntime Application.
* ``ApplicationToolMcpGateway`` makes the already-selected Application tool
  catalog callable by an MCP-capable Runtime/Harness.

The gateway is an Adapter-side transport utility, not a seventh Kernel Port.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import json
import math
import secrets
import socket
from dataclasses import dataclass, field
from typing import Any, Protocol

from areal_agent_runtime.contracts.content import (
    AudioRefBlock,
    FileRefBlock,
    ImageRefBlock,
    JsonBlock,
    ReasoningBlock,
    TextBlock,
    VideoRefBlock,
)
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import ToolExecution, ToolResult, ToolSpec

APPLICATION_TOOL_MCP_PROTOCOL = "mcp.streamable-http"
APPLICATION_TOOL_MCP_SERVER_NAME = "areal_agent_runtime_application"
_MAX_BODY_BYTES = 4 * 1024 * 1024
_SERVER_LIFECYCLE_TIMEOUT_SECONDS = 5.0


class ApplicationToolExecution(Protocol):
    """Execution-owned rendezvous implemented by Runtime channels."""

    async def invoke_application_tool(
        self,
        *,
        call_id: str,
        name: str,
        arguments: dict[str, object],
        agent_id: str | None,
    ) -> ToolResult: ...


@dataclass(frozen=True, slots=True)
class ApplicationMcpTool:
    canonical_name: str
    exposed_name: str
    description: str
    input_schema: dict[str, object]
    execution: ToolExecution
    terminal_on_success: bool


@dataclass(frozen=True, slots=True)
class ApplicationToolMcpEndpoint:
    session_id: str
    url: str
    server_name: str
    bearer_token: str = field(repr=False)
    tools: tuple[ApplicationMcpTool, ...] = ()


@dataclass(slots=True)
class _GatewaySession:
    endpoint: ApplicationToolMcpEndpoint
    server: _McpEndpointServer
    tool_by_exposed_name: dict[str, ApplicationMcpTool]
    limiter: asyncio.Semaphore
    execution: ApplicationToolExecution | None = None


class ApplicationToolMcpGateway:
    """Expose each Runtime session's selected ToolSet through standard MCP.

    A separate authenticated loopback endpoint is used per Runtime session, so
    an MCP client never receives a catalog belonging to another tenant/session.
    The caller receives only tools already present in AgentEnvironmentSnapshot;
    registration in the global ToolRegistry is insufficient.
    """

    def __init__(
        self,
        *,
        asset_store: AssetStorePort | None = None,
        call_timeout_seconds: float = 120.0,
        max_asset_bytes: int = _MAX_BODY_BYTES,
        max_concurrency_per_session: int = 16,
    ) -> None:
        if (
            isinstance(call_timeout_seconds, bool)
            or not isinstance(call_timeout_seconds, (int, float))
            or not math.isfinite(call_timeout_seconds)
            or call_timeout_seconds <= 0
        ):
            raise ValueError("call_timeout_seconds must be positive")
        if isinstance(max_asset_bytes, bool) or not isinstance(max_asset_bytes, int) or max_asset_bytes < 1:
            raise ValueError("max_asset_bytes must be positive")
        if (
            isinstance(max_concurrency_per_session, bool)
            or not isinstance(max_concurrency_per_session, int)
            or max_concurrency_per_session < 1
        ):
            raise ValueError("max_concurrency_per_session must be positive")
        self._asset_store = asset_store
        self._call_timeout_seconds = call_timeout_seconds
        self._max_asset_bytes = max_asset_bytes
        self._max_concurrency = max_concurrency_per_session
        self._sessions: dict[str, _GatewaySession] = {}
        self._lifecycle_lock = asyncio.Lock()
        self._closing = False
        self._closed = False

    async def open_session(
        self,
        session_id: str,
        tools: tuple[ToolSpec, ...],
    ) -> ApplicationToolMcpEndpoint:
        if not isinstance(session_id, str) or not session_id.strip() or session_id != session_id.strip():
            raise ValueError("Application MCP session_id must be a non-blank, trimmed string")
        if not isinstance(tools, tuple) or any(not isinstance(tool, ToolSpec) for tool in tools):
            raise TypeError("Application MCP tools must be a tuple of ToolSpec values")
        async with self._lifecycle_lock:
            if self._closing or self._closed:
                raise RuntimeError("Application MCP gateway is closed")
            selected = tuple(
                ApplicationMcpTool(
                    canonical_name=tool.name,
                    exposed_name=tool.name,
                    description=tool.description,
                    input_schema=dict(tool.input_schema),
                    execution=tool.execution,
                    terminal_on_success=tool.terminal_on_success,
                )
                for tool in tools
                if tool.execution in {ToolExecution.APPLICATION, ToolExecution.REMOTE}
            )
            existing = self._sessions.get(session_id)
            if existing is not None:
                if existing.endpoint.tools != selected:
                    raise ValueError(
                        "Application MCP tool catalog cannot change inside one Runtime session"
                    )
                return existing.endpoint
            names = [tool.exposed_name for tool in selected]
            if len(names) != len(set(names)):
                raise ValueError("Application MCP tool names must be unique")
            token = secrets.token_urlsafe(32)
            server = _McpEndpointServer(
                session_id=session_id,
                bearer_token=token,
                list_tools=lambda: selected,
                call_tool=lambda name, arguments, request_id: self._call_tool(
                    session_id,
                    name,
                    arguments,
                    request_id=request_id,
                ),
                to_mcp_result=self._to_mcp_result,
            )
            url = await server.start()
            endpoint = ApplicationToolMcpEndpoint(
                session_id=session_id,
                url=url,
                server_name=APPLICATION_TOOL_MCP_SERVER_NAME,
                bearer_token=token,
                tools=selected,
            )
            self._sessions[session_id] = _GatewaySession(
                endpoint=endpoint,
                server=server,
                tool_by_exposed_name={tool.exposed_name: tool for tool in selected},
                limiter=asyncio.Semaphore(self._max_concurrency),
            )
            return endpoint

    def bind(self, session_id: str, execution: ApplicationToolExecution) -> None:
        registration = self._registration(session_id)
        if registration.execution is not None and registration.execution is not execution:
            raise RuntimeError(f"Runtime session already has an active Application tool execution: {session_id}")
        registration.execution = execution

    def unbind(self, session_id: str, execution: ApplicationToolExecution) -> None:
        registration = self._sessions.get(session_id)
        if registration is not None and registration.execution is execution:
            registration.execution = None

    async def close_session(self, session_id: str) -> None:
        async with self._lifecycle_lock:
            registration = self._sessions.pop(session_id, None)
            if registration is not None:
                await registration.server.close()

    async def close(self) -> None:
        async with self._lifecycle_lock:
            if self._closed:
                return
            self._closing = True
            registrations = tuple(self._sessions.values())
            self._sessions.clear()
            errors: list[BaseException] = []
            for registration in registrations:
                try:
                    await registration.server.close()
                except BaseException as exc:
                    errors.append(exc)
            self._closed = True
            self._closing = False
            if errors:
                raise BaseExceptionGroup("one or more Application MCP sessions failed to close", errors)

    def _registration(self, session_id: str) -> _GatewaySession:
        try:
            return self._sessions[session_id]
        except KeyError as exc:
            raise LookupError(f"Unknown Application MCP session: {session_id}") from exc

    async def _call_tool(
        self,
        session_id: str,
        exposed_name: str,
        arguments: dict[str, object],
        *,
        request_id: str,
    ) -> ToolResult:
        registration = self._registration(session_id)
        tool = registration.tool_by_exposed_name.get(exposed_name)
        if tool is None:
            return ToolResult(
                call_id=self._call_id(session_id, request_id),
                error=ErrorInfo(
                    code="APPLICATION_MCP_TOOL_NOT_FOUND",
                    category=ErrorCategory.PERMISSION,
                    message=f"Tool is not in this Session ToolSet: {exposed_name}",
                ),
            )
        execution = registration.execution
        if execution is None:
            return ToolResult(
                call_id=self._call_id(session_id, request_id),
                error=ErrorInfo(
                    code="APPLICATION_MCP_EXECUTION_NOT_ACTIVE",
                    category=ErrorCategory.CONFLICT,
                    message="Runtime session has no active Application execution",
                    retryable=True,
                ),
            )
        call_id = self._call_id(session_id, request_id)
        async with registration.limiter:
            try:
                async with asyncio.timeout(self._call_timeout_seconds):
                    result = await execution.invoke_application_tool(
                        call_id=call_id,
                        name=tool.canonical_name,
                        arguments=arguments,
                        agent_id=None,
                    )
            except TimeoutError:
                return ToolResult(
                    call_id=call_id,
                    error=ErrorInfo(
                        code="APPLICATION_MCP_TOOL_TIMEOUT",
                        category=ErrorCategory.TIMEOUT,
                        message=f"Application tool timed out: {tool.canonical_name}",
                        retryable=True,
                    ),
                )
            except Exception as exc:
                return ToolResult(
                    call_id=call_id,
                    error=ErrorInfo(
                        code="APPLICATION_MCP_TOOL_FAILED",
                        category=ErrorCategory.INTERNAL,
                        message=str(exc) or type(exc).__name__,
                        retryable=False,
                    ),
                )
        if result.call_id != call_id:
            return ToolResult(
                call_id=call_id,
                error=ErrorInfo(
                    code="APPLICATION_MCP_CALL_CORRELATION_MISMATCH",
                    category=ErrorCategory.PROTOCOL,
                    message=f"Application returned ToolResult for {result.call_id}, expected {call_id}",
                ),
            )
        return result

    @staticmethod
    def _call_id(session_id: str, request_id: str) -> str:
        digest = hashlib.sha256(f"{session_id}\0{request_id}".encode()).hexdigest()[:24]
        return f"tool_mcp_{digest}"

    async def _to_mcp_result(self, result: ToolResult) -> object:
        from mcp import types

        content: list[object] = []
        for block in result.content:
            if isinstance(block, (TextBlock, ReasoningBlock)):
                content.append(types.TextContent(text=block.text))
            elif isinstance(block, JsonBlock):
                content.append(
                    types.TextContent(
                        text=json.dumps(block.value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                    )
                )
            elif isinstance(block, ImageRefBlock):
                raw = await self._asset_bytes(block.asset_id)
                if raw is None:
                    content.append(self._asset_link(block.asset_id, block.media_type))
                else:
                    content.append(
                        types.ImageContent(
                            data=base64.b64encode(raw).decode("ascii"),
                            mimeType=block.media_type,
                        )
                    )
            elif isinstance(block, AudioRefBlock):
                raw = await self._asset_bytes(block.asset_id)
                if raw is None:
                    content.append(self._asset_link(block.asset_id, block.media_type))
                else:
                    content.append(
                        types.AudioContent(
                            data=base64.b64encode(raw).decode("ascii"),
                            mimeType=block.media_type,
                        )
                    )
            elif isinstance(block, (FileRefBlock, VideoRefBlock)):
                raw = await self._asset_bytes(block.asset_id)
                if raw is None:
                    content.append(self._asset_link(block.asset_id, block.media_type))
                else:
                    content.append(
                        types.EmbeddedResource(
                            resource=types.BlobResourceContents(
                                uri=f"areal_agent_runtime://assets/{block.asset_id}",
                                mimeType=block.media_type,
                                blob=base64.b64encode(raw).decode("ascii"),
                            )
                        )
                    )
        if result.error is not None:
            content.append(types.TextContent(text=f"[{result.error.code}] {result.error.message}"))
        return types.CallToolResult(
            content=content,
            structuredContent={
                "callId": result.call_id,
                "value": result.value,
                "error": (
                    result.error.model_dump(mode="json", by_alias=True)
                    if result.error is not None
                    else None
                ),
            },
            isError=result.error is not None,
            _meta={"areal_agent_runtime/callId": result.call_id},
        )

    async def _asset_bytes(self, asset_id: str) -> bytes | None:
        if self._asset_store is None:
            return None
        chunks: list[bytes] = []
        size = 0
        async for chunk in self._asset_store.open(asset_id):
            size += len(chunk)
            if size > self._max_asset_bytes:
                raise ValueError(f"Application MCP asset exceeds {self._max_asset_bytes} bytes: {asset_id}")
            chunks.append(chunk)
        return b"".join(chunks)

    @staticmethod
    def _asset_link(asset_id: str, media_type: str) -> object:
        from mcp import types

        return types.ResourceLink(
            name=asset_id,
            uri=f"areal_agent_runtime://assets/{asset_id}",
            mimeType=media_type,
        )


class _McpEndpointServer:
    """One authenticated, stateless MCP Streamable HTTP endpoint."""

    def __init__(
        self,
        *,
        session_id: str,
        bearer_token: str,
        list_tools: Any,
        call_tool: Any,
        to_mcp_result: Any,
    ) -> None:
        self._session_id = session_id
        self._token = bearer_token
        self._list_tools = list_tools
        self._call_tool = call_tool
        self._to_mcp_result = to_mcp_result
        self._manager: Any = None
        self._manager_task: asyncio.Task[None] | None = None
        self._manager_ready = asyncio.Event()
        self._manager_stop = asyncio.Event()
        self._server: Any = None
        self._server_task: asyncio.Task[None] | None = None
        self._socket: socket.socket | None = None

    async def start(self) -> str:
        try:
            return await self._start()
        except BaseException as start_error:
            try:
                await self.close()
            except BaseException as cleanup_error:
                raise BaseExceptionGroup(
                    "Application MCP server failed to start and cleanup also failed",
                    [start_error, cleanup_error],
                ) from None
            raise

    async def _start(self) -> str:
        import uvicorn
        from mcp import types
        from mcp.server.lowlevel import Server
        from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

        async def on_list_tools(_context: object, _params: object) -> object:
            tools = self._list_tools()
            return types.ListToolsResult(
                tools=[
                    types.Tool(
                        name=tool.exposed_name,
                        description=tool.description,
                        inputSchema=tool.input_schema,
                        _meta={
                            "areal_agent_runtime/canonicalName": tool.canonical_name,
                            "areal_agent_runtime/execution": tool.execution.value,
                            "areal_agent_runtime/terminalOnSuccess": tool.terminal_on_success,
                        },
                    )
                    for tool in tools
                ]
            )

        async def on_call_tool(context: object, params: object) -> object:
            name = getattr(params, "name", None)
            arguments = getattr(params, "arguments", None) or {}
            if not isinstance(name, str) or not isinstance(arguments, dict):
                result = ToolResult(
                    call_id="tool_mcp_invalid",
                    error=ErrorInfo(
                        code="APPLICATION_MCP_REQUEST_INVALID",
                        category=ErrorCategory.PROTOCOL,
                        message="MCP tools/call requires a tool name and object arguments",
                    ),
                )
            else:
                raw_request_id = getattr(context, "request_id", None)
                request_id = str(raw_request_id) if raw_request_id is not None else secrets.token_hex(12)
                result = await self._call_tool(name, dict(arguments), request_id)
            return await self._to_mcp_result(result)

        low_level = Server(
            APPLICATION_TOOL_MCP_SERVER_NAME,
            version="1.0.0",
            on_list_tools=on_list_tools,
            on_call_tool=on_call_tool,
        )
        self._manager = StreamableHTTPSessionManager(
            low_level,
            json_response=True,
            stateless=True,
            max_request_body_size=_MAX_BODY_BYTES,
        )
        self._manager_task = asyncio.create_task(
            self._run_manager(),
            name=f"application-mcp-manager:{self._session_id}",
        )
        ready = asyncio.create_task(self._manager_ready.wait())
        try:
            done, _pending = await asyncio.wait(
                {ready, self._manager_task},
                timeout=_SERVER_LIFECYCLE_TIMEOUT_SECONDS,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if self._manager_task in done:
                await self._manager_task
                raise RuntimeError("Application MCP manager stopped during startup")
            if ready not in done:
                raise TimeoutError("Application MCP manager did not become ready")
        finally:
            if not ready.done():
                ready.cancel()
            await asyncio.gather(ready, return_exceptions=True)

        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind(("127.0.0.1", 0))
        listener.listen(128)
        listener.setblocking(False)
        self._socket = listener
        port = int(listener.getsockname()[1])
        config = uvicorn.Config(
            self._asgi,
            host="127.0.0.1",
            port=port,
            log_level="warning",
            access_log=False,
            lifespan="off",
            interface="asgi3",
        )
        self._server = uvicorn.Server(config)
        self._server_task = asyncio.create_task(
            self._server.serve(sockets=[listener]),
            name=f"application-mcp:{self._session_id}",
        )
        for _ in range(500):
            if self._server.started:
                return f"http://127.0.0.1:{port}/mcp"
            if self._server_task.done():
                await self._server_task
                raise RuntimeError("Application MCP server stopped during startup")
            await asyncio.sleep(0.01)
        raise TimeoutError("Application MCP server did not become ready")

    async def close(self) -> None:
        errors: list[BaseException] = []
        if self._server is not None:
            self._server.should_exit = True
        if self._server_task is not None:
            if self._server_task is not asyncio.current_task():
                try:
                    await asyncio.wait_for(
                        self._server_task,
                        timeout=_SERVER_LIFECYCLE_TIMEOUT_SECONDS,
                    )
                except TimeoutError:
                    if self._server is not None:
                        self._server.force_exit = True
                    self._server_task.cancel()
                    await asyncio.gather(self._server_task, return_exceptions=True)
                    errors.append(TimeoutError("Application MCP server did not stop in time"))
                except BaseException as exc:
                    errors.append(exc)
        self._server_task = None
        self._server = None
        if self._socket is not None:
            with contextlib.suppress(OSError):
                self._socket.close()
        self._socket = None
        self._manager_stop.set()
        if self._manager_task is not None:
            if self._manager_task is not asyncio.current_task():
                try:
                    await asyncio.wait_for(
                        self._manager_task,
                        timeout=_SERVER_LIFECYCLE_TIMEOUT_SECONDS,
                    )
                except TimeoutError:
                    self._manager_task.cancel()
                    await asyncio.gather(self._manager_task, return_exceptions=True)
                    errors.append(TimeoutError("Application MCP manager did not stop in time"))
                except BaseException as exc:
                    errors.append(exc)
        self._manager_task = None
        self._manager = None
        if errors:
            if len(errors) == 1:
                raise errors[0]
            raise BaseExceptionGroup("Application MCP server failed to close cleanly", errors)

    async def _run_manager(self) -> None:
        async with self._manager.run():
            self._manager_ready.set()
            await self._manager_stop.wait()

    async def _asgi(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope.get("type") != "http" or scope.get("path") != "/mcp":
            await _send_json(send, 404, {"error": "not_found"})
            return
        authorization = [
            value.decode("latin-1")
            for key, value in scope.get("headers", ())
            if key.decode("latin-1").lower() == "authorization"
        ]
        supplied = authorization[0] if len(authorization) == 1 else ""
        if not secrets.compare_digest(supplied, f"Bearer {self._token}"):
            await _send_json(
                send,
                401,
                {"error": "unauthorized"},
                headers=((b"www-authenticate", b"Bearer"),),
            )
            return
        # This endpoint is deliberately request/response-only: Application
        # tools never initiate server-to-client requests or notifications. MCP
        # Streamable HTTP makes the standalone GET/SSE channel optional and
        # requires 405 when it is not offered. Rejecting it explicitly also
        # prevents an otherwise idle SSE request from outliving the owning
        # Runtime session and being force-cancelled during Uvicorn shutdown.
        if scope.get("method") == "GET":
            await _send_empty(
                send,
                405,
                headers=((b"allow", b"POST"),),
            )
            return
        await self._manager.handle_request(scope, receive, send)


async def _send_json(
    send: Any,
    status: int,
    payload: dict[str, object],
    *,
    headers: tuple[tuple[bytes, bytes], ...] = (),
) -> None:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": (
                (b"content-type", b"application/json; charset=utf-8"),
                (b"content-length", str(len(body)).encode("ascii")),
                *headers,
            ),
        }
    )
    await send({"type": "http.response.body", "body": body})


async def _send_empty(
    send: Any,
    status: int,
    *,
    headers: tuple[tuple[bytes, bytes], ...] = (),
) -> None:
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": ((b"content-length", b"0"), *headers),
        }
    )
    await send({"type": "http.response.body", "body": b""})
