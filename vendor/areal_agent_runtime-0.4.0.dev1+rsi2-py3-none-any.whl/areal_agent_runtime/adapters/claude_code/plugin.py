"""Claude Code entrypoint sharing the official SDK adapter implementation."""

from areal_agent_runtime.adapters.claude_code.runtime import ClaudeCodeRuntimeAdapter
from areal_agent_runtime.adapters.claude_sdk.plugin import ClaudeAgentSDKRuntimePlugin
from areal_agent_runtime.plugin_sdk import PluginEntrypoints, PluginManifest, PortKey


class ClaudeCodeRuntimePlugin(ClaudeAgentSDKRuntimePlugin):
    runtime_class = ClaudeCodeRuntimeAdapter
    manifest = PluginManifest(
        name="claude-code-runtime",
        version="1.0.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.claude_code.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("process.spawn", "workspace.read", "workspace.write", "network.model"),
        metadata={"areal.agent-runtime.bootstrap.profileBinding": True},
    )


def create_plugin() -> ClaudeCodeRuntimePlugin:
    return ClaudeCodeRuntimePlugin()
