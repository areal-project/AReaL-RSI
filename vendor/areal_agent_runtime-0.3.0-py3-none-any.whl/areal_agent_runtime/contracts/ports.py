"""Stable Kernel ports plus the narrow Host resource-materialization binding SPI."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from pydantic import Field, JsonValue, field_validator

from areal_agent_runtime.contracts.base import (
    ContractModel,
    require_media_type,
    require_optional_trimmed,
    require_trimmed,
    require_unique_trimmed,
)
from areal_agent_runtime.contracts.content import AssetRef, ContentBlock
from areal_agent_runtime.contracts.data import CommandReceipt, DataAnnotation, RuntimeCommand
from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot, ResourceSource
from areal_agent_runtime.contracts.events import RunEvent
from areal_agent_runtime.contracts.product import RunSnapshot
from areal_agent_runtime.contracts.runtime import HealthStatus, ToolCall, ToolResult, ToolSpec, WorkspaceRef


class EnvironmentSpec(ContractModel):
    workspace: WorkspaceRef
    permissions: tuple[str, ...] = ()
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("permissions")
    @classmethod
    def validate_permissions(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return require_unique_trimmed(value, "Environment permissions")


class EnvironmentRef(ContractModel):
    environment_id: str = Field(min_length=1)
    workspace: WorkspaceRef

    @field_validator("environment_id")
    @classmethod
    def validate_environment_id(cls, value: str) -> str:
        return require_trimmed(value, "environmentId")


class WorkspaceCheckpoint(ContractModel):
    checkpoint_id: str = Field(min_length=1)
    workspace_id: str = Field(min_length=1)
    digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    locator: str | None = None

    @field_validator("checkpoint_id", "workspace_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Workspace checkpoint identity")

    @field_validator("digest")
    @classmethod
    def normalize_digest(cls, value: str) -> str:
        return value.lower()

    @field_validator("locator")
    @classmethod
    def validate_locator(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Workspace checkpoint locator")


class LoadedResource(ContractModel):
    """Host-resolved resource content with a safe logical locator."""

    content: JsonValue
    media_type: str = Field(min_length=1)
    sha256: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    version: str | None = None
    locator: str = Field(min_length=1)

    @field_validator("sha256")
    @classmethod
    def normalize_sha256(cls, value: str) -> str:
        return value.lower()

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value)

    @field_validator("locator")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Loaded resource identity")

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Loaded resource version")


@runtime_checkable
class ResourceLoaderPort(Protocol):
    async def load(self, source: ResourceSource) -> LoadedResource: ...


@runtime_checkable
class ToolProviderPort(Protocol):
    """Stable provider surface; discovery must be deterministic and side-effect free until refresh/reload."""

    async def list_tools(self) -> tuple[ToolSpec, ...]: ...

    async def invoke(self, call: ToolCall) -> ToolResult: ...

    async def health(self) -> HealthStatus: ...


@runtime_checkable
class EnvironmentPort(Protocol):
    async def open(self, spec: EnvironmentSpec) -> EnvironmentRef: ...

    async def checkpoint(self, environment: EnvironmentRef) -> WorkspaceCheckpoint: ...

    async def close(self, environment: EnvironmentRef) -> None: ...

    async def health(self) -> HealthStatus: ...


@runtime_checkable
class StateStorePort(Protocol):
    async def create_run(self, snapshot: RunSnapshot) -> None: ...

    async def save_run(self, snapshot: RunSnapshot) -> None: ...

    async def get_run(self, run_id: str) -> RunSnapshot | None: ...

    async def try_acquire_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool:
        """Claim execution ownership without creating a second public Port."""

        ...

    async def renew_run(
        self,
        run_id: str,
        owner_id: str,
        *,
        ttl_seconds: float,
    ) -> bool: ...

    async def release_run(self, run_id: str, owner_id: str) -> None: ...

    async def save_environment_snapshot(
        self,
        session_id: str,
        snapshot: AgentEnvironmentSnapshot,
    ) -> None: ...

    async def get_environment_snapshot(self, session_id: str) -> AgentEnvironmentSnapshot | None: ...

    async def commit_event(
        self,
        event: RunEvent,
        snapshot: RunSnapshot,
        *,
        outbox_sinks: tuple[str, ...],
    ) -> None:
        """Atomically commit canonical history, its read model and delivery intents."""

        ...

    async def latest_event_sequence(self, run_id: str) -> int: ...

    async def list_run_ids(self) -> tuple[str, ...]: ...

    async def list_events(self, run_id: str) -> tuple[RunEvent, ...]: ...

    async def pending_event_deliveries(
        self,
        run_id: str,
        sink_id: str,
        *,
        limit: int = 128,
    ) -> tuple[RunEvent, ...]: ...

    async def acknowledge_event_delivery(
        self,
        run_id: str,
        sink_id: str,
        *,
        through_sequence: int,
    ) -> None: ...

    def stream_events(self, run_id: str, after: int | None = None) -> AsyncIterator[RunEvent]: ...


@runtime_checkable
class AssetStorePort(Protocol):
    async def put(
        self,
        chunks: AsyncIterator[bytes],
        *,
        media_type: str,
        metadata: dict[str, JsonValue] | None = None,
    ) -> AssetRef:
        """Persist one immutable descriptor idempotently.

        Repeating ``put`` with identical bytes, media type and metadata must
        return the same logical ``AssetRef``.  This makes an external delivery
        retry safe when its result was accepted but the canonical event commit
        was interrupted.
        """

        ...

    def open(self, asset_id: str) -> AsyncIterator[bytes]: ...

    async def get(self, asset_id: str) -> AssetRef | None: ...

    async def resolve(self, asset_id: str, *, ttl_seconds: int = 300) -> str: ...


@runtime_checkable
class EventSinkPort(Protocol):
    async def consume(self, event: RunEvent) -> None: ...

    async def flush(self, run_id: str) -> None: ...

    async def health(self) -> HealthStatus: ...


@runtime_checkable
class AnnotationStorePort(Protocol):
    """Append-only annotation SPI, separate from immutable runtime facts."""

    async def append(self, annotation: DataAnnotation) -> None: ...

    async def list(self, run_id: str) -> tuple[DataAnnotation, ...]: ...


@runtime_checkable
class RuntimeCommandBusPort(Protocol):
    """Cross-owner command SPI with at-least-once and fencing semantics.

    Production implementations must deduplicate ``commandId`` and reject a
    command whose expected revision or fencing token is stale.  Core does not
    ship a fake distributed implementation and therefore does not advertise
    cross-Pod forwarding yet.
    """

    async def publish(self, command: RuntimeCommand) -> CommandReceipt: ...


class ArtifactRef(ContractModel):
    artifact_id: str = Field(min_length=1)
    version: str = Field(min_length=1)
    content: tuple[ContentBlock, ...] = ()
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("artifact_id", "version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Artifact identity")


class ArtifactPublishReceipt(ContractModel):
    publisher: str = Field(min_length=1)
    artifact_id: str = Field(min_length=1)
    version: str = Field(min_length=1)
    locator: str | None = None
    checksum: str | None = None
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("publisher", "artifact_id", "version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Artifact receipt identity")

    @field_validator("locator", "checksum")
    @classmethod
    def validate_optional_value(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Artifact receipt value")


@runtime_checkable
class ArtifactPublisherPort(Protocol):
    """ARealAgentRuntime domain extension; deliberately not a generic Kernel port."""

    async def publish(self, artifact: ArtifactRef) -> ArtifactPublishReceipt:
        """Publish durably and honor ``metadata.idempotencyKey`` when present.

        A repeated key with an identical artifact returns the original receipt;
        reusing a key for a different artifact must fail closed.
        """

        ...
