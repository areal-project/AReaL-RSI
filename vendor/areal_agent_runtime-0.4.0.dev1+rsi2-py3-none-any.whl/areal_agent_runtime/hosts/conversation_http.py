"""Explicit, additive Conversation routes for the existing Native HTTP Host."""

from typing import Any

from pydantic import ValidationError

from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.hosts.conversation import (
    ConversationKey,
    ConversationService,
    ConversationTurnRequest,
)


def mount_conversation_api(app: Any, service: ConversationService, *, scope: str) -> None:
    """Opt in on create_http_app's FastAPI app, retaining its limits/error handlers.

    One mount serves one trusted scope. Authenticate/authorize access at the product
    gateway; a request cannot choose scope. Multi-principal products should call the
    service from their authenticated Host and resolve ConversationKey there instead.
    No existing Product routes, defaults, DTOs or Runtime Session semantics change.
    """

    ConversationKey(scope=scope, conversation_id="validation")
    prefix = "/conversations/v1"
    if any(getattr(route, "path", "").startswith(prefix) for route in app.routes):
        raise ValueError("Conversation API is already mounted")

    def key(conversation_id: str) -> ConversationKey:
        try:
            return ConversationKey(scope=scope, conversation_id=conversation_id)
        except ValidationError as exc:
            raise ContractError(ErrorInfo(
                code="CONVERSATION_ID_INVALID", category=ErrorCategory.INVALID_REQUEST,
                message="Invalid conversation identity",
            )) from exc

    @app.post(prefix + "/{conversation_id}/turns", status_code=202)
    async def start_turn(conversation_id: str, request: ConversationTurnRequest):
        turn = await service.start_turn(key(conversation_id), request)
        # Admission returns identities only. Input/output remain behind the scoped
        # conversation read and the existing governed Runtime data interfaces.
        return {"requestId": turn.request_id, "run": turn.run.model_dump(mode="json") if turn.run else None}

    @app.get(prefix + "/{conversation_id}")
    async def get_conversation(conversation_id: str):
        record = await service.get(key(conversation_id))
        if record is None:
            raise ContractError(ErrorInfo(
                code="CONVERSATION_NOT_FOUND", category=ErrorCategory.NOT_FOUND,
                message="Conversation does not exist in this scope",
            ))
        return record.model_dump(mode="json")
