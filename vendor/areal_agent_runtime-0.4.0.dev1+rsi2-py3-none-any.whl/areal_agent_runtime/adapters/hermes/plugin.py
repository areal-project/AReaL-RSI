"""ARealAgentRuntime Plugin SPI packaging for a spawned Hermes TUI Gateway."""

from __future__ import annotations

import math
import re
from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.hermes.native import HermesNativeRuntimeAdapter
from areal_agent_runtime.adapters.hermes.runtime import (
    DEFAULT_MAX_HERMES_INPUT_ASSET_BYTES,
    HermesGatewayRuntimeAdapter,
)
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import (
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)


class HermesGatewayRuntimePlugin:
    manifest = PluginManifest(
        name="hermes-runtime",
        version="1.1.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.hermes.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("process.spawn", "workspace.read", "workspace.write", "network.model"),
        metadata={"areal.agent-runtime.bootstrap.profileBinding": True},
    )

    def __init__(self) -> None:
        self.runtime: HermesGatewayRuntimeAdapter | HermesNativeRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        self.runtime = await HermesGatewayRuntimeAdapter.spawn_stdio(
            python=_string(config.get("python"), field_name="python"),
            hermes_root=_string(config.get("hermesRoot"), field_name="hermesRoot"),
            cwd=_string(config.get("cwd"), field_name="cwd"),
            env=_environment(config.get("env")),
            profile_binding=_string(config.get("profileBinding"), field_name="profileBinding") or "auto",
            native_toolsets=_toolsets(config.get("nativeToolsets")),
            asset_store=_optional_asset_store(context),
            startup_timeout_seconds=_positive_float(
                config.get("startupTimeoutSeconds"),
                default=30.0,
                field_name="startupTimeoutSeconds",
            ),
            max_concurrency=_positive_integer(
                config.get("maxConcurrency"),
                default=8,
                field_name="maxConcurrency",
            ),
            max_input_asset_bytes=_positive_integer(
                config.get("maxInputAssetBytes"),
                default=DEFAULT_MAX_HERMES_INPUT_ASSET_BYTES,
                field_name="maxInputAssetBytes",
            ),
        )
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Hermes plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> HermesGatewayRuntimePlugin:
    return HermesGatewayRuntimePlugin()


def _optional_asset_store(context: PluginContext) -> AssetStorePort | None:
    if not context.providers(PortKey.ASSET_STORE):
        return None
    return cast(AssetStorePort, context.require(PortKey.ASSET_STORE))


def _string(value: JsonValue | None, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"{field_name} must be a non-blank, trimmed string")
    return value


def _positive_float(
    value: JsonValue | None,
    *,
    default: float,
    field_name: str,
) -> float:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{field_name} must be a finite positive number")
    return float(value)


def _positive_integer(value: JsonValue | None, *, default: int, field_name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _environment(value: JsonValue | None) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, dict) or len(value) > 256:
        raise ValueError("env must be an object with at most 256 entries")
    result: dict[str, str] = {}
    for key, item in value.items():
        if not isinstance(key, str) or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) is None:
            raise ValueError("env keys must be portable environment variable names")
        if not isinstance(item, str) or "\x00" in item:
            raise ValueError("env values must be strings without NUL bytes")
        result[key] = item
    return result


def _toolsets(value: JsonValue | None) -> tuple[str, ...] | None:
    if value is None:
        return None
    if not isinstance(value, list) or not value or any(not isinstance(item, str) for item in value):
        raise ValueError("nativeToolsets must be a non-empty array of native toolset names")
    return tuple(cast(str, item) for item in value)
