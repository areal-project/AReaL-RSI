"""Durable append-only annotation storage for the local distribution."""

from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import os
import tempfile
import weakref
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import IO

from areal_agent_runtime.adapters._blocking_io import run_blocking_io
from areal_agent_runtime.contracts.data import DataAnnotation


class FileSystemAnnotationStore:
    def __init__(self, root: str | Path) -> None:
        self._root = Path(root).expanduser().resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )

    async def append(self, annotation: DataAnnotation) -> None:
        durable = DataAnnotation.model_validate(
            annotation.model_dump(mode="json", by_alias=True)
        )
        lock = self._locks.setdefault(durable.run_id, asyncio.Lock())
        async with lock:
            await run_blocking_io(self._append, durable)

    async def list(self, run_id: str) -> tuple[DataAnnotation, ...]:
        _validate_identity(run_id)
        lock = self._locks.setdefault(run_id, asyncio.Lock())
        async with lock:
            return await run_blocking_io(self._list, run_id)

    def _append(self, annotation: DataAnnotation) -> None:
        path = self._path(annotation.run_id)
        with self._file_lock(annotation.run_id):
            existing = self._read(path, annotation.run_id)
            by_id = {item.annotation_id: item for item in existing}
            previous = by_id.get(annotation.annotation_id)
            if previous is not None:
                if previous == annotation:
                    return
                raise ValueError(
                    "annotationId already exists with different content: "
                    f"{annotation.annotation_id}"
                )
            # An interrupted append must not poison the previously accepted
            # annotation log. Publish a complete replacement under the same
            # process-shared lock and fsync before acknowledging the caller.
            encoded = b"".join(
                (json.dumps(item.model_dump(mode="json", by_alias=True), ensure_ascii=False,
                            sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
                for item in (*existing, annotation)
            )
            descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.stem}.", suffix=".tmp", dir=self._root)
            temporary = Path(temporary_name)
            try:
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(encoded)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, path)
                directory = os.open(self._root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            finally:
                temporary.unlink(missing_ok=True)

    def _list(self, run_id: str) -> tuple[DataAnnotation, ...]:
        with self._file_lock(run_id):
            return self._read(self._path(run_id), run_id)

    @staticmethod
    def _read(path: Path, run_id: str) -> tuple[DataAnnotation, ...]:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return ()
        items: list[DataAnnotation] = []
        ids: set[str] = set()
        for line in lines:
            if not line:
                continue
            item = DataAnnotation.model_validate(json.loads(line))
            if item.run_id != run_id:
                raise ValueError("durable annotation runId does not match its store partition")
            if item.annotation_id in ids:
                raise ValueError(f"duplicate durable annotationId: {item.annotation_id}")
            ids.add(item.annotation_id)
            items.append(item)
        return tuple(items)

    def _path(self, run_id: str) -> Path:
        _validate_identity(run_id)
        digest = hashlib.sha256(run_id.encode("utf-8")).hexdigest()
        return self._root / f"{digest}.jsonl"

    @contextmanager
    def _file_lock(self, run_id: str) -> Iterator[IO[bytes]]:
        lock_path = self._path(run_id).with_suffix(".lock")
        handle = lock_path.open("a+b")
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            yield handle
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()


def _validate_identity(value: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError("run_id must be a non-empty trimmed string")
