"""Native Product API commands and results consumed by Hosts."""

from __future__ import annotations

from enum import StrEnum

from pydantic import ConfigDict, Field, JsonValue, StrictBool, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel, require_optional_trimmed, require_trimmed
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.data import RunIdentityContext
from areal_agent_runtime.contracts.environment import AgentEnvironmentSpec
from areal_agent_runtime.contracts.knowledge import KnowledgeRef
from areal_agent_runtime.contracts.runtime import WorkspaceRef
from areal_agent_runtime.contracts.version import PRODUCT_API_VERSION, ProductApiVersion


class RunStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    WAITING = "waiting"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class RuntimeSelection(ContractModel):
    selector: str = Field(min_length=1)
    model: str | None = None
    provider: str | None = None

    @field_validator("selector")
    @classmethod
    def validate_selector(cls, value: str) -> str:
        return require_trimmed(value, "Runtime selector")

    @field_validator("model", "provider")
    @classmethod
    def validate_optional_identity(cls, value: str | None, info) -> str | None:  # type: ignore[no-untyped-def]
        return require_optional_trimmed(value, f"Runtime {info.field_name}")


class StartRunCommand(ContractModel):
    model_config = ConfigDict(
        json_schema_extra={
            "allOf": [
                {
                    "if": {
                        "properties": {"resumeSession": {"const": True}},
                        "required": ["resumeSession"],
                    },
                    "then": {
                        "properties": {"sessionId": {"type": "string", "minLength": 1}},
                        "required": ["sessionId"],
                    },
                }
            ]
        }
    )

    api_version: ProductApiVersion = PRODUCT_API_VERSION
    profile: str = Field(min_length=1)
    input: tuple[ContentBlock, ...] = Field(min_length=1)
    instructions: tuple[ContentBlock, ...] = ()
    knowledge: tuple[KnowledgeRef, ...] = ()
    # None means "use the Host/Distribution default environment policy".  An
    # explicitly supplied empty spec is intentionally different: it lets a
    # caller choose fallback/merge/replace without inheriting that policy.
    agent_environment: AgentEnvironmentSpec | None = None
    runtime: RuntimeSelection
    workspace: WorkspaceRef
    session_id: str | None = None
    resume_session: StrictBool | None = None
    context: RunIdentityContext = Field(default_factory=RunIdentityContext)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("profile")
    @classmethod
    def validate_profile(cls, value: str) -> str:
        return require_trimmed(value, "Run profile")

    @field_validator("session_id")
    @classmethod
    def validate_session_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "sessionId")

    @model_validator(mode="after")
    def validate_resume_identity(self) -> StartRunCommand:
        if self.resume_session is True and self.session_id is None:
            raise ValueError("resumeSession=true requires sessionId")
        identities = [(item.source, item.name, item.revision) for item in self.knowledge]
        if len(identities) != len(set(identities)):
            raise ValueError("knowledge references must not contain duplicates")
        return self


class RunRef(ContractModel):
    api_version: ProductApiVersion = PRODUCT_API_VERSION
    run_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    status: RunStatus
    events_url: str

    @field_validator("run_id", "session_id", "events_url")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "RunRef identity")


class RunSnapshot(ContractModel):
    api_version: ProductApiVersion = PRODUCT_API_VERSION
    run_id: str = Field(min_length=1)
    session_id: str = Field(min_length=1)
    profile: str = Field(min_length=1)
    workspace_id: str | None = None
    environment_id: str | None = None
    context: RunIdentityContext = Field(default_factory=RunIdentityContext)
    status: RunStatus
    last_sequence: StrictInt = Field(ge=-1)
    error: dict[str, JsonValue] | None = None

    @field_validator("run_id", "session_id", "profile")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "RunSnapshot identity")

    @field_validator("workspace_id", "environment_id")
    @classmethod
    def validate_workspace_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "RunSnapshot environment/workspace identity")


class SubmitInteractionCommand(ContractModel):
    run_id: str = Field(min_length=1)
    interaction_id: str = Field(min_length=1)
    execution_id: str | None = None
    response: JsonValue

    @field_validator("run_id", "interaction_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "Interaction command identity")

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Interaction command executionId")


class SteerRunCommand(ContractModel):
    run_id: str = Field(min_length=1)
    execution_id: str | None = None
    input: tuple[ContentBlock, ...] = Field(min_length=1)

    @field_validator("run_id")
    @classmethod
    def validate_run_id(cls, value: str) -> str:
        return require_trimmed(value, "Steer command runId")

    @field_validator("execution_id")
    @classmethod
    def validate_execution_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Steer command executionId")


class CancelRunCommand(ContractModel):
    run_id: str = Field(min_length=1)
    reason: str = "Cancelled by caller"

    @field_validator("run_id")
    @classmethod
    def validate_run_id(cls, value: str) -> str:
        return require_trimmed(value, "Cancel command runId")

    @field_validator("reason")
    @classmethod
    def validate_reason(cls, value: str) -> str:
        return require_trimmed(value, "Cancel command reason")
