"""Materialize immutable resources as real native SKILL.md files, never prompt text."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

import yaml

from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot

MAX_SKILLS = 256
MAX_SKILL_BYTES = 16 * 1024 * 1024


def materialize_skills(environment: AgentEnvironmentSnapshot, root: Path) -> dict[str, Path]:
    if len(environment.skills) > MAX_SKILLS:
        raise ValueError("Codex supports at most 256 selected skill snapshots")
    selected: dict[str, Path] = {}
    size = 0
    for resource in environment.skills:
        content = resource.content
        text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False, sort_keys=True)
        size += len(text.encode("utf-8"))
        if size > MAX_SKILL_BYTES:
            raise ValueError("Codex skill snapshots exceed the 16 MiB limit")
        if text.startswith("---\n") or text.startswith("---\r\n"):
            match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|\Z)", text, re.DOTALL)
            if match is None or len(match[1]) > 65536:
                raise ValueError("Invalid Codex SKILL.md frontmatter")
            header = yaml.safe_load(match[1])
            if not isinstance(header, dict):
                raise ValueError("Codex SKILL.md frontmatter must be a mapping")
            name, description = header.get("name"), header.get("description")
            if not isinstance(name, str) or re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name) is None:
                raise ValueError("Codex skill name must use lowercase letters, digits and single hyphens")
            if len(name) > 64 or not isinstance(description, str) or not description.strip():
                raise ValueError("Codex skill requires a name up to 64 characters and a description")
        else:
            name = "areal-" + hashlib.sha256(resource.resource_id.encode()).hexdigest()[:24]
            description = "Selected skill resource: " + resource.resource_id
            text = (
                "---\n" + yaml.safe_dump({"name": name, "description": description}, sort_keys=False) + "---\n" + text
            )
        if name in selected:
            raise ValueError(f"Duplicate selected Codex skill name: {name}")
        directory = root / name
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        path = directory / "SKILL.md"
        if path.exists() and path.read_text(encoding="utf-8") != text:
            raise ValueError("Persisted Codex skill differs from the immutable session snapshot")
        if not path.exists():
            path.write_text(text, encoding="utf-8")
            path.chmod(0o600)
        selected[name] = path.resolve()
    return selected


def verify_selected_skills(result: dict[str, Any], selected: dict[str, Path]) -> None:
    entries = result.get("data")
    if not isinstance(entries, list) or len(entries) != 1:
        raise RuntimeError("Codex did not return the native skill catalog for the session workspace")
    catalog = entries[0].get("skills", [])
    errors = entries[0].get("errors", [])
    for name, path in selected.items():
        matches = [item for item in catalog if item.get("name") == name and item.get("enabled") is True]
        if len(matches) != 1 or Path(matches[0]["path"]).resolve() != path:
            raise ValueError(f"Selected Codex skill is missing, disabled or shadowed by native configuration: {name}")
        if any(Path(item.get("path", "")).resolve() == path for item in errors):
            raise ValueError(f"Codex rejected selected SKILL.md: {name}")
