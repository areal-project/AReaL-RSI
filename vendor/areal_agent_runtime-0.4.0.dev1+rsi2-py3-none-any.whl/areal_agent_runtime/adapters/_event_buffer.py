"""Bounded local RuntimeEvent delivery, including synchronous SDK callbacks."""

from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Awaitable, Callable

from areal_agent_runtime.contracts.runtime import RuntimeEvent


class RuntimeEventBufferOverflow(RuntimeError):
    """The producer stopped because its consumer could not retain more events."""


class RuntimeEventBuffer:
    """FIFO with byte/count budgets and an out-of-band terminal/error signal.

    This buffer belongs to one event loop. Synchronous producers must stop when
    put raises: silently dropping observations would falsely report success.
    Already accepted events remain readable before the original failure. The
    byte budget measures serialized events, not the total interpreter RSS.
    """

    def __init__(self, terminal: object, *, max_events: int = 1024, max_bytes: int = 8 * 1024 * 1024) -> None:
        for name, value in (("max_events", max_events), ("max_bytes", max_bytes)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        self._terminal = terminal
        self._max_events = max_events
        self._max_bytes = max_bytes
        self._pending: deque[bytes] = deque()
        self._bytes = 0
        self._ready = asyncio.Event()
        self._finished = False
        self._error: BaseException | None = None

    @property
    def error(self) -> BaseException | None:
        return self._error

    @property
    def buffered_bytes(self) -> int:
        return self._bytes

    def qsize(self) -> int:
        return len(self._pending)

    def finish(self, error: BaseException | None = None) -> None:
        if self._error is None and error is not None:
            self._error = error
        self._finished = True
        self._ready.set()

    def producer_done(self, task: asyncio.Task[None]) -> None:
        """Expose an unexpected producer failure even if its cleanup also failed."""
        if task.cancelled():
            self.finish()
        elif (error := task.exception()) is not None:
            self.finish(error)
        if isinstance(self._error, RuntimeEventBufferOverflow):
            # Do not retain the rejected event or the producer's active model
            # request through the exception's traceback after it has stopped.
            self._error.__traceback__ = None

    async def run_producer(self, producer: Callable[[], Awaitable[None]]) -> None:
        try:
            await producer()
        except asyncio.CancelledError:
            raise
        except BaseException as error:
            # Record before the task yields control; a done callback alone can
            # race a waiting consumer that has already been signalled by END.
            self.finish(error)
            raise

    def put_nowait(self, item: RuntimeEvent | object) -> None:
        if item is self._terminal:
            self.finish()
            return
        if self._error is not None:
            raise self._error.with_traceback(None)
        if self._finished:
            raise RuntimeError("Runtime event producer emitted after its stream ended")
        if not isinstance(item, RuntimeEvent):
            raise TypeError("Runtime event buffer accepts only RuntimeEvent or its terminal sentinel")
        encoded = item.model_dump_json(by_alias=True).encode("utf-8")
        if len(self._pending) >= self._max_events or self._bytes + len(encoded) > self._max_bytes:
            error = RuntimeEventBufferOverflow(
                "Runtime event buffer overflow: consumer fell behind "
                f"(maxEvents={self._max_events}, maxBytes={self._max_bytes}); execution stopped"
            )
            self.finish(error)
            raise error
        self._pending.append(encoded)
        self._bytes += len(encoded)
        self._ready.set()

    async def put(self, item: RuntimeEvent | object) -> None:
        # There is deliberately no wait-for-space: terminal/cancel must remain
        # possible when the consumer is itself blocked in storage or cleanup.
        self.put_nowait(item)

    async def get(self) -> RuntimeEvent | object:
        while True:
            if self._pending:
                encoded = self._pending.popleft()
                self._bytes -= len(encoded)
                return RuntimeEvent.model_validate_json(encoded)
            if self._error is not None:
                raise self._error.with_traceback(None)
            if self._finished:
                return self._terminal
            self._ready.clear()
            await self._ready.wait()
