"""Inbound protocol adapters (Hosts)."""

from areal_agent_runtime.hosts.arca import ArcaServerlessConfig, ArcaServerlessHost, ArcaServerlessRequest
from areal_agent_runtime.hosts.data_http import (
    RUNTIME_DATA_HTTP_MOUNT_PATH,
    RUNTIME_DATA_HTTP_V1_ROUTES,
    RuntimeDataAuthorizerPort,
    RuntimeDataHttpConfig,
    RuntimeDataPermission,
    RuntimeDataPrincipal,
    StaticBearerDataAuthorizer,
    create_runtime_data_http_app,
    mount_runtime_data_api,
)
from areal_agent_runtime.hosts.legacy_knowledge import (
    LegacyKnowledgeResolutionError,
    LegacyPromptResolver,
    ResolvedLegacyPrompt,
    ResolvedLegacySkills,
)
from areal_agent_runtime.hosts.native_http import NativeHttpHostConfig, create_http_app
from areal_agent_runtime.hosts.openai_compat import (
    OpenAIChatRequest,
    OpenAICompatibilityConfig,
    OpenAICompatibilityHost,
    create_openai_http_app,
)
from areal_agent_runtime.hosts.resource_bindings import (
    BuiltinResource,
    HostResourceBindings,
    ResourceBindingPolicy,
)

__all__ = [
    "ArcaServerlessConfig",
    "ArcaServerlessHost",
    "BuiltinResource",
    "ArcaServerlessRequest",
    "LegacyKnowledgeResolutionError",
    "LegacyPromptResolver",
    "HostResourceBindings",
    "NativeHttpHostConfig",
    "OpenAIChatRequest",
    "OpenAICompatibilityConfig",
    "OpenAICompatibilityHost",
    "ResolvedLegacyPrompt",
    "ResolvedLegacySkills",
    "ResourceBindingPolicy",
    "RUNTIME_DATA_HTTP_MOUNT_PATH",
    "RUNTIME_DATA_HTTP_V1_ROUTES",
    "RuntimeDataAuthorizerPort",
    "RuntimeDataHttpConfig",
    "RuntimeDataPermission",
    "RuntimeDataPrincipal",
    "StaticBearerDataAuthorizer",
    "create_runtime_data_http_app",
    "create_openai_http_app",
    "create_http_app",
    "mount_runtime_data_api",
]
