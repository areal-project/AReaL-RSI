"""Append-first canonical event publication."""

from __future__ import annotations

import asyncio
import math
import weakref
from collections import OrderedDict
from collections.abc import AsyncIterator, Mapping
from datetime import UTC, datetime

from pydantic import JsonValue

from areal_agent_runtime.contracts.data import DataGovernance
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import EventSinkPort, StateStorePort
from areal_agent_runtime.contracts.product import RunSnapshot, RunStatus
from areal_agent_runtime.kernel.data import CanonicalDataPolicy, CanonicalObservationProjector
from areal_agent_runtime.kernel.ids import new_id
from areal_agent_runtime.kernel.state_queries import iter_run_snapshots


class EventPublisher:
    def __init__(
        self,
        state: StateStorePort,
        sinks: Mapping[str, EventSinkPort] | tuple[EventSinkPort, ...] = (),
        *,
        data_policy: CanonicalDataPolicy | None = None,
        delivery_timeout_seconds: float = 30.0,
        flush_timeout_seconds: float = 1.0,
        delivery_queue_size: int = 128,
    ) -> None:
        for name, value in (
            ("delivery_timeout_seconds", delivery_timeout_seconds),
            ("flush_timeout_seconds", flush_timeout_seconds),
        ):
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value <= 0
            ):
                raise ValueError(f"{name} must be finite and positive")
        if isinstance(delivery_queue_size, bool) or not isinstance(delivery_queue_size, int) or delivery_queue_size < 1:
            raise ValueError("delivery_queue_size must be a positive integer")
        self._state = state
        self._sinks = self._normalize_sinks(sinks)
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()
        self._delivery_failures: OrderedDict[tuple[str, str], str] = OrderedDict()
        self._data_policy = data_policy or CanonicalDataPolicy()
        self._projector = CanonicalObservationProjector()
        self._delivery_timeout = delivery_timeout_seconds
        self._flush_timeout = flush_timeout_seconds
        self._progress = asyncio.Event()
        self._closed = False
        self._dispatchers = {
            sink_id: _SinkDispatcher(self, sink_id, sink, queue_size=delivery_queue_size)
            for sink_id, sink in self._sinks.items()
        }

    async def publish(
        self,
        *,
        run_id: str,
        session_id: str,
        event_type: EventType,
        data: dict[str, JsonValue],
        execution_id: str | None = None,
        agent_attempt_id: str | None = None,
        agent_id: str | None = None,
        parent_agent_id: str | None = None,
        causation_id: str | None = None,
        span_id: str | None = None,
        environment_id: str | None = None,
        agent_environment_id: str | None = None,
        ignorable: bool = False,
        governance: DataGovernance | None = None,
        snapshot_status: RunStatus | None = None,
        snapshot_error: dict[str, JsonValue] | None = None,
    ) -> RunEvent:
        if self._closed:
            raise RuntimeError("EventPublisher is closed")
        lock = self._locks.setdefault(run_id, asyncio.Lock())
        async with lock:
            if snapshot_error is not None and (
                event_type != EventType.RUN_FAILED or snapshot_error != data.get("error")
            ):
                raise ValueError("snapshot_error must match the canonical run.failed error")
            protected_data, inferred_governance = self._data_policy.protect(event_type, data)
            event_id = new_id("evt")
            event_time = datetime.now(UTC)
            for attempt in range(4):
                current = await self._state.get_run(run_id)
                if current is None:
                    raise KeyError(run_id)
                # Snapshot revision and its projected fields are one coherent
                # read. Reading the log head separately can pair a newer
                # sequence with an older status/environment during contention.
                sequence = current.last_sequence + 1
                event = RunEvent(
                    event_id=event_id,
                    sequence=sequence,
                    time=event_time,
                    run_id=run_id,
                    session_id=session_id,
                    execution_id=execution_id,
                    agent_attempt_id=agent_attempt_id,
                    agent_id=agent_id,
                    parent_agent_id=parent_agent_id,
                    causation_id=causation_id,
                    correlation_id=current.context.correlation_id or run_id,
                    tenant_id=current.context.tenant_id,
                    project_id=current.context.project_id,
                    trace_id=current.context.trace_id,
                    span_id=span_id,
                    episode_id=current.context.episode_id,
                    environment_id=(
                        environment_id
                        if environment_id is not None
                        else current.environment_id
                    ),
                    agent_environment_id=agent_environment_id,
                    workspace_id=current.workspace_id,
                    type=event_type,
                    data=protected_data,
                    ignorable=ignorable,
                    governance=self._data_policy.combine(inferred_governance, governance),
                )
                # New writes are accepted only when data/v1 has a typed,
                # deterministic representation. Historical malformed v1 data
                # remains readable through the projector's explicit raw path.
                self._projector.project(event, strict=True)
                updates: dict[str, object] = {"last_sequence": sequence}
                if snapshot_status is not None:
                    updates["status"] = snapshot_status
                if event_type == EventType.RUN_FAILED:
                    # Both durable representations must derive from the same
                    # governed fact. Copying the unredacted caller error would
                    # fail StateStore's projection check (or leak secrets in a
                    # backend that did not enforce that invariant).
                    updates["error"] = protected_data.get("error")
                if event_type == EventType.ENVIRONMENT_CREATED:
                    if environment_id is None:
                        raise ValueError("environment.created requires environment_id")
                    updates["environment_id"] = environment_id
                try:
                    await self._commit_event(
                        event,
                        current.model_copy(update=updates),
                    )
                    break
                except ValueError as exc:
                    if "non-contiguous event sequence" not in str(exc) or attempt == 3:
                        raise
            else:  # pragma: no cover - loop either breaks or raises
                raise RuntimeError("event sequence allocation failed")
        return event

    async def _commit_event(self, event: RunEvent, snapshot: RunSnapshot) -> None:
        # A cancelled await cannot undo a database transaction or stop a
        # filesystem worker thread. Resolve this commit before releasing the
        # per-Run lock, and preserve its outbox wake-up even when the caller
        # cancels. Repeated cancellation must not leave an orphan commit task.
        task = asyncio.create_task(
            self._state.commit_event(event, snapshot, outbox_sinks=tuple(self._sinks)),
            name=f"areal_agent_runtime:commit:{event.run_id}:{event.sequence}",
        )
        cancelled: asyncio.CancelledError | None = None
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError as exc:
                cancelled = cancelled or exc
            except Exception:
                break
        try:
            task.result()
        except BaseException as exc:
            if cancelled is not None:
                raise cancelled from exc
            raise
        finally:
            # Queue entries are disposable hints. Even an uncertain failure
            # may have durably accepted the transaction; replay reads facts
            # from StateStore, never from this task's return value.
            for dispatcher in self._dispatchers.values():
                dispatcher.schedule(event.run_id)
        if cancelled is not None:
            raise cancelled

    async def flush(self, run_id: str) -> None:
        """Wait a bounded interval for this Run's durable outbox to drain.

        Failed or slow deliveries remain pending for background retry and
        restart recovery. A timeout never changes the committed Run status.
        """

        if not self._dispatchers or self._closed:
            return
        for dispatcher in self._dispatchers.values():
            dispatcher.schedule(run_id)
        try:
            async with asyncio.timeout(self._flush_timeout):
                while True:
                    self._progress.clear()
                    pending = False
                    for sink_id in self._sinks:
                        try:
                            pending = bool(
                                await self._state.pending_event_deliveries(run_id, sink_id, limit=1)
                            ) or pending
                        except Exception as exc:
                            self._record_delivery_failure(run_id, sink_id, exc)
                            pending = True
                    if not pending:
                        return
                    await self._progress.wait()
        except TimeoutError:
            return

    async def recover(self) -> None:
        """Schedule durable outbox replay without holding up Host startup."""

        if self._closed:
            raise RuntimeError("EventPublisher is closed")
        for dispatcher in self._dispatchers.values():
            dispatcher.rescan()

    async def aclose(self) -> None:
        """Stop delivery workers within the timeout; leave unacked work durable.

        Application shutdown drains active Runs through flush() first. This
        final stop does not require an available external sink. An installed
        sink must cooperate with task cancellation; even a noncooperative sink
        cannot make this method wait indefinitely.
        """

        if self._closed:
            return
        self._closed = True
        tasks = [dispatcher.task for dispatcher in self._dispatchers.values() if dispatcher.task is not None]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.wait(tasks, timeout=self._flush_timeout)
        self._progress.set()

    @property
    def delivery_failures(self) -> dict[tuple[str, str], str]:
        return dict(self._delivery_failures)

    def _record_delivery_failure(self, run_id: str, sink_id: str, error: Exception) -> None:
        # This is a recent diagnostic view, not the durable retry ledger.
        # A long-lived unavailable exporter must not retain every historical
        # failed Run (or arbitrarily large backend error strings) in RAM.
        key = (run_id, sink_id)
        self._delivery_failures.pop(key, None)
        self._delivery_failures[key] = (str(error) or type(error).__name__)[:4096]
        while len(self._delivery_failures) > 1024:
            self._delivery_failures.popitem(last=False)

    @staticmethod
    def _normalize_sinks(
        sinks: Mapping[str, EventSinkPort] | tuple[EventSinkPort, ...],
    ) -> dict[str, EventSinkPort]:
        if isinstance(sinks, Mapping):
            normalized = dict(sinks)
        else:
            normalized = {}
            for index, sink in enumerate(sinks):
                explicit = getattr(sink, "sink_id", None)
                sink_id = (
                    explicit
                    if isinstance(explicit, str) and explicit
                    else f"{type(sink).__module__}.{type(sink).__qualname__}#{index}"
                )
                if sink_id in normalized:
                    raise ValueError(f"duplicate EventSink identity: {sink_id}")
                normalized[sink_id] = sink
        if any(
            not isinstance(sink_id, str) or not sink_id.strip() or sink_id != sink_id.strip() for sink_id in normalized
        ):
            raise ValueError("EventSink identities must be non-empty trimmed strings")
        return normalized


class _SinkDispatcher:
    """One ordered, bounded delivery worker per installed sink.

    Run IDs in the queue are disposable hints. Overflow and retry recover work
    by reading StateStore, so neither queue loss nor shutdown loses an intent.
    Different sinks never share a delivery lock or wait on one another.
    """

    _BATCH_SIZE = 128
    _RETRY_DELAY = 0.1
    _MAX_RETRY_DELAY = 5.0

    def __init__(self, publisher: EventPublisher, sink_id: str, sink: EventSinkPort, *, queue_size: int) -> None:
        self._publisher = publisher
        self._sink_id = sink_id
        self._sink = sink
        self._queue: asyncio.Queue[str] = asyncio.Queue(maxsize=queue_size)
        self._queued: set[str] = set()
        self._again: set[str] = set()
        self._scan: AsyncIterator[RunSnapshot] | None = None
        self._needs_scan = False
        self._retry_after = 0.0
        self._retry_delay = self._RETRY_DELAY
        self.task: asyncio.Task[None] | None = None

    def schedule(self, run_id: str) -> None:
        if self._publisher._closed:
            return
        if run_id in self._queued:
            # A publish may race an empty pending read by the in-flight
            # worker. Preserve its wake-up until that delivery pass finishes.
            self._again.add(run_id)
        elif self._queue.full():
            self._needs_scan = True
        else:
            self._queued.add(run_id)
            self._queue.put_nowait(run_id)
        self._start()

    def rescan(self) -> None:
        self._needs_scan = True
        self._start()

    def _start(self) -> None:
        if self._publisher._closed or (self.task is not None and not self.task.done()):
            return
        self.task = asyncio.create_task(self._run(), name=f"areal_agent_runtime:outbox:{self._sink_id}")
        # Retrieve unexpected failures even when no explicit flush/close waits
        # on this task; ordinary delivery failures are handled in _run().
        self.task.add_done_callback(self._observe_completion)

    def _observe_completion(self, task: asyncio.Task[None]) -> None:
        if not task.cancelled():
            task.exception()

    async def _fill_from_scan(self) -> None:
        while self._scan is not None and not self._queue.full():
            snapshot = await anext(self._scan, None)
            if snapshot is None:
                self._scan = None
            elif snapshot.run_id not in self._queued:
                self._queued.add(snapshot.run_id)
                self._queue.put_nowait(snapshot.run_id)

    async def _run(self) -> None:
        publisher = self._publisher
        while not publisher._closed:
            try:
                async with asyncio.timeout(publisher._delivery_timeout):
                    await self._fill_from_scan()
            except Exception:
                self._scan = None
                self._defer_retry()
            if self._queue.empty():
                if not self._needs_scan:
                    self._retry_delay = self._RETRY_DELAY
                    return
                delay = self._retry_after - asyncio.get_running_loop().time()
                if delay > 0:
                    await asyncio.sleep(delay)
                self._needs_scan = False
                try:
                    async with asyncio.timeout(publisher._delivery_timeout):
                        self._scan = iter_run_snapshots(publisher._state)
                        await self._fill_from_scan()
                except Exception:
                    self._scan = None
                    self._defer_retry()
                    continue
                if self._queue.empty():
                    return
            run_id = self._queue.get_nowait()
            self._again.discard(run_id)
            more = False
            failed = False
            try:
                deadline = asyncio.get_running_loop().time() + publisher._delivery_timeout
                async with asyncio.timeout_at(deadline):
                    more = await self._deliver_batch(run_id, deadline=deadline)
                publisher._delivery_failures.pop((run_id, self._sink_id), None)
            except Exception as exc:
                failed = True
                publisher._record_delivery_failure(run_id, self._sink_id, exc)
                self._defer_retry()
            finally:
                self._queued.discard(run_id)
                self._queue.task_done()
                publisher._progress.set()
            if failed:
                # A concurrent publish hint must not bypass the backoff and
                # hammer a failing sink. The deferred durable rescan includes
                # both the failed batch and any newly committed events.
                self._again.discard(run_id)
            elif more or run_id in self._again:
                self._again.discard(run_id)
                self.schedule(run_id)

    def _defer_retry(self) -> None:
        self._needs_scan = True
        self._retry_after = asyncio.get_running_loop().time() + self._retry_delay
        self._retry_delay = min(self._retry_delay * 2, self._MAX_RETRY_DELAY)

    async def _deliver_batch(self, run_id: str, *, deadline: float) -> bool:
        publisher = self._publisher
        pending = await publisher._state.pending_event_deliveries(run_id, self._sink_id, limit=self._BATCH_SIZE)
        if not pending:
            return False
        for event in pending:
            self._require_delivery_active(deadline)
            await self._sink.consume(event)
        self._require_delivery_active(deadline)
        await self._sink.flush(run_id)
        self._require_delivery_active(deadline)
        await publisher._state.acknowledge_event_delivery(
            run_id,
            self._sink_id,
            through_sequence=pending[-1].sequence,
        )
        # A backend can stop early at its byte budget. A nonempty short batch
        # is not proof the outbox is empty; schedule one more bounded read.
        return True

    def _require_delivery_active(self, deadline: float) -> None:
        if self._publisher._closed:
            raise asyncio.CancelledError
        if asyncio.get_running_loop().time() >= deadline:
            # A sink which swallowed task cancellation still cannot process
            # the rest of a timed-out batch or acknowledge it as delivered.
            raise TimeoutError("EventSink delivery exceeded its deadline")
