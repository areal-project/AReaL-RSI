"""Canonical trajectory EventSink adapters."""

from areal_agent_runtime.adapters.trajectory.http import (
    HttpTrajectoryEventSink,
    TrajectoryHttpClient,
    TrajectoryHttpConfig,
    TrajectoryReportClient,
    TrajectoryReportPayload,
)
from areal_agent_runtime.adapters.trajectory.plugin import HttpTrajectoryPlugin, create_plugin

__all__ = [
    "HttpTrajectoryEventSink",
    "HttpTrajectoryPlugin",
    "TrajectoryHttpClient",
    "TrajectoryHttpConfig",
    "TrajectoryReportPayload",
    "TrajectoryReportClient",
    "create_plugin",
]
