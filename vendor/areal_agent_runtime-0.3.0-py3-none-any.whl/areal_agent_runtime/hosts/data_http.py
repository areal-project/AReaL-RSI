"""Authenticated HTTP projection of :class:`RuntimeDataClient`.

The Data API is deliberately mounted as an isolated ASGI application.  This
keeps its versioning, authentication and error envelope independent from the
frozen Product API v1 and from compatibility Hosts such as OpenAI Chat.
"""

import base64
import hashlib
import json
import os
import secrets
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Annotated, Protocol, runtime_checkable
from urllib.parse import urlsplit

from areal_agent_runtime.application.data_plane import RuntimeDataClient
from areal_agent_runtime.contracts.base import require_optional_trimmed, require_trimmed
from areal_agent_runtime.contracts.data import (
    DataAnnotation,
    DataClassification,
    DataGovernance,
    DataRunState,
    ObservationPage,
    RedactionStatus,
    RetentionClass,
    SessionState,
    TrajectoryPurpose,
    TrajectoryView,
)
from areal_agent_runtime.contracts.data_http import (
    AnnotationPage,
    AppendAnnotationRequest,
    RemoteRunPage,
    ResolvedAsset,
)
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.product import RunStatus

RUNTIME_DATA_HTTP_MOUNT_PATH = "/data"
RUNTIME_DATA_HTTP_V1_ROUTES = (
    ("GET", "/v1/runs"),
    ("GET", "/v1/runs/{run_id}/state"),
    ("GET", "/v1/sessions/{session_id}/state"),
    ("GET", "/v1/runs/{run_id}/observations"),
    ("GET", "/v1/runs/{run_id}/observations/stream"),
    ("GET", "/v1/runs/{run_id}/trajectory"),
    ("GET", "/v1/runs/{run_id}/annotations"),
    ("POST", "/v1/runs/{run_id}/annotations"),
    ("GET", "/v1/runs/{run_id}/assets/{asset_id}/resolve"),
    ("GET", "/v1/runs/{run_id}/assets/{asset_id}/content"),
)


class RuntimeDataPermission(StrEnum):
    READ = "data:read"
    READ_CONFIDENTIAL = "data:read-confidential"
    READ_RESTRICTED = "data:read-restricted"
    APPEND_ANNOTATION = "data:append-annotation"
    RESOLVE_ASSET = "data:resolve-asset"
    ADMIN = "data:admin"


@dataclass(frozen=True, slots=True)
class RuntimeDataPrincipal:
    """Authenticated identity and its tenant/project boundary.

    A non-admin principal must belong to exactly one tenant.  ``project_id``
    optionally narrows it to one project; ``None`` means all projects in that
    tenant.  Unscoped legacy Runs are intentionally visible only to admins.
    """

    subject: str
    tenant_id: str | None
    project_id: str | None = None
    permissions: frozenset[RuntimeDataPermission] = frozenset()

    def __post_init__(self) -> None:
        require_trimmed(self.subject, "Runtime Data principal subject")
        require_optional_trimmed(self.tenant_id, "Runtime Data principal tenantId")
        require_optional_trimmed(self.project_id, "Runtime Data principal projectId")
        normalized = frozenset(RuntimeDataPermission(item) for item in self.permissions)
        object.__setattr__(self, "permissions", normalized)
        if not normalized:
            raise ValueError("Runtime Data principal requires at least one permission")
        if self.project_id is not None and self.tenant_id is None:
            raise ValueError("Runtime Data principal projectId requires tenantId")
        if RuntimeDataPermission.ADMIN not in normalized and self.tenant_id is None:
            raise ValueError("non-admin Runtime Data principal requires tenantId")


@runtime_checkable
class RuntimeDataAuthorizerPort(Protocol):
    """Authenticate one already-parsed bearer credential.

    Implementations may validate an OIDC token, call an authorization service,
    or use the static reference implementation below.  Authentication failure
    must raise ``ContractError`` with the ``authentication`` category.
    """

    async def authenticate(self, bearer_token: str) -> RuntimeDataPrincipal: ...


class StaticBearerDataAuthorizer:
    """Fail-closed bearer-token authorizer for simple and local deployments."""

    def __init__(self, credentials: Mapping[str, RuntimeDataPrincipal]) -> None:
        if not credentials:
            raise ValueError("at least one Runtime Data bearer credential is required")
        parsed: list[tuple[str, RuntimeDataPrincipal]] = []
        for token, principal in credentials.items():
            if not isinstance(token, str) or len(token) < 32:
                raise ValueError("Runtime Data bearer tokens must contain at least 32 characters")
            if any(character.isspace() or ord(character) < 33 or ord(character) > 126 for character in token):
                raise ValueError("Runtime Data bearer tokens must use printable non-whitespace ASCII")
            if not isinstance(principal, RuntimeDataPrincipal):
                raise TypeError("Runtime Data credentials must map tokens to RuntimeDataPrincipal")
            parsed.append((token, principal))
        self._credentials = tuple(parsed)

    @classmethod
    def from_environment(
        cls,
        environment_variable: str,
        principal: RuntimeDataPrincipal,
    ) -> "StaticBearerDataAuthorizer":
        require_trimmed(environment_variable, "Runtime Data token environment variable")
        token = os.environ.get(environment_variable)
        if token is None:
            raise ValueError(
                f"Runtime Data bearer token environment variable is not set: {environment_variable}"
            )
        return cls({token: principal})

    async def authenticate(self, bearer_token: str) -> RuntimeDataPrincipal:
        if not isinstance(bearer_token, str) or not bearer_token or len(bearer_token) > 4096:
            raise _authentication_error()
        match: RuntimeDataPrincipal | None = None
        # Scan the complete key set so the matching credential's position does
        # not affect the response path. compare_digest avoids ordinary string
        # equality timing differences.
        for expected, principal in self._credentials:
            if secrets.compare_digest(expected, bearer_token):
                match = principal
        if match is None:
            raise _authentication_error()
        return match


@dataclass(frozen=True, slots=True)
class RuntimeDataHttpConfig:
    title: str = "ARealAgentRuntime Data API"
    max_page_size: int = 500
    max_request_bytes: int = 256 * 1024
    max_asset_ttl_seconds: int = 3600

    def __post_init__(self) -> None:
        require_trimmed(self.title, "Runtime Data HTTP title")
        for name, value, maximum in (
            ("max_page_size", self.max_page_size, 1000),
            ("max_request_bytes", self.max_request_bytes, 16 * 1024 * 1024),
            ("max_asset_ttl_seconds", self.max_asset_ttl_seconds, 24 * 60 * 60),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= maximum:
                raise ValueError(f"{name} must be an integer between 1 and {maximum}")


def create_runtime_data_http_app(
    data: RuntimeDataClient,
    authorizer: RuntimeDataAuthorizerPort,
    *,
    config: RuntimeDataHttpConfig | None = None,
):
    """Create an authenticated Data API ASGI app with routes rooted at ``/v1``.

    Use :func:`mount_runtime_data_api` to expose it under the canonical
    ``/data/v1`` path alongside an existing Product/compatibility Host.
    """

    try:
        from fastapi import FastAPI, Query, Request, Response, Security
        from fastapi.exceptions import RequestValidationError
        from fastapi.responses import JSONResponse, StreamingResponse
        from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
    except ImportError as exc:  # pragma: no cover - optional dependency guard
        raise RuntimeError("Install areal-agent-runtime[api] to use the Runtime Data HTTP Host") from exc

    if not isinstance(data, RuntimeDataClient):
        raise TypeError("data must be a RuntimeDataClient")
    if not isinstance(authorizer, RuntimeDataAuthorizerPort):
        raise TypeError("authorizer must implement RuntimeDataAuthorizerPort")
    effective = config or RuntimeDataHttpConfig()
    app = FastAPI(title=effective.title)
    app.add_middleware(_DataRequestBodyLimitMiddleware, max_bytes=effective.max_request_bytes)
    bearer = HTTPBearer(auto_error=False)

    @app.exception_handler(ContractError)
    async def contract_error(_request: Request, exc: ContractError):
        status = _http_status(exc.info.category)
        headers = {"Cache-Control": "no-store"}
        if status == 401:
            headers["WWW-Authenticate"] = "Bearer"
        return JSONResponse(
            status_code=status,
            headers=headers,
            content={"error": exc.info.model_dump(mode="json", by_alias=True)},
        )

    @app.exception_handler(RequestValidationError)
    async def request_validation_error(_request: Request, _exc: RequestValidationError):
        info = ErrorInfo(
            code="DATA_REQUEST_INVALID",
            category=ErrorCategory.INVALID_REQUEST,
            message="Request does not match the Runtime Data API contract",
        )
        return JSONResponse(
            status_code=400,
            headers={"Cache-Control": "no-store"},
            content={"error": info.model_dump(mode="json", by_alias=True)},
        )

    async def current_principal(
        credentials: Annotated[
            HTTPAuthorizationCredentials | None,
            Security(bearer),
        ] = None,
    ) -> RuntimeDataPrincipal:
        if credentials is None or credentials.scheme.lower() != "bearer":
            raise _authentication_error()
        try:
            principal = await authorizer.authenticate(credentials.credentials)
        except ContractError:
            raise
        except Exception as exc:
            # An authorization backend outage is not an authentication denial.
            # Preserve that distinction without exposing backend details.
            raise _error(
                "DATA_AUTHORIZER_UNAVAILABLE",
                ErrorCategory.UNAVAILABLE,
                "Runtime Data authorization service is unavailable",
            ) from exc
        if not isinstance(principal, RuntimeDataPrincipal):
            raise _error(
                "DATA_AUTHORIZER_INVALID_RESULT",
                ErrorCategory.UNAVAILABLE,
                "Runtime Data authorization service returned an invalid principal",
            )
        return principal

    PrincipalDependency = Annotated[
        RuntimeDataPrincipal,
        Security(current_principal),
    ]

    def page_limit(default: int):
        return Query(default=default, ge=1, le=effective.max_page_size)

    @app.get("/v1/runs", response_model=RemoteRunPage, response_model_by_alias=True)
    async def query_runs(
        response: Response,
        principal: PrincipalDependency,
        session_id: str | None = Query(default=None, alias="sessionId"),
        tenant_id: str | None = Query(default=None, alias="tenantId"),
        project_id: str | None = Query(default=None, alias="projectId"),
        status: RunStatus | None = None,
        page_token: str | None = Query(default=None, alias="pageToken"),
        limit: int = page_limit(50),
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> RemoteRunPage:
        _require_permission(principal, RuntimeDataPermission.READ)
        tenant_id, project_id = _scoped_query(principal, tenant_id, project_id)
        try:
            session_id = require_optional_trimmed(session_id, "Runtime Data query sessionId")
        except ValueError as exc:
            raise _invalid_request(str(exc)) from exc
        include_confidential, _include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        scope_digest = _run_page_scope_digest(
            principal,
            session_id=session_id,
            tenant_id=tenant_id,
            project_id=project_id,
            status=status,
            include_confidential=include_confidential,
            include_restricted=_include_restricted,
        )
        after_run_id = _decode_page_token(page_token, expected_scope=scope_digest)
        try:
            runs = await _query_all_runs(
                data,
                session_id=session_id,
                tenant_id=tenant_id,
                project_id=project_id,
                status=status,
                include_confidential=include_confidential,
            )
        except ValueError as exc:
            raise _invalid_request(str(exc)) from exc
        remaining = tuple(
            state
            for state in runs
            if after_run_id is None or state.run_id > after_run_id
        )
        page = remaining[:limit]
        next_page_token = (
            _encode_page_token(page[-1].run_id, scope_digest=scope_digest)
            if len(remaining) > len(page) and page
            else None
        )
        _mark_private(response)
        return RemoteRunPage(runs=page, next_page_token=next_page_token)

    @app.get("/v1/runs/{run_id}/state", response_model_by_alias=True)
    async def get_run_state(
        run_id: str,
        response: Response,
        principal: PrincipalDependency,
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> DataRunState:
        _require_permission(principal, RuntimeDataPermission.READ)
        await _authorized_run(data, principal, run_id)
        include_confidential, _include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        state = await data.get_run_state(
            run_id,
            include_confidential=include_confidential,
        )
        _mark_private(response)
        return state

    @app.get("/v1/sessions/{session_id}/state", response_model_by_alias=True)
    async def get_session_state(
        session_id: str,
        response: Response,
        principal: PrincipalDependency,
    ) -> SessionState:
        _require_permission(principal, RuntimeDataPermission.READ)
        tenant_id, project_id = _scoped_query(principal, None, None)
        try:
            state = await data.get_session_state(
                _bounded_identity(session_id, "sessionId"),
                tenant_id=tenant_id,
                project_id=project_id,
            )
        except KeyError as exc:
            raise _not_found("SESSION_NOT_FOUND", "Session was not found") from exc
        _mark_private(response)
        return state

    @app.get("/v1/runs/{run_id}/observations", response_model_by_alias=True)
    async def list_observations(
        run_id: str,
        response: Response,
        principal: PrincipalDependency,
        after: int = Query(default=-1, ge=-1),
        limit: int = page_limit(200),
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> ObservationPage:
        _require_permission(principal, RuntimeDataPermission.READ)
        await _authorized_run(data, principal, run_id)
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        result = await data.list_observations(
            run_id,
            after=after,
            limit=limit,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        _mark_private(response)
        return result

    @app.get("/v1/runs/{run_id}/observations/stream")
    async def stream_observations(
        run_id: str,
        request: Request,
        principal: PrincipalDependency,
        after: int = Query(default=-1, ge=-1),
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ):
        _require_permission(principal, RuntimeDataPermission.READ)
        await _authorized_run(data, principal, run_id)
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )

        async def event_stream():
            async for observation in data.subscribe_observations(
                run_id,
                after=after,
                include_confidential=include_confidential,
                include_restricted=include_restricted,
            ):
                if await request.is_disconnected():
                    return
                payload = json.dumps(
                    observation.model_dump(mode="json", by_alias=True),
                    ensure_ascii=False,
                    separators=(",", ":"),
                    allow_nan=False,
                )
                yield f"id: {observation.sequence}\nevent: observation\ndata: {payload}\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-store",
                "X-Accel-Buffering": "no",
            },
        )

    @app.get("/v1/runs/{run_id}/trajectory", response_model_by_alias=True)
    async def get_trajectory(
        run_id: str,
        response: Response,
        purpose: TrajectoryPurpose,
        principal: PrincipalDependency,
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> TrajectoryView:
        _require_permission(principal, RuntimeDataPermission.READ)
        await _authorized_run(data, principal, run_id)
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        result = await data.get_trajectory_view(
            run_id,
            purpose=purpose,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        _mark_private(response)
        return result

    @app.get(
        "/v1/runs/{run_id}/annotations",
        response_model=AnnotationPage,
        response_model_by_alias=True,
    )
    async def list_annotations(
        run_id: str,
        response: Response,
        principal: PrincipalDependency,
        cursor: int = Query(default=0, ge=0),
        limit: int = page_limit(100),
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> AnnotationPage:
        _require_permission(principal, RuntimeDataPermission.READ)
        await _authorized_run(data, principal, run_id)
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        values = await data.list_annotations(
            run_id,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        page = values[cursor : cursor + limit]
        next_cursor = cursor + len(page) if cursor + len(page) < len(values) else None
        _mark_private(response)
        return AnnotationPage(annotations=page, next_cursor=next_cursor)

    @app.post(
        "/v1/runs/{run_id}/annotations",
        status_code=201,
        response_model=DataAnnotation,
        response_model_by_alias=True,
    )
    async def append_annotation(
        run_id: str,
        command: AppendAnnotationRequest,
        response: Response,
        principal: PrincipalDependency,
    ) -> DataAnnotation:
        _require_permission(principal, RuntimeDataPermission.APPEND_ANNOTATION)
        await _authorized_run(data, principal, run_id)
        annotation = DataAnnotation(
            annotation_id=command.annotation_id,
            run_id=run_id,
            created_at=command.created_at,
            source=principal.subject,
            payload=command.payload,
            governance=_annotation_governance(command.classification),
            execution_id=command.execution_id,
            model_call_id=command.model_call_id,
            interaction_id=command.interaction_id,
        )
        try:
            await data.append_annotation(annotation)
        except ValueError as exc:
            category = ErrorCategory.CONFLICT if "already exists" in str(exc) else ErrorCategory.INVALID_REQUEST
            raise _error("ANNOTATION_REJECTED", category, str(exc)) from exc
        _mark_private(response)
        return annotation

    @app.get(
        "/v1/runs/{run_id}/assets/{asset_id}/resolve",
        response_model=ResolvedAsset,
        response_model_by_alias=True,
    )
    async def resolve_asset(
        run_id: str,
        asset_id: str,
        request: Request,
        response: Response,
        principal: PrincipalDependency,
        ttl_seconds: int = Query(default=300, ge=1, le=effective.max_asset_ttl_seconds, alias="ttlSeconds"),
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ) -> ResolvedAsset:
        _require_permission(principal, RuntimeDataPermission.RESOLVE_ASSET)
        await _authorized_run(data, principal, run_id)
        asset_id = _bounded_identity(asset_id, "assetId")
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        try:
            ref = await data.get_run_asset(
                run_id,
                asset_id,
                include_confidential=include_confidential,
                include_restricted=include_restricted,
            )
            if ref is None:
                raise FileNotFoundError(asset_id)
            url = await data.resolve_run_asset(
                run_id,
                asset_id,
                ttl_seconds=ttl_seconds,
                include_confidential=include_confidential,
                include_restricted=include_restricted,
            )
        except (KeyError, FileNotFoundError) as exc:
            raise _not_found("ASSET_NOT_FOUND", "Asset was not found for this Run") from exc
        except RuntimeError as exc:
            raise _error(
                "ASSET_STORE_UNAVAILABLE",
                ErrorCategory.UNAVAILABLE,
                "Runtime Data API has no AssetStore binding",
            ) from exc
        if urlsplit(url).scheme.lower() not in {"http", "https"}:
            # Local stores resolve to server-local file:// URLs. Never disclose
            # those paths to a remote caller; keep authorization at this Host
            # by returning its run-scoped proxy route instead.
            url = request.url_for(
                "download_asset_content",
                run_id=run_id,
                asset_id=asset_id,
            ).path
        _mark_private(response)
        return ResolvedAsset(
            run_id=run_id,
            asset_id=ref.asset_id,
            media_type=ref.media_type,
            size=ref.size,
            sha256=ref.sha256,
            url=url,
            requested_ttl_seconds=ttl_seconds,
        )

    @app.get(
        "/v1/runs/{run_id}/assets/{asset_id}/content",
        name="download_asset_content",
    )
    async def download_asset_content(
        run_id: str,
        asset_id: str,
        principal: PrincipalDependency,
        include_confidential: bool = Query(default=False, alias="includeConfidential"),
        include_restricted: bool = Query(default=False, alias="includeRestricted"),
    ):
        _require_permission(principal, RuntimeDataPermission.RESOLVE_ASSET)
        await _authorized_run(data, principal, run_id)
        asset_id = _bounded_identity(asset_id, "assetId")
        include_confidential, include_restricted = _authorized_visibility(
            principal,
            include_confidential=include_confidential,
            include_restricted=include_restricted,
        )
        try:
            ref = await data.get_run_asset(
                run_id,
                asset_id,
                include_confidential=include_confidential,
                include_restricted=include_restricted,
            )
        except RuntimeError as exc:
            raise _error(
                "ASSET_STORE_UNAVAILABLE",
                ErrorCategory.UNAVAILABLE,
                "Runtime Data API has no AssetStore binding",
            ) from exc
        if ref is None:
            raise _not_found("ASSET_NOT_FOUND", "Asset was not found for this Run")
        headers = {
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        }
        if ref.size is not None:
            headers["Content-Length"] = str(ref.size)
        return StreamingResponse(
            data.open_run_asset(
                run_id,
                asset_id,
                include_confidential=include_confidential,
                include_restricted=include_restricted,
            ),
            media_type=ref.media_type,
            headers=headers,
        )

    return app


def mount_runtime_data_api(
    app,
    data: RuntimeDataClient,
    authorizer: RuntimeDataAuthorizerPort,
    *,
    config: RuntimeDataHttpConfig | None = None,
    path: str = RUNTIME_DATA_HTTP_MOUNT_PATH,
):
    """Mount Data API v1 without changing the parent Host's existing routes."""

    if path != RUNTIME_DATA_HTTP_MOUNT_PATH:
        raise ValueError(
            f"the stable Runtime Data API mount path is {RUNTIME_DATA_HTTP_MOUNT_PATH}"
        )
    app.mount(path, create_runtime_data_http_app(data, authorizer, config=config))
    return app


async def _authorized_run(
    data: RuntimeDataClient,
    principal: RuntimeDataPrincipal,
    run_id: str,
):
    run_id = _bounded_identity(run_id, "runId")
    try:
        state = await data.get_run_state(run_id)
    except KeyError as exc:
        raise _not_found("RUN_NOT_FOUND", "Run was not found") from exc
    if RuntimeDataPermission.ADMIN in principal.permissions:
        return state
    context = state.context
    if context.tenant_id != principal.tenant_id:
        raise _not_found("RUN_NOT_FOUND", "Run was not found")
    if principal.project_id is not None and context.project_id != principal.project_id:
        raise _not_found("RUN_NOT_FOUND", "Run was not found")
    return state


async def _query_all_runs(
    data: RuntimeDataClient,
    *,
    session_id: str | None,
    tenant_id: str | None,
    project_id: str | None,
    status: RunStatus | None,
    include_confidential: bool,
) -> tuple[DataRunState, ...]:
    """Adapt the local offset facade to stable run-id keyset pagination."""

    cursor = 0
    result: list[DataRunState] = []
    while True:
        page = await data.query_runs(
            session_id=session_id,
            tenant_id=tenant_id,
            project_id=project_id,
            status=status,
            cursor=cursor,
            limit=1000,
            include_confidential=include_confidential,
        )
        result.extend(page.runs)
        if page.next_cursor is None:
            return tuple(result)
        if page.next_cursor <= cursor:
            raise RuntimeError("RuntimeDataClient returned a non-advancing run cursor")
        cursor = page.next_cursor


def _run_page_scope_digest(
    principal: RuntimeDataPrincipal,
    *,
    session_id: str | None,
    tenant_id: str | None,
    project_id: str | None,
    status: RunStatus | None,
    include_confidential: bool,
    include_restricted: bool,
) -> str:
    encoded = json.dumps(
        {
            "subject": principal.subject,
            "principalTenantId": principal.tenant_id,
            "principalProjectId": principal.project_id,
            "permissions": sorted(item.value for item in principal.permissions),
            "sessionId": session_id,
            "tenantId": tenant_id,
            "projectId": project_id,
            "status": status.value if status is not None else None,
            "includeConfidential": include_confidential,
            "includeRestricted": include_restricted,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _encode_page_token(after_run_id: str, *, scope_digest: str) -> str:
    payload = json.dumps(
        {
            "version": 1,
            "afterRunId": after_run_id,
            "scope": scope_digest,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return base64.urlsafe_b64encode(payload).rstrip(b"=").decode("ascii")


def _decode_page_token(value: str | None, *, expected_scope: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value or value != value.strip() or len(value) > 4096:
        raise _invalid_request("pageToken is invalid")
    try:
        padding = b"=" * (-len(value) % 4)
        decoded = base64.b64decode(
            value.encode("ascii") + padding,
            altchars=b"-_",
            validate=True,
        )
        payload = json.loads(decoded, parse_constant=_reject_json_constant)
    except (UnicodeEncodeError, UnicodeDecodeError, ValueError, json.JSONDecodeError) as exc:
        raise _invalid_request("pageToken is invalid") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"version", "afterRunId", "scope"}
        or payload.get("version") != 1
        or not isinstance(payload.get("afterRunId"), str)
        or not payload["afterRunId"]
        or len(payload["afterRunId"]) > 512
        or payload.get("scope") != expected_scope
    ):
        raise _invalid_request("pageToken does not match the current query scope")
    return payload["afterRunId"]


def _scoped_query(
    principal: RuntimeDataPrincipal,
    tenant_id: str | None,
    project_id: str | None,
) -> tuple[str | None, str | None]:
    try:
        tenant_id = require_optional_trimmed(tenant_id, "Runtime Data query tenantId")
        project_id = require_optional_trimmed(project_id, "Runtime Data query projectId")
    except ValueError as exc:
        raise _invalid_request(str(exc)) from exc
    if RuntimeDataPermission.ADMIN in principal.permissions:
        return tenant_id, project_id
    if tenant_id is not None and tenant_id != principal.tenant_id:
        raise _permission_error("requested tenant is outside the authenticated scope")
    if principal.project_id is not None:
        if project_id is not None and project_id != principal.project_id:
            raise _permission_error("requested project is outside the authenticated scope")
        project_id = principal.project_id
    return principal.tenant_id, project_id


def _authorized_visibility(
    principal: RuntimeDataPrincipal,
    *,
    include_confidential: bool,
    include_restricted: bool,
) -> tuple[bool, bool]:
    if include_restricted:
        _require_permission(principal, RuntimeDataPermission.READ_RESTRICTED)
        return True, True
    if include_confidential:
        if not (
            RuntimeDataPermission.ADMIN in principal.permissions
            or RuntimeDataPermission.READ_CONFIDENTIAL in principal.permissions
            or RuntimeDataPermission.READ_RESTRICTED in principal.permissions
        ):
            raise _permission_error("confidential Runtime Data access is not permitted")
    return include_confidential, False


def _require_permission(principal: RuntimeDataPrincipal, permission: RuntimeDataPermission) -> None:
    if RuntimeDataPermission.ADMIN in principal.permissions or permission in principal.permissions:
        return
    raise _permission_error(f"missing Runtime Data permission: {permission.value}")


def _annotation_governance(requested: DataClassification) -> DataGovernance:
    ordering = (
        DataClassification.PUBLIC,
        DataClassification.INTERNAL,
        DataClassification.CONFIDENTIAL,
        DataClassification.RESTRICTED,
    )
    classification = max(
        (DataClassification.INTERNAL, requested),
        key=ordering.index,
    )
    return DataGovernance(
        classification=classification,
        retention=RetentionClass.STANDARD,
        redaction=RedactionStatus.NOT_REQUIRED,
        policy_id="runtime-data-http/v1",
    )


def _bounded_identity(value: str, field: str) -> str:
    try:
        value = require_trimmed(value, field)
    except ValueError as exc:
        raise _invalid_request(str(exc)) from exc
    if len(value) > 512:
        raise _invalid_request(f"{field} exceeds 512 characters")
    return value


def _mark_private(response) -> None:  # type: ignore[no-untyped-def]
    response.headers["Cache-Control"] = "no-store"


def _authentication_error() -> ContractError:
    return _error(
        "DATA_AUTHENTICATION_FAILED",
        ErrorCategory.AUTHENTICATION,
        "A valid Runtime Data bearer credential is required",
    )


def _permission_error(message: str) -> ContractError:
    return _error("DATA_PERMISSION_DENIED", ErrorCategory.PERMISSION, message)


def _not_found(code: str, message: str) -> ContractError:
    return _error(code, ErrorCategory.NOT_FOUND, message)


def _invalid_request(message: str) -> ContractError:
    return _error("DATA_REQUEST_INVALID", ErrorCategory.INVALID_REQUEST, message)


def _error(code: str, category: ErrorCategory, message: str) -> ContractError:
    return ContractError(ErrorInfo(code=code, category=category, message=message))


def _http_status(category: ErrorCategory) -> int:
    return {
        ErrorCategory.INVALID_REQUEST: 400,
        ErrorCategory.AUTHENTICATION: 401,
        ErrorCategory.PERMISSION: 403,
        ErrorCategory.NOT_FOUND: 404,
        ErrorCategory.CONFLICT: 409,
        ErrorCategory.RATE_LIMIT: 429,
        ErrorCategory.TIMEOUT: 504,
        ErrorCategory.UNAVAILABLE: 503,
    }.get(category, 500)


class _DataRequestBodyLimitMiddleware:
    """Reject oversized Data API mutations before JSON model parsing."""

    def __init__(self, app, *, max_bytes: int) -> None:  # type: ignore[no-untyped-def]
        self._app = app
        self._max_bytes = max_bytes

    async def __call__(self, scope, receive, send) -> None:  # type: ignore[no-untyped-def]
        if scope.get("type") != "http" or scope.get("method") not in {"POST", "PUT", "PATCH"}:
            await self._app(scope, receive, send)
            return
        lengths = [value for name, value in scope.get("headers", ()) if name.lower() == b"content-length"]
        if lengths:
            try:
                if len(lengths) != 1:
                    raise ValueError
                declared = int(lengths[0].decode("ascii"))
                if declared < 0:
                    raise ValueError
            except (UnicodeDecodeError, ValueError):
                await self._reject(send, 400, "DATA_REQUEST_LENGTH_INVALID", "Content-Length is invalid")
                return
            if declared > self._max_bytes:
                await self._reject(send, 413, "DATA_REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
                return
        body = bytearray()
        while True:
            message = await receive()
            if message.get("type") == "http.disconnect":
                return
            if message.get("type") != "http.request":
                continue
            body.extend(message.get("body", b""))
            if len(body) > self._max_bytes:
                await self._reject(send, 413, "DATA_REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
                return
            if not message.get("more_body", False):
                break
        try:
            json.loads(bytes(body), parse_constant=_reject_json_constant)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, RecursionError):
            await self._reject(send, 400, "DATA_REQUEST_JSON_INVALID", "request body must be valid JSON")
            return
        delivered = False

        async def replay():
            nonlocal delivered
            if not delivered:
                delivered = True
                return {"type": "http.request", "body": bytes(body), "more_body": False}
            return await receive()

        await self._app(scope, replay, send)

    @staticmethod
    async def _reject(send, status: int, code: str, message: str) -> None:  # type: ignore[no-untyped-def]
        info = ErrorInfo(code=code, category=ErrorCategory.INVALID_REQUEST, message=message)
        body = json.dumps(
            {"error": info.model_dump(mode="json", by_alias=True)},
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                    (b"cache-control", b"no-store"),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


def _reject_json_constant(_value: str) -> None:
    raise ValueError("non-finite JSON numbers are not accepted")
