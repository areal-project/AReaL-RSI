"""ARealAgentRuntime application services and workflow profiles."""

from areal_agent_runtime.application.app import ARealAgentRuntime
from areal_agent_runtime.application.data_plane import InMemoryAnnotationStore, RuntimeDataClient
from areal_agent_runtime.application.orchestration import (
    AgentScheduler,
    ApplicationOrchestrator,
    OrchestratorDecision,
    PlanProposal,
    ProposedAgent,
    ProposedAgentOverrides,
    ProposedParallelGroup,
    RuntimeGraphSnapshot,
    ValidatedGraphPatch,
    WorkspaceView,
    graph_digest,
    plan_proposal_instruction,
    proposal_digest,
)
from areal_agent_runtime.application.profiles import WorkflowProfile, default_profiles
from areal_agent_runtime.application.tool_gateway import ToolGateway
from areal_agent_runtime.application.training import (
    TrainingProjectionError,
    TrainingTrajectoryProjector,
)
from areal_agent_runtime.application.workflow import (
    AgentGraph,
    AgentInputMode,
    AgentProfile,
    AgentSpec,
    CancelPolicy,
    DynamicAgentPolicy,
    FailurePolicy,
    JoinMode,
    JoinPolicy,
    MultiAgentOwnership,
    ParallelGroup,
    TimeoutPolicy,
    WorkflowAgent,
    WorkspaceAccess,
)

# Clear public terminology for new integrations. The implementation class name
# remains available for existing users.
RuntimeClient = ARealAgentRuntime

__all__ = [
    "AgentGraph",
    "AgentInputMode",
    "AgentProfile",
    "AgentScheduler",
    "AgentSpec",
    "ApplicationOrchestrator",
    "CancelPolicy",
    "DynamicAgentPolicy",
    "FailurePolicy",
    "ARealAgentRuntime",
    "InMemoryAnnotationStore",
    "JoinMode",
    "JoinPolicy",
    "MultiAgentOwnership",
    "OrchestratorDecision",
    "ParallelGroup",
    "PlanProposal",
    "ProposedAgent",
    "ProposedAgentOverrides",
    "ProposedParallelGroup",
    "RuntimeGraphSnapshot",
    "RuntimeClient",
    "RuntimeDataClient",
    "TimeoutPolicy",
    "ToolGateway",
    "TrainingProjectionError",
    "TrainingTrajectoryProjector",
    "ValidatedGraphPatch",
    "WorkflowAgent",
    "WorkflowProfile",
    "WorkspaceAccess",
    "WorkspaceView",
    "default_profiles",
    "graph_digest",
    "plan_proposal_instruction",
    "proposal_digest",
]
