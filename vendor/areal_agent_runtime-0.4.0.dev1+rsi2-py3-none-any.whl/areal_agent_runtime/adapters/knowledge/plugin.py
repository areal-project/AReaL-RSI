"""Plugin packaging for request-scoped local knowledge catalogs."""

from __future__ import annotations

from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters.knowledge.tools import LocalKnowledgeConfig, LocalKnowledgeToolProvider
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class LocalKnowledgeToolsPlugin:
    manifest = PluginManifest(
        name="local-knowledge",
        version="1.0.0",
        implements=(PortKey.TOOL_PROVIDER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.knowledge.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("knowledge.read",),
        metadata={"areal.agent-runtime.bootstrap.requestKnowledgeDefaults": True},
    )

    def __init__(self) -> None:
        self.provider: LocalKnowledgeToolProvider | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        roots = _roots(config)
        self.provider = LocalKnowledgeToolProvider(
            LocalKnowledgeConfig(
                roots=roots,
                max_file_bytes=_positive_int(config.get("maxFileBytes"), 256 * 1024),
                max_selected_bundles=_positive_int(config.get("maxSelectedBundles"), 32),
            )
        )
        context.provide(PortKey.TOOL_PROVIDER, self.provider)

    async def start(self) -> None:
        if self.provider is None:
            raise RuntimeError("Local knowledge plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.provider is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.provider.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> LocalKnowledgeToolsPlugin:
    return LocalKnowledgeToolsPlugin()


def _roots(config: dict[str, JsonValue]) -> dict[str, Path]:
    value = config.get("roots")
    if not isinstance(value, dict) or not value:
        raise ValueError("local-knowledge requires a non-empty config.roots object")
    roots = {
        source: Path(path)
        for source, path in value.items()
        if isinstance(source, str)
        and source
        and source == source.strip()
        and isinstance(path, str)
        and path
        and path == path.strip()
    }
    if len(roots) != len(value):
        raise ValueError("local-knowledge roots must map non-empty source names to paths")
    return roots


def _positive_int(value: JsonValue | None, default: int) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("knowledge limits must be positive integers")
    return value
