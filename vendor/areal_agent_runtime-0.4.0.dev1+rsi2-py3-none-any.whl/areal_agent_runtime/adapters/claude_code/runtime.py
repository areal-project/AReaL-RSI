"""Select the installed Claude Code CLI without introducing another agent loop."""

from __future__ import annotations

import asyncio
import contextlib
import dataclasses
import shutil
import sys
from typing import Any

from areal_agent_runtime.adapters.claude_sdk import ClaudeAgentSDKRuntimeAdapter
from areal_agent_runtime.contracts.runtime import HealthStatus, RuntimeDescriptor


class ClaudeCodeRuntimeAdapter(ClaudeAgentSDKRuntimeAdapter):
    def __init__(self, *, base_options: object | None = None, **kwargs: Any) -> None:
        from claude_agent_sdk import ClaudeAgentOptions

        base = base_options if isinstance(base_options, ClaudeAgentOptions) else ClaudeAgentOptions()
        cli_path = base.cli_path or shutil.which("claude.exe" if sys.platform == "win32" else "claude")
        if cli_path is None:
            raise RuntimeError("Install Claude Code or configure its cliPath to use the claude-code adapter")
        self._cli_path = cli_path
        self._cli_version: str | None = None
        self._version_lock = asyncio.Lock()
        super().__init__(base_options=dataclasses.replace(base, cli_path=cli_path), **kwargs)

    async def _installed_version(self) -> str:
        async with self._version_lock:
            if self._cli_version is None:
                process = await asyncio.create_subprocess_exec(
                    self._cli_path,
                    "--version",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                try:
                    stdout, _stderr = await asyncio.wait_for(process.communicate(), 5)
                finally:
                    if process.returncode is None:
                        with contextlib.suppress(ProcessLookupError):
                            process.kill()
                        await process.wait()
                value = stdout.decode("utf-8", errors="replace").strip()
                if process.returncode != 0 or not value or len(value) > 256:
                    raise RuntimeError("Claude Code --version did not return a valid version")
                self._cli_version = value
            return self._cli_version

    async def describe(self) -> RuntimeDescriptor:
        descriptor = await super().describe()
        try:
            runtime_version = await self._installed_version()
        except (OSError, RuntimeError, TimeoutError):
            runtime_version = "unavailable"
        return descriptor.model_copy(
            update={
                "name": "claude-code",
                "adapter_version": "1.0.0",
                "runtime_version": runtime_version,
            }
        )

    async def health(self) -> HealthStatus:
        sdk = await super().health()
        if sdk.status == "unhealthy":
            return sdk
        try:
            runtime_version = await self._installed_version()
        except (OSError, RuntimeError, TimeoutError):
            return HealthStatus(status="unhealthy", details={"reason": "claude_code_unavailable"})
        return HealthStatus(status="healthy", details={**sdk.details, "cliVersion": runtime_version})
