"""Read-only, offline configuration checks for humans and coding agents.

This module deliberately never imports a configured entrypoint. Bundled plugin
metadata is read as literal AST data and schemas are resolved only within the
installed package. Successful static validation is not a runtime health proof.
"""

from __future__ import annotations

import ast
import asyncio
import ipaddress
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml
from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from pydantic import BaseModel, ValidationError

from areal_agent_runtime.application.profiles import default_profiles
from areal_agent_runtime.bootstrap import BootstrapConfig, RuntimeServiceBootstrapConfig, _runtime_config_values
from areal_agent_runtime.configuration import (
    AgentsConfiguration,
    CompositionConfiguration,
    ReleaseConfiguration,
    WorkflowsConfiguration,
    load_project_configuration,
)
from areal_agent_runtime.plugin_sdk.contracts import PortKey
from areal_agent_runtime.plugin_sdk.loader import _reject_external_schema_references

_PACKAGE = Path(__file__).resolve().parent
_RUNTIME_MODULES = {
    "fake": "fake",
    "dsh": "dsh",
    "claude-agent-sdk": "claude_sdk",
    "claude-code": "claude_code",
    "hermes": "hermes",
    "anthropic": "anthropic_messages",
    "codex-cli": "codex_cli",
    "remote": "remote",
}
_BUNDLED_MODULES = {
    *(f"{name}.plugin" for name in _RUNTIME_MODULES.values()),
    "storage.plugin",
    "environment.plugin",
    "workspace.plugin",
    "knowledge.plugin",
    "vision.plugin",
    "mcp.plugin",
    "trajectory.plugin",
    "bridge.plugin",
    "bridge.mounted_plugin",
    "dsh.skill_plugin",
}
_TOOL_SOURCES = {
    "workspace.plugin": "workspace/tools.py",
    "knowledge.plugin": "knowledge/tools.py",
    "vision.plugin": "vision/ocr.py",
    "dsh.skill_plugin": "dsh/skill_plugin.py",
}
_PROJECT_MODELS: dict[str, type[BaseModel]] = {
    "release.yaml": ReleaseConfiguration,
    "composition.yaml": CompositionConfiguration,
    "workflow.yaml": WorkflowsConfiguration,
    "agents.yaml": AgentsConfiguration,
}
_ENTRYPOINT = re.compile(r"^[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*:[A-Za-z_]\w*$")


@dataclass
class ValidationReport:
    config_kind: str = "unknown"
    errors: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[dict[str, Any]] = field(default_factory=list)
    skipped_checks: list[dict[str, Any]] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": "areal.agent-runtime.config-validation/v1",
            "valid": self.valid,
            "configKind": self.config_kind,
            "errors": self.errors,
            "warnings": self.warnings,
            "skippedChecks": self.skipped_checks,
        }

    def add(
        self,
        code: str,
        file: str,
        location: tuple[str | int, ...],
        message: str,
        *,
        level: Literal["errors", "warnings", "skipped_checks"] = "errors",
    ) -> None:
        getattr(self, level).append({"code": code, "file": file, "location": list(location), "message": message})


class _UniqueSafeLoader(yaml.SafeLoader):
    """Reject accidental YAML shadowing before the canonical compiler runs."""

    def construct_mapping(self, node: yaml.MappingNode, deep: bool = False) -> dict[Any, Any]:
        # Allow normal YAML merge keys, but reject duplicate explicit keys.
        keys = [self.construct_object(key, deep=deep) for key, _ in node.value if key.tag != "tag:yaml.org,2002:merge"]
        try:
            if len(keys) != len(set(keys)):
                raise ValueError("duplicate mapping key")
        except TypeError as exc:
            raise ValueError("mapping keys must be scalars") from exc
        return super().construct_mapping(node, deep=deep)


def _unique_json(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate mapping key")
        result[key] = value
    return result


def _reject_constant(_: str) -> None:
    raise ValueError("non-finite number")


def _read(path: Path, report: ValidationReport, *, is_yaml: bool = False) -> dict[str, Any] | None:
    try:
        raw = path.read_text(encoding="utf-8")
        payload = (
            yaml.load(raw, Loader=_UniqueSafeLoader)
            if is_yaml
            else json.loads(raw, object_pairs_hook=_unique_json, parse_constant=_reject_constant)
        )
        if not isinstance(payload, dict):
            report.add("DOCUMENT_NOT_OBJECT", path.name, (), "配置文件根节点必须是对象。")
            return None
        # This also rejects YAML non-finite numbers, dates, non-string keys and cycles
        # before they can enter the otherwise deliberately permissive plugin config.
        _check_json_values(payload)
        return payload
    except OSError:
        report.add("FILE_UNREADABLE", path.name, (), "配置文件不存在或不可读。")
    except (UnicodeError, ValueError, TypeError, RecursionError, yaml.YAMLError) as exc:
        location: tuple[str | int, ...] = ()
        if isinstance(exc, json.JSONDecodeError):
            location = ("line", exc.lineno, "column", exc.colno)
        report.add("DOCUMENT_INVALID", path.name, location, "配置语法无效、存在重复键，或包含非 JSON 兼容值。")
    return None


def _check_json_values(value: Any, depth: int = 0) -> None:
    if depth > 64:
        raise ValueError("configuration too deep")
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise ValueError("non-string key")
        for item in value.values():
            _check_json_values(item, depth + 1)
    elif isinstance(value, list):
        for item in value:
            _check_json_values(item, depth + 1)
    else:
        json.dumps(value, allow_nan=False)


def _model_errors(report: ValidationReport, exc: ValidationError, file: str, prefix: tuple = ()) -> None:
    for error in exc.errors(include_input=False, include_context=False, include_url=False):
        # Custom validators may interpolate config values into their error message.
        # Never echo those messages or Pydantic's repr of the rejected input.
        message = {
            "missing": "缺少必填字段。",
            "extra_forbidden": "不支持此配置字段。",
            "literal_error": "字段值不在模型允许的枚举值中。",
            "enum": "字段值不在模型允许的枚举值中。",
            "union_tag_invalid": "kind 等类型标记不受支持；请检查对应配置模型。",
            "union_tag_not_found": "缺少 kind 等类型标记。",
        }.get(error["type"], "字段类型、范围、组合或引用违反配置模型约束；请检查该位置及配置参考。")
        report.add("MODEL_" + error["type"].upper(), file, (*prefix, *error["loc"]), message)


async def validate_configuration(
    path: str | Path,
    *,
    kind: Literal["auto", "bootstrap", "runtime-service"] = "auto",
) -> ValidationReport:
    """Validate without creating directories, loading plugins, or reading secrets.

    Auto detection treats JSON containing ``wire`` as RuntimeServiceBootstrapConfig.
    Use ``kind='runtime-service'`` when a service relies on the default Wire settings.
    A canonical YAML filename is accepted as a shorthand for its project directory.
    """
    report = ValidationReport()
    config: BootstrapConfig | RuntimeServiceBootstrapConfig
    resolved, is_directory = await asyncio.to_thread(
        lambda: (Path(path).expanduser(), Path(path).expanduser().is_dir())
    )
    project = is_directory or resolved.name in _PROJECT_MODELS
    if project:
        report.config_kind = "project"
        if kind != "auto":
            report.add("CONFIG_KIND_MISMATCH", resolved.name, (), "四文件目录请使用默认的 --kind auto。")
            return report
        root = resolved if is_directory else resolved.parent
        documents: dict[str, Any] = {}
        for filename, model in _PROJECT_MODELS.items():
            raw = _read(root / filename, report, is_yaml=True)
            if raw is not None:
                try:
                    documents[filename] = model.model_validate(raw)
                except ValidationError as exc:
                    _model_errors(report, exc, filename)
        if report.errors:
            return report
        _project_references(documents, report)
        if report.errors:
            return report
        try:
            config = await load_project_configuration(root)
        except ValidationError as exc:
            _model_errors(report, exc, "workflow.yaml")
            return report
        except (ValueError, OSError, RecursionError):
            report.add(
                "PROJECT_COMPILE_FAILED", "workflow.yaml", (), "四文件编译失败；检查 DAG、AgentProfile 及发布引用。"
            )
            return report
        file = "composition.yaml"
    else:
        raw = _read(resolved, report)
        if raw is None:
            return report
        report.config_kind = (
            "runtime-service" if kind == "runtime-service" or (kind == "auto" and "wire" in raw) else "bootstrap"
        )
        model = RuntimeServiceBootstrapConfig if report.config_kind == "runtime-service" else BootstrapConfig
        try:
            config = model.model_validate(raw)
        except ValidationError as exc:
            _model_errors(report, exc, resolved.name)
            return report
        file = resolved.name
    tools, unknown_tools = _validate_plugins(config, report, file)
    if isinstance(config, BootstrapConfig):
        _application_references(config, report, file)
        _profile_tools(config, documents if project else None, report, file, tools, unknown_tools)
    else:
        if not config.storage.enabled:
            report.add("STORAGE_DISABLED", file, ("storage", "enabled"), "Runtime Service 必须启用 storage。")
        wire = config.wire
        if wire.host not in {"127.0.0.1", "::1", "localhost"} and not wire.tls_cert_file and not wire.allow_insecure:
            report.add(
                "WIRE_TLS_REQUIRED", file, ("wire",), "非 loopback Wire 监听必须配置 TLS，或显式设置 allowInsecure。"
            )
    report.add(
        "RUNTIME_NOT_STARTED",
        file,
        (),
        "未加载插件、启动 Runtime、调用模型或验证实际能力与健康状态。",
        level="skipped_checks",
    )
    report.add(
        "DEPLOYMENT_NOT_CHECKED",
        file,
        (),
        "未读取环境变量值、Secret、证书及资源内容；未验证网络、二进制、挂载和文件系统权限。",
        level="skipped_checks",
    )
    return report


def _project_references(documents: dict[str, Any], report: ValidationReport) -> None:
    release, composition = documents["release.yaml"], documents["composition.yaml"]
    workflows, agents = documents["workflow.yaml"], documents["agents.yaml"]
    workflow_ids = {workflow.workflow_id for workflow in workflows.workflows}
    agent_ids = {agent.agent_profile_id for agent in agents.agents}
    runtime_ids = {runtime.selector for runtime in composition.runtimes}
    for index, profile in enumerate(release.profiles):
        if profile.workflow_id is not None and profile.workflow_id not in workflow_ids:
            report.add(
                "WORKFLOW_NOT_FOUND",
                "release.yaml",
                ("profiles", index, "workflowId"),
                "workflowId 未在 workflow.yaml 定义。",
            )
    for index, workflow in enumerate(workflows.workflows):
        for node_index, node in enumerate(workflow.nodes):
            if node.agent_profile_id not in agent_ids:
                report.add(
                    "AGENT_PROFILE_NOT_FOUND",
                    "workflow.yaml",
                    ("workflows", index, "nodes", node_index, "agentProfileId"),
                    "agentProfileId 未在 agents.yaml 定义。",
                )
            if node.runtime_selector is not None and node.runtime_selector not in runtime_ids:
                report.add(
                    "RUNTIME_NOT_FOUND",
                    "workflow.yaml",
                    ("workflows", index, "nodes", node_index, "runtimeSelector"),
                    "节点引用的 Runtime selector 未安装。",
                )
        if workflow.dynamic_policy is not None:
            for runtime_index, selector in enumerate(workflow.dynamic_policy.allowed_runtime_selectors):
                if selector not in runtime_ids:
                    report.add(
                        "RUNTIME_NOT_FOUND",
                        "workflow.yaml",
                        ("workflows", index, "dynamicPolicy", "allowedRuntimeSelectors", runtime_index),
                        "动态策略允许了未安装的 Runtime selector。",
                    )
    for index, agent in enumerate(agents.agents):
        if agent.runtime_selector is not None and agent.runtime_selector not in runtime_ids:
            report.add(
                "RUNTIME_NOT_FOUND",
                "agents.yaml",
                ("agents", index, "runtimeSelector"),
                "AgentProfile 引用的 Runtime selector 未安装。",
            )
    if composition.host.default_profile not in {profile.profile_id for profile in release.profiles}:
        report.add(
            "PROFILE_NOT_FOUND",
            "composition.yaml",
            ("host", "defaultProfile"),
            "defaultProfile 未在 release.yaml 暴露。",
        )


@dataclass
class _Metadata:
    name: str
    ports: tuple[PortKey, ...]
    permissions: tuple[str, ...]
    schema: Path
    tools: dict[str, tuple[str, ...]] | None
    receives_profile_binding: bool = False


def _literal_keywords(call: ast.Call) -> dict[str, ast.expr]:
    return {keyword.arg: keyword.value for keyword in call.keywords if keyword.arg is not None}


def _bundled_metadata(entrypoint: str) -> _Metadata | None:
    prefix = "areal_agent_runtime.adapters."
    module = entrypoint.removeprefix(prefix).removesuffix(":create_plugin")
    if not entrypoint.startswith(prefix) or not entrypoint.endswith(":create_plugin") or module not in _BUNDLED_MODULES:
        return None
    path = _PACKAGE / "adapters" / (module.replace(".", "/") + ".py")
    tree = ast.parse(path.read_text(encoding="utf-8"))
    manifests = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "PluginManifest"
    ]
    if len(manifests) != 1:
        raise ValueError("bundled manifest no longer static")
    fields = _literal_keywords(manifests[0])
    ports_node = fields["implements"]
    if not isinstance(ports_node, ast.Tuple):
        raise ValueError("bundled ports no longer static")
    ports = []
    for node in ports_node.elts:
        if not isinstance(node, ast.Attribute) or not isinstance(node.value, ast.Name) or node.value.id != "PortKey":
            raise ValueError("bundled ports no longer static")
        ports.append(PortKey[node.attr])
    schema = path.parent / ast.literal_eval(fields["config_schema"])
    if not schema.resolve().is_relative_to(path.parent.resolve()):
        raise ValueError("bundled schema escaped package")
    tools = None
    if module in _TOOL_SOURCES:
        tools = {}
        source = _PACKAGE / "adapters" / _TOOL_SOURCES[module]
        tool_tree = ast.parse(source.read_text(encoding="utf-8"))
        constants = {
            target.id: statement.value
            for statement in tool_tree.body
            if isinstance(statement, ast.Assign) and isinstance(statement.value, ast.Constant)
            for target in statement.targets
            if isinstance(target, ast.Name)
        }
        for tool_node in ast.walk(tool_tree):
            if (
                isinstance(tool_node, ast.Call)
                and isinstance(tool_node.func, ast.Name)
                and tool_node.func.id == "ToolSpec"
            ):
                values = _literal_keywords(tool_node)
                name_node = values["name"]
                if isinstance(name_node, ast.Name):
                    name_node = constants[name_node.id]
                tools[ast.literal_eval(name_node)] = (
                    ast.literal_eval(values["permissions"]) if "permissions" in values else ()
                )
    manifest_metadata = ast.literal_eval(fields["metadata"]) if "metadata" in fields else {}
    if not isinstance(manifest_metadata, dict):
        raise ValueError("bundled manifest metadata no longer static")
    return _Metadata(
        ast.literal_eval(fields["name"]),
        tuple(ports),
        ast.literal_eval(fields["permissions"]) if "permissions" in fields else (),
        schema,
        tools,
        manifest_metadata.get("areal.agent-runtime.bootstrap.profileBinding") is True,
    )


def _schema_config(config: dict, metadata: _Metadata, report: ValidationReport, file: str, location: tuple) -> None:
    schema = json.loads(metadata.schema.read_text(encoding="utf-8"))
    _reject_external_schema_references(schema, metadata.name)
    Draft202012Validator.check_schema(schema)
    reported: set[tuple] = set()
    for error in Draft202012Validator(schema).iter_errors(config):
        relative = tuple(error.absolute_path)
        # JSON Schema messages interpolate complete instances, including secrets.
        message = f"插件配置不满足 JSON Schema 约束（{error.validator}）；请查阅对应内置 schema。"
        if error.validator == "required":
            for key in error.validator_value:
                if key not in error.instance and (*relative, key) not in reported:
                    report.add(
                        "PLUGIN_SCHEMA_REQUIRED",
                        file,
                        (*location, "config", *relative, key),
                        "缺少插件配置的必填字段。",
                    )
                    reported.add((*relative, key))
            continue
        if error.validator == "additionalProperties" and error.validator_value is False:
            properties = error.schema.get("properties", {})
            patterns = error.schema.get("patternProperties", {})
            for key in error.instance:
                if key not in properties and not any(re.search(pattern, key) for pattern in patterns):
                    report.add(
                        "PLUGIN_SCHEMA_ADDITIONALPROPERTIES",
                        file,
                        (*location, "config", *relative, key),
                        "不支持此插件配置字段。",
                    )
            continue
        report.add("PLUGIN_SCHEMA_" + str(error.validator).upper(), file, (*location, "config", *relative), message)


def _validate_plugins(
    config: BootstrapConfig | RuntimeServiceBootstrapConfig, report: ValidationReport, file: str
) -> tuple[dict[str, tuple[str, ...]], bool]:
    # Preserve actual bootstrap loading order and defaults, including inactive knowledgeTools.
    entries: list[tuple[Any, tuple, str | None, dict, tuple[PortKey, ...]]] = []
    runtimes: list[tuple[Any, tuple, str | None]]
    entries.append(
        (
            config.storage,
            ("storage",),
            None,
            {"root": config.data_root, **config.storage.config},
            (PortKey.ASSET_STORE,),
        )
    )
    if isinstance(config, BootstrapConfig):
        entries[0] = (*entries[0][:-1], (PortKey.STATE_STORE, PortKey.ASSET_STORE))
        environment_config = {
            "root": config.data_root + "/environment",
            "allowExternalMounts": config.host.kind == "arca" or config.host.default_workspace_mount is not None,
            "allowedExternalMountRoots": [],
            **config.environment.config,
        }
        entries.append((config.environment, ("environment",), None, environment_config, (PortKey.ENVIRONMENT,)))
        entries.extend((item, ("plugins", index), None, item.config, ()) for index, item in enumerate(config.plugins))
        if config.host.request_knowledge.enabled:
            knowledge = config.knowledge_tools
            defaults = (
                {
                    "roots": dict(config.host.request_knowledge.skill_roots),
                    "maxFileBytes": config.host.request_knowledge.max_skill_bytes,
                    "maxSelectedBundles": config.host.request_knowledge.max_requested_skills,
                }
                if knowledge.entrypoint == "areal_agent_runtime.adapters.knowledge.plugin:create_plugin"
                else {}
            )
            entries.append(
                (knowledge, ("knowledgeTools",), None, {**defaults, **knowledge.config}, (PortKey.TOOL_PROVIDER,))
            )
        elif config.knowledge_tools.config or not config.knowledge_tools.enabled:
            report.add(
                "KNOWLEDGE_TOOLS_INACTIVE",
                file,
                ("knowledgeTools",),
                "requestKnowledge.enabled=false，此配置不会被加载。",
                level="warnings",
            )
        entries.append(
            (config.workspace_tools, ("workspaceTools",), None, config.workspace_tools.config, (PortKey.TOOL_PROVIDER,))
        )
        if config.domain_tools is not None:
            entries.append(
                (config.domain_tools, ("domainTools",), None, config.domain_tools.config, (PortKey.TOOL_PROVIDER,))
            )
        runtimes = [
            (runtime, ("runtimes", index) if config.runtimes else ("runtime",), "runtime." + runtime.selector)
            for index, runtime in enumerate(config.configured_runtimes())
        ]
    else:
        runtimes = [(config.runtime, ("runtime",), None)]
    entries.extend(
        (runtime, location, owner, runtime.config, (PortKey.AGENT_RUNTIME,)) for runtime, location, owner in runtimes
    )
    providers: dict[str, tuple[PortKey, ...] | None] = {}
    unknown_owner = False
    tools: dict[str, tuple[str, ...]] = {}
    unknown_tools = False
    for item, location, owner_override, effective, required_ports in entries:
        if not getattr(item, "enabled", True):
            continue
        entrypoint = getattr(item, "entrypoint", None)
        if entrypoint is None:
            entrypoint = (
                item.plugin_entrypoint
                if item.kind == "entrypoint"
                else (f"areal_agent_runtime.adapters.{_RUNTIME_MODULES[item.kind]}.plugin:create_plugin")
            )
        if not _ENTRYPOINT.fullmatch(entrypoint):
            report.add("ENTRYPOINT_INVALID", file, location, "entrypoint 必须使用 python.module:factory 格式。")
            continue
        try:
            metadata = _bundled_metadata(entrypoint)
            if metadata is not None:
                if required_ports == (PortKey.AGENT_RUNTIME,):
                    try:
                        effective = _runtime_config_values(
                            item, receives_profile_binding=metadata.receives_profile_binding
                        )
                    except ValueError:
                        report.add(
                            "RUNTIME_PROFILE_BINDING_CONFLICT",
                            file,
                            (*location, "config", "profileBinding"),
                            "插件 config.profileBinding 与外层 Runtime profileBinding 冲突；请在外层选择绑定策略。",
                        )
                _schema_config(effective, metadata, report, file, location)
        except (OSError, ValueError, KeyError, SyntaxError, TypeError, SchemaError):
            report.add(
                "BUNDLED_METADATA_INVALID",
                file,
                location,
                "安装包的内置 manifest/schema 无法静态读取；请检查包完整性。",
            )
            continue
        owner = owner_override or getattr(item, "instance_name", None) or (metadata.name if metadata else None)
        if owner is not None and owner in providers:
            report.add(
                "PLUGIN_INSTANCE_DUPLICATE", file, (*location, "instanceName"), "插件实例名与此前加载的实例冲突。"
            )
        for port, provider in item.service_bindings.items():
            provided_ports = providers.get(provider)
            if provider not in providers:
                if unknown_owner:
                    report.add(
                        "SERVICE_BINDING_UNVERIFIED",
                        file,
                        (*location, "serviceBindings", port.value),
                        "外部插件未声明静态实例名，无法证明服务提供者存在。",
                        level="skipped_checks",
                    )
                else:
                    report.add(
                        "SERVICE_PROVIDER_NOT_FOUND",
                        file,
                        (*location, "serviceBindings", port.value),
                        "服务提供者尚未加载；检查实例名、加载顺序及对应 Port。",
                    )
            elif provided_ports is not None and port not in provided_ports:
                report.add(
                    "SERVICE_PORT_NOT_PROVIDED",
                    file,
                    (*location, "serviceBindings", port.value),
                    "指定插件实例未声明该 Port。",
                )
            elif providers[provider] is None:
                report.add(
                    "SERVICE_BINDING_UNVERIFIED",
                    file,
                    (*location, "serviceBindings", port.value),
                    "未加载外部插件，无法证明其提供该 Port。",
                    level="skipped_checks",
                )
        if metadata is None:
            report.add(
                "EXTERNAL_PLUGIN_NOT_LOADED",
                file,
                location,
                "未导入外部 entrypoint；其 schema、manifest、权限、工具目录和服务声明尚未校验。",
                level="skipped_checks",
            )
            unknown_tools = True
            unknown_owner |= owner is None
        else:
            if set(required_ports).difference(metadata.ports):
                report.add("PLUGIN_ROLE_PORT_MISSING", file, location, "内置插件未声明此配置位置要求的 Port。")
            if config.allowed_plugin_permissions is not None and set(metadata.permissions).difference(
                config.allowed_plugin_permissions
            ):
                report.add(
                    "PLUGIN_PERMISSION_DENIED",
                    file,
                    location,
                    "allowedPluginPermissions 未覆盖该内置插件 manifest 的全部权限。",
                )
            if PortKey.TOOL_PROVIDER in metadata.ports:
                if metadata.tools is None:
                    unknown_tools = True
                    report.add(
                        "TOOL_DISCOVERY_NOT_RUN",
                        file,
                        location,
                        "工具目录需要实际发现；未连接 MCP 或启动工具提供者。",
                        level="skipped_checks",
                    )
                else:
                    for name, permissions in metadata.tools.items():
                        if name in tools:
                            report.add("TOOL_NAME_DUPLICATE", file, location, "内置 ToolProvider 存在重复工具名称。")
                        tools[name] = permissions
                        if (
                            isinstance(config, BootstrapConfig)
                            and config.allowed_tool_permissions is not None
                            and set(permissions).difference(config.allowed_tool_permissions)
                        ):
                            report.add(
                                "TOOL_PERMISSION_DENIED",
                                file,
                                location,
                                "allowedToolPermissions 必须覆盖已安装工具目录的全部权限，即使未绑定工具。",
                            )
            if entrypoint == "areal_agent_runtime.adapters.remote.plugin:create_plugin":
                if (
                    not _remote_loopback(effective.get("host"))
                    and not effective.get("tls")
                    and not effective.get("allowInsecure")
                ):
                    report.add(
                        "REMOTE_TLS_REQUIRED",
                        file,
                        (*location, "config"),
                        "非 loopback Remote Wire 必须启用 TLS，或显式设置 allowInsecure。",
                    )
                if not effective.get("tls") and any(
                    effective.get(key) is not None
                    for key in ("caFile", "clientCertFile", "clientKeyFile", "serverHostname")
                ):
                    report.add(
                        "REMOTE_TLS_OPTIONS_WITHOUT_TLS",
                        file,
                        (*location, "config", "tls"),
                        "TLS 证书和 serverHostname 要求显式配置 tls=true。",
                    )
            if entrypoint == "areal_agent_runtime.adapters.vision.plugin:create_plugin":
                if not effective.get("engineEntrypoint"):
                    report.add(
                        "OCR_ENGINE_REQUIRED",
                        file,
                        (*location, "config", "engineEntrypoint"),
                        "通过配置加载 OCR 插件时必须提供 engineEntrypoint。",
                    )
                else:
                    report.add(
                        "OCR_ENGINE_NOT_LOADED",
                        file,
                        (*location, "config", "engineEntrypoint"),
                        "未导入外部 OCR engine；其配置与可用性尚未校验。",
                        level="skipped_checks",
                    )
        if owner is not None:
            providers[owner] = metadata.ports if metadata else None
    if isinstance(config, BootstrapConfig):
        for index, binding in enumerate(config.tool_bindings):
            for tool_index, name in enumerate(binding.tool_names):
                if name not in tools:
                    report.add(
                        "TOOL_NOT_VERIFIED" if unknown_tools else "TOOL_NOT_FOUND",
                        file,
                        ("toolBindings", index, "toolNames", tool_index),
                        "未在内置工具目录找到；外部目录需运行时发现。"
                        if unknown_tools
                        else "未在已安装的内置工具目录找到该工具。",
                        level="skipped_checks" if unknown_tools else "errors",
                    )

    return tools, unknown_tools


def _profile_tools(config, documents, report, file, tools, unknown_tools) -> None:
    references: list[tuple[str, tuple, tuple[str, ...]]] = []
    if documents is not None:
        for index, profile in enumerate(documents["release.yaml"].profiles):
            references.append(("release.yaml", ("profiles", index, "toolNames"), profile.tool_names))
        for index, agent in enumerate(documents["agents.yaml"].agents):
            references.append(("agents.yaml", ("agents", index, "toolNames"), agent.tool_names))
        for index, workflow in enumerate(documents["workflow.yaml"].workflows):
            for node_index, node in enumerate(workflow.nodes):
                references.append(
                    ("workflow.yaml", ("workflows", index, "nodes", node_index, "toolNames"), node.tool_names)
                )
            if workflow.dynamic_policy is not None:
                references.append(
                    (
                        "workflow.yaml",
                        ("workflows", index, "dynamicPolicy", "allowedToolNames"),
                        workflow.dynamic_policy.allowed_tool_names,
                    )
                )
    else:
        for index, profile in enumerate(config.profile_overrides):
            prefix = ("profileOverrides", index)
            references.append((file, (*prefix, "toolNames"), profile.tool_names))
            for agent_index, agent in enumerate(profile.agent_profiles):
                references.append((file, (*prefix, "agentProfiles", agent_index, "toolNames"), agent.tool_names))
            if profile.agent_graph is not None:
                for node_index, node in enumerate(profile.agent_graph.agents):
                    references.append(
                        (file, (*prefix, "agentGraph", "agents", node_index, "toolNames"), node.tool_names)
                    )
                policy = profile.agent_graph.dynamic_policy
                if policy is not None:
                    references.append(
                        (file, (*prefix, "agentGraph", "dynamicPolicy", "allowedToolNames"), policy.allowed_tool_names)
                    )
    for source_file, location, names in references:
        for index, name in enumerate(names):
            if name not in tools:
                report.add(
                    "TOOL_NOT_VERIFIED" if unknown_tools else "TOOL_NOT_FOUND",
                    source_file,
                    (*location, index),
                    "工具名称无法在静态目录中解析；请核对提供者和目录。",
                    level="skipped_checks" if unknown_tools else "errors",
                )


def _remote_loopback(host: object) -> bool:
    if not isinstance(host, str):
        return False
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _application_references(config: BootstrapConfig, report: ValidationReport, file: str) -> None:
    selectors = {runtime.selector for runtime in config.configured_runtimes()}
    profiles = default_profiles() if config.include_default_profiles else {}
    profiles.update({profile.profile_id: profile for profile in config.profile_overrides})
    if not profiles:
        report.add("PROFILES_EMPTY", file, ("profileOverrides",), "必须启用默认 Profiles 或提供至少一个 Profile。")
    if config.host.default_runtime_selector is not None and config.host.default_runtime_selector not in selectors:
        report.add("RUNTIME_NOT_FOUND", file, ("host", "defaultRuntimeSelector"), "Runtime selector 未安装。")
    for mode, selector in config.host.mode_runtime_selectors.items():
        if selector not in selectors:
            report.add("RUNTIME_NOT_FOUND", file, ("host", "modeRuntimeSelectors", mode), "Runtime selector 未安装。")
    if config.host.kind == "arca" and config.host.default_profile not in profiles:
        report.add("PROFILE_NOT_FOUND", file, ("host", "defaultProfile"), "ARCA defaultProfile 未安装。")
    if config.host.kind == "openai":
        for mode, profile_id in config.host.mode_profiles.items():
            if profile_id not in profiles:
                report.add(
                    "PROFILE_NOT_FOUND", file, ("host", "modeProfiles", mode), "OpenAI Host 映射的 Profile 未安装。"
                )
    for index, binding in enumerate(config.tool_bindings):
        profile = profiles.get(binding.profile_id)
        if profile is None:
            report.add(
                "PROFILE_NOT_FOUND", file, ("toolBindings", index, "profileId"), "工具绑定引用的 Profile 未安装。"
            )
        elif binding.agent_id is not None and (
            profile.agent_graph is None
            or binding.agent_id not in {node.agent_id for node in profile.agent_graph.agents}
        ):
            report.add(
                "AGENT_NOT_FOUND",
                file,
                ("toolBindings", index, "agentId"),
                "工具绑定的 agentId 不属于此 Profile 的 DAG。",
            )
    for index, profile in enumerate(config.profile_overrides):
        for agent_index, agent_profile in enumerate(profile.agent_profiles):
            if agent_profile.runtime_selector is not None and agent_profile.runtime_selector not in selectors:
                report.add(
                    "RUNTIME_NOT_FOUND",
                    file,
                    ("profileOverrides", index, "agentProfiles", agent_index, "runtimeSelector"),
                    "动态 AgentProfile 引用的 Runtime selector 未安装。",
                )
        if profile.agent_graph is not None:
            for node_index, node in enumerate(profile.agent_graph.agents):
                if node.runtime_selector is not None and node.runtime_selector not in selectors:
                    report.add(
                        "RUNTIME_NOT_FOUND",
                        file,
                        ("profileOverrides", index, "agentGraph", "agents", node_index, "runtimeSelector"),
                        "DAG 节点引用的 Runtime selector 未安装（此位置为编译后的 BootstrapConfig）。",
                    )
            policy = profile.agent_graph.dynamic_policy
            if policy is not None and set(policy.allowed_runtime_selectors).difference(selectors):
                report.add(
                    "RUNTIME_NOT_FOUND",
                    file,
                    ("profileOverrides", index, "agentGraph", "dynamicPolicy", "allowedRuntimeSelectors"),
                    "动态策略允许了未安装的 Runtime selector（此位置为编译后的 BootstrapConfig）。",
                )
