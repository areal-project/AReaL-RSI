"""Assemble named AssetStore providers without replacing authoritative state."""

from __future__ import annotations

from typing import cast

from pydantic import JsonValue

from areal_agent_runtime.adapters.storage.routing import AssetRoutingRule, RoutingAssetStore
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class RoutingAssetStorePlugin:
    manifest = PluginManifest(
        name="routing-assets",
        version="1.0.0",
        implements=(PortKey.ASSET_STORE,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.storage.routing_plugin:create_plugin"),
        config_schema="routing.schema.json",
    )

    def __init__(self) -> None:
        self.asset_store: RoutingAssetStore | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        bindings = config.get("backends")
        if not isinstance(bindings, dict) or any(not isinstance(owner, str) for owner in bindings.values()):
            raise ValueError("Asset routing backends must map aliases to registered provider owners")
        default = config.get("defaultBackend")
        if not isinstance(default, str):
            raise ValueError("Asset routing requires defaultBackend")
        raw_rules = config.get("rules", [])
        if not isinstance(raw_rules, list) or any(not isinstance(rule, dict) for rule in raw_rules):
            raise ValueError("Asset routing rules must be objects")
        rules = tuple(
            AssetRoutingRule(
                backend=cast(str, rule["backend"]),
                run_id=cast(str | None, rule.get("runId")),
                profile_id=cast(str | None, rule.get("profileId")),
                agent_id=cast(str | None, rule.get("agentId")),
                media_type=cast(str | None, rule.get("mediaType")),
            )
            for rule in cast(list[dict[str, JsonValue]], raw_rules)
        )
        self.asset_store = RoutingAssetStore(
            {
                alias: cast(AssetStorePort, context.require(PortKey.ASSET_STORE, owner=cast(str, owner)))
                for alias, owner in bindings.items()
            },
            default_backend=default,
            legacy_backend=cast(str | None, config.get("legacyBackend")),
            rules=rules,
        )
        context.provide(PortKey.ASSET_STORE, self.asset_store)

    async def start(self) -> None:
        if self.asset_store is None:
            raise RuntimeError("Asset routing plugin is not configured")

    async def health(self) -> HealthStatus:
        # AssetStore has no required health method. Underlying provider plugins
        # own their connection checks; this reports successful router assembly.
        return HealthStatus(status="healthy" if self.asset_store is not None else "unhealthy")

    async def stop(self) -> None:
        # The PluginManager owns backend lifetimes and closes them after users.
        return None


def create_plugin() -> RoutingAssetStorePlugin:
    return RoutingAssetStorePlugin()
