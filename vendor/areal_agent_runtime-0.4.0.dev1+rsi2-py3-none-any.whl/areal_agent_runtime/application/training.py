"""Deterministic join from Runtime lineage to AReaL-shaped training records."""

from __future__ import annotations

from collections.abc import Iterable

from areal_agent_runtime.contracts.data import (
    ARealModelResponseRecord,
    ARealTrainingSample,
    CanonicalObservation,
    DataAnnotation,
    ModelCallObservation,
    ModelCallTrainingRecord,
    ObservationLineage,
    RewardAnnotationPayload,
    RewardOnlySample,
    TrainingProjection,
)


class TrainingProjectionError(ValueError):
    """Training facts are absent, ambiguous, or do not match Runtime lineage."""


class TrainingTrajectoryProjector:
    """Join token/reward facts without tokenizing text or inventing policy data.

    Token IDs, output logprobs and output policy versions must be supplied by
    AReaL (or another instrumented inference plane) as
    ``ModelCallTrainingRecord``.  Runtime observations contribute only stable
    identity and agent/tool/environment lineage.
    """

    def project_token_level(
        self,
        *,
        run_id: str,
        observations: Iterable[CanonicalObservation],
        records: Iterable[ModelCallTrainingRecord],
        annotations: Iterable[DataAnnotation] = (),
    ) -> TrainingProjection:
        lineage = _model_lineage(run_id, observations)
        rewards = _annotation_rewards(run_id, annotations, lineage)
        supplied = tuple(records)
        if not supplied:
            raise TrainingProjectionError(
                "token-level projection requires real token/logprob/version records"
            )
        seen: set[str] = set()
        samples: list[ARealTrainingSample] = []
        for record in supplied:
            if record.model_call_id in seen:
                raise TrainingProjectionError(
                    f"duplicate modelCallId training record: {record.model_call_id}"
                )
            seen.add(record.model_call_id)
            source_lineage = lineage.get(record.model_call_id)
            if source_lineage is None:
                raise TrainingProjectionError(
                    f"training record has no Runtime model call: {record.model_call_id}"
                )
            annotation = rewards.get(record.model_call_id)
            if annotation is not None:
                assert isinstance(annotation.payload, RewardAnnotationPayload)
            if annotation is not None and annotation.interaction_id not in {None, record.interaction_id}:
                raise TrainingProjectionError(
                    f"reward interactionId does not match training record: {record.model_call_id}"
                )
            annotation_reward = annotation.payload.value if annotation is not None else None
            if record.reward is not None and annotation_reward is not None:
                if record.reward != annotation_reward:
                    raise TrainingProjectionError(
                        f"conflicting rewards for modelCallId {record.model_call_id}"
                    )
            reward = record.reward if record.reward is not None else annotation_reward
            if reward is None:
                raise TrainingProjectionError(
                    f"token-level record has no real reward: {record.model_call_id}"
                )
            samples.append(
                ARealTrainingSample(
                    model_call_id=record.model_call_id,
                    interaction_id=record.interaction_id,
                    model_response=ARealModelResponseRecord(
                        input_tokens=record.input_token_ids,
                        output_tokens=record.output_token_ids,
                        output_logprobs=record.output_logprobs,
                        output_versions=record.output_versions,
                    ),
                    reward=reward,
                    lineage=source_lineage.model_copy(
                        update={"interaction_id": record.interaction_id}
                    ),
                )
            )
        return TrainingProjection(
            run_id=run_id,
            mode="token-level",
            trainable=True,
            samples=tuple(samples),
        )

    def project_reward_only(
        self,
        *,
        run_id: str,
        observations: Iterable[CanonicalObservation],
        annotations: Iterable[DataAnnotation],
    ) -> TrainingProjection:
        lineage = _model_lineage(run_id, observations)
        samples: list[RewardOnlySample] = []
        seen: set[str] = set()
        for annotation in annotations:
            if annotation.run_id != run_id or not isinstance(
                annotation.payload, RewardAnnotationPayload
            ):
                continue
            model_call_id = annotation.model_call_id
            if model_call_id is None:
                raise TrainingProjectionError(
                    "reward-only training annotation requires modelCallId"
                )
            if model_call_id in seen:
                raise TrainingProjectionError(
                    f"ambiguous rewards for modelCallId {model_call_id}"
                )
            source_lineage = lineage.get(model_call_id)
            if source_lineage is None:
                raise TrainingProjectionError(
                    f"reward annotation has no Runtime model call: {model_call_id}"
                )
            _validate_reward_lineage(annotation, source_lineage)
            seen.add(model_call_id)
            samples.append(
                RewardOnlySample(
                    model_call_id=model_call_id,
                    interaction_id=annotation.interaction_id,
                    reward=annotation.payload.value,
                    lineage=source_lineage.model_copy(
                        update={"interaction_id": annotation.interaction_id}
                    ),
                )
            )
        if not samples:
            raise TrainingProjectionError(
                "reward-only projection requires a linked reward annotation"
            )
        return TrainingProjection(
            run_id=run_id,
            mode="reward-only",
            trainable=False,
            reward_only=tuple(samples),
        )


def _model_lineage(
    run_id: str,
    observations: Iterable[CanonicalObservation],
) -> dict[str, ObservationLineage]:
    result: dict[str, ObservationLineage] = {}
    phases: dict[str, set[str]] = {}
    for observation in observations:
        if observation.lineage.run_id != run_id:
            raise TrainingProjectionError("observation escaped the requested Run")
        if not isinstance(observation.payload, ModelCallObservation):
            continue
        model_call_id = observation.lineage.model_call_id
        if model_call_id is None:
            raise TrainingProjectionError("model-call observation lacks modelCallId lineage")
        previous = result.get(model_call_id)
        if previous is not None and (
            previous.execution_id != observation.lineage.execution_id
            or previous.agent_id != observation.lineage.agent_id
            or previous.agent_attempt_id != observation.lineage.agent_attempt_id
        ):
            raise TrainingProjectionError(
                f"modelCallId has conflicting Runtime lineage: {model_call_id}"
            )
        result.setdefault(model_call_id, observation.lineage)
        phases.setdefault(model_call_id, set()).add(observation.payload.phase)
    return {
        model_call_id: lineage
        for model_call_id, lineage in result.items()
        if phases[model_call_id] >= {"started", "completed"}
        and "failed" not in phases[model_call_id]
    }


def _annotation_rewards(
    run_id: str,
    annotations: Iterable[DataAnnotation],
    lineage: dict[str, ObservationLineage],
) -> dict[str, DataAnnotation]:
    result: dict[str, DataAnnotation] = {}
    for annotation in annotations:
        if annotation.run_id != run_id or not isinstance(
            annotation.payload, RewardAnnotationPayload
        ):
            continue
        if annotation.model_call_id is None:
            continue
        source = lineage.get(annotation.model_call_id)
        if source is None:
            raise TrainingProjectionError(
                f"reward annotation has no Runtime model call: {annotation.model_call_id}"
            )
        _validate_reward_lineage(annotation, source)
        previous = result.get(annotation.model_call_id)
        if previous is not None and (
            previous.payload != annotation.payload or previous.interaction_id != annotation.interaction_id
        ):
            raise TrainingProjectionError(
                f"conflicting reward annotations for {annotation.model_call_id}"
            )
        result[annotation.model_call_id] = annotation
    return result


def _validate_reward_lineage(annotation: DataAnnotation, lineage: ObservationLineage) -> None:
    if annotation.execution_id != lineage.execution_id:
        raise TrainingProjectionError(
            f"reward executionId does not match Runtime execution: {annotation.model_call_id}"
        )
    if lineage.interaction_id is not None and annotation.interaction_id != lineage.interaction_id:
        raise TrainingProjectionError(
            f"reward interactionId does not match Runtime interaction: {annotation.model_call_id}"
        )
