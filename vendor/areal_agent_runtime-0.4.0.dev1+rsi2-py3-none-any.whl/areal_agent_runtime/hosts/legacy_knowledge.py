"""Safe resolution of the historical request-selected system prompt."""

from __future__ import annotations

import asyncio
import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from pydantic import JsonValue

from areal_agent_runtime.contracts.content import TextBlock
from areal_agent_runtime.contracts.environment import InlineResourceSource
from areal_agent_runtime.contracts.knowledge import KnowledgeRef

_ALLOWED_SUFFIXES = frozenset({".md", ".txt"})
_FORBIDDEN_VOCABULARY = ("sandbox", "mount", "挂载", "oss")


@dataclass(frozen=True, slots=True)
class ResolvedLegacyPrompt:
    instructions: tuple[TextBlock, ...] = ()
    source: str = "profile-default"
    path: str = ""
    sha256: str | None = None
    fallback_reason: str | None = None
    resource: InlineResourceSource | None = None

    def metadata(self) -> dict[str, JsonValue]:
        result: dict[str, JsonValue] = {"source": self.source, "path": self.path}
        if self.sha256 is not None:
            result["sha256"] = self.sha256
        if self.fallback_reason is not None:
            result["fallbackReason"] = self.fallback_reason
        return result


@dataclass(frozen=True, slots=True)
class ResolvedLegacySkills:
    instructions: tuple[TextBlock, ...] = ()
    snapshots: tuple[dict[str, JsonValue], ...] = ()
    resources: tuple[InlineResourceSource, ...] = ()


class LegacyKnowledgeResolutionError(RuntimeError):
    pass


class LegacyPromptResolver:
    """Resolve catalog/user prompt references without exposing their paths to Application."""

    def __init__(
        self,
        roots: Mapping[str, str | Path],
        *,
        skill_roots: Mapping[str, str | Path] | None = None,
        max_bytes: int = 32 * 1024,
        max_skill_bytes: int = 256 * 1024,
    ) -> None:
        self._roots = {source: Path(root).expanduser().resolve() for source, root in roots.items()}
        self._skill_roots = {
            source: Path(root).expanduser().resolve()
            for source, root in (skill_roots or {}).items()
        }
        self._max_bytes = max_bytes
        self._max_skill_bytes = max_skill_bytes

    async def resolve(self, selection: JsonValue) -> ResolvedLegacyPrompt:
        return await asyncio.to_thread(self._resolve, selection)

    async def resolve_skills(self, selected: tuple[KnowledgeRef, ...]) -> ResolvedLegacySkills:
        return await asyncio.to_thread(self._resolve_skills, selected)

    def _resolve_skills(self, selected: tuple[KnowledgeRef, ...]) -> ResolvedLegacySkills:
        instructions: list[TextBlock] = []
        snapshots: list[dict[str, JsonValue]] = []
        resources: list[InlineResourceSource] = []
        for ref in selected:
            root = self._skill_roots.get(ref.source)
            if root is None:
                raise LegacyKnowledgeResolutionError(f"unknown skill source: {ref.source}")
            skill_root = (root / ref.name).resolve(strict=False)
            if not skill_root.is_relative_to(root):
                raise LegacyKnowledgeResolutionError(f"invalid skill name: {ref.name}")
            path = (skill_root / "SKILL.md").resolve(strict=False)
            if not path.is_relative_to(skill_root) or not path.is_file():
                raise LegacyKnowledgeResolutionError(
                    f"skill is missing SKILL.md: {ref.source}/{ref.name}"
                )
            try:
                if path.stat().st_size > self._max_skill_bytes:
                    raise LegacyKnowledgeResolutionError(
                        f"skill exceeds {self._max_skill_bytes} bytes: {ref.source}/{ref.name}"
                    )
                text = path.read_text(encoding="utf-8").strip()
            except UnicodeDecodeError as exc:
                raise LegacyKnowledgeResolutionError(
                    f"skill must be UTF-8: {ref.source}/{ref.name}"
                ) from exc
            if not text:
                raise LegacyKnowledgeResolutionError(f"skill is empty: {ref.source}/{ref.name}")
            digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
            instruction = TextBlock(
                text=(
                    f'<REQUEST_SKILL source="{ref.source}" name="{ref.name}" sha256="{digest}">\n'
                    f"{text}\n"
                    "</REQUEST_SKILL>"
                )
            )
            instructions.append(instruction)
            resources.append(
                InlineResourceSource(
                    resource_id=f"legacy-skill:{digest[:24]}",
                    version=ref.revision,
                    media_type="text/markdown",
                    content=instruction.text,
                )
            )
            snapshots.append(
                {
                    "source": ref.source,
                    "name": ref.name,
                    "revision": ref.revision,
                    "skillMdSha256": digest,
                }
            )
        return ResolvedLegacySkills(
            instructions=tuple(instructions),
            snapshots=tuple(snapshots),
            resources=tuple(resources),
        )

    def _resolve(self, selection: JsonValue) -> ResolvedLegacyPrompt:
        if selection is None:
            return ResolvedLegacyPrompt()
        if not isinstance(selection, dict):
            return self._fallback("invalid_selection")
        source = selection.get("source")
        relative = selection.get("path")
        if not isinstance(source, str) or source not in self._roots:
            return self._fallback("invalid_source")
        if not isinstance(relative, str) or not relative:
            return self._fallback("missing_path")
        candidate = PurePosixPath(relative)
        if candidate.is_absolute() or any(part in {"", ".", ".."} for part in candidate.parts):
            return self._fallback("path_traversal")
        if candidate.suffix.lower() not in _ALLOWED_SUFFIXES:
            return self._fallback("unsupported_suffix")
        root = self._roots[source]
        path = (root / candidate.as_posix()).resolve(strict=False)
        if not path.is_relative_to(root):
            return self._fallback("path_traversal")
        if not path.is_file():
            return self._fallback("not_found")
        try:
            if path.stat().st_size > self._max_bytes:
                return self._fallback("too_large")
            text = path.read_text(encoding="utf-8").strip()
        except (OSError, UnicodeDecodeError):
            return self._fallback("unreadable")
        if not text:
            return self._fallback("empty")
        lowered = text.lower()
        if any(term in lowered for term in _FORBIDDEN_VOCABULARY):
            return self._fallback("forbidden_vocabulary")
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        instruction = TextBlock(
            text=(
                f'<REQUEST_CHARTER source="{source}" sha256="{digest}">\n'
                f"{text}\n"
                "</REQUEST_CHARTER>"
            )
        )
        return ResolvedLegacyPrompt(
            instructions=(instruction,),
            source=source,
            path=relative,
            sha256=digest,
            resource=InlineResourceSource(
                resource_id=f"legacy-prompt:{digest[:24]}",
                media_type="text/plain",
                content=instruction.text,
            ),
        )

    @staticmethod
    def _fallback(reason: str) -> ResolvedLegacyPrompt:
        return ResolvedLegacyPrompt(fallback_reason=reason)
