"""Application-owned multi-agent decisions, scheduling and durable graph state.

This module deliberately defines no Kernel Port.  Runtimes execute one agent;
the Application owns DAG readiness, bounded concurrency, joins, cancellation,
workspace access and dynamic in-memory graph expansion.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Literal

from pydantic import (
    Field,
    JsonValue,
    SerializerFunctionWrapHandler,
    StrictBool,
    StrictInt,
    ValidationError,
    field_validator,
    model_serializer,
    model_validator,
)

from areal_agent_runtime.application.workflow import (
    AgentGraph,
    AgentInputMode,
    AgentProfile,
    AgentSpec,
    CancelPolicy,
    DynamicAgentPolicy,
    FailurePolicy,
    JoinMode,
    JoinPolicy,
    MultiAgentOwnership,
    ParallelGroup,
    TimeoutPolicy,
    WorkflowAgent,
    WorkspaceAccess,
)
from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import ContentBlock, JsonBlock, ReasoningBlock, TextBlock
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType
from areal_agent_runtime.contracts.runtime import RuntimeCapabilities, WorkspaceRef


class ProposedAgentOverrides(ContractModel):
    """The complete set of fields a Planner may ask the owner to override.

    Prompt text, skills, MCP endpoints, plugins, secrets and host permissions
    are intentionally absent.  Those authorities can only enter through a
    trusted AgentProfile or the invocation's already-authorized environment.
    """

    runtime_selector: str | None = None
    workspace_access: WorkspaceAccess | None = None
    input_mode: AgentInputMode | None = None
    required_features: tuple[str, ...] = ()
    tool_names: tuple[str, ...] | None = None
    timeout_seconds: float | None = Field(default=None, gt=0)
    max_attempts: StrictInt | None = Field(default=None, ge=1)
    retry_backoff_seconds: float | None = Field(default=None, ge=0)
    merge_overlays: tuple[str, ...] = ()
    allow_runtime_subagents: StrictBool | None = None

    @field_validator("runtime_selector")
    @classmethod
    def validate_identifier(cls, value: str | None) -> str | None:
        return _trimmed_or_none(value, "proposed runtime selector")

    @field_validator("required_features", "merge_overlays")
    @classmethod
    def validate_string_sets(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return _unique_trimmed(value, "proposed agent override")

    @field_validator("tool_names")
    @classmethod
    def validate_tool_names(cls, value: tuple[str, ...] | None) -> tuple[str, ...] | None:
        return None if value is None else _unique_trimmed(value, "proposed toolNames override")

    @field_validator("timeout_seconds", mode="before")
    @classmethod
    def validate_timeout(cls, value: object) -> object:
        return _finite_number_or_none(value, "proposed agent timeoutSeconds")

    @field_validator("retry_backoff_seconds", mode="before")
    @classmethod
    def validate_backoff(cls, value: object) -> object:
        return _finite_number_or_none(value, "proposed agent retryBackoffSeconds")


class ProposedAgent(ContractModel):
    """Untrusted request to instantiate one catalog profile in the graph."""

    agent_id: str = Field(min_length=1)
    agent_profile_id: str = Field(min_length=1)
    depends_on: tuple[str, ...] = ()
    overrides: ProposedAgentOverrides = Field(default_factory=ProposedAgentOverrides)
    budget_units: StrictInt = Field(default=1, ge=1)

    @field_validator("agent_id", "agent_profile_id")
    @classmethod
    def validate_identifiers(cls, value: str) -> str:
        return _trimmed(value, "proposed agent identifier")

    @field_validator("depends_on")
    @classmethod
    def validate_dependencies(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return _unique_trimmed(value, "proposed agent dependencies")


class ProposedParallelGroup(ContractModel):
    group_id: str = Field(min_length=1)
    agent_ids: tuple[str, ...] = Field(min_length=2)
    join: JoinPolicy = Field(default_factory=JoinPolicy)

    @model_validator(mode="after")
    def validate_group(self) -> ProposedParallelGroup:
        ParallelGroup(group_id=self.group_id, agent_ids=self.agent_ids, join=self.join)
        return self

    def to_parallel_group(self) -> ParallelGroup:
        return ParallelGroup(group_id=self.group_id, agent_ids=self.agent_ids, join=self.join)


class PlanProposal(ContractModel):
    schema_version: Literal["areal.agent-runtime.plan-proposal/v1"] = "areal.agent-runtime.plan-proposal/v1"
    proposal_id: str = Field(min_length=1)
    agents: tuple[ProposedAgent, ...] = Field(min_length=1)
    parallel_groups: tuple[ProposedParallelGroup, ...] = ()

    @field_validator("proposal_id")
    @classmethod
    def validate_proposal_id(cls, value: str) -> str:
        return _trimmed(value, "proposalId")

    @model_validator(mode="after")
    def validate_unique_ids(self) -> PlanProposal:
        agent_ids = [agent.agent_id for agent in self.agents]
        group_ids = [group.group_id for group in self.parallel_groups]
        if len(agent_ids) != len(set(agent_ids)):
            raise ValueError("proposal agentId values must be unique")
        if len(group_ids) != len(set(group_ids)):
            raise ValueError("proposal parallel groupId values must be unique")
        collisions = sorted(set(agent_ids).intersection(group_ids))
        if collisions:
            raise ValueError("proposal group IDs collide with agents: " + ", ".join(collisions))
        return self


def plan_proposal_instruction(policy: DynamicAgentPolicy) -> TextBlock:
    """Publish the exact Runtime-owned proposal contract to a dynamic planner.

    This improves provider portability without granting authority: the returned
    object remains untrusted until ``ApplicationOrchestrator.decide`` resolves
    and validates it against the same owner policy.
    """

    schema = PlanProposal.model_json_schema(by_alias=True)
    policy_summary = {
        "allowedAgentProfileIds": list(policy.allowed_agent_profile_ids),
        "allowedOverrideFields": list(policy.allowed_override_fields),
        "allowedWorkspaceAccess": [item.value for item in policy.allowed_workspace_access],
        "maxDynamicAgents": policy.max_dynamic_agents,
        "maxParallelGroups": policy.max_parallel_groups,
        "maxConcurrency": policy.max_concurrency,
        "maxBudgetUnits": policy.max_budget_units,
        "maxAgentBudgetUnits": policy.max_agent_budget_units,
    }
    return TextBlock(
        text=(
            "You are the dynamic DAG proposal producer. Your final answer must be exactly one bare JSON "
            "object, with no Markdown fence, preface, explanation, or trailing text. It must validate "
            "against this ARealAgentRuntime JSON Schema:\n"
            + json.dumps(schema, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            + "\nThe owner-controlled proposal limits are:\n"
            + json.dumps(
                policy_summary,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
            + "\nOnly propose fields defined by the schema. This output is an untrusted proposal; the "
            "ApplicationOrchestrator will independently authorize and normalize it."
        )
    )


class ValidatedGraphPatch(ContractModel):
    """Complete, immutable and digest-bound graph change.

    This is the only dynamic graph mutation protocol accepted by
    ``AgentScheduler``.  It contains resolved ``AgentSpec`` values rather than
    planner-authored references or lossy scheduling summaries.
    """

    schema_version: Literal["areal.agent-runtime.graph-patch/v1"] = "areal.agent-runtime.graph-patch/v1"
    proposal_id: str = Field(min_length=1)
    proposal_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    base_graph_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    agents: tuple[AgentSpec, ...] = Field(min_length=1)
    parallel_groups: tuple[ParallelGroup, ...] = ()
    result_graph_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    patch_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")

    @classmethod
    def create(
        cls,
        *,
        proposal_id: str,
        proposal_digest: str,
        base_graph: AgentGraph,
        agents: tuple[AgentSpec, ...],
        parallel_groups: tuple[ParallelGroup, ...],
    ) -> ValidatedGraphPatch:
        result = _apply_patch_payload(base_graph, agents, parallel_groups)
        payload = {
            "proposal_id": proposal_id,
            "proposal_digest": proposal_digest,
            "base_graph_digest": graph_digest(base_graph),
            "agents": agents,
            "parallel_groups": parallel_groups,
            "result_graph_digest": graph_digest(result),
        }
        digest = _model_payload_digest(cls, payload, "patch_digest")
        return cls(**payload, patch_digest=digest)

    @model_validator(mode="after")
    def validate_patch(self) -> ValidatedGraphPatch:
        expected = _digest(
            self.model_dump(mode="json", by_alias=True, exclude={"patch_digest"})
        )
        if self.patch_digest.lower() != expected:
            raise ValueError("ValidatedGraphPatch digest mismatch")
        return self

    def apply_to(self, graph: AgentGraph) -> AgentGraph:
        if graph_digest(graph) != self.base_graph_digest.lower():
            raise ValueError("ValidatedGraphPatch base graph digest mismatch")
        result = _apply_patch_payload(graph, self.agents, self.parallel_groups)
        if graph_digest(result) != self.result_graph_digest.lower():
            raise ValueError("ValidatedGraphPatch result graph digest mismatch")
        return result


class OrchestratorDecision(ContractModel):
    schema_version: Literal["areal.agent-runtime.orchestrator-decision/v1"] = (
        "areal.agent-runtime.orchestrator-decision/v1"
    )
    proposal_id: str = Field(min_length=1)
    accepted: StrictBool
    proposal_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    base_graph_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    graph_patch: ValidatedGraphPatch | None = None
    rejections: tuple[str, ...] = ()
    decision_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")

    @classmethod
    def accepted_decision(
        cls,
        *,
        proposal: PlanProposal,
        base_graph: AgentGraph,
        patch: ValidatedGraphPatch,
    ) -> OrchestratorDecision:
        return cls._create(
            proposal_id=proposal.proposal_id,
            accepted=True,
            proposal_digest=proposal_digest(proposal),
            base_graph_digest=graph_digest(base_graph),
            graph_patch=patch,
            rejections=(),
        )

    @classmethod
    def rejected_decision(
        cls,
        *,
        proposal: PlanProposal,
        base_graph: AgentGraph,
        rejections: tuple[str, ...],
    ) -> OrchestratorDecision:
        return cls._create(
            proposal_id=proposal.proposal_id,
            accepted=False,
            proposal_digest=proposal_digest(proposal),
            base_graph_digest=graph_digest(base_graph),
            graph_patch=None,
            rejections=rejections,
        )

    @classmethod
    def _create(cls, **payload: object) -> OrchestratorDecision:
        digest = _model_payload_digest(cls, payload, "decision_digest")
        return cls(**payload, decision_digest=digest)

    @model_validator(mode="after")
    def validate_decision(self) -> OrchestratorDecision:
        _trimmed(self.proposal_id, "decision proposalId")
        _unique_trimmed(self.rejections, "decision rejections")
        if self.accepted and (self.rejections or self.graph_patch is None):
            raise ValueError("accepted orchestrator decision requires only graphPatch")
        if not self.accepted and (self.graph_patch is not None or not self.rejections):
            raise ValueError("rejected orchestrator decision requires rejections and no graphPatch")
        if self.graph_patch is not None:
            if self.graph_patch.proposal_id != self.proposal_id:
                raise ValueError("decision and graphPatch proposalId differ")
            if self.graph_patch.proposal_digest != self.proposal_digest.lower():
                raise ValueError("decision and graphPatch proposalDigest differ")
            if self.graph_patch.base_graph_digest != self.base_graph_digest.lower():
                raise ValueError("decision and graphPatch baseGraphDigest differ")
        expected = _digest(
            self.model_dump(mode="json", by_alias=True, exclude={"decision_digest"})
        )
        if self.decision_digest.lower() != expected:
            raise ValueError("OrchestratorDecision digest mismatch")
        return self


class AgentNodeStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class GroupStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    JOINED = "joined"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentNodeSnapshot(ContractModel):
    agent_id: str = Field(min_length=1)
    status: AgentNodeStatus = AgentNodeStatus.PENDING
    attempt: StrictInt = Field(default=0, ge=0)
    output: tuple[ContentBlock, ...] = ()
    error: ErrorInfo | None = None
    dynamic: StrictBool = False
    completion_sequence: StrictInt | None = Field(default=None, ge=0)

    @model_serializer(mode="wrap")
    def _serialize(self, handler: SerializerFunctionWrapHandler):  # type: ignore[no-untyped-def]
        payload = handler(self)
        # Keep the exact digest representation of snapshots written before
        # completion order was recorded. A missing order is not an order of zero.
        if self.completion_sequence is None:
            payload.pop("completionSequence", None)
            payload.pop("completion_sequence", None)
        return payload


class ParallelGroupSnapshot(ContractModel):
    group_id: str = Field(min_length=1)
    status: GroupStatus = GroupStatus.PENDING
    succeeded: tuple[str, ...] = ()
    failed: tuple[str, ...] = ()
    cancelled: tuple[str, ...] = ()
    output: tuple[ContentBlock, ...] = ()


class RuntimeGraphSnapshot(ContractModel):
    schema_version: Literal["areal.agent-runtime.runtime-graph/v1"] = "areal.agent-runtime.runtime-graph/v1"
    run_id: str = Field(min_length=1)
    revision: StrictInt = Field(default=0, ge=0)
    graph: AgentGraph
    graph_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    agents: tuple[AgentNodeSnapshot, ...]
    groups: tuple[ParallelGroupSnapshot, ...] = ()
    decisions: tuple[OrchestratorDecision, ...] = ()
    snapshot_digest: str = Field(pattern=r"^[a-fA-F0-9]{64}$")

    @classmethod
    def create(
        cls,
        *,
        run_id: str,
        revision: int,
        graph: AgentGraph,
        agents: tuple[AgentNodeSnapshot, ...],
        groups: tuple[ParallelGroupSnapshot, ...] = (),
        decisions: tuple[OrchestratorDecision, ...] = (),
    ) -> RuntimeGraphSnapshot:
        payload = {
            "run_id": run_id,
            "revision": revision,
            "graph": graph,
            "graph_digest": graph_digest(graph),
            "agents": agents,
            "groups": groups,
            "decisions": decisions,
        }
        digest = _model_payload_digest(cls, payload, "snapshot_digest")
        return cls(**payload, snapshot_digest=digest)

    @model_validator(mode="after")
    def validate_projection(self) -> RuntimeGraphSnapshot:
        if self.graph_digest.lower() != graph_digest(self.graph):
            raise ValueError("runtime graph snapshot graphDigest mismatch")
        expected_agents = {agent.agent_id for agent in self.graph.agents}
        actual_agent_ids = [agent.agent_id for agent in self.agents]
        if len(actual_agent_ids) != len(set(actual_agent_ids)):
            raise ValueError("runtime graph snapshot repeats agentId values")
        if set(actual_agent_ids) != expected_agents:
            raise ValueError("runtime graph snapshot agents do not match its graph")
        completion_sequences = [
            node.completion_sequence for node in self.agents if node.completion_sequence is not None
        ]
        if len(completion_sequences) != len(set(completion_sequences)):
            raise ValueError("runtime graph snapshot repeats a completionSequence")
        for node in self.agents:
            if node.completion_sequence is not None and (
                node.status not in {AgentNodeStatus.SUCCEEDED, AgentNodeStatus.FAILED, AgentNodeStatus.CANCELLED}
                or node.completion_sequence > self.revision
            ):
                raise ValueError("runtime graph completionSequence must identify a committed terminal node")

        graph_groups = {group.group_id: group for group in self.graph.parallel_groups}
        actual_group_ids = [group.group_id for group in self.groups]
        if len(actual_group_ids) != len(set(actual_group_ids)):
            raise ValueError("runtime graph snapshot repeats groupId values")
        if set(actual_group_ids) != set(graph_groups):
            raise ValueError("runtime graph snapshot groups do not match its graph")
        for snapshot in self.groups:
            declarations = (snapshot.succeeded, snapshot.failed, snapshot.cancelled)
            flattened = [agent_id for values in declarations for agent_id in values]
            if len(flattened) != len(set(flattened)):
                raise ValueError(f"runtime graph group {snapshot.group_id} has overlapping outcomes")
            unknown = sorted(set(flattened).difference(graph_groups[snapshot.group_id].agent_ids))
            if unknown:
                raise ValueError(
                    f"runtime graph group {snapshot.group_id} references unknown members: "
                    + ", ".join(unknown)
                )
        if self.decisions:
            proposal_ids: set[str] = set()
            expected_base = self.decisions[0].base_graph_digest.lower()
            for decision in self.decisions:
                if not decision.accepted or decision.graph_patch is None:
                    raise ValueError("runtime graph snapshot may persist only accepted decisions")
                if decision.proposal_id in proposal_ids:
                    raise ValueError("runtime graph snapshot repeats a proposalId")
                proposal_ids.add(decision.proposal_id)
                if decision.base_graph_digest.lower() != expected_base:
                    raise ValueError("runtime graph snapshot decision chain is discontinuous")
                expected_base = decision.graph_patch.result_graph_digest.lower()
            if expected_base != self.graph_digest.lower():
                raise ValueError("runtime graph snapshot does not match its latest decision")
        expected_snapshot_digest = _digest(
            self.model_dump(mode="json", by_alias=True, exclude={"snapshot_digest"})
        )
        if self.snapshot_digest.lower() != expected_snapshot_digest:
            raise ValueError("RuntimeGraphSnapshot digest mismatch")
        return self


class WorkspaceView(ContractModel):
    """Logical per-agent view inside the Run's single EnvironmentLease."""

    agent_id: str = Field(min_length=1)
    access: WorkspaceAccess
    workspace: WorkspaceRef
    isolation_key: str | None = None
    parallel_group_id: str | None = None


class OrchestrationError(ContractError):
    def __init__(self, code: str, message: str, *, details: dict[str, JsonValue] | None = None) -> None:
        super().__init__(
            ErrorInfo(
                code=code,
                category=ErrorCategory.INVALID_REQUEST,
                message=message,
                details=details or {},
            )
        )


class ApplicationOrchestrator:
    """Validate, authorize and normalize untrusted Planner proposals."""

    def __init__(
        self,
        *,
        policy: DynamicAgentPolicy,
        agent_profiles: Mapping[str, AgentProfile],
        runtime_capabilities: Mapping[str, RuntimeCapabilities],
        session_tool_names: tuple[str, ...] = (),
        default_runtime_selector: str,
    ) -> None:
        self._policy = policy
        self._agent_profiles = dict(agent_profiles)
        self._runtime_capabilities = runtime_capabilities
        self._session_tool_names = frozenset(session_tool_names)
        self._default_runtime_selector = default_runtime_selector
        if len(self._agent_profiles) != len(agent_profiles):
            raise ValueError("AgentProfile catalog contains duplicate identities")
        for profile_id, profile in self._agent_profiles.items():
            if profile_id != profile.agent_profile_id:
                raise ValueError(f"AgentProfile catalog key mismatch: {profile_id}")

    def decide(self, graph: AgentGraph, proposal: PlanProposal) -> OrchestratorDecision:
        rejections: list[str] = []
        existing_ids = {
            *(agent.agent_id for agent in graph.agents),
            *(group.group_id for group in graph.parallel_groups),
        }
        proposed_ids = [agent.agent_id for agent in proposal.agents]
        proposed_group_ids = [group.group_id for group in proposal.parallel_groups]
        collisions = sorted(existing_ids.intersection((*proposed_ids, *proposed_group_ids)))
        if collisions:
            rejections.append(f"proposal collides with existing graph IDs: {', '.join(collisions)}")
        if len(proposal.agents) > self._policy.max_dynamic_agents:
            rejections.append("proposal exceeds maxDynamicAgents")
        if len(proposal.parallel_groups) > self._policy.max_parallel_groups:
            rejections.append("proposal exceeds maxParallelGroups")
        if sum(agent.budget_units for agent in proposal.agents) > self._policy.max_budget_units:
            rejections.append("proposal exceeds maxBudgetUnits")

        allowed_profiles = set(self._policy.allowed_agent_profile_ids)
        allowed_roles = set(self._policy.allowed_roles)
        allowed_runtimes = set(self._policy.allowed_runtime_selectors)
        allowed_tools = set(self._policy.allowed_tool_names)
        allowed_features = set(self._policy.allowed_features)
        allowed_skills = set(self._policy.allowed_skill_resource_ids)
        allowed_workspace_access = set(self._policy.allowed_workspace_access)
        allowed_overrides = set(self._policy.allowed_override_fields)
        resolved_agents: list[AgentSpec] = []
        for agent in proposal.agents:
            if agent.agent_profile_id not in allowed_profiles:
                rejections.append(
                    f"agent {agent.agent_id} profile is not allowed: {agent.agent_profile_id}"
                )
            profile = self._agent_profiles.get(agent.agent_profile_id)
            if profile is None:
                rejections.append(
                    f"agent {agent.agent_id} selects unknown profile: {agent.agent_profile_id}"
                )
                continue
            requested_overrides = set(agent.overrides.model_fields_set)
            forbidden_overrides = sorted(requested_overrides.difference(allowed_overrides))
            if forbidden_overrides:
                rejections.append(
                    f"agent {agent.agent_id} requests disallowed overrides: "
                    f"{', '.join(forbidden_overrides)}"
                )

            overrides = agent.overrides
            selector = overrides.runtime_selector or profile.runtime_selector or self._default_runtime_selector
            capabilities = self._runtime_capabilities.get(selector)
            workspace_access = overrides.workspace_access or profile.workspace_access
            requested_features = tuple(dict.fromkeys((*profile.required_features, *overrides.required_features)))
            requested_tools = profile.tool_names if overrides.tool_names is None else overrides.tool_names
            timeout_seconds = (
                profile.timeout_seconds if overrides.timeout_seconds is None else overrides.timeout_seconds
            )
            max_attempts = profile.max_attempts if overrides.max_attempts is None else overrides.max_attempts
            retry_backoff_seconds = (
                profile.retry_backoff_seconds
                if overrides.retry_backoff_seconds is None
                else overrides.retry_backoff_seconds
            )
            allow_runtime_subagents = (
                profile.allow_runtime_subagents
                if overrides.allow_runtime_subagents is None
                else overrides.allow_runtime_subagents
            )

            if profile.role not in allowed_roles:
                rejections.append(f"agent {agent.agent_id} role is not allowed: {profile.role}")
            if selector not in allowed_runtimes:
                rejections.append(f"agent {agent.agent_id} runtime is not allowed: {selector}")
            if workspace_access not in allowed_workspace_access:
                rejections.append(
                    f"agent {agent.agent_id} workspace access is not allowed: {workspace_access.value}"
                )
            if agent.budget_units > self._policy.max_agent_budget_units:
                rejections.append(f"agent {agent.agent_id} exceeds maxAgentBudgetUnits")
            if max_attempts > self._policy.max_attempts:
                rejections.append(f"agent {agent.agent_id} exceeds maxAttempts")
            if timeout_seconds is not None and timeout_seconds > self._policy.max_timeout_seconds:
                rejections.append(f"agent {agent.agent_id} exceeds maxTimeoutSeconds")
            if overrides.tool_names is not None:
                escalated_tools = sorted(set(overrides.tool_names).difference(profile.tool_names))
                if escalated_tools:
                    rejections.append(
                        f"agent {agent.agent_id} tool override exceeds profile: {', '.join(escalated_tools)}"
                    )
            if allow_runtime_subagents and not profile.allow_runtime_subagents:
                rejections.append(
                    f"agent {agent.agent_id} cannot enable runtime subagents beyond its profile"
                )

            profile_skills = {skill.resource_id for skill in profile.agent_environment.skills}
            forbidden_skills = sorted(profile_skills.difference(allowed_skills))
            if forbidden_skills:
                rejections.append(
                    f"agent {agent.agent_id} profile uses unauthorized skills: {', '.join(forbidden_skills)}"
                )
            if capabilities is None:
                rejections.append(f"agent {agent.agent_id} selects unknown runtime: {selector}")
                continue
            if allow_runtime_subagents:
                if "native_multi_agent" not in allowed_features:
                    rejections.append(
                        f"agent {agent.agent_id} requests disallowed feature: native_multi_agent"
                    )
                if not capabilities.native_multi_agent:
                    rejections.append(
                        f"agent {agent.agent_id} runtime lacks feature: native_multi_agent"
                    )
            missing_modalities = sorted(
                modality.value
                for modality in set(profile.required_input_modalities).difference(capabilities.input_modalities)
            )
            if missing_modalities:
                rejections.append(f"agent {agent.agent_id} runtime lacks modalities: {', '.join(missing_modalities)}")
            forbidden_features = sorted(set(requested_features).difference(allowed_features))
            if forbidden_features:
                rejections.append(
                    f"agent {agent.agent_id} requests disallowed features: {', '.join(forbidden_features)}"
                )
            unavailable_features = sorted(
                feature for feature in requested_features if not bool(getattr(capabilities, feature, False))
            )
            if unavailable_features:
                rejections.append(f"agent {agent.agent_id} runtime lacks features: {', '.join(unavailable_features)}")
            if requested_tools and not capabilities.tool_calling:
                rejections.append(f"agent {agent.agent_id} runtime lacks feature: tool_calling")
            if requested_tools and not capabilities.application_tool_bridge:
                rejections.append(
                    f"agent {agent.agent_id} runtime lacks feature: application_tool_bridge"
                )
            forbidden_tools = sorted(set(requested_tools).difference(allowed_tools))
            if forbidden_tools:
                rejections.append(f"agent {agent.agent_id} requests disallowed tools: {', '.join(forbidden_tools)}")
            unavailable_tools = sorted(set(requested_tools).difference(self._session_tool_names))
            if unavailable_tools:
                rejections.append(
                    f"agent {agent.agent_id} requests tools outside the Session Tool Catalog: "
                    f"{', '.join(unavailable_tools)}"
                )

            resolved_agents.append(
                AgentSpec(
                    agent_id=agent.agent_id,
                    agent_profile_id=profile.agent_profile_id,
                    agent_profile_version=profile.version,
                    role=profile.role,
                    depends_on=agent.depends_on or (self._policy.planner_agent_id,),
                    system=profile.system,
                    agent_environment=profile.agent_environment,
                    runtime_selector=selector,
                    workspace_access=workspace_access,
                    input_mode=overrides.input_mode or AgentInputMode.ORIGINAL_AND_DEPENDENCIES,
                    required_input_modalities=profile.required_input_modalities,
                    required_features=requested_features,
                    tool_names=requested_tools,
                    timeout_seconds=timeout_seconds,
                    max_attempts=max_attempts,
                    retry_backoff_seconds=retry_backoff_seconds,
                    merge_overlays=overrides.merge_overlays,
                    allow_runtime_subagents=allow_runtime_subagents,
                    budget_units=agent.budget_units,
                )
            )

        proposed_id_set = set(proposed_ids)
        for group in proposal.parallel_groups:
            non_dynamic_members = sorted(set(group.agent_ids).difference(proposed_id_set))
            if non_dynamic_members:
                rejections.append(
                    f"parallel group {group.group_id} may contain only agents from this proposal: "
                    f"{', '.join(non_dynamic_members)}"
                )

        groups = tuple(item.to_parallel_group() for item in proposal.parallel_groups)
        if not rejections:
            try:
                patch = ValidatedGraphPatch.create(
                    proposal_id=proposal.proposal_id,
                    proposal_digest=proposal_digest(proposal),
                    base_graph=graph,
                    agents=tuple(resolved_agents),
                    parallel_groups=groups,
                )
                patch.apply_to(graph)
            except (ValidationError, ValueError) as exc:
                rejections.append(str(exc))
        if rejections:
            return OrchestratorDecision.rejected_decision(
                proposal=proposal,
                base_graph=graph,
                rejections=tuple(dict.fromkeys(rejections)),
            )
        return OrchestratorDecision.accepted_decision(
            proposal=proposal,
            base_graph=graph,
            patch=patch,
        )


ExecuteAgent = Callable[
    [WorkflowAgent, Mapping[str, tuple[ContentBlock, ...]], WorkspaceView],
    Awaitable[tuple[ContentBlock, ...]],
]
SchedulerEvent = Callable[
    [EventType, dict[str, JsonValue], str | None, str | None],
    Awaitable[None],
]
ReduceGroup = Callable[
    [ParallelGroup, Mapping[str, tuple[ContentBlock, ...]]],
    Awaitable[tuple[ContentBlock, ...]],
]


@dataclass(slots=True)
class _AgentOutcome:
    agent_id: str
    output: tuple[ContentBlock, ...] = ()
    error: BaseException | None = None
    cancelled: bool = False


@dataclass(slots=True)
class _UnitOutcome:
    key: str
    outputs: dict[str, tuple[ContentBlock, ...]]
    group_output: tuple[ContentBlock, ...] = ()
    error: BaseException | None = None


class AgentScheduler:
    """Bounded asyncio.TaskGroup scheduler for static and dynamic DAGs."""

    def __init__(
        self,
        *,
        run_id: str,
        workspace: WorkspaceRef,
        execute_agent: ExecuteAgent,
        emit: SchedulerEvent,
        reduce_group: ReduceGroup | None = None,
        interruption_is_recoverable: Callable[[], bool] | None = None,
    ) -> None:
        self._run_id = run_id
        self._workspace = workspace
        self._execute_agent = execute_agent
        self._emit = emit
        self._reduce_group = reduce_group or self._default_reduce
        self._interruption_is_recoverable = interruption_is_recoverable or (lambda: False)
        self._state_lock = asyncio.Lock()
        self._workspace_guard = _WorkspaceGuard()
        self._revision = 0
        self._graph: AgentGraph | None = None
        self._nodes: dict[str, AgentNodeSnapshot] = {}
        self._groups: dict[str, ParallelGroupSnapshot] = {}
        self._decisions: list[OrchestratorDecision] = []
        self._dynamic_ids: set[str] = set()

    async def execute(
        self,
        graph: AgentGraph,
        *,
        resume: RuntimeGraphSnapshot | None = None,
        orchestrator: ApplicationOrchestrator | None = None,
    ) -> tuple[ContentBlock, ...]:
        if graph.ownership not in {MultiAgentOwnership.APPLICATION, MultiAgentOwnership.HYBRID}:
            raise OrchestrationError(
                "MULTI_AGENT_OWNERSHIP_INVALID",
                "Application AgentScheduler can only execute application or hybrid graphs",
            )
        self._restore(graph, resume)
        await self._snapshot()

        restored_failure = self._restored_failure()
        if restored_failure is not None:
            raise restored_failure

        outputs = {
            node.agent_id: node.output for node in self._nodes.values() if node.status == AgentNodeStatus.SUCCEEDED
        }
        outputs.update(
            {group.group_id: group.output for group in self._groups.values() if group.status == GroupStatus.JOINED}
        )
        proposal_applied = bool(self._decisions)

        while True:
            assert self._graph is not None
            # Recovery may land after the planner's output was committed but
            # before its decision/patch. Consume durable output before deciding
            # that there is no work left; never re-run an already completed planner.
            policy = self._graph.dynamic_policy
            if policy is not None and not proposal_applied and policy.planner_agent_id in outputs:
                if orchestrator is None:
                    raise OrchestrationError(
                        "DYNAMIC_ORCHESTRATOR_MISSING",
                        "A dynamic workflow requires an ApplicationOrchestrator",
                    )
                proposal = extract_plan_proposal(outputs[policy.planner_agent_id])
                if proposal is None:
                    raise OrchestrationError(
                        "PLAN_PROPOSAL_MISSING",
                        f"Planner {policy.planner_agent_id} did not return one valid PlanProposal object",
                    )
                decision = orchestrator.decide(self._graph, proposal)
                await self._emit(
                    EventType.ORCHESTRATOR_DECIDED,
                    decision.model_dump(mode="json", by_alias=True),
                    policy.planner_agent_id,
                    None,
                )
                if not decision.accepted:
                    raise OrchestrationError(
                        "PLAN_PROPOSAL_REJECTED",
                        "; ".join(decision.rejections),
                        details={"proposalId": proposal.proposal_id},
                    )
                await self.apply_decision(decision)
                proposal_applied = True

            pending_units = self._pending_units(self._graph)
            if not pending_units:
                break
            completed = set(outputs)
            ready = [unit for unit in pending_units if self._unit_dependencies(self._graph, unit).issubset(completed)]
            if not ready:
                raise OrchestrationError(
                    "AGENT_GRAPH_DEADLOCK",
                    "Runtime graph has no schedulable ready-set",
                    details={"pending": pending_units, "completed": sorted(completed)},
                )

            outcomes = await self._execute_ready_set(self._graph, ready, outputs)
            first_error = next((outcome.error for outcome in outcomes if outcome.error is not None), None)
            group_ids = {group.group_id for group in self._graph.parallel_groups}
            for outcome in outcomes:
                outputs.update(outcome.outputs)
                # Empty output still completes a joined group dependency.
                if outcome.error is None and outcome.key in group_ids:
                    outputs[outcome.key] = outcome.group_output
            if first_error is not None:
                raise first_error

        return self._terminal_output(self._graph, outputs)

    async def apply_decision(self, decision: OrchestratorDecision) -> None:
        """Atomically apply the sole authorized dynamic graph protocol."""

        if not isinstance(decision, OrchestratorDecision):
            raise OrchestrationError(
                "ORCHESTRATOR_DECISION_REQUIRED",
                "AgentScheduler accepts only a validated OrchestratorDecision",
            )
        try:
            decision = OrchestratorDecision.model_validate(
                decision.model_dump(mode="json", by_alias=True)
            )
        except ValidationError as exc:
            raise OrchestrationError(
                "ORCHESTRATOR_DECISION_TAMPERED",
                f"OrchestratorDecision failed integrity validation: {exc}",
            ) from exc
        if not decision.accepted or decision.graph_patch is None:
            raise OrchestrationError(
                "ORCHESTRATOR_DECISION_REJECTED",
                "AgentScheduler can apply only an accepted OrchestratorDecision",
            )
        async with self._state_lock:
            if self._graph is None:
                raise OrchestrationError(
                    "RUNTIME_GRAPH_NOT_INITIALIZED",
                    "AgentScheduler must initialize its graph before applying a decision",
                )
            if decision.base_graph_digest.lower() != graph_digest(self._graph):
                raise OrchestrationError(
                    "ORCHESTRATOR_DECISION_STALE",
                    "OrchestratorDecision does not target the current Runtime Graph",
                )
            new_graph = decision.graph_patch.apply_to(self._graph)
            for agent in decision.graph_patch.agents:
                if agent.agent_id in self._nodes:
                    raise OrchestrationError(
                        "ORCHESTRATOR_DECISION_CONFLICT",
                        f"OrchestratorDecision repeats agent {agent.agent_id}",
                    )
            for group in decision.graph_patch.parallel_groups:
                if group.group_id in self._groups:
                    raise OrchestrationError(
                        "ORCHESTRATOR_DECISION_CONFLICT",
                        f"OrchestratorDecision repeats parallel group {group.group_id}",
                    )
            self._graph = new_graph
            self._decisions.append(decision)
            for agent in decision.graph_patch.agents:
                self._dynamic_ids.add(agent.agent_id)
                self._nodes[agent.agent_id] = AgentNodeSnapshot(agent_id=agent.agent_id, dynamic=True)
            for group in decision.graph_patch.parallel_groups:
                self._groups[group.group_id] = ParallelGroupSnapshot(group_id=group.group_id)
            await self._snapshot_locked()

    def _restore(self, graph: AgentGraph, resume: RuntimeGraphSnapshot | None) -> None:
        if resume is None:
            self._graph = graph
            self._nodes = {agent.agent_id: AgentNodeSnapshot(agent_id=agent.agent_id) for agent in graph.agents}
            self._groups = {
                group.group_id: ParallelGroupSnapshot(group_id=group.group_id) for group in graph.parallel_groups
            }
            self._decisions = []
            self._dynamic_ids = set()
            return
        try:
            resume = RuntimeGraphSnapshot.model_validate(
                resume.model_dump(mode="json", by_alias=True)
            )
        except ValidationError as exc:
            raise OrchestrationError(
                "RUNTIME_GRAPH_SNAPSHOT_TAMPERED",
                f"RuntimeGraphSnapshot failed integrity validation: {exc}",
            ) from exc
        if resume.run_id != self._run_id:
            raise OrchestrationError(
                "RUNTIME_GRAPH_RUN_MISMATCH",
                f"Runtime graph belongs to {resume.run_id}, not {self._run_id}",
            )
        expected_base_digest = (
            resume.decisions[0].base_graph_digest if resume.decisions else resume.graph_digest
        )
        if graph_digest(graph) != expected_base_digest.lower():
            raise OrchestrationError(
                "RUNTIME_GRAPH_DEFINITION_MISMATCH",
                "Recovered Runtime Graph does not originate from the configured static graph",
            )
        self._graph = resume.graph
        self._revision = resume.revision
        self._decisions = list(resume.decisions)
        self._dynamic_ids = set()
        self._nodes = {}
        for node in resume.agents:
            status = node.status
            attempt = node.attempt
            if status == AgentNodeStatus.RUNNING:
                status = AgentNodeStatus.PENDING
                # A process/lease interruption is not an exhausted agent
                # attempt.  Retaining the RUNNING attempt made max_attempts=1
                # nodes resume with an empty retry range.
                attempt = max(0, attempt - 1)
            self._nodes[node.agent_id] = node.model_copy(update={"status": status, "attempt": attempt})
            if node.dynamic:
                self._dynamic_ids.add(node.agent_id)
        self._groups = {}
        for group in resume.groups:
            status = GroupStatus.PENDING if group.status == GroupStatus.RUNNING else group.status
            self._groups[group.group_id] = group.model_copy(update={"status": status})
        for group in self._graph.parallel_groups:
            if self._groups[group.group_id].status != GroupStatus.PENDING:
                continue
            if group.join.mode not in {JoinMode.ANY, JoinMode.FIRST_SUCCESS, JoinMode.QUORUM}:
                continue
            completed = [self._nodes[key] for key in group.agent_ids if self._nodes[key].status in {
                AgentNodeStatus.SUCCEEDED, AgentNodeStatus.FAILED, AgentNodeStatus.CANCELLED,
            }]
            if len(completed) > 1 and any(node.completion_sequence is None for node in completed):
                raise OrchestrationError(
                    "PARALLEL_GROUP_COMPLETION_ORDER_UNAVAILABLE",
                    f"Cannot recover completion order for group {group.group_id}; "
                    "the canonical event history is required",
                )

    def _restored_failure(self) -> OrchestrationError | None:
        """Surface a durable terminal unit instead of silently completing on recovery."""

        assert self._graph is not None
        membership = {agent_id: group.group_id for group in self._graph.parallel_groups for agent_id in group.agent_ids}
        failed_groups = sorted(
            group_id for group_id, snapshot in self._groups.items() if snapshot.status == GroupStatus.FAILED
        )
        cancelled_groups = sorted(
            group_id for group_id, snapshot in self._groups.items() if snapshot.status == GroupStatus.CANCELLED
        )
        failed_agents: list[str] = []
        for agent_id, snapshot in self._nodes.items():
            if snapshot.status != AgentNodeStatus.FAILED:
                continue
            group_id = membership.get(agent_id)
            if group_id is None or self._groups[group_id].status not in {
                GroupStatus.PENDING,
                GroupStatus.JOINED,
            }:
                failed_agents.append(agent_id)
        failed_agents.sort()
        cancelled_agents = sorted(
            agent_id
            for agent_id, snapshot in self._nodes.items()
            if snapshot.status == AgentNodeStatus.CANCELLED and agent_id not in membership
        )
        if not failed_groups and not cancelled_groups and not failed_agents and not cancelled_agents:
            return None
        return OrchestrationError(
            "RUNTIME_GRAPH_TERMINAL_UNIT",
            "Recovered runtime graph contains a terminal failed or cancelled unit",
            details={
                "failedGroups": failed_groups,
                "cancelledGroups": cancelled_groups,
                "failedAgents": failed_agents,
                "cancelledAgents": cancelled_agents,
            },
        )

    def _pending_units(self, graph: AgentGraph) -> list[str]:
        membership = {agent_id: group.group_id for group in graph.parallel_groups for agent_id in group.agent_ids}
        units = [
            agent.agent_id
            for agent in graph.agents
            if agent.agent_id not in membership and self._nodes[agent.agent_id].status == AgentNodeStatus.PENDING
        ]
        units.extend(
            group.group_id
            for group in graph.parallel_groups
            if self._groups[group.group_id].status == GroupStatus.PENDING
        )
        return units

    def _unit_dependencies(self, graph: AgentGraph, unit: str) -> set[str]:
        groups = {group.group_id: group for group in graph.parallel_groups}
        agents = {agent.agent_id: agent for agent in graph.agents}
        if unit in groups:
            dependencies: set[str] = set()
            for agent_id in groups[unit].agent_ids:
                if self._nodes[agent_id].status == AgentNodeStatus.PENDING:
                    dependencies.update(agents[agent_id].depends_on)
            return dependencies
        return set(agents[unit].depends_on)

    async def _execute_ready_set(
        self,
        graph: AgentGraph,
        ready: list[str],
        outputs: dict[str, tuple[ContentBlock, ...]],
    ) -> list[_UnitOutcome]:
        queue: asyncio.Queue[_UnitOutcome] = asyncio.Queue()
        tasks: list[asyncio.Task[None]] = []
        limiter = asyncio.Semaphore(graph.max_concurrency)
        groups = {group.group_id: group for group in graph.parallel_groups}
        agents = {agent.agent_id: agent for agent in graph.agents}

        async def execute_unit(key: str) -> None:
            try:
                if key in groups:
                    result = await self._run_group(groups[key], agents, outputs, limiter)
                else:
                    outcome = await self._run_agent(agents[key], outputs, limiter)
                    result = _UnitOutcome(
                        key=key,
                        outputs={key: outcome.output} if outcome.error is None else {},
                        error=outcome.error,
                    )
            except asyncio.CancelledError:
                task = asyncio.current_task()
                if task is not None and task.cancelling():
                    raise
                result = _UnitOutcome(
                    key=key,
                    outputs={},
                    error=OrchestrationError(
                        "AGENT_TASK_CANCELLED_UNEXPECTEDLY",
                        f"Scheduler unit cancelled itself: {key}",
                    ),
                )
            except BaseException as exc:
                result = _UnitOutcome(key=key, outputs={}, error=exc)
            await queue.put(result)

        outcomes: list[_UnitOutcome] = []
        async with asyncio.TaskGroup() as task_group:
            for key in ready:
                tasks.append(task_group.create_task(execute_unit(key), name=f"scheduler:{self._run_id}:{key}"))
            for _ in ready:
                result = await queue.get()
                outcomes.append(result)
                if result.error is not None:
                    for task in tasks:
                        if not task.done():
                            task.cancel()
                    break
        return outcomes

    async def _run_agent(
        self,
        agent: WorkflowAgent,
        outputs: Mapping[str, tuple[ContentBlock, ...]],
        limiter: asyncio.Semaphore,
        group_id: str | None = None,
    ) -> _AgentOutcome:
        node = self._nodes[agent.agent_id]
        start_attempt = node.attempt + 1
        for attempt in range(start_attempt, agent.max_attempts + 1):
            await self._set_node(agent.agent_id, status=AgentNodeStatus.RUNNING, attempt=attempt)
            await self._emit(
                EventType.AGENT_SCHEDULED,
                {
                    "attempt": attempt,
                    "maxAttempts": agent.max_attempts,
                    "workspaceView": agent.workspace_access.value,
                    "dynamic": agent.agent_id in self._dynamic_ids,
                },
                agent.agent_id,
                None,
            )
            view = WorkspaceView(
                agent_id=agent.agent_id,
                access=agent.workspace_access,
                workspace=self._workspace,
                isolation_key=(
                    f"overlay:{agent.agent_id}" if agent.workspace_access == WorkspaceAccess.OVERLAY else None
                ),
                parallel_group_id=group_id,
            )
            try:
                async with limiter:
                    async with self._workspace_guard.hold(agent.workspace_access):
                        if agent.timeout_seconds is None:
                            result = await self._execute_agent(agent, outputs, view)
                        else:
                            async with asyncio.timeout(agent.timeout_seconds):
                                result = await self._execute_agent(agent, outputs, view)
            except asyncio.CancelledError:
                task = asyncio.current_task()
                if task is None or not task.cancelling():
                    error = OrchestrationError(
                        "AGENT_TASK_CANCELLED_UNEXPECTEDLY",
                        f"Agent cancelled its own scheduler task: {agent.agent_id}",
                    )
                    await self._set_node(
                        agent.agent_id,
                        status=AgentNodeStatus.FAILED,
                        error=error.info,
                    )
                    return _AgentOutcome(agent_id=agent.agent_id, error=error)
                # Process shutdown and lease loss use task cancellation as an
                # infrastructure control signal.  Do not persist it as a
                # business cancellation; a RUNNING snapshot is intentionally
                # recoverable after owner takeover.
                if not self._interruption_is_recoverable():
                    await self._set_node(agent.agent_id, status=AgentNodeStatus.CANCELLED)
                raise
            except BaseException as exc:
                error = _error_info(exc, code="AGENT_SCHEDULE_FAILED")
                if attempt < agent.max_attempts:
                    await self._set_node(agent.agent_id, status=AgentNodeStatus.PENDING, error=error)
                    await self._emit(
                        EventType.AGENT_RETRY_SCHEDULED,
                        {
                            "attempt": attempt,
                            "nextAttempt": attempt + 1,
                            "backoffSeconds": agent.retry_backoff_seconds,
                            "error": error.model_dump(mode="json", by_alias=True),
                        },
                        agent.agent_id,
                        None,
                    )
                    if agent.retry_backoff_seconds:
                        await asyncio.sleep(agent.retry_backoff_seconds)
                    continue
                await self._set_node(agent.agent_id, status=AgentNodeStatus.FAILED, error=error)
                return _AgentOutcome(agent_id=agent.agent_id, error=exc)
            await self._set_node(
                agent.agent_id,
                status=AgentNodeStatus.SUCCEEDED,
                output=result,
                error=None,
            )
            return _AgentOutcome(agent_id=agent.agent_id, output=result)
        raise AssertionError("agent retry loop exhausted without an outcome")

    async def _run_group(
        self,
        group: ParallelGroup,
        agents: Mapping[str, WorkflowAgent],
        outputs: Mapping[str, tuple[ContentBlock, ...]],
        limiter: asyncio.Semaphore,
    ) -> _UnitOutcome:
        try:
            return await self._run_group_inner(group, agents, outputs, limiter)
        except asyncio.CancelledError:
            if self._interruption_is_recoverable():
                raise
            cancelled = tuple(
                agent_id for agent_id in group.agent_ids if self._nodes[agent_id].status == AgentNodeStatus.CANCELLED
            )
            await self._set_group(
                group.group_id,
                status=GroupStatus.CANCELLED,
                cancelled=cancelled,
            )
            await self._emit(
                EventType.PARALLEL_GROUP_CANCELLED,
                {"groupId": group.group_id, "cancelled": list(cancelled)},
                None,
                None,
            )
            raise

    async def _run_group_inner(
        self,
        group: ParallelGroup,
        agents: Mapping[str, WorkflowAgent],
        outputs: Mapping[str, tuple[ContentBlock, ...]],
        limiter: asyncio.Semaphore,
    ) -> _UnitOutcome:
        await self._set_group(group.group_id, status=GroupStatus.RUNNING)
        await self._emit(
            EventType.PARALLEL_GROUP_STARTED,
            {
                "groupId": group.group_id,
                "agentIds": list(group.agent_ids),
                "join": group.join.model_dump(mode="json", by_alias=True),
            },
            None,
            None,
        )
        pending_ids = [
            agent_id for agent_id in group.agent_ids if self._nodes[agent_id].status == AgentNodeStatus.PENDING
        ]
        completed_nodes = sorted(
            (self._nodes[key] for key in group.agent_ids if self._nodes[key].status in {
                AgentNodeStatus.SUCCEEDED, AgentNodeStatus.FAILED, AgentNodeStatus.CANCELLED,
            }),
            key=lambda node: node.completion_sequence if node.completion_sequence is not None else -1,
        )
        outcomes = [
            _AgentOutcome(
                agent_id=node.agent_id,
                output=node.output,
                error=(OrchestrationError(
                    "AGENT_PREVIOUSLY_FAILED",
                    f"Agent {node.agent_id} exhausted its attempts before scheduler recovery",
                ) if node.status == AgentNodeStatus.FAILED else None),
                cancelled=node.status == AgentNodeStatus.CANCELLED,
            )
            for node in completed_nodes
        ]
        queue: asyncio.Queue[_AgentOutcome] = asyncio.Queue()
        tasks: dict[str, asyncio.Task[None]] = {}

        async def execute_member(agent_id: str) -> None:
            try:
                outcome = await self._run_agent(
                    agents[agent_id],
                    outputs,
                    limiter,
                    group_id=group.group_id,
                )
            except asyncio.CancelledError:
                task = asyncio.current_task()
                if task is not None and task.cancelling():
                    raise
                outcome = _AgentOutcome(
                    agent_id=agent_id,
                    error=OrchestrationError(
                        "AGENT_TASK_CANCELLED_UNEXPECTEDLY",
                        f"Parallel agent cancelled itself: {agent_id}",
                    ),
                )
            except BaseException as exc:
                outcome = _AgentOutcome(agent_id=agent_id, error=exc)
            await queue.put(outcome)

        timed_out = False
        stopped_early = self._join_satisfied(group.join, outcomes, len(group.agent_ids)) or (
            self._fail_fast(group.join) and any(outcome.error is not None for outcome in outcomes)
        )
        if stopped_early and group.join.cancel == CancelPolicy.CANCEL_REMAINING:
            for agent_id in pending_ids:
                await self._set_node(agent_id, status=AgentNodeStatus.CANCELLED)
            pending_ids = []
        async with asyncio.TaskGroup() as task_group:
            for agent_id in pending_ids:
                tasks[agent_id] = task_group.create_task(
                    execute_member(agent_id),
                    name=f"scheduler:{self._run_id}:{group.group_id}:{agent_id}",
                )
            try:
                if group.join.timeout_seconds is None:
                    stopped_early = (
                        await self._collect_until_join(group, outcomes, queue, len(pending_ids)) or stopped_early
                    )
                else:
                    async with asyncio.timeout(group.join.timeout_seconds):
                        stopped_early = (
                            await self._collect_until_join(group, outcomes, queue, len(pending_ids)) or stopped_early
                        )
            except TimeoutError:
                timed_out = True
            finally:
                should_cancel = (timed_out or stopped_early) and group.join.cancel == CancelPolicy.CANCEL_REMAINING
                if should_cancel:
                    for task in tasks.values():
                        if not task.done():
                            task.cancel()

        succeeded = [outcome for outcome in outcomes if outcome.error is None and not outcome.cancelled]
        failed = [outcome for outcome in outcomes if outcome.error is not None]
        cancelled = [
            agent_id for agent_id in group.agent_ids if self._nodes[agent_id].status == AgentNodeStatus.CANCELLED
        ]
        if timed_out and not (
            group.join.timeout.value == "partial"
            and self._join_satisfied(group.join, outcomes, len(group.agent_ids), allow_partial=True)
        ):
            error = OrchestrationError(
                "PARALLEL_GROUP_TIMEOUT",
                f"Parallel group timed out: {group.group_id}",
            )
            await self._fail_group(group, succeeded, failed, cancelled, error)
            return _UnitOutcome(key=group.group_id, outputs={}, error=error)

        failure = self._group_failure(
            group.join,
            outcomes,
            len(group.agent_ids),
            allow_partial=(timed_out and group.join.timeout == TimeoutPolicy.PARTIAL),
        )
        if failure is not None:
            error = OrchestrationError(
                "PARALLEL_GROUP_FAILED",
                f"Parallel group {group.group_id} failed: {failure}",
            )
            await self._fail_group(group, succeeded, failed, cancelled, error)
            return _UnitOutcome(key=group.group_id, outputs={}, error=error)

        selected = self._selected_successes(group.join, succeeded)
        selected_outputs = {item.agent_id: item.output for item in selected}
        try:
            if group.join.mode == JoinMode.REDUCE:
                group_output = await self._reduce_group(group, selected_outputs)
            elif group.join.mode in {JoinMode.ANY, JoinMode.FIRST_SUCCESS} and selected:
                group_output = selected[0].output
            else:
                group_output = await self._default_reduce(group, selected_outputs)
        except asyncio.CancelledError:
            # The group wrapper distinguishes business cancellation from an
            # infrastructure interruption. Do not turn either into a reducer failure.
            raise
        except BaseException as exc:
            await self._fail_group(group, succeeded, failed, cancelled, exc)
            return _UnitOutcome(key=group.group_id, outputs={}, error=exc)
        await self._set_group(
            group.group_id,
            status=GroupStatus.JOINED,
            succeeded=tuple(item.agent_id for item in succeeded),
            failed=tuple(item.agent_id for item in failed),
            cancelled=tuple(cancelled),
            output=group_output,
        )
        await self._emit(
            EventType.PARALLEL_GROUP_JOINED,
            {
                "groupId": group.group_id,
                "mode": group.join.mode.value,
                "succeeded": [item.agent_id for item in succeeded],
                "failed": [item.agent_id for item in failed],
                "cancelled": cancelled,
                "timedOut": timed_out,
            },
            None,
            None,
        )
        return _UnitOutcome(
            key=group.group_id,
            outputs={item.agent_id: item.output for item in succeeded},
            group_output=group_output,
        )

    async def _collect_until_join(
        self,
        group: ParallelGroup,
        outcomes: list[_AgentOutcome],
        queue: asyncio.Queue[_AgentOutcome],
        remaining: int,
    ) -> bool:
        while remaining:
            outcome = await queue.get()
            outcomes.append(outcome)
            remaining -= 1
            if (
                outcome.error is not None
                and self._fail_fast(group.join)
                and group.join.cancel == CancelPolicy.CANCEL_REMAINING
            ):
                return True
            if self._join_satisfied(group.join, outcomes, len(group.agent_ids)):
                if group.join.cancel == CancelPolicy.CANCEL_REMAINING:
                    return True
        return False

    @staticmethod
    def _fail_fast(policy: JoinPolicy) -> bool:
        return policy.failure == FailurePolicy.FAIL_FAST and policy.mode != JoinMode.FIRST_SUCCESS

    @staticmethod
    def _join_satisfied(
        policy: JoinPolicy,
        outcomes: list[_AgentOutcome],
        total: int,
        *,
        allow_partial: bool = False,
    ) -> bool:
        successes = sum(item.error is None and not item.cancelled for item in outcomes)
        completed = len(outcomes)
        if policy.mode == JoinMode.ANY:
            return completed >= 1
        if policy.mode == JoinMode.FIRST_SUCCESS:
            return successes >= 1 or completed >= total
        if policy.mode == JoinMode.QUORUM:
            assert policy.quorum is not None
            return successes >= policy.quorum or completed >= total
        if allow_partial:
            return successes > 0
        return completed >= total

    @staticmethod
    def _group_failure(
        policy: JoinPolicy,
        outcomes: list[_AgentOutcome],
        total: int,
        *,
        allow_partial: bool = False,
    ) -> str | None:
        failures = [item for item in outcomes if item.error is not None]
        successes = [item for item in outcomes if item.error is None and not item.cancelled]
        cancellations = [item for item in outcomes if item.cancelled]
        if allow_partial and successes:
            return None
        if policy.mode == JoinMode.ANY:
            first = outcomes[0] if outcomes else None
            if first is not None and first.error is not None:
                return str(first.error)
            return "first branch was cancelled" if first is not None and first.cancelled else None
        if policy.mode == JoinMode.FIRST_SUCCESS:
            return None if successes else "no branch succeeded"
        if policy.mode == JoinMode.QUORUM:
            assert policy.quorum is not None
            return None if len(successes) >= policy.quorum else "quorum was not reached"
        if failures and policy.failure != FailurePolicy.CONTINUE:
            return f"{len(failures)} branch(es) failed"
        if cancellations and policy.failure != FailurePolicy.CONTINUE:
            return f"{len(cancellations)} branch(es) were cancelled"
        if not successes and total:
            return "no branch succeeded"
        return None

    @staticmethod
    def _selected_successes(policy: JoinPolicy, succeeded: list[_AgentOutcome]) -> list[_AgentOutcome]:
        if policy.mode in {JoinMode.ANY, JoinMode.FIRST_SUCCESS}:
            return succeeded[:1]
        if policy.mode == JoinMode.QUORUM:
            assert policy.quorum is not None
            return succeeded[: policy.quorum]
        return succeeded

    async def _fail_group(
        self,
        group: ParallelGroup,
        succeeded: list[_AgentOutcome],
        failed: list[_AgentOutcome],
        cancelled: list[str],
        error: BaseException,
    ) -> None:
        await self._set_group(
            group.group_id,
            status=GroupStatus.FAILED,
            succeeded=tuple(item.agent_id for item in succeeded),
            failed=tuple(item.agent_id for item in failed),
            cancelled=tuple(cancelled),
        )
        await self._emit(
            EventType.PARALLEL_GROUP_FAILED,
            {
                "groupId": group.group_id,
                "succeeded": [item.agent_id for item in succeeded],
                "failed": [item.agent_id for item in failed],
                "cancelled": cancelled,
                "error": str(error),
            },
            None,
            None,
        )

    async def _set_node(
        self,
        agent_id: str,
        *,
        status: AgentNodeStatus,
        attempt: int | None = None,
        output: tuple[ContentBlock, ...] | None = None,
        error: ErrorInfo | None | object = ...,  # ``...`` means retain the previous value.
    ) -> None:
        async with self._state_lock:
            current = self._nodes[agent_id]
            changes: dict[str, object] = {"status": status}
            changes["completion_sequence"] = (
                self._revision + 1
                if status in {AgentNodeStatus.SUCCEEDED, AgentNodeStatus.FAILED, AgentNodeStatus.CANCELLED}
                else None
            )
            if attempt is not None:
                changes["attempt"] = attempt
            if output is not None:
                changes["output"] = output
            if error is not ...:
                changes["error"] = error
            self._nodes[agent_id] = current.model_copy(update=changes)
            await self._snapshot_locked()

    async def _set_group(self, group_id: str, **changes: object) -> None:
        async with self._state_lock:
            current = self._groups[group_id]
            self._groups[group_id] = current.model_copy(update=changes)
            await self._snapshot_locked()

    async def _snapshot(self) -> None:
        async with self._state_lock:
            await self._snapshot_locked()

    async def checkpoint_for_recovery(self) -> None:
        """Normalize externally interrupted work to a resumable graph snapshot.

        asyncio cancellation is also used for process shutdown and lease loss.
        The scheduler records cancellation eagerly so join policies remain
        deterministic, but those infrastructure interruptions must not become
        durable terminal node states.  Completed work is retained; only active
        units are rewound, without charging an attempt.
        """

        async with self._state_lock:
            recoverable_groups = {
                group_id
                for group_id, group in self._groups.items()
                if group.status in {GroupStatus.RUNNING, GroupStatus.CANCELLED}
            }
            for group_id in recoverable_groups:
                self._groups[group_id] = self._groups[group_id].model_copy(
                    update={
                        "status": GroupStatus.PENDING,
                        "succeeded": (),
                        "failed": (),
                        "cancelled": (),
                        "output": (),
                    }
                )

            membership = (
                {agent_id: group.group_id for group in self._graph.parallel_groups for agent_id in group.agent_ids}
                if self._graph is not None
                else {}
            )
            for agent_id, node in tuple(self._nodes.items()):
                group_id = membership.get(agent_id)
                recoverable = node.status == AgentNodeStatus.RUNNING or (
                    node.status == AgentNodeStatus.CANCELLED and (group_id is None or group_id in recoverable_groups)
                )
                if not recoverable:
                    continue
                self._nodes[agent_id] = node.model_copy(
                    update={
                        "status": AgentNodeStatus.PENDING,
                        "attempt": max(0, node.attempt - 1),
                        "error": None,
                        "completion_sequence": None,
                    }
                )
            await self._snapshot_locked()

    async def _snapshot_locked(self) -> None:
        assert self._graph is not None
        self._revision += 1
        snapshot = RuntimeGraphSnapshot.create(
            run_id=self._run_id,
            revision=self._revision,
            graph=self._graph,
            agents=tuple(self._nodes[key] for key in sorted(self._nodes)),
            groups=tuple(self._groups[key] for key in sorted(self._groups)),
            decisions=tuple(self._decisions),
        )
        await self._emit(
            EventType.RUNTIME_GRAPH_SNAPSHOTTED,
            snapshot.model_dump(mode="json", by_alias=True),
            None,
            None,
        )

    @staticmethod
    async def _default_reduce(
        group: ParallelGroup,
        outputs: Mapping[str, tuple[ContentBlock, ...]],
    ) -> tuple[ContentBlock, ...]:
        result: list[ContentBlock] = []
        for agent_id in group.agent_ids:
            content = outputs.get(agent_id)
            if content is None:
                continue
            if len(outputs) > 1:
                result.append(TextBlock(text=f"Output from {agent_id}:"))
            result.extend(content)
        return tuple(result)

    @staticmethod
    def _terminal_output(
        graph: AgentGraph,
        outputs: Mapping[str, tuple[ContentBlock, ...]],
    ) -> tuple[ContentBlock, ...]:
        dependencies = {dependency for agent in graph.agents for dependency in agent.depends_on}
        dependencies.update(agent_id for group in graph.parallel_groups for agent_id in group.agent_ids)
        terminal = [
            key
            for key in [
                *(agent.agent_id for agent in graph.agents),
                *(group.group_id for group in graph.parallel_groups),
            ]
            if key not in dependencies and key in outputs
        ]
        result: list[ContentBlock] = []
        for key in terminal:
            if len(terminal) > 1:
                result.append(TextBlock(text=f"Output from {key}:"))
            result.extend(outputs[key])
        return tuple(result)


class _WorkspaceGuard:
    """Fair Run-local reader/writer guard; overlays never share writes."""

    def __init__(self) -> None:
        self._condition = asyncio.Condition()
        self._readers = 0
        self._writer = False
        self._waiting_writers = 0

    def hold(self, access: WorkspaceAccess) -> _WorkspaceGuardContext:
        return _WorkspaceGuardContext(self, access)

    async def acquire(self, access: WorkspaceAccess) -> None:
        if access == WorkspaceAccess.OVERLAY:
            return
        async with self._condition:
            if access == WorkspaceAccess.READ:
                await self._condition.wait_for(lambda: not self._writer and self._waiting_writers == 0)
                self._readers += 1
                return
            self._waiting_writers += 1
            try:
                await self._condition.wait_for(lambda: not self._writer and self._readers == 0)
                self._writer = True
            finally:
                self._waiting_writers -= 1
                self._condition.notify_all()

    async def release(self, access: WorkspaceAccess) -> None:
        if access == WorkspaceAccess.OVERLAY:
            return
        async with self._condition:
            if access == WorkspaceAccess.READ:
                self._readers -= 1
            else:
                self._writer = False
            self._condition.notify_all()


class _WorkspaceGuardContext:
    def __init__(self, guard: _WorkspaceGuard, access: WorkspaceAccess) -> None:
        self._guard = guard
        self._access = access

    async def __aenter__(self) -> None:
        await self._guard.acquire(self._access)

    async def __aexit__(self, _exc_type: object, _exc: object, _tb: object) -> None:
        await self._guard.release(self._access)


def extract_plan_proposal(content: tuple[ContentBlock, ...]) -> PlanProposal | None:
    """Decode one proposal while preserving the untrusted-planner boundary.

    Structured runtimes can return a canonical ``JsonBlock``. Text-only
    runtimes such as DSH and CLI adapters may instead return one bare JSON
    object. Text decoding is deliberately strict: reasoning may accompany
    exactly one text block, but prose, Markdown fences, multiple candidates and
    other content types are rejected. The decoded value still passes through
    the same ``PlanProposal`` validation and owner-controlled authorization.
    """

    for block in reversed(content):
        if not isinstance(block, JsonBlock) or not isinstance(block.value, dict):
            continue
        proposal = _validate_plan_proposal_object(block.value)
        if proposal is not None:
            return proposal

    text_blocks = tuple(block for block in content if isinstance(block, TextBlock))
    if len(text_blocks) != 1 or any(
        not isinstance(block, (TextBlock, ReasoningBlock)) for block in content
    ):
        return None
    try:
        raw = json.loads(text_blocks[0].text)
    except (json.JSONDecodeError, TypeError):
        return None
    return _validate_plan_proposal_object(raw)


def _validate_plan_proposal_object(raw: object) -> PlanProposal | None:
    if not isinstance(raw, dict):
        return None
    candidate = raw.get("planProposal", raw)
    if not isinstance(candidate, dict):
        return None
    try:
        return PlanProposal.model_validate(candidate)
    except ValidationError:
        return None


def restore_runtime_graph(events: tuple[object, ...]) -> RuntimeGraphSnapshot | None:
    """Return the newest valid graph snapshot from a canonical event stream."""

    for index in range(len(events) - 1, -1, -1):
        event = events[index]
        if getattr(event, "type", None) != EventType.RUNTIME_GRAPH_SNAPSHOTTED:
            continue
        data = getattr(event, "data", None)
        try:
            snapshot = RuntimeGraphSnapshot.model_validate(data)
        except ValidationError:
            continue
        return _restore_legacy_completion_order(snapshot, events[:index + 1])
    return None


def _restore_legacy_completion_order(
    snapshot: RuntimeGraphSnapshot, events: tuple[object, ...],
) -> RuntimeGraphSnapshot:
    """Recover old node completion order only from witnessed durable transitions.

    Legacy snapshots omitted the completion sequence. The event stream contains
    a full snapshot at every node transition; its revision supplies the missing
    order without interpreting model output or guessing from agent IDs. A
    truncated/corrupt history may leave the order unknown, which the scheduler
    rejects for an unresolved order-sensitive join.
    """
    pending_groups = {group.group_id for group in snapshot.groups if group.status in {
        GroupStatus.PENDING, GroupStatus.RUNNING,
    }}
    sensitive_members = {
        agent_id for group in snapshot.graph.parallel_groups
        if group.group_id in pending_groups and group.join.mode in {
            JoinMode.ANY, JoinMode.FIRST_SUCCESS, JoinMode.QUORUM,
        }
        for agent_id in group.agent_ids
    }
    missing = {node.agent_id: node for node in snapshot.agents if (
        node.agent_id in sensitive_members and node.completion_sequence is None
        and node.status in {AgentNodeStatus.SUCCEEDED, AgentNodeStatus.FAILED, AgentNodeStatus.CANCELLED}
    )}
    if not missing:
        return snapshot
    first_terminal: dict[str, int] = {}
    witnessed: set[str] = set()
    previous_revision = snapshot.revision + 1
    for event in reversed(events):
        if getattr(event, "type", None) != EventType.RUNTIME_GRAPH_SNAPSHOTTED:
            continue
        try:
            earlier = RuntimeGraphSnapshot.model_validate(getattr(event, "data", None))
        except ValidationError:
            # A missing transition cannot safely establish which node completed
            # first. Leave missing orders for the scheduler to reject.
            break
        if earlier.run_id != snapshot.run_id or earlier.revision >= previous_revision:
            break
        previous_revision = earlier.revision
        by_id = {node.agent_id: node for node in earlier.agents}
        for agent_id, terminal in missing.items():
            if agent_id in witnessed:
                continue
            prior = by_id.get(agent_id)
            if prior is not None and prior.status == terminal.status and prior.attempt == terminal.attempt:
                first_terminal[agent_id] = earlier.revision
            elif agent_id in first_terminal:
                witnessed.add(agent_id)
        if witnessed == set(missing):
            break
    if witnessed != set(missing) or len(set(first_terminal.values())) != len(first_terminal):
        return snapshot
    agents = tuple(node.model_copy(update={"completion_sequence": first_terminal[node.agent_id]})
                   if node.agent_id in first_terminal else node for node in snapshot.agents)
    return RuntimeGraphSnapshot.create(
        run_id=snapshot.run_id, revision=snapshot.revision, graph=snapshot.graph,
        agents=agents, groups=snapshot.groups, decisions=snapshot.decisions,
    )


def _error_info(exc: BaseException, *, code: str) -> ErrorInfo:
    info = getattr(exc, "info", None)
    if isinstance(info, ErrorInfo):
        return info
    return ErrorInfo(
        code=code,
        category=ErrorCategory.TIMEOUT if isinstance(exc, TimeoutError) else ErrorCategory.INTERNAL,
        message=str(exc) or type(exc).__name__,
        retryable=isinstance(exc, (TimeoutError, ConnectionError)),
    )


def graph_digest(graph: AgentGraph) -> str:
    """Return the canonical SHA-256 identity of one immutable graph."""

    return _digest(graph.model_dump(mode="json", by_alias=True))


def proposal_digest(proposal: PlanProposal) -> str:
    """Return the canonical SHA-256 identity of one Planner proposal."""

    return _digest(proposal.model_dump(mode="json", by_alias=True))


def _apply_patch_payload(
    graph: AgentGraph,
    agents: tuple[AgentSpec, ...],
    parallel_groups: tuple[ParallelGroup, ...],
) -> AgentGraph:
    payload = graph.model_dump(mode="python", by_alias=False)
    policy = graph.dynamic_policy
    payload.update(
        {
            "agents": (*graph.agents, *agents),
            "parallel_groups": (*graph.parallel_groups, *parallel_groups),
            "max_concurrency": min(graph.max_concurrency, policy.max_concurrency)
            if policy is not None
            else graph.max_concurrency,
            # The MVP permits one Planner expansion.  Future multi-wave
            # planning can retain policy plus a durable budget ledger without
            # changing the patch protocol.
            "dynamic_policy": None,
        }
    )
    return AgentGraph.model_validate(payload)


def _json_payload(value: object) -> JsonValue:
    if isinstance(value, ContractModel):
        return value.model_dump(mode="json", by_alias=True)
    if isinstance(value, Mapping):
        return {str(key): _json_payload(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_payload(item) for item in value]
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError(f"value is not canonical JSON: {type(value).__name__}")


def _model_payload_digest(
    model_type: type[ContractModel],
    payload: Mapping[str, object],
    digest_field: str,
) -> str:
    candidate = model_type.model_construct(**payload, **{digest_field: "0" * 64})
    return _digest(
        candidate.model_dump(mode="json", by_alias=True, exclude={digest_field})
    )


def _digest(value: JsonValue) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _trimmed(value: str, name: str) -> str:
    if not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be non-blank and trimmed")
    return value


def _trimmed_or_none(value: str | None, name: str) -> str | None:
    return None if value is None else _trimmed(value, name)


def _unique_trimmed(values: tuple[str, ...], name: str) -> tuple[str, ...]:
    for value in values:
        _trimmed(value, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must not contain duplicates")
    return values


def _finite_number(value: object, name: str) -> object:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    return value


def _finite_number_or_none(value: object, name: str) -> object:
    if value is None:
        return None
    return _finite_number(value, name)
