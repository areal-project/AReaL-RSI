"""ARealAgentRuntime Plugin SPI v1."""

from __future__ import annotations

from enum import StrEnum
from typing import Protocol, TypeVar, runtime_checkable

from pydantic import Field, JsonValue, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.contracts.version import PLUGIN_API_VERSION, PluginApiVersion


class PortKey(StrEnum):
    AGENT_RUNTIME = "areal.agent-runtime.agent-runtime/v1"
    TOOL_PROVIDER = "areal.agent-runtime.tool-provider/v1"
    ENVIRONMENT = "areal.agent-runtime.environment/v1"
    STATE_STORE = "areal.agent-runtime.state-store/v1"
    ASSET_STORE = "areal.agent-runtime.asset-store/v1"
    EVENT_SINK = "areal.agent-runtime.event-sink/v1"
    ARTIFACT_PUBLISHER = "areal.agent-runtime.artifact-publisher/v1"


class PluginEntrypoints(ContractModel):
    local: str | None = Field(default=None, min_length=1)
    remote: str | None = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def validate_entrypoints(self) -> PluginEntrypoints:
        values = (self.local, self.remote)
        if all(value is None for value in values):
            raise ValueError("at least one plugin entrypoint is required")
        if any(
            value is not None and (not value.strip() or value != value.strip())
            for value in values
        ):
            raise ValueError("plugin entrypoints must be non-blank and trimmed")
        return self


class PluginManifest(ContractModel):
    api_version: PluginApiVersion = PLUGIN_API_VERSION
    name: str = Field(min_length=1, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    version: str = Field(min_length=1)
    implements: tuple[PortKey, ...] = Field(
        min_length=1,
        json_schema_extra={"uniqueItems": True},
    )
    entrypoints: PluginEntrypoints
    config_schema: str | None = None
    requires: tuple[str, ...] = Field(default=(), json_schema_extra={"uniqueItems": True})
    permissions: tuple[str, ...] = Field(default=(), json_schema_extra={"uniqueItems": True})
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("version", "config_schema")
    @classmethod
    def validate_optional_text(cls, value: str | None) -> str | None:
        if value is not None and (not value.strip() or value != value.strip()):
            raise ValueError("plugin text fields must be non-blank and trimmed")
        return value

    @model_validator(mode="after")
    def validate_declarations(self) -> PluginManifest:
        if len(self.implements) != len(set(self.implements)):
            raise ValueError("plugin implements must not contain duplicate ports")
        for name, values in (("requires", self.requires), ("permissions", self.permissions)):
            if any(not value.strip() or value != value.strip() for value in values):
                raise ValueError(f"plugin {name} values must be non-blank and trimmed")
            if len(values) != len(set(values)):
                raise ValueError(f"plugin {name} must not contain duplicates")
        if self.name in self.requires:
            raise ValueError("plugin cannot require itself")
        return self


ServiceT = TypeVar("ServiceT")


@runtime_checkable
class PluginContext(Protocol):
    def provide(self, key: PortKey, service: object) -> None: ...

    def require(self, key: PortKey, owner: str | None = None) -> object: ...

    def providers(self, key: PortKey) -> tuple[str, ...]: ...


@runtime_checkable
class Plugin(Protocol):
    manifest: PluginManifest

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None: ...

    async def start(self) -> None: ...

    async def health(self) -> HealthStatus: ...

    async def stop(self) -> None: ...
