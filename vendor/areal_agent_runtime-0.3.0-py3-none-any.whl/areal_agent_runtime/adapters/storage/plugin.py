"""Plugin packaging for the local AssetStore and trajectory EventSink."""

from __future__ import annotations

from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters.storage.assets import FileSystemAssetStore
from areal_agent_runtime.adapters.storage.state import FileSystemStateStore
from areal_agent_runtime.adapters.storage.trajectory import JsonlTrajectorySink
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class LocalStoragePlugin:
    manifest = PluginManifest(
        name="local-storage",
        version="1.0.0",
        implements=(PortKey.STATE_STORE, PortKey.ASSET_STORE, PortKey.EVENT_SINK),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.storage.plugin:create_plugin"),
        config_schema="config.schema.json",
        permissions=("filesystem.read", "filesystem.write"),
    )

    def __init__(self) -> None:
        self.asset_store: FileSystemAssetStore | None = None
        self.state_store: FileSystemStateStore | None = None
        self.trajectory_sink: JsonlTrajectorySink | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        configured_root = config.get("root")
        root = Path(configured_root) if isinstance(configured_root, str) else Path(".areal-agent-runtime")
        self.state_store = FileSystemStateStore(root / "state")
        self.asset_store = FileSystemAssetStore(root / "assets")
        self.trajectory_sink = JsonlTrajectorySink(root / "trajectories", asset_store=self.asset_store)
        context.provide(PortKey.STATE_STORE, self.state_store)
        context.provide(PortKey.ASSET_STORE, self.asset_store)
        context.provide(PortKey.EVENT_SINK, self.trajectory_sink)

    async def start(self) -> None:
        health = await self.health()
        if health.status == "unhealthy":
            raise RuntimeError("Local storage is not writable")

    async def health(self) -> HealthStatus:
        if self.trajectory_sink is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.trajectory_sink.health()

    async def stop(self) -> None:
        return None


def create_plugin() -> LocalStoragePlugin:
    return LocalStoragePlugin()
