"""Vision ToolProvider adapters."""

from areal_agent_runtime.adapters.vision.ocr import (
    BoundingBox,
    OCREngine,
    OCRExtraction,
    OCRSpan,
    OCRToolProvider,
)
from areal_agent_runtime.adapters.vision.plugin import VisionOCRPlugin, create_plugin
from areal_agent_runtime.adapters.vision.tesseract import (
    TesseractOCRConfig,
    TesseractOCREngine,
)
from areal_agent_runtime.adapters.vision.tesseract import (
    create_engine as create_tesseract_engine,
)

__all__ = [
    "BoundingBox",
    "OCREngine",
    "OCRExtraction",
    "OCRSpan",
    "OCRToolProvider",
    "VisionOCRPlugin",
    "TesseractOCRConfig",
    "TesseractOCREngine",
    "create_plugin",
    "create_tesseract_engine",
]
