"""Concrete implementations of ARealAgentRuntime-owned Ports."""
