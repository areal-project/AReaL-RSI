"""Authenticated loopback bridge used by the DSH Cordis tool plugin.

The public boundary remains ``ExecutionChannel``.  This transport is private to
the DSH Adapter and exists only because the official DSH Python SDK does not
currently expose a host-tool-result method.
"""

from __future__ import annotations

import asyncio
import json
import secrets
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Protocol

from areal_agent_runtime.contracts.runtime import ToolExecution, ToolResult, ToolSpec

BRIDGE_PROTOCOL_VERSION = "areal.agent-runtime.dsh-tool-bridge/v1"
_MAX_HEADER_BYTES = 64 * 1024
_MAX_BODY_BYTES = 4 * 1024 * 1024
_REQUEST_TIMEOUT_SECONDS = 10.0


class DSHBridgeExecution(Protocol):
    async def invoke_application_tool(
        self,
        *,
        call_id: str,
        name: str,
        arguments: dict[str, object],
        agent_id: str | None,
    ) -> ToolResult: ...


@dataclass(frozen=True, slots=True)
class DSHBridgeTool:
    canonical_name: str
    runtime_name: str
    description: str
    input_schema: dict[str, object]
    execution: ToolExecution
    terminal_on_success: bool

    def to_wire(self) -> dict[str, object]:
        return {
            "canonicalName": self.canonical_name,
            "runtimeName": self.runtime_name,
            "description": self.description,
            "inputSchema": self.input_schema,
            "execution": self.execution.value,
            "terminalOnSuccess": self.terminal_on_success,
        }


@dataclass(slots=True)
class _SessionRegistration:
    tools: tuple[DSHBridgeTool, ...]
    ready: asyncio.Event
    execution: DSHBridgeExecution | None = None


class DSHApplicationToolBridge:
    """Small HTTP server reachable only by a colocated DSH subprocess."""

    def __init__(self) -> None:
        self._token = secrets.token_urlsafe(32)
        self._server: asyncio.AbstractServer | None = None
        self._endpoint: str | None = None
        self._sessions: dict[str, _SessionRegistration] = {}
        self._lifecycle_lock = asyncio.Lock()
        self._closed = False

    @property
    def token(self) -> str:
        return self._token

    @property
    def endpoint(self) -> str:
        if self._endpoint is None:
            raise RuntimeError("DSH application tool bridge is not started")
        return self._endpoint

    async def start(self) -> None:
        async with self._lifecycle_lock:
            if self._closed:
                raise RuntimeError("DSH application tool bridge is closed")
            if self._server is not None:
                return
            server = await asyncio.start_server(self._handle_client, "127.0.0.1", 0)
            socket = server.sockets[0] if server.sockets else None
            if socket is None:
                server.close()
                await server.wait_closed()
                raise RuntimeError("DSH application tool bridge did not bind a socket")
            port = int(socket.getsockname()[1])
            self._server = server
            self._endpoint = f"http://127.0.0.1:{port}"

    def register_session(self, session_id: str, tools: tuple[ToolSpec, ...]) -> tuple[DSHBridgeTool, ...]:
        _required_string({"sessionId": session_id}, "sessionId")
        if self._closed:
            raise RuntimeError("DSH application tool bridge is closed")
        if not isinstance(tools, tuple) or any(not isinstance(tool, ToolSpec) for tool in tools):
            raise TypeError("DSH bridge tools must be a tuple of ToolSpec values")
        catalog = tuple(
            DSHBridgeTool(
                canonical_name=tool.name,
                runtime_name=_runtime_tool_name(tool.name),
                description=tool.description,
                input_schema=dict(tool.input_schema),
                execution=tool.execution,
                terminal_on_success=tool.terminal_on_success,
            )
            for tool in tools
            if tool.execution in {ToolExecution.APPLICATION, ToolExecution.REMOTE}
        )
        runtime_names = [tool.runtime_name for tool in catalog]
        if len(runtime_names) != len(set(runtime_names)):
            raise ValueError("DSH bridge runtime tool-name mapping is not unique")
        existing = self._sessions.get(session_id)
        if existing is not None:
            if existing.tools != catalog:
                raise ValueError("DSH bridge tool catalog cannot change inside one Runtime session")
            return existing.tools
        self._sessions[session_id] = _SessionRegistration(tools=catalog, ready=asyncio.Event())
        return catalog

    def bind(self, session_id: str, execution: DSHBridgeExecution) -> None:
        registration = self._registration(session_id)
        if registration.execution is not None and registration.execution is not execution:
            raise RuntimeError(f"DSH session already has an active execution: {session_id}")
        registration.execution = execution

    def unbind(self, session_id: str, execution: DSHBridgeExecution) -> None:
        registration = self._sessions.get(session_id)
        if registration is not None and registration.execution is execution:
            registration.execution = None

    async def wait_ready(self, session_id: str, timeout_seconds: float) -> None:
        registration = self._registration(session_id)
        try:
            await asyncio.wait_for(registration.ready.wait(), timeout=timeout_seconds)
        except TimeoutError as exc:
            raise RuntimeError(
                "DSH application tool bridge did not become ready; ensure the selected "
                "DSH profile loads @areal/agent-runtime-dsh/application-tool-bridge"
            ) from exc

    def unregister_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    async def close(self) -> None:
        async with self._lifecycle_lock:
            if self._closed:
                return
            self._closed = True
            server = self._server
            self._server = None
            self._endpoint = None
            self._sessions.clear()
            if server is not None:
                server.close()
                await server.wait_closed()

    def _registration(self, session_id: str) -> _SessionRegistration:
        try:
            return self._sessions[session_id]
        except KeyError as exc:
            raise LookupError(f"Unknown DSH bridge session: {session_id}") from exc

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            async with asyncio.timeout(_REQUEST_TIMEOUT_SECONDS):
                method, path, headers, body = await _read_request(reader)
            if method != "POST":
                await _respond(writer, 405, {"error": "method_not_allowed"})
                return
            supplied = headers.get("authorization", "")
            expected = f"Bearer {self._token}"
            if not secrets.compare_digest(supplied, expected):
                await _respond(writer, 401, {"error": "unauthorized"})
                return
            payload = json.loads(
                body,
                parse_constant=lambda constant: _raise_invalid_json_constant(constant),
                object_pairs_hook=_reject_duplicate_json_keys,
            )
            if not isinstance(payload, dict):
                raise ValueError("request body must be a JSON object")
            if path == "/v1/catalog":
                response = self._catalog(payload)
            elif path == "/v1/ready":
                response = self._ready(payload)
            elif path == "/v1/tool-calls":
                response = await self._tool_call(payload)
            else:
                await _respond(writer, 404, {"error": "not_found"})
                return
            await _respond(writer, 200, response)
        except TimeoutError:
            await _respond(writer, 408, {"error": "request_timeout"})
        except (LookupError, ValueError, json.JSONDecodeError) as exc:
            await _respond(writer, 400, {"error": "invalid_request", "message": str(exc)})
        except Exception as exc:  # fail closed at this private transport boundary
            await _respond(
                writer,
                500,
                {"error": "bridge_failure", "message": str(exc) or type(exc).__name__},
            )
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except (ConnectionError, RuntimeError):
                pass

    def _catalog(self, payload: Mapping[str, object]) -> dict[str, object]:
        session_id = _required_string(payload, "sessionId")
        registration = self._registration(session_id)
        return {
            "protocolVersion": BRIDGE_PROTOCOL_VERSION,
            "tools": [tool.to_wire() for tool in registration.tools],
        }

    def _ready(self, payload: Mapping[str, object]) -> dict[str, object]:
        session_id = _required_string(payload, "sessionId")
        protocol_version = _required_string(payload, "protocolVersion")
        if protocol_version != BRIDGE_PROTOCOL_VERSION:
            raise ValueError(f"unsupported bridge protocol: {protocol_version}")
        registration = self._registration(session_id)
        raw_names = payload.get("runtimeToolNames")
        if not isinstance(raw_names, list) or not all(isinstance(item, str) for item in raw_names):
            raise ValueError("runtimeToolNames must be a string array")
        expected = sorted(tool.runtime_name for tool in registration.tools)
        if sorted(raw_names) != expected:
            raise ValueError("DSH bridge registered a different tool catalog")
        registration.ready.set()
        return {"ok": True}

    async def _tool_call(self, payload: Mapping[str, object]) -> dict[str, object]:
        session_id = _required_string(payload, "sessionId")
        registration = self._registration(session_id)
        execution = registration.execution
        if execution is None:
            raise ValueError(f"DSH session has no active execution: {session_id}")
        call_id = _required_string(payload, "callId")
        canonical_name = _required_string(payload, "canonicalName")
        runtime_name = _required_string(payload, "runtimeName")
        tool = next(
            (
                item
                for item in registration.tools
                if item.canonical_name == canonical_name and item.runtime_name == runtime_name
            ),
            None,
        )
        if tool is None:
            raise ValueError(f"tool is not in the registered DSH bridge catalog: {canonical_name}")
        arguments = payload.get("arguments")
        if not isinstance(arguments, dict) or not all(isinstance(key, str) for key in arguments):
            raise ValueError("arguments must be a JSON object")
        agent_id = payload.get("agentId")
        if agent_id is not None and not isinstance(agent_id, str):
            raise ValueError("agentId must be a string")
        result = await execution.invoke_application_tool(
            call_id=call_id,
            name=canonical_name,
            arguments=dict(arguments),
            agent_id=agent_id,
        )
        return {"result": result.model_dump(mode="json", by_alias=True)}


def _runtime_tool_name(canonical_name: str) -> str:
    """Map namespaced canonical names to conservative provider-safe names."""

    import hashlib
    import re

    readable = re.sub(r"[^A-Za-z0-9_-]+", "_", canonical_name).strip("_-") or "tool"
    digest = hashlib.sha256(canonical_name.encode("utf-8")).hexdigest()[:8]
    prefix = f"ga_{readable}"
    return f"{prefix[:54]}_{digest}"


async def _read_request(
    reader: asyncio.StreamReader,
) -> tuple[str, str, dict[str, str], str]:
    raw_headers = await reader.readuntil(b"\r\n\r\n")
    if len(raw_headers) > _MAX_HEADER_BYTES:
        raise ValueError("request headers are too large")
    lines = raw_headers.decode("iso-8859-1").split("\r\n")
    request_line = lines[0].split(" ")
    if len(request_line) != 3:
        raise ValueError("malformed HTTP request line")
    method, path, http_version = request_line
    if http_version != "HTTP/1.1" or not path.startswith("/") or "#" in path:
        raise ValueError("unsupported HTTP request target or version")
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if not line:
            continue
        key, separator, value = line.partition(":")
        if not separator:
            raise ValueError("malformed HTTP header")
        normalized_key = key.strip().lower()
        if not normalized_key or normalized_key in headers:
            raise ValueError("duplicate or empty HTTP header")
        headers[normalized_key] = value.strip()
    if "transfer-encoding" in headers:
        raise ValueError("Transfer-Encoding is not supported")
    try:
        content_length = int(headers.get("content-length", "0"))
    except ValueError as exc:
        raise ValueError("invalid Content-Length") from exc
    if content_length < 0 or content_length > _MAX_BODY_BYTES:
        raise ValueError("request body is too large")
    body = (await reader.readexactly(content_length)).decode("utf-8")
    return method, path, headers, body


async def _respond(
    writer: asyncio.StreamWriter,
    status: int,
    payload: Mapping[str, object],
) -> None:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(body) > _MAX_BODY_BYTES:
        status = 500
        body = b'{"error":"response_too_large"}'
    reasons = {
        200: "OK",
        400: "Bad Request",
        401: "Unauthorized",
        404: "Not Found",
        405: "Method Not Allowed",
        408: "Request Timeout",
    }
    reason = reasons.get(
        status,
        "Internal Server Error",
    )
    writer.write(
        (
            f"HTTP/1.1 {status} {reason}\r\n"
            "Content-Type: application/json; charset=utf-8\r\n"
            f"Content-Length: {len(body)}\r\n"
            "Connection: close\r\n\r\n"
        ).encode("ascii")
        + body
    )
    await writer.drain()


def _required_string(payload: Mapping[str, object], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value or value != value.strip() or "\x00" in value:
        raise ValueError(f"{key} must be a non-blank, trimmed string")
    return value


def _reject_duplicate_json_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _raise_invalid_json_constant(constant: str) -> None:
    raise ValueError(f"non-finite JSON number: {constant}")
