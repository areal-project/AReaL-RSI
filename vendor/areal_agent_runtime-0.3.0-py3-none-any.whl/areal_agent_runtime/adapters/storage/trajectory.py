"""Canonical JSONL trajectory projection with multimodal asset provenance."""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.kernel.data import (
    CanonicalObservationProjector,
    canonical_asset_ids,
    governance_allows_external,
)

TERMINAL_EVENTS = {
    EventType.RUN_COMPLETED,
    EventType.RUN_FAILED,
    EventType.RUN_CANCELLED,
}


@dataclass(frozen=True, slots=True)
class LiteralSecretRedactor:
    """Small injectable redactor; production Hosts can supply their run secret set."""

    secrets: tuple[str, ...]
    placeholder: str = "[REDACTED]"

    def __call__(self, value: JsonValue) -> JsonValue:
        return self._redact(value)

    def _redact(self, value: JsonValue) -> JsonValue:
        if isinstance(value, str):
            result = value
            for secret in self.secrets:
                if secret:
                    result = result.replace(secret, self.placeholder)
            return result
        if isinstance(value, list):
            return [self._redact(item) for item in value]
        if isinstance(value, dict):
            return {str(self._redact(str(key))): self._redact(item) for key, item in value.items()}
        return value


@dataclass(slots=True)
class _RunState:
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    event_count: int = 0
    asset_ids: set[str] = field(default_factory=set)
    event_ids: set[str] = field(default_factory=set)
    event_sequences: dict[int, str] = field(default_factory=dict)
    observation_ids: set[str] = field(default_factory=set)
    asset_observations: set[tuple[str, str]] = field(default_factory=set)
    initialized: bool = False


class JsonlTrajectorySink:
    """Project the canonical event log; never parse a vendor transcript."""

    def __init__(
        self,
        root: str | Path,
        *,
        asset_store: AssetStorePort | None = None,
        redactor: Callable[[JsonValue], JsonValue] | None = None,
        include_restricted: bool = False,
    ) -> None:
        self._root = Path(root).expanduser().resolve()
        self._asset_store = asset_store
        self._redactor = redactor
        self._include_restricted = include_restricted
        self._projector = CanonicalObservationProjector()
        self._runs: dict[str, _RunState] = {}
        self._root.mkdir(parents=True, exist_ok=True)

    async def consume(self, event: RunEvent) -> None:
        state = self._runs.setdefault(event.run_id, _RunState())
        async with state.lock:
            run_dir = self._root / event.run_id
            assets_dir = run_dir / "assets"
            run_dir.mkdir(parents=True, exist_ok=True)
            assets_dir.mkdir(parents=True, exist_ok=True)
            if not state.initialized:
                await asyncio.to_thread(self._restore_run_state, run_dir, state)
                if not (run_dir / "episode.json").exists():
                    episode: JsonValue = {
                        "schemaVersion": "areal.agent-runtime.trajectory/v1",
                        "runId": event.run_id,
                        "sessionId": event.session_id,
                        "traceId": event.trace_id,
                        "episodeId": event.episode_id,
                        "createdAt": event.time.isoformat(),
                    }
                    await asyncio.to_thread(
                        self._write_json_atomic,
                        run_dir / "episode.json",
                        self._redact(episode),
                    )
                state.initialized = True

            payload = event.model_dump(mode="json", by_alias=True)
            allowed = governance_allows_external(
                event,
                include_restricted=self._include_restricted,
            )
            if not allowed:
                payload["data"] = {
                    "redacted": True,
                    "policyId": event.governance.policy_id,
                }
            existing_event_id = state.event_sequences.get(event.sequence)
            if existing_event_id is not None and existing_event_id != event.event_id:
                raise ValueError(
                    f"trajectory sequence {event.sequence} already belongs to {existing_event_id}, not {event.event_id}"
                )
            if event.event_id not in state.event_ids:
                await asyncio.to_thread(self._append_jsonl, run_dir / "events.jsonl", self._redact(payload))
                state.event_count += 1
                state.event_ids.add(event.event_id)
                state.event_sequences[event.sequence] = event.event_id

            if allowed:
                observation = self._projector.project(event)
                if observation.observation_id not in state.observation_ids:
                    await asyncio.to_thread(
                        self._append_jsonl,
                        run_dir / "observations.jsonl",
                        self._redact(
                            observation.model_dump(mode="json", by_alias=True)
                        ),
                    )
                    state.observation_ids.add(observation.observation_id)

            for asset_id in canonical_asset_ids(event) if allowed else ():
                state.asset_ids.add(asset_id)
                observation_id = (event.event_id, asset_id)
                if observation_id in state.asset_observations:
                    continue
                observation = await self._asset_observation(event, asset_id)
                await asyncio.to_thread(
                    self._append_jsonl,
                    assets_dir / "manifest.jsonl",
                    self._redact(observation),
                )
                state.asset_observations.add(observation_id)

            if event.type in TERMINAL_EVENTS:
                summary: JsonValue = {
                    "schemaVersion": "areal.agent-runtime.trajectory-summary/v1",
                    "runId": event.run_id,
                    "sessionId": event.session_id,
                    "terminalEvent": event.type.value,
                    "lastSequence": event.sequence,
                    "eventCount": state.event_count,
                    "observationCount": len(state.observation_ids),
                    "uniqueAssetCount": len(state.asset_ids),
                    "finishedAt": event.time.isoformat(),
                }
                await asyncio.to_thread(self._write_json_atomic, run_dir / "summary.json", self._redact(summary))

    async def flush(self, run_id: str) -> None:
        state = self._runs.get(run_id)
        if state is not None:
            async with state.lock:
                return None

    async def health(self) -> HealthStatus:
        writable = self._root.exists() and os.access(self._root, os.W_OK)
        return HealthStatus(
            status="healthy" if writable else "unhealthy",
            details={"root": str(self._root), "writable": writable},
        )

    async def _asset_observation(self, event: RunEvent, asset_id: str) -> JsonValue:
        ref = await self._asset_store.get(asset_id) if self._asset_store is not None else None
        data = event.data if isinstance(event.data, dict) else {}
        return {
            "schemaVersion": "areal.agent-runtime.asset-observation/v1",
            "assetId": asset_id,
            "status": "available" if ref is not None else "unresolved",
            "asset": ref.model_dump(mode="json", by_alias=True) if ref is not None else None,
            "provenance": {
                "eventId": event.event_id,
                "sequence": event.sequence,
                "eventType": event.type.value,
                "executionId": event.execution_id,
                "agentAttemptId": event.agent_attempt_id,
                "agentId": event.agent_id,
                "modelCallId": data.get("modelCallId"),
                "toolCallId": data.get("callId"),
                "environmentId": event.environment_id,
                "agentEnvironmentId": event.agent_environment_id,
                "workspaceId": event.workspace_id,
            },
        }

    def _redact(self, value: JsonValue) -> JsonValue:
        return self._redactor(value) if self._redactor is not None else value

    @staticmethod
    def _restore_run_state(run_dir: Path, state: _RunState) -> None:
        events_path = run_dir / "events.jsonl"
        if events_path.exists():
            for line in events_path.read_text(encoding="utf-8").splitlines():
                if not line:
                    continue
                payload = json.loads(line)
                event_id = payload.get("eventId")
                sequence = payload.get("sequence")
                if not isinstance(event_id, str) or not isinstance(sequence, int):
                    raise ValueError(f"corrupt trajectory event: {events_path}")
                existing = state.event_sequences.get(sequence)
                if existing is not None and existing != event_id:
                    raise ValueError(f"duplicate trajectory sequence {sequence}: {events_path}")
                state.event_ids.add(event_id)
                state.event_sequences[sequence] = event_id
            state.event_count = len(state.event_ids)

        manifest_path = run_dir / "assets" / "manifest.jsonl"
        if manifest_path.exists():
            for line in manifest_path.read_text(encoding="utf-8").splitlines():
                if not line:
                    continue
                payload = json.loads(line)
                event_id = payload.get("provenance", {}).get("eventId")
                asset_id = payload.get("assetId")
                if isinstance(event_id, str) and isinstance(asset_id, str):
                    state.asset_ids.add(asset_id)
                    state.asset_observations.add((event_id, asset_id))

        observations_path = run_dir / "observations.jsonl"
        if observations_path.exists():
            for line in observations_path.read_text(encoding="utf-8").splitlines():
                if not line:
                    continue
                payload = json.loads(line)
                observation_id = payload.get("observationId")
                if not isinstance(observation_id, str):
                    raise ValueError(f"corrupt canonical observation: {observations_path}")
                state.observation_ids.add(observation_id)

    @staticmethod
    def _append_jsonl(path: Path, payload: JsonValue) -> None:
        with path.open("a", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

    @staticmethod
    def _write_json_atomic(path: Path, payload: JsonValue) -> None:
        descriptor, temporary_name = tempfile.mkstemp(prefix=f"{path.name}-", dir=path.parent)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, path)
        except BaseException:
            Path(temporary_name).unlink(missing_ok=True)
            raise
