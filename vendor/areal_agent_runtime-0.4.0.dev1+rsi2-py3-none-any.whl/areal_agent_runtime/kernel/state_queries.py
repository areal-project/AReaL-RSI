"""Finite, paged reads with a compatibility fallback for existing v1 stores.

The fallback preserves old adapters, but only the optional paged capability can
bound backend allocation. Never use a live event subscription for a finite query.
"""

from collections.abc import AsyncIterator

from areal_agent_runtime.contracts.events import RunEvent
from areal_agent_runtime.contracts.ports import StateStorePort
from areal_agent_runtime.contracts.product import RunSnapshot


async def iter_run_snapshots(
    state: StateStorePort, *, batch_size: int = 128, after_run_id: str | None = None,
) -> AsyncIterator[RunSnapshot]:
    page_reader = getattr(state, "list_run_snapshots", None)
    if not callable(page_reader):
        for run_id in sorted(await state.list_run_ids()):
            if after_run_id is not None and run_id <= after_run_id:
                continue
            snapshot = await state.get_run(run_id)
            if snapshot is not None:
                yield snapshot
        return
    cursor = after_run_id
    while True:
        page = await page_reader(after_run_id=cursor, limit=batch_size)
        if len(page) > batch_size:
            raise ValueError("StateStore returned more Run snapshots than the page limit")
        for snapshot in page:
            if cursor is not None and snapshot.run_id <= cursor:
                raise ValueError("StateStore Run page must use a strictly increasing exclusive cursor")
            cursor = snapshot.run_id
            yield snapshot
        if not page:
            return


async def iter_events(
    state: StateStorePort, run_id: str, *, after: int = -1, batch_size: int = 128,
) -> AsyncIterator[RunEvent]:
    page_reader = getattr(state, "list_event_page", None)
    if not callable(page_reader):
        for event in await state.list_events(run_id):
            if event.sequence > after:
                yield event
        return
    # A query is a finite view. Later concurrent commits belong to the next
    # query; otherwise a busy Run can keep a history scan alive indefinitely.
    head = await state.latest_event_sequence(run_id)
    cursor = after
    while cursor < head:
        page = await page_reader(run_id, after=cursor, limit=batch_size)
        if len(page) > batch_size:
            raise ValueError("StateStore returned more events than the page limit")
        for event in page:
            if event.run_id != run_id or event.sequence != cursor + 1:
                raise ValueError("StateStore event page must preserve Run identity and contiguous sequence")
            if event.sequence > head:
                return
            cursor = event.sequence
            yield event
        if not page:
            raise ValueError("StateStore event page ended before the committed history head")
