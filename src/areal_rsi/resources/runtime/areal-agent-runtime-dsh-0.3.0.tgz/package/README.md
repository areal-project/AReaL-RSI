# ARealAgentRuntime

ARealAgentRuntime 是一个面向任意 Agent 产品的、Runtime-neutral 的应用运行框架。它负责会话、事件、工具、
工作区、静态/动态 DAG、恢复、统一数据面与 Host 投影；模型供应商、沙箱实现、业务 Profile 和领域工具均通过
Harness Adapter 或插件接入。默认 Core 只提供 `general.*` Profile，不依赖 GameAgent、browser game 或其他业务模块。

当前 MVP 的核心原则是：Planner 只能提案，应用所有者掌握最终执行权限。

```mermaid
flowchart LR
  U["Host / API"] --> A["ARealAgentRuntime"]
  A --> P["Profile + Policy"]
  A --> S["AgentScheduler"]
  S --> R["Runtime Adapter"]
  S --> T["Authorized Tool Catalog"]
  S --> W["Environment / Workspace"]
  R --> C["Codex CLI / DSH / Claude SDK / Hermes / Remote"]
```

## 为什么这样设计

- `PlanProposal` 是模型生成的不可信输入，只包含 `agentProfileId`、依赖、预算和受控 overrides。
- `ApplicationOrchestrator` 从可信 `AgentProfile` Catalog 解析完整 `AgentSpec`，校验 Runtime、Tool、Skill、并发、预算和工作区权限。
- `OrchestratorDecision.graphPatch` 是唯一动态改图协议；不存在第二套命令式调度旁路。
- `AgentScheduler` 同时执行静态与动态 DAG，并统一处理 ready-set、join、timeout、cancel、retry、overlay 与恢复。
- `RuntimeGraphSnapshot` 是唯一可恢复执行状态，包含已接受 Decision 和不可变摘要链。
- 默认 Profile 不隐式获得工具；部署者必须通过 `toolBindings` 明确授权。

最新统一设计、核心模型、Host 协议、DSH 接入与数据面说明见
[当前架构设计](docs/architecture/ARCHITECTURE.md)；完整证据、已知限制和外部审查模板见
[架构与代码审查指南](docs/architecture/ARCHITECTURE_REVIEW_GUIDE.md)；专题约束见
[数据面设计与实现边界](docs/architecture/DATA_PLANE.md)、
[Multi-Agent 设计](docs/architecture/MULTI_AGENT.md) 和 [安全与沙箱](docs/architecture/SANDBOXING.md)。

面向团队技术分享，参见[项目意义与核心设计](docs/sharing/TECHNICAL_SHARING.md)，包含 Harness 对比、五张架构/流程图与当前实现边界；也可打开[离线阅读版](docs/sharing/TECHNICAL_SHARING.html)。

本次开源发布前的实际缺陷、修复回归与能力边界见
[v0.3.0 架构审查记录](docs/audits/ARCHITECTURE-REVIEW-2026-09-07.md)。

## 数据面现状

当前已经走通 `Harness -> Application -> 权威 EventLog -> typed CanonicalObservation -> query/state/view`：

- Event API v1 保持兼容，Data API v1 提供 message/model call/tool/usage/interaction 的强类型投影；
- 未知且可忽略的 Harness 事件保存为 governed RawEvent，不会静默丢失；
- `RuntimeDataClient` 提供 Run 查询、observation 分页/订阅、状态投影、用途化 trajectory、asset 与 annotation；
- 可选的 `/data/v1` HTTP/SSE Host 提供 bearer 认证、tenant/project 隔离、治理可见性和 run-scoped Asset 解析，
  默认关闭且不改变已有 `/v1` Product API；
- `DataCoverage` + conformance report 区分 Adapter 真正暴露的深度；
- AReaL 投影只联结真实 token/logprob/policy-version/reward，不从文本伪造训练信号。

这仍是单节点/文件实现的数据面闭环，不是已完成的分布式数据平台：SQL 高吞吐存储、跨 Pod command routing、
portable checkpoint Adapter、retention/DLP 作业和访问审计仍待实现。远程接口的启用与安全边界见
[Runtime Data API 指南](docs/guides/DATA_API.md)，具体能力矩阵与限制以
[DATA_PLANE.md](docs/architecture/DATA_PLANE.md) 为准。

## 快速开始

要求 Python 3.11+。普通使用者直接安装不可变发行版，不需要克隆 Runtime 仓库：

```bash
python -m pip install "areal-agent-runtime[api]==0.3.0"
```

然后可以从稳定根包导入 composition API：

```python
import asyncio

from areal_agent_runtime import BootstrapConfig, build_composition


async def main() -> None:
    config = BootstrapConfig.model_validate(
        {
            "runtime": {
                "kind": "fake",
                "selector": "primary",
                "profileBinding": "runtime-owned",
            },
            "host": {"kind": "native"},
        }
    )
    composition = await build_composition(config)
    try:
        app = composition.create_http_app()
        assert app is not None
    finally:
        await composition.close()


asyncio.run(main())
```

CLI 等价方式：

```bash
areal-agent-runtime serve \
  --config examples/config/fake-native.json \
  --host 127.0.0.1 \
  --port 3092
```

启动后可调用原生 API：

```bash
curl -sS http://127.0.0.1:3092/v1/runs \
  -H 'content-type: application/json' \
  -d '{
    "profile":"general.default",
    "input":[{"type":"text","text":"Summarize the workspace"}],
    "runtime":{"selector":"primary"},
    "workspace":{"workspaceId":"demo"}
  }'
```

OpenAI Chat Completions 兼容入口使用 `examples/config/*-openai.json`。请求中的 Profile、Runtime 和 Model
override 均需在 Host 配置中显式允许。

框架正式区分四种接入模式：配置/CLI、嵌入应用、领域产品/Plugin、自定义 Harness Adapter。稳定导入路径、
最小实现和验收清单见[接入指南](docs/guides/INTEGRATION.md)；版本与协议兼容规则见
[版本策略](docs/guides/VERSIONING.md)。

从源码贡献时才需要 [uv](https://docs.astral.sh/uv/)：

```bash
uv sync --frozen --extra api --extra dsh --extra claude --extra anthropic --extra codex
make test
```

让 Codex / Claude Code 帮助产品接入，先用 [runtime-integrate](.agents/skills/runtime-integrate/SKILL.md)：
它会区分使用现有能力、开发独立 Adapter 和修改框架，路由到配置、Harness、工具、存储/轨迹、工作流或协议技能。
[Agent 接入指南](docs/guides/AGENT_INTEGRATION.md)说明默认实现、公开导入面、插件装配和验收范围。

```bash
python scripts/install_agent_skills.py --project /absolute/path/to/consumer-project --agent both
```

安装器生成可搬迁的技能与参考副本，保留接入方现有指令；详细更新和离线分发见
[技能安装指南](docs/guides/AGENT_SKILLS_INSTALLATION.md)。仅需要配置时仍可安装单独的 `runtime-configure`。
框架源码开发先读 [AGENTS.md](AGENTS.md)；Claude Code 通过 [CLAUDE.md](CLAUDE.md)读取同一规则。
`examples/extensions/` 同时提供接口形状示例和可独立构建的完整扩展包；`make agent-integration-check` 验证独立 wheel
安装后的工具往返、基础设施与持久化查询，以及进程崩溃后的 outbox 重放；`make agent-skills` 构建完整技能分发包。

## 容器运行

默认镜像只包含 Python 核心和 Fake Runtime，用于确定性 smoke/E2E；它以非 root、只读根文件系统、
`cap_drop: ALL` 和 `no-new-privileges` 运行：

```bash
make docker-e2e
make docker-data-e2e
```

需要复用本机 Codex 登录时，使用独立的 `Dockerfile.codex`/`compose.codex.yaml`。认证文件只读挂载，
由无网络的一次性初始化容器复制到临时命名卷，不会写入镜像；长期运行的 Host 始终是非 root。
容器内 Codex 可以显式配置 `danger-full-access`，Docker/OCI 容器仍是外层安全边界。

```bash
CODEX_AUTH_FILE="$HOME/.codex/auth.json" \
CODEX_MODEL=gpt-5.6-luna \
make docker-codex-e2e
```

DSH Adapter 使用独立的通用基座镜像。它安装官方 `deepseek-harness-sdk`、固定版本的 Runtime DSH
bundle 和 SDK profile；模型路由、凭证引用及产品 patch 仍由上层产品部署配置注入：

```bash
make docker-dsh-build
```

该命令默认生成 `areal-agent-runtime-dsh:0.3.0`；消费方可用 `DSH_IMAGE` 改成自己的 registry tag。公开部署应在
发布平台推送并使用 digest，不能把可变的 `latest` 或不同源码复用为同一版本。

镜像以非 root、只读根文件系统方式运行时，会把 DSH bundle 与 SDK profile 模板按原目录关系同步到可写的
`DSH_HOME` 数据卷；DSH 可在该受管副本中生成 `cordis.yml` 并写入动态模块缓存，应用镜像层仍保持只读。
凭证不得写入 profile、配置 JSON 或镜像，应由上层通过 Secret 文件或受控环境变量提供。

每个 DSH 子进程还会从已解析的 `AgentEnvironment` 绑定真实的 scoped system persona，并把模型可见 ToolSet
收敛到该 Session 的 Runtime/Application/MCP 工具交集；限制同时作用于 schema 可见性和执行 guard。DSH 原生
委派工具默认关闭，只有受信 `AgentSpec.allowRuntimeSubagents=true` 才会同时开启插件与 ToolSet。产品不能用
部署环境变量绕过这些逐 Session 决策。

不要把 Docker socket 挂入 Agent 容器。生产环境应把每次执行交给独立 OCI 沙箱或远程 Runtime Adapter，
并由平台配置网络、资源、身份和文件系统策略。

## 配置与扩展

接入方可以直接让 Codex 或 Claude Code 生成和校验配置。参见
[Agent 配置接入](docs/guides/AGENT_CONFIGURATION.md)、[配置指南](docs/guides/CONFIGURATION.md)
和[逐字段参考](docs/guides/CONFIGURATION_REFERENCE.md)。

```bash
# 在 Runtime 源码仓库中，把自包含配置 skill 安装到接入方已有项目。
python scripts/install_configuration_skill.py --project /absolute/path/to/consumer-project --agent both

# 接入方安装匹配的 Runtime CLI 后，先做不启动模型或插件的静态校验。
areal-agent-runtime validate --config /absolute/path/to/consumer-project/deploy/runtime --json
```

Codex 可使用 `$runtime-configure`，Claude Code 可使用 `/runtime-configure`。skill 引导选择模板、生成配置、
处理错误和报告未验证项；[场景索引](examples/project/README.md)覆盖工具授权、并行隔离、MCP、DSH skills、
Claude 高级配置及 Remote mTLS。当前源码新增的 `validate` 命令需匹配的源码/wheel，不能仅凭旧版包名判断存在。

- `examples/config/fake-native.json`：无外部依赖的原生 HTTP Host。
- `examples/config/fake-native-data-api.json`：默认关闭能力的显式启用样例，token 只从环境变量读取。
- `examples/config/codex-cli-openai.json`：Codex CLI + OpenAI 兼容 Host。
- `examples/config/multi-runtime-openai.json`：按 execution mode 选择不同 Runtime。
- `examples/config/remote-runtime-openai.json`：连接独立沙箱/容器中的 Runtime Wire 服务。
- `examples/project/agent-runtime-v1/`：四文件 Release/Composition/Workflow/Agent 配置。
- `examples/dsh-profile/`：可选 DSH SDK profile；安装后用于真实 ToolCall/ToolResult 与并发证明。

插件只能实现稳定 Port：Agent Runtime、Tool Provider、Environment、State/Asset Store、Event Sink 或
Artifact Publisher。MCP endpoint、Secret、Plugin 和 Host 权限属于部署配置，Planner 无权动态创建。

新 Harness 接入建议使用 `HarnessAdapterPort` 和 `areal_agent_runtime.harness_sdk`；已有
`AgentRuntimePort` 继续作为 v1 兼容名称。安装包名、import 和 schema namespace 分别是
`areal-agent-runtime`、`areal_agent_runtime`、`areal.agent-runtime.*`，详见
[命名与 v1 兼容 ADR](docs/architecture/ADR-0001-NAMING-AND-V1-COMPATIBILITY.md)。
已接入项目的升级约束、旧 Wire 降级规则和发布门禁见
[兼容性与协议演进规范](docs/guides/COMPATIBILITY.md)。

## 验证

```bash
make test
make schemas-check
make compatibility-check
make release-check
make agent-skills
make docker-e2e
make docker-data-e2e
```

测试覆盖 Runtime/Data 合约、canonical/raw 闭环、coverage 真实性、AReaL fixture、工具闭环、静态/动态 DAG、
所有 join 模式、失败传播、恢复、摘要防篡改、多 writer/overlay、远程 Runtime Wire，以及可选的真实 Harness 子进程证明。
`make test-dsh-real` 验证 DSH；`make test-native-real` 验证 Claude Code/SDK、Codex 和 Hermes，需先准备
对应 CLI/SDK、DSH profile 或 Hermes checkout。它们使用本地受控模型；真实模型验收需另行提供授权配置，
具体入口与已验证边界见[原生 Harness 指南](docs/guides/NATIVE_HARNESSES.md)。完整门禁会报告未配置依赖的跳过项。

## 开源与发布

源码采用 Apache-2.0，包含贡献、安全、支持、版本、变更记录、CI、构建与 Trusted Publishing 流程。
每个发行版附带不可变 tag、校验和、SBOM 和第三方许可证报告。发布责任人的完整核验步骤见
[开源发布清单](docs/guides/OPEN_SOURCE_READINESS.md)与[发布流程](docs/guides/RELEASING.md)。
