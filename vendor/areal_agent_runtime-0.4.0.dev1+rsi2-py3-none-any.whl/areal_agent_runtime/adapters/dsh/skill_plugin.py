"""Trusted catalog entry for DSH's native skill loader.

This provider declares the native tool so deployments can authorize it through
normal tool bindings. Skill discovery and execution stay inside the DSH adapter.
"""

from __future__ import annotations

from pydantic import JsonValue

from areal_agent_runtime.contracts import (
    ErrorCategory,
    ErrorInfo,
    ToolCall,
    ToolExecution,
    ToolResult,
    ToolSpec,
)
from areal_agent_runtime.plugin_sdk import (
    HealthStatus,
    PluginContext,
    PluginEntrypoints,
    PluginManifest,
    PortKey,
)


class DSHSkillToolProvider:
    """Expose only the authorization descriptor for DSH's native ``skill`` tool."""

    async def list_tools(self) -> tuple[ToolSpec, ...]:
        # Match @deepseek-ai/dsh-tool-skill 0.1.2-alpha.5. DSH's parameter
        # compiler leaves the implicit object open; do not narrow its schema.
        return (
            ToolSpec(
                name="skill",
                description=(
                    "Load the full instructions for an available skill. Call this with the exact skill name "
                    "from the session skill catalog before acting on a task that names or clearly matches that skill."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "The exact skill name from the available skills list.",
                        },
                    },
                    "required": ["name"],
                },
                execution=ToolExecution.RUNTIME,
            ),
        )

    async def invoke(self, call: ToolCall) -> ToolResult:
        return ToolResult(
            call_id=call.call_id,
            error=ErrorInfo(
                code="DSH_SKILL_RUNTIME_ONLY",
                category=ErrorCategory.PROTOCOL,
                message=(
                    "The skill tool must execute through DSH's native skill registry, "
                    "not the Application provider."
                ),
            ),
        )

    async def health(self) -> HealthStatus:
        return HealthStatus(status="healthy")


class DSHSkillToolsPlugin:
    manifest = PluginManifest(
        name="dsh-skill-tools",
        version="1.0.0",
        implements=(PortKey.TOOL_PROVIDER,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.dsh.skill_plugin:create_plugin"),
        config_schema="skill.config.schema.json",
    )

    def __init__(self) -> None:
        self.provider: DSHSkillToolProvider | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        if config:
            raise ValueError("DSH skill tools plugin does not accept configuration fields")
        self.provider = DSHSkillToolProvider()
        context.provide(PortKey.TOOL_PROVIDER, self.provider)

    async def start(self) -> None:
        if self.provider is None:
            raise RuntimeError("DSH skill tools plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.provider is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.provider.health()

    async def stop(self) -> None:
        self.provider = None


def create_plugin() -> DSHSkillToolsPlugin:
    return DSHSkillToolsPlugin()
