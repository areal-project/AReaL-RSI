"""Materialize resolved text skills as a session-local Claude Code plugin.

Claude owns discovery, summaries, invocation policy and the native Skill tool.
Resource locators are provenance; they never authorize copying host directories.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path

import yaml

from areal_agent_runtime.contracts.environment import AgentEnvironmentSnapshot, ResolvedResourceSnapshot

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
PLUGIN_NAME = "areal-session"
MAX_SKILL_BYTES = 16 * 1024 * 1024


@dataclass
class ClaudeSkillPlugin:
    directory: tempfile.TemporaryDirectory[str]
    names: tuple[str, ...]
    files: tuple[tuple[str, int, str], ...]
    root_identity: tuple[int, int]

    @property
    def path(self) -> str:
        return self.directory.name

    def close(self) -> None:
        self.directory.cleanup()

    def verify(self) -> None:
        """Check the bounded native plugin tree against its original snapshot."""
        root = Path(self.path)
        expected = {name: (size, digest) for name, size, digest in self.files}
        directories = {
            parent.as_posix() for name in expected for parent in Path(name).parents if parent != Path(".")
        }
        try:
            identity = root.lstat()
            if not stat.S_ISDIR(identity.st_mode) or (identity.st_dev, identity.st_ino) != self.root_identity:
                raise ValueError("plugin root changed")
            found: set[str] = set()
            pending = [root]
            while pending:
                directory = pending.pop()
                with os.scandir(directory) as entries:
                    for entry in entries:
                        path = Path(entry.path)
                        relative = path.relative_to(root).as_posix()
                        if relative in directories and entry.is_dir(follow_symlinks=False):
                            pending.append(path)
                            continue
                        if relative not in expected or not entry.is_file(follow_symlinks=False):
                            raise ValueError("plugin tree changed")
                        size, digest = expected[relative]
                        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
                        with os.fdopen(descriptor, "rb") as source:
                            info = os.fstat(source.fileno())
                            if not stat.S_ISREG(info.st_mode) or info.st_size != size:
                                raise ValueError("plugin file size changed")
                            body = source.read(size + 1)
                        if len(body) != size or hashlib.sha256(body).hexdigest() != digest:
                            raise ValueError("plugin file digest changed")
                        found.add(relative)
            if found != set(expected):
                raise ValueError("plugin file missing")
        except (OSError, ValueError) as exc:
            raise ValueError("Claude session skill plugin was modified or is unavailable") from exc


def _skill_document(
    resource: ResolvedResourceSnapshot,
    portable_native_tools: frozenset[str] | None = None,
) -> tuple[str, str]:
    text = resource.content if isinstance(resource.content, str) else json.dumps(resource.content, ensure_ascii=False)
    if "\0" in text or len(text.encode("utf-8")) > MAX_SKILL_BYTES:
        raise ValueError("Claude skill must be text without NUL and at most 16 MiB")
    text = text.lstrip("\ufeff")
    fallback = re.sub(r"[^a-z0-9]+", "-", resource.resource_id.lower()).strip("-")[:48].rstrip("-") or "skill"
    fallback += "-" + hashlib.sha256(resource.resource_id.encode()).hexdigest()[:12]
    name = fallback
    document = text
    metadata: dict[str, object] = {}
    body = text
    description_fallback = json.dumps(f"Instructions for resource {resource.resource_id}.", ensure_ascii=False)
    match = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|\Z)", text, re.DOTALL)
    if text.startswith(("---\n", "---\r\n")) and match is None:
        raise ValueError("Claude skill has unterminated YAML frontmatter")
    if match is not None:
        if len(match[1].encode("utf-8")) > 65536:
            raise ValueError("Claude skill frontmatter exceeds 64 KiB")
        try:
            depth = 0
            for event in yaml.parse(match[1]):
                if isinstance(event, yaml.AliasEvent):
                    raise ValueError("Claude resolved skill frontmatter must not contain YAML aliases")
                if isinstance(event, (yaml.MappingStartEvent, yaml.SequenceStartEvent)):
                    depth += 1
                    if depth > 16:
                        raise ValueError("Claude skill frontmatter exceeds 16 nesting levels")
                elif isinstance(event, (yaml.MappingEndEvent, yaml.SequenceEndEvent)):
                    depth -= 1
            node = yaml.compose(match[1], Loader=yaml.SafeLoader)
            if isinstance(node, yaml.MappingNode):
                keys = [key.value for key, _value in node.value if isinstance(key, yaml.ScalarNode)]
                if len(set(keys)) != len(keys):
                    raise ValueError("Claude skill frontmatter must not repeat fields")
            parsed = yaml.safe_load(match[1]) or {}
        except yaml.YAMLError as exc:
            raise ValueError("Claude skill has invalid YAML frontmatter") from exc
        if not isinstance(parsed, dict):
            raise ValueError("Claude skill frontmatter must be a mapping")
        metadata = parsed
        body = text[match.end() :]
        native_name = metadata.get("name", fallback)
        if not isinstance(native_name, str) or not _NAME.fullmatch(native_name) or len(native_name) > 64:
            raise ValueError("Claude skill name must be lower-case kebab-case, at most 64 characters")
        name = native_name
        description = metadata.get("description")
        if description is not None and (not isinstance(description, str) or not description.strip()):
            raise ValueError("Claude skill description must be non-empty text")
        if description is None:
            # Keep all native fields and the body verbatim, including invocation
            # policy, context: fork, arguments and dynamic substitutions.
            insertion = f"description: {description_fallback}\n"
            start = text.index("\n") + 1
            document = text[:start] + insertion + text[start:]
    else:
        document = f"---\nname: {name}\ndescription: {description_fallback}\n---\n\n{text}"
    if portable_native_tools is not None:
        # Native skill pre-processing runs before the model can request tools.
        # It must not grant shell/child capabilities absent from the snapshot.
        if metadata.get("hooks"):
            # Native hooks can run commands/agents or override permissions
            # outside the portable tool guard, including after the last turn.
            raise ValueError("Claude portable skills cannot register native hooks; use runtime-owned binding")
        if "!`" in body and "Bash" not in portable_native_tools:
            raise ValueError("Claude portable skill dynamic commands require the runtime tool 'Bash'")
        if metadata.get("context") == "fork" and not portable_native_tools.intersection({"Agent", "Task"}):
            raise ValueError("Claude portable context: fork skills require the runtime tool 'Agent' or 'Task'")
    return name, document


def materialize_skills(
    environment: AgentEnvironmentSnapshot,
    *,
    portable_native_tools: frozenset[str] | None = None,
) -> ClaudeSkillPlugin | None:
    environment.assert_integrity()
    if not environment.skills:
        return None
    if len(environment.skills) > 256:
        raise ValueError("Claude supports at most 256 resolved skills per session")
    documents = [_skill_document(resource, portable_native_tools) for resource in environment.skills]
    names = [name for name, _document in documents]
    if len(names) != len(set(names)):
        raise ValueError("Claude resolved skills have duplicate native names")
    if sum(len(document.encode("utf-8")) for _, document in documents) > MAX_SKILL_BYTES:
        raise ValueError("Claude resolved skill plugin exceeds 16 MiB")
    directory = tempfile.TemporaryDirectory(prefix="areal-claude-skills-")
    try:
        root = Path(directory.name)
        manifest = root / ".claude-plugin" / "plugin.json"
        manifest.parent.mkdir(mode=0o700)
        manifest_content = json.dumps({"name": PLUGIN_NAME, "version": "1.0.0"})
        manifest.write_bytes(manifest_content.encode("utf-8"))
        expected_files = [(manifest.relative_to(root).as_posix(), manifest_content)]
        for name, document in documents:
            path = root / "skills" / name / "SKILL.md"
            path.parent.mkdir(parents=True, mode=0o700)
            path.touch(mode=0o600)
            path.write_bytes(document.encode("utf-8"))
            expected_files.append((path.relative_to(root).as_posix(), document))
        identity = root.stat()
        return ClaudeSkillPlugin(
            directory,
            tuple(f"{PLUGIN_NAME}:{name}" for name in names),
            tuple((name, len(body.encode("utf-8")), hashlib.sha256(body.encode("utf-8")).hexdigest())
                  for name, body in expected_files),
            (identity.st_dev, identity.st_ino),
        )
    except BaseException:
        directory.cleanup()
        raise


def resolved_system_prompt(environment: AgentEnvironmentSnapshot) -> str:
    environment.assert_integrity()
    return "\n".join(
        resource.content if isinstance(resource.content, str) else json.dumps(resource.content, ensure_ascii=False)
        for resource in environment.system_prompts
    )
