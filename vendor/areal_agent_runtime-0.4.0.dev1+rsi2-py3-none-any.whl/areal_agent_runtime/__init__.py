"""Stable, dependency-light public API for embedding ARealAgentRuntime."""

from importlib.metadata import version as _distribution_version

from areal_agent_runtime.application import ARealAgentRuntime
from areal_agent_runtime.bootstrap import (
    ARealAgentRuntimeComposition,
    BootstrapConfig,
    BuiltinResourceBootstrapConfig,
    HostBootstrapConfig,
    PluginBootstrapConfig,
    RequestKnowledgeBootstrapConfig,
    ResourceBindingsBootstrapConfig,
    RuntimeBootstrapConfig,
    ToolBindingBootstrapConfig,
    build_composition,
)
from areal_agent_runtime.contracts.version import (
    DATA_API_VERSION,
    EVENT_API_VERSION,
    PLUGIN_API_VERSION,
    PRODUCT_API_VERSION,
    RUNTIME_API_VERSION,
    RUNTIME_WIRE_API_VERSION,
)

__version__ = _distribution_version("areal-agent-runtime")

__all__ = [
    "ARealAgentRuntime",
    "ARealAgentRuntimeComposition",
    "BootstrapConfig",
    "BuiltinResourceBootstrapConfig",
    "DATA_API_VERSION",
    "EVENT_API_VERSION",
    "HostBootstrapConfig",
    "PLUGIN_API_VERSION",
    "PRODUCT_API_VERSION",
    "PluginBootstrapConfig",
    "RUNTIME_API_VERSION",
    "RUNTIME_WIRE_API_VERSION",
    "RequestKnowledgeBootstrapConfig",
    "ResourceBindingsBootstrapConfig",
    "RuntimeBootstrapConfig",
    "ToolBindingBootstrapConfig",
    "__version__",
    "build_composition",
]
