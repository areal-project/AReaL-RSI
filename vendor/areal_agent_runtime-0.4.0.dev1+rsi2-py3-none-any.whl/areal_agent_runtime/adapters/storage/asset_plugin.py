"""Asset-only local plugin for independent media storage selection."""

from __future__ import annotations

from pathlib import Path

from pydantic import JsonValue

from areal_agent_runtime.adapters.storage.assets import FileSystemAssetStore
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class FileSystemAssetStorePlugin:
    manifest = PluginManifest(
        name="filesystem-assets",
        version="1.0.0",
        implements=(PortKey.ASSET_STORE,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.storage.asset_plugin:create_plugin"),
        config_schema="asset.schema.json",
        permissions=("filesystem.read", "filesystem.write"),
    )

    def __init__(self) -> None:
        self.asset_store: FileSystemAssetStore | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        root = config.get("root")
        if not isinstance(root, str) or not root or root != root.strip():
            raise ValueError("Filesystem AssetStore requires a trimmed config.root")
        self.asset_store = FileSystemAssetStore(
            Path(root),
            read_chunk_size=_limit(config, "readChunkSize", 1024 * 1024),
            max_asset_bytes=_limit(config, "maxAssetBytes", 256 * 1024 * 1024),
            max_metadata_bytes=_limit(config, "maxMetadataBytes", 1024 * 1024),
        )
        context.provide(PortKey.ASSET_STORE, self.asset_store)

    async def start(self) -> None:
        if self.asset_store is None:
            raise RuntimeError("Filesystem AssetStore plugin is not configured")

    async def health(self) -> HealthStatus:
        return HealthStatus(status="healthy" if self.asset_store is not None else "unhealthy")

    async def stop(self) -> None:
        return None


def create_plugin() -> FileSystemAssetStorePlugin:
    return FileSystemAssetStorePlugin()


def _limit(config: dict[str, JsonValue], key: str, default: int) -> int:
    value = config.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"Filesystem AssetStore {key} must be a positive integer")
    return value
