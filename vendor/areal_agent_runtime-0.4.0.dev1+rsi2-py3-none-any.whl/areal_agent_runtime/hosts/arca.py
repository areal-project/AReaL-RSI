"""ARCA/serverless invocation adapter over the native Product API."""

from __future__ import annotations

import asyncio
import contextlib
import math
from dataclasses import dataclass

from pydantic import Field, JsonValue, StrictBool, field_validator

from areal_agent_runtime.application import ARealAgentRuntime
from areal_agent_runtime.compatibility import dump_event_api_v1, dump_product_run_snapshot_v1
from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.environment import AgentEnvironmentSpec
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.product import CancelRunCommand, RuntimeSelection, StartRunCommand
from areal_agent_runtime.contracts.runtime import WorkspaceRef
from areal_agent_runtime.hosts.workspace_selection import session_scoped_workspace
from areal_agent_runtime.kernel.ids import new_id


class ArcaServerlessRequest(ContractModel):
    input: tuple[ContentBlock, ...] = Field(min_length=1)
    profile: str | None = None
    runtime: RuntimeSelection | None = None
    workspace: WorkspaceRef | None = None
    session_id: str | None = None
    resume_session: StrictBool | None = None
    agent_environment: AgentEnvironmentSpec | None = None
    wait: StrictBool = True
    timeout_seconds: float | None = Field(default=None, gt=0)
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("timeout_seconds")
    @classmethod
    def finite_timeout(cls, value: float | None) -> float | None:
        if value is not None and not math.isfinite(value):
            raise ValueError("timeoutSeconds must be finite")
        return value


@dataclass(frozen=True, slots=True)
class ArcaServerlessConfig:
    default_profile: str
    default_runtime: RuntimeSelection
    default_workspace: WorkspaceRef
    default_timeout_seconds: float | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.default_profile, str) or not self.default_profile.strip():
            raise ValueError("default_profile must not be blank")
        if not isinstance(self.default_runtime, RuntimeSelection):
            raise TypeError("default_runtime must be a RuntimeSelection")
        if not isinstance(self.default_workspace, WorkspaceRef):
            raise TypeError("default_workspace must be a WorkspaceRef")
        timeout = self.default_timeout_seconds
        if timeout is not None and (
            isinstance(timeout, bool)
            or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout)
            or timeout <= 0
        ):
            raise ValueError("default_timeout_seconds must be a finite positive number")


class ArcaServerlessHost:
    """A transport-agnostic handler suitable for ARCA/container function entrypoints."""

    def __init__(self, application: ARealAgentRuntime, config: ArcaServerlessConfig) -> None:
        self._application = application
        self._config = config

    async def invoke(self, payload: ArcaServerlessRequest | dict[str, object]) -> dict[str, JsonValue]:
        request = (
            payload if isinstance(payload, ArcaServerlessRequest) else ArcaServerlessRequest.model_validate(payload)
        )
        requested_session_id = request.session_id
        session_id = requested_session_id or new_id("ses")
        workspace = request.workspace or session_scoped_workspace(
            self._config.default_workspace,
            session_id,
        )
        ref = await self._application.start_run(
            StartRunCommand(
                profile=request.profile or self._config.default_profile,
                input=request.input,
                runtime=request.runtime or self._config.default_runtime,
                workspace=workspace,
                session_id=session_id,
                resume_session=(
                    request.resume_session
                    if request.resume_session is not None
                    else requested_session_id is not None
                ),
                agent_environment=request.agent_environment,
                metadata={
                    **request.metadata,
                    "host": "arca-serverless",
                    "workspaceIsolation": (
                        "explicit"
                        if request.workspace is not None
                        else (
                            "external-mount"
                            if self._config.default_workspace.mount_hint is not None
                            else "session"
                        )
                    ),
                },
            )
        )
        response: dict[str, JsonValue] = {
            "run": ref.model_dump(mode="json", by_alias=True),
        }
        if not request.wait:
            return response

        timeout_seconds = request.timeout_seconds or self._config.default_timeout_seconds
        try:
            if timeout_seconds is None:
                snapshot = await self._application.wait(ref.run_id)
            else:
                async with asyncio.timeout(timeout_seconds):
                    snapshot = await self._application.wait(ref.run_id)
        except TimeoutError as exc:
            with contextlib.suppress(Exception):
                await self._application.cancel_run(
                    CancelRunCommand(
                        run_id=ref.run_id,
                        reason="ARCA invocation deadline exceeded",
                    )
                )
            raise ContractError(
                ErrorInfo(
                    code="ARCA_DEADLINE_EXCEEDED",
                    category=ErrorCategory.TIMEOUT,
                    message="ARCA invocation exceeded its configured deadline",
                    retryable=True,
                    details={"runId": ref.run_id, "timeoutSeconds": timeout_seconds},
                )
            ) from exc
        events = [event async for event in self._application.stream_events(ref.run_id)]
        response["run"] = dump_product_run_snapshot_v1(snapshot)
        response["events"] = [dump_event_api_v1(event) for event in events]
        return response
