"""Durable append-only annotation storage for the local distribution."""

from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import os
import weakref
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import IO

from areal_agent_runtime.contracts.data import DataAnnotation


class FileSystemAnnotationStore:
    def __init__(self, root: str | Path) -> None:
        self._root = Path(root).expanduser().resolve()
        self._root.mkdir(parents=True, exist_ok=True)
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )

    async def append(self, annotation: DataAnnotation) -> None:
        durable = DataAnnotation.model_validate(
            annotation.model_dump(mode="json", by_alias=True)
        )
        lock = self._locks.setdefault(durable.run_id, asyncio.Lock())
        async with lock:
            await asyncio.to_thread(self._append, durable)

    async def list(self, run_id: str) -> tuple[DataAnnotation, ...]:
        _validate_identity(run_id)
        lock = self._locks.setdefault(run_id, asyncio.Lock())
        async with lock:
            return await asyncio.to_thread(self._list, run_id)

    def _append(self, annotation: DataAnnotation) -> None:
        path = self._path(annotation.run_id)
        with self._file_lock(annotation.run_id):
            existing = self._read(path)
            by_id = {item.annotation_id: item for item in existing}
            previous = by_id.get(annotation.annotation_id)
            if previous is not None:
                if previous == annotation:
                    return
                raise ValueError(
                    "annotationId already exists with different content: "
                    f"{annotation.annotation_id}"
                )
            encoded = (
                json.dumps(
                    annotation.model_dump(mode="json", by_alias=True),
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                    allow_nan=False,
                )
                + "\n"
            ).encode("utf-8")
            descriptor = os.open(path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
            try:
                remaining = memoryview(encoded)
                while remaining:
                    written = os.write(descriptor, remaining)
                    if written <= 0:
                        raise OSError("annotation append made no progress")
                    remaining = remaining[written:]
                os.fsync(descriptor)
            finally:
                os.close(descriptor)

    def _list(self, run_id: str) -> tuple[DataAnnotation, ...]:
        with self._file_lock(run_id):
            return self._read(self._path(run_id))

    @staticmethod
    def _read(path: Path) -> tuple[DataAnnotation, ...]:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except FileNotFoundError:
            return ()
        items: list[DataAnnotation] = []
        ids: set[str] = set()
        for line in lines:
            if not line:
                continue
            item = DataAnnotation.model_validate(json.loads(line))
            if item.annotation_id in ids:
                raise ValueError(f"duplicate durable annotationId: {item.annotation_id}")
            ids.add(item.annotation_id)
            items.append(item)
        return tuple(items)

    def _path(self, run_id: str) -> Path:
        _validate_identity(run_id)
        digest = hashlib.sha256(run_id.encode("utf-8")).hexdigest()
        return self._root / f"{digest}.jsonl"

    @contextmanager
    def _file_lock(self, run_id: str) -> Iterator[IO[bytes]]:
        lock_path = self._path(run_id).with_suffix(".lock")
        handle = lock_path.open("a+b")
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            yield handle
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()


def _validate_identity(value: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError("run_id must be a non-empty trimmed string")
