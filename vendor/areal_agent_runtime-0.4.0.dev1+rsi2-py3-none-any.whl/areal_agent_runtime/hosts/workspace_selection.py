"""Host-side workspace identity policies projected into concrete references."""

from __future__ import annotations

import hashlib

from areal_agent_runtime.contracts.runtime import WorkspaceRef


def session_scoped_workspace(base: WorkspaceRef, session_id: str) -> WorkspaceRef:
    """Create a stable per-session identity unless a platform mount is explicit.

    A mount hint is already a deployment-owned concrete allocation (for example
    ARCA's per-invocation ``/workspace``) and must not be rewritten. Local/server
    deployments without one use an opaque session digest so different sessions
    never share a LocalEnvironment directory by accident.
    """

    if base.mount_hint is not None:
        return base
    digest = hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:24]
    return base.model_copy(update={"workspace_id": f"{base.workspace_id}.session.{digest}"})
