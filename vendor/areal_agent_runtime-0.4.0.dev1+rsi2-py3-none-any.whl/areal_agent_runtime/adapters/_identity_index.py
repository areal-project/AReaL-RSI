"""Finite-memory, process-lifetime metadata for adapter identity checks.

These temporary indexes retain exact membership without evicting old close
handles or grants. They are not restart storage, and errors never reset them or
turn failed lookups into permission. Operations are small synchronous SQLite
lookups; no full-table Python cache or background task is created.
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import weakref
from collections.abc import Callable, Iterable, Iterator, MutableMapping, MutableSet
from pathlib import Path
from typing import Generic, TypeVar

from areal_agent_runtime.contracts.runtime import RuntimeSessionRef

T = TypeVar("T")


def _dispose(connection: sqlite3.Connection, directory: tempfile.TemporaryDirectory[str]) -> None:
    connection.close()
    directory.cleanup()


class AdapterIdentityMap(MutableMapping[str, T], Generic[T]):
    """A lazy temporary index with a 256 KiB SQLite page-cache target.

    The owner serializes operations on its event loop, as it did for the dict
    this replaces. check_same_thread=False permits finalization in another
    thread; it does not make multi-operation lifecycle changes transactional.
    Filesystem latency can still delay a synchronous lookup. No fsync/restart
    durability is promised for these process-local capabilities.
    """

    def __init__(self, encode: Callable[[T], str], decode: Callable[[str], T]) -> None:
        self._encode, self._decode = encode, decode
        self._connection: sqlite3.Connection | None = None
        self._directory: tempfile.TemporaryDirectory[str] | None = None
        self._finalizer: weakref.finalize | None = None
        self._closed = False

    def _database(self) -> sqlite3.Connection:
        if self._closed:
            raise RuntimeError("Adapter identity index is closed")
        if self._connection is not None:
            return self._connection
        directory = tempfile.TemporaryDirectory(prefix="areal-adapter-identities-")
        connection: sqlite3.Connection | None = None
        try:
            path = Path(directory.name) / "identities.sqlite3"
            connection = sqlite3.connect(path, isolation_level=None, check_same_thread=False, cached_statements=16)
            os.chmod(path, 0o600)
            connection.execute("PRAGMA cache_size = -256")
            connection.execute("PRAGMA mmap_size = 0")
            connection.execute("PRAGMA temp_store = FILE")
            connection.execute("PRAGMA journal_mode = MEMORY")
            connection.execute("PRAGMA synchronous = OFF")
            connection.execute("CREATE TABLE identities (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID")
        except BaseException:
            if connection is not None:
                connection.close()
            directory.cleanup()
            raise
        self._connection, self._directory = connection, directory
        self._finalizer = weakref.finalize(self, _dispose, connection, directory)
        return connection

    def __getitem__(self, key: str) -> T:
        if self._connection is None:
            raise KeyError(key)
        row = self._connection.execute("SELECT value FROM identities WHERE key = ?", (key,)).fetchone()
        if row is None:
            raise KeyError(key)
        return self._decode(row[0])

    def __setitem__(self, key: str, value: T) -> None:
        if not isinstance(key, str):
            raise TypeError("Adapter identity keys must be strings")
        encoded = self._encode(value)
        self._database().execute(
            "INSERT INTO identities VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, encoded),
        )

    def __delitem__(self, key: str) -> None:
        if self._connection is None or not self._connection.execute(
            "DELETE FROM identities WHERE key = ?", (key,),
        ).rowcount:
            raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        if self._connection is None:
            return
        cursor = self._connection.execute("SELECT key FROM identities ORDER BY key")
        try:
            for row in cursor:
                yield row[0]
        finally:
            cursor.close()

    def __len__(self) -> int:
        if self._connection is None:
            return 0
        return int(self._connection.execute("SELECT COUNT(*) FROM identities").fetchone()[0])

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and self._connection is not None and self._connection.execute(
            "SELECT 1 FROM identities WHERE key = ?", (key,),
        ).fetchone() is not None

    def clear(self) -> None:
        if self._connection is not None:
            self._connection.execute("DELETE FROM identities")

    def close(self) -> None:
        # Stop writes even if directory removal needs a later cleanup retry.
        self._closed = True
        if self._connection is not None:
            self._connection.close()
            self._connection = None
        if self._directory is not None:
            self._directory.cleanup()
            self._directory = None
        if self._finalizer is not None:
            self._finalizer.detach()
            self._finalizer = None


def session_identity_map() -> AdapterIdentityMap[RuntimeSessionRef]:
    return AdapterIdentityMap(lambda ref: ref.model_dump_json(), RuntimeSessionRef.model_validate_json)


def string_identity_map() -> AdapterIdentityMap[str]:
    return AdapterIdentityMap(lambda value: value, lambda value: value)


def resume_identity_map() -> AdapterIdentityMap[tuple[str, str]]:
    def decode(encoded: str) -> tuple[str, str]:
        value = json.loads(encoded)
        if not isinstance(value, list) or len(value) != 2 or not all(isinstance(item, str) for item in value):
            raise ValueError("Invalid adapter resume identity record")
        return value[0], value[1]

    return AdapterIdentityMap(json.dumps, decode)


class AdapterIdentitySet(MutableSet[str]):
    def __init__(self) -> None:
        self._values = string_identity_map()

    def __contains__(self, key: object) -> bool:
        return key in self._values

    def __iter__(self) -> Iterator[str]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def add(self, key: str) -> None:
        self._values[key] = ""

    def discard(self, key: str) -> None:
        self._values.pop(key, None)

    def update(self, keys: Iterable[str]) -> None:
        for key in keys:
            self.add(key)

    def clear(self) -> None:
        self._values.clear()

    def close(self) -> None:
        self._values.close()
