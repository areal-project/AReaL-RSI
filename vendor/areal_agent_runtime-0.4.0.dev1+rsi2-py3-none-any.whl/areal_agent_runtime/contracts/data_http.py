"""Transport-neutral request/response contracts for the remote Data API.

The canonical facts remain in :mod:`areal_agent_runtime.contracts.data`.
These models only describe bounded query and mutation envelopes exposed by an
HTTP Host.  Keeping them separate prevents transport concerns from leaking
into the canonical observation model.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import (
    ContractModel,
    require_media_type,
    require_optional_trimmed,
    require_trimmed,
)
from areal_agent_runtime.contracts.data import (
    AnnotationPayload,
    DataAnnotation,
    DataClassification,
    DataRunState,
)
from areal_agent_runtime.contracts.version import DATA_API_VERSION, DataApiVersion


class AppendAnnotationRequest(ContractModel):
    """Authenticated annotation input.

    ``source`` and the effective governance policy are assigned by the Host,
    not trusted from the caller.  ``createdAt`` is producer time and therefore
    remains in the idempotent request body.
    """

    api_version: DataApiVersion = DATA_API_VERSION
    annotation_id: str = Field(min_length=1)
    created_at: datetime
    payload: AnnotationPayload
    classification: DataClassification = DataClassification.INTERNAL
    execution_id: str | None = None
    model_call_id: str | None = None
    interaction_id: str | None = None

    @field_validator("annotation_id")
    @classmethod
    def validate_annotation_id(cls, value: str) -> str:
        return require_trimmed(value, "annotation identity")

    @field_validator("execution_id", "model_call_id", "interaction_id")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "annotation target identity")

    @field_validator("created_at")
    @classmethod
    def validate_created_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("annotation createdAt must include a timezone")
        return value

    @model_validator(mode="after")
    def require_target_hierarchy(self) -> AppendAnnotationRequest:
        if self.model_call_id is not None and self.execution_id is None:
            raise ValueError("annotation modelCallId requires executionId")
        if self.interaction_id is not None and self.execution_id is None:
            raise ValueError("annotation interactionId requires executionId")
        return self


class AnnotationPage(ContractModel):
    api_version: DataApiVersion = DATA_API_VERSION
    annotations: tuple[DataAnnotation, ...]
    next_cursor: StrictInt | None = Field(default=None, ge=0)


class RemoteRunPage(ContractModel):
    """Stable keyset-style page used by the remote Data API."""

    api_version: DataApiVersion = DATA_API_VERSION
    runs: tuple[DataRunState, ...]
    next_page_token: str | None = None

    @field_validator("next_page_token")
    @classmethod
    def validate_next_page_token(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "Runtime Data nextPageToken")


class ResolvedAsset(ContractModel):
    """A run-scoped, authorized Asset resolution without internal locator data."""

    api_version: DataApiVersion = DATA_API_VERSION
    run_id: str = Field(min_length=1)
    asset_id: str = Field(min_length=1)
    media_type: str = Field(min_length=1)
    size: StrictInt | None = Field(default=None, ge=0)
    sha256: str | None = Field(default=None, pattern=r"^[a-fA-F0-9]{64}$")
    url: str = Field(min_length=1)
    requested_ttl_seconds: StrictInt = Field(ge=1)

    @field_validator("run_id", "asset_id", "url")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "resolved asset identity")

    @field_validator("media_type")
    @classmethod
    def validate_media_type(cls, value: str) -> str:
        return require_media_type(value)

    @field_validator("sha256")
    @classmethod
    def normalize_sha256(cls, value: str | None) -> str | None:
        return value.lower() if value is not None else None
