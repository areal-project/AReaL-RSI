"""Bounded stdio transport for the native Codex App Server protocol."""

from __future__ import annotations

import asyncio
import contextlib
import json
from collections.abc import Callable
from typing import Any


class CodexRpc:
    def __init__(self, process: asyncio.subprocess.Process) -> None:
        self.process = process
        self.notification: Callable[[str, dict[str, Any]], None] = lambda _method, _params: None
        self.failure: Callable[[Exception], None] = lambda _error: None
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._next_id = 0
        self._closed = False
        self._close_task: asyncio.Task[None] | None = None
        self._write_lock = asyncio.Lock()
        self._reader = asyncio.create_task(self._read())
        self._stderr = asyncio.create_task(self._drain_stderr())

    async def _write(self, payload: dict[str, Any]) -> None:
        if self._closed or self.process.stdin is None:
            raise RuntimeError("Codex App Server connection is closed")
        async with self._write_lock:
            self.process.stdin.write(json.dumps(payload, ensure_ascii=False).encode() + b"\n")
            await self.process.stdin.drain()

    async def request(self, method: str, params: dict[str, Any], *, timeout_seconds: float = 30) -> dict[str, Any]:
        self._next_id += 1
        request_id = self._next_id
        future: asyncio.Future[dict[str, Any]] = asyncio.get_running_loop().create_future()
        self._pending[request_id] = future
        try:
            await self._write({"id": request_id, "method": method, "params": params})
            return await asyncio.wait_for(future, timeout_seconds)
        finally:
            self._pending.pop(request_id, None)

    async def notify(self, method: str) -> None:
        await self._write({"method": method})

    async def _read(self) -> None:
        assert self.process.stdout is not None
        try:
            while line := await self.process.stdout.readline():
                message = json.loads(line)
                if not isinstance(message, dict):
                    raise RuntimeError("Codex App Server returned an invalid frame")
                request_id = message.get("id")
                method = message.get("method")
                if isinstance(method, str):
                    params = message.get("params", {})
                    if not isinstance(params, dict):
                        raise RuntimeError("Codex App Server returned invalid notification parameters")
                    if request_id is not None:
                        # No live approval capability is advertised. Never silently grant it.
                        if method in {"item/commandExecution/requestApproval", "item/fileChange/requestApproval"}:
                            await self._write({"id": request_id, "result": {"decision": "decline"}})
                        else:
                            await self._write(
                                {
                                    "id": request_id,
                                    "error": {
                                        "code": -32601,
                                        "message": "Client interaction is not supported by this adapter",
                                    },
                                }
                            )
                    else:
                        self.notification(method, params)
                elif isinstance(request_id, int) and request_id in self._pending:
                    future = self._pending[request_id]
                    if future.done():
                        continue
                    if "error" in message:
                        # Vendor errors can include configuration and credentials: do not echo raw frames.
                        future.set_exception(RuntimeError("Codex App Server rejected the native request"))
                    elif isinstance(message.get("result"), dict):
                        future.set_result(message["result"])
                    else:
                        future.set_exception(RuntimeError("Codex App Server returned an invalid response"))
            if not self._closed:
                raise RuntimeError("Codex App Server exited before the connection was closed")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(exc)
            if not self._closed:
                self.failure(exc)

    async def _drain_stderr(self) -> None:
        # Drain continuously without keeping model payloads or credentials in an adapter log.
        assert self.process.stderr is not None
        while await self.process.stderr.read(16384):
            pass

    async def close(self) -> None:
        # The transport owns process cleanup. A cancelled caller may stop
        # waiting, but must not cancel cleanup or prevent a later caller joining it.
        if self._close_task is None:
            self._closed = True
            self._close_task = asyncio.create_task(self._close(), name="codex-rpc-close")
        await asyncio.shield(self._close_task)

    async def _close(self) -> None:
        for future in self._pending.values():
            if not future.done():
                future.set_exception(RuntimeError("Codex App Server connection closed"))
        try:
            if self.process.stdin is not None:
                self.process.stdin.close()
            try:
                await asyncio.wait_for(self.process.wait(), 2)
            except TimeoutError:
                with contextlib.suppress(ProcessLookupError):
                    self.process.terminate()
                try:
                    await asyncio.wait_for(self.process.wait(), 2)
                except TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        self.process.kill()
                    await self.process.wait()
        finally:
            # Also reap on an internal error or event-loop shutdown cancelling
            # the owned cleanup task, after ordinary callers have detached.
            if self.process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    self.process.kill()
                await self.process.wait()
            self._reader.cancel()
            self._stderr.cancel()
            await asyncio.gather(self._reader, self._stderr, return_exceptions=True)
