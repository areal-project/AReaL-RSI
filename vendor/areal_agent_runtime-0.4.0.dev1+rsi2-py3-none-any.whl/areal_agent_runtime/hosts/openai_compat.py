"""Small OpenAI Chat Completions projection over the canonical Runtime API."""

import base64
import binascii
import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, JsonValue, ValidationError

from areal_agent_runtime.application import ARealAgentRuntime
from areal_agent_runtime.contracts.content import ContentBlock, ImageRefBlock, TextBlock
from areal_agent_runtime.contracts.errors import ContractError, ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.ports import AssetStorePort
from areal_agent_runtime.contracts.product import RuntimeSelection, StartRunCommand
from areal_agent_runtime.contracts.runtime import WorkspaceRef
from areal_agent_runtime.hosts.workspace_selection import session_scoped_workspace
from areal_agent_runtime.kernel.ids import new_id


class OpenAIMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: str
    content: str | list[JsonValue]


class OpenAIChatRequest(BaseModel):
    """Supported Chat Completions subset plus explicit Runtime routing."""

    model_config = ConfigDict(extra="forbid")

    messages: tuple[OpenAIMessage, ...] = Field(min_length=1)
    model: str | None = None
    stream: bool = False
    profile: str | None = None
    runtime: str | None = None
    session_id: str | None = None
    execution_mode: str = "default"
    metadata: dict[str, JsonValue] = Field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class OpenAICompatibilityConfig:
    default_runtime: RuntimeSelection
    default_workspace: WorkspaceRef
    default_profile: str = "general.default"
    default_model: str = "areal-agent-runtime"
    mode_profiles: dict[str, str] = field(default_factory=lambda: {"default": "general.default"})
    mode_runtimes: dict[str, RuntimeSelection] = field(default_factory=dict)
    allowed_profiles: tuple[str, ...] = ()
    allowed_runtime_selectors: tuple[str, ...] = ()
    allowed_models: tuple[str, ...] = ()
    max_inline_image_bytes: int = 16 * 1024 * 1024
    max_request_bytes: int = 32 * 1024 * 1024

    def __post_init__(self) -> None:
        if not isinstance(self.default_runtime, RuntimeSelection):
            raise TypeError("default_runtime must be a RuntimeSelection")
        if not isinstance(self.default_workspace, WorkspaceRef):
            raise TypeError("default_workspace must be a WorkspaceRef")
        if not self.default_profile.strip() or not self.default_model.strip():
            raise ValueError("default profile and model must not be blank")
        for name, value in (
            ("max_inline_image_bytes", self.max_inline_image_bytes),
            ("max_request_bytes", self.max_request_bytes),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if "default" not in self.mode_profiles:
            raise ValueError("mode_profiles must define the default route")
        if set(self.mode_runtimes).difference(self.mode_profiles):
            raise ValueError("mode_runtimes contains a mode without a profile route")
        _unique_nonblank(self.allowed_profiles, "allowed_profiles")
        _unique_nonblank(self.allowed_runtime_selectors, "allowed_runtime_selectors")
        _unique_nonblank(self.allowed_models, "allowed_models")
        object.__setattr__(self, "mode_profiles", dict(self.mode_profiles))
        object.__setattr__(self, "mode_runtimes", dict(self.mode_runtimes))


class OpenAICompatibilityHost:
    def __init__(
        self,
        application: ARealAgentRuntime,
        config: OpenAICompatibilityConfig,
        *,
        asset_store: AssetStorePort | None = None,
    ) -> None:
        self._application = application
        self._config = config
        self._assets = asset_store

    @property
    def default_model(self) -> str:
        return self._config.default_model

    @property
    def max_request_bytes(self) -> int:
        return self._config.max_request_bytes

    async def complete(self, request: OpenAIChatRequest | dict[str, Any]) -> dict[str, JsonValue]:
        parsed = request if isinstance(request, OpenAIChatRequest) else OpenAIChatRequest.model_validate(request)
        command = await self._decode(parsed)
        ref = await self._application.start_run(command)
        snapshot = await self._application.wait(ref.run_id)
        events = [event async for event in self._application.stream_events(ref.run_id)]
        text = _completed_text(events)
        response: dict[str, JsonValue] = {
            "id": f"chatcmpl-{ref.run_id}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": parsed.model or self.default_model,
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": text},
                    "finish_reason": "stop" if snapshot.error is None else "error",
                }
            ],
        }
        usage = _usage(events)
        if usage is not None:
            response["usage"] = usage
        if snapshot.error is not None:
            response["error"] = snapshot.error
        return response

    async def stream(self, request: OpenAIChatRequest | dict[str, Any]) -> AsyncIterator[str]:
        parsed = request if isinstance(request, OpenAIChatRequest) else OpenAIChatRequest.model_validate(request)
        command = await self._decode(parsed)
        ref = await self._application.start_run(command)
        created = int(time.time())
        model = parsed.model or self.default_model

        def chunk(
            content: str = "",
            finish_reason: str | None = None,
            *,
            role: str | None = None,
        ) -> str:
            delta: dict[str, JsonValue] = {}
            if role is not None:
                delta["role"] = role
            if content:
                delta["content"] = content
            payload: dict[str, JsonValue] = {
                "id": f"chatcmpl-{ref.run_id}",
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": delta,
                        "finish_reason": finish_reason,
                    }
                ],
            }
            return _sse(payload)

        yield chunk(role="assistant")
        saw_delta = False
        async for event in self._application.stream_events(ref.run_id):
            if event.type == EventType.MESSAGE_DELTA:
                text = _event_text(event)
                if text:
                    saw_delta = True
                    yield chunk(text)
            elif event.type == EventType.MESSAGE_COMPLETED and not saw_delta:
                text = _event_text(event)
                if text:
                    yield chunk(text)
            elif event.type == EventType.RUN_COMPLETED:
                yield chunk(finish_reason="stop")
            elif event.type in {EventType.RUN_FAILED, EventType.RUN_CANCELLED}:
                yield chunk(finish_reason="error")
        yield "data: [DONE]\n\n"

    async def _decode(self, request: OpenAIChatRequest) -> StartRunCommand:
        if request.execution_mode not in self._config.mode_profiles:
            raise _request_error("ROUTE_NOT_ALLOWED", f"unknown execution mode: {request.execution_mode}")
        profile = request.profile or self._config.mode_profiles[request.execution_mode] or self._config.default_profile
        allowed_profiles = set(self._config.allowed_profiles)
        if request.profile is not None and (not allowed_profiles or profile not in allowed_profiles):
            raise _request_error("PROFILE_NOT_ALLOWED", f"profile is not allowed: {profile}")

        configured_runtime = self._config.mode_runtimes.get(
            request.execution_mode,
            self._config.default_runtime,
        )
        selector = request.runtime or configured_runtime.selector
        allowed_runtimes = set(self._config.allowed_runtime_selectors)
        if request.runtime is not None and (not allowed_runtimes or selector not in allowed_runtimes):
            raise _request_error("RUNTIME_NOT_ALLOWED", f"runtime override is not allowed: {selector}")
        allowed_models = set(self._config.allowed_models)
        if request.model is not None and (not allowed_models or request.model not in allowed_models):
            raise _request_error("MODEL_NOT_ALLOWED", f"model override is not allowed: {request.model}")
        session_id = request.session_id or new_id("ses")
        return StartRunCommand(
            profile=profile,
            input=await self._decode_messages(request.messages),
            runtime=RuntimeSelection(selector=selector, model=request.model or configured_runtime.model),
            workspace=session_scoped_workspace(self._config.default_workspace, session_id),
            session_id=session_id,
            resume_session=request.session_id is not None,
            metadata={"host": "openai-compat", "executionMode": request.execution_mode, **request.metadata},
        )

    async def _decode_messages(self, messages: tuple[OpenAIMessage, ...]) -> tuple[ContentBlock, ...]:
        blocks: list[ContentBlock] = []
        prefix_roles = len(messages) > 1
        for message in messages:
            if isinstance(message.content, str):
                text = f"[{message.role}] {message.content}" if prefix_roles else message.content
                blocks.append(TextBlock(text=text))
                continue
            for part in message.content:
                if not isinstance(part, dict):
                    continue
                kind = part.get("type")
                if kind in {"text", "input_text"} and isinstance(part.get("text"), str):
                    text = str(part["text"])
                    blocks.append(TextBlock(text=f"[{message.role}] {text}" if prefix_roles else text))
                elif kind in {"image_url", "input_image"}:
                    blocks.append(await self._decode_image(part))
        if not blocks:
            raise _request_error("INVALID_MESSAGES", "messages contain no supported content")
        return tuple(blocks)

    async def _decode_image(self, part: dict[str, JsonValue]) -> ImageRefBlock:
        asset_id = _string(part.get("assetId")) or _string(part.get("asset_id"))
        media_type = _string(part.get("mediaType")) or _string(part.get("media_type")) or "image/png"
        image_url = part.get("image_url")
        url = _string(image_url.get("url")) if isinstance(image_url, dict) else _string(image_url)
        if asset_id is None and url and url.startswith("asset://"):
            asset_id = url.removeprefix("asset://")
        if asset_id:
            return ImageRefBlock(asset_id=asset_id, media_type=media_type)
        if not url or not url.startswith("data:image/") or self._assets is None:
            raise _request_error("ATTACHMENT_INVALID", "upload an AssetRef or use an inline data image")
        header, encoded = url.split(",", 1)
        if ";base64" not in header:
            raise _request_error("ATTACHMENT_INVALID", "only base64 data image URLs are supported")
        media_type = header.removeprefix("data:").split(";", 1)[0]
        max_encoded = 4 * ((self._config.max_inline_image_bytes + 2) // 3)
        if len(encoded) > max_encoded:
            raise _request_error("ATTACHMENT_INVALID", "inline image exceeds the configured limit")
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error) as exc:
            raise _request_error("ATTACHMENT_INVALID", "invalid base64 image data") from exc
        if len(raw) > self._config.max_inline_image_bytes:
            raise _request_error("ATTACHMENT_INVALID", "inline image exceeds the configured limit")

        async def chunks() -> AsyncIterator[bytes]:
            yield raw

        ref = await self._assets.put(chunks(), media_type=media_type, metadata={"source": "openai-compat"})
        return ImageRefBlock(asset_id=ref.asset_id, media_type=ref.media_type)


def create_openai_http_app(host: OpenAICompatibilityHost):
    """Expose a bounded Chat Completions-compatible HTTP endpoint."""

    try:
        from fastapi import FastAPI, Request
        from fastapi.responses import JSONResponse, StreamingResponse
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Install areal-agent-runtime[api] to use the OpenAI Host") from exc

    app = FastAPI(title="ARealAgentRuntime OpenAI Compatibility")

    @app.exception_handler(ContractError)
    async def contract_error(_request: Request, exc: ContractError):
        status = {
            ErrorCategory.INVALID_REQUEST: 400,
            ErrorCategory.AUTHENTICATION: 401,
            ErrorCategory.PERMISSION: 403,
            ErrorCategory.NOT_FOUND: 404,
            ErrorCategory.CONFLICT: 409,
            ErrorCategory.RATE_LIMIT: 429,
            ErrorCategory.UNAVAILABLE: 503,
            ErrorCategory.TIMEOUT: 504,
        }.get(exc.info.category, 500)
        if exc.info.code == "REQUEST_TOO_LARGE":
            status = 413
        return JSONResponse(status_code=status, content={"code": exc.info.code, "detail": exc.info.message})

    @app.get("/healthz")
    async def health():
        return {"ok": True, "status": "healthy"}

    @app.get("/readyz")
    async def ready():
        return {"ready": True, "runtimes": len(await host._application.list_runtimes())}

    @app.get("/v1/models")
    async def models():
        return {"object": "list", "data": [{"id": host.default_model, "object": "model"}]}

    @app.post("/v1/chat/completions")
    async def chat(request: Request):
        body = await _read_bounded_json(request, host.max_request_bytes)
        try:
            parsed = OpenAIChatRequest.model_validate(body)
        except ValidationError as exc:
            raise _request_error("REQUEST_INVALID", "chat completion request is invalid") from exc
        if parsed.stream:
            return StreamingResponse(host.stream(parsed), media_type="text/event-stream")
        return await host.complete(parsed)

    return app


def _event_text(event: RunEvent) -> str:
    if not isinstance(event.data, dict):
        return ""
    content = event.data.get("content")
    if not isinstance(content, list):
        delta = event.data.get("delta")
        content = delta if isinstance(delta, list) else []
    result: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") in {"text", "reasoning"}:
            text = block.get("text")
            if isinstance(text, str):
                result.append(text)
    return "".join(result)


def _completed_text(events: list[RunEvent]) -> str:
    completed = [_event_text(event) for event in events if event.type == EventType.MESSAGE_COMPLETED]
    return "".join(text for text in completed if text)


def _usage(events: list[RunEvent]) -> JsonValue | None:
    for event in reversed(events):
        if event.type == EventType.USAGE_UPDATED and isinstance(event.data, dict):
            return event.data.get("usage")
    return None


def _unique_nonblank(values: tuple[str, ...], field_name: str) -> None:
    if any(not value.strip() or value != value.strip() for value in values):
        raise ValueError(f"{field_name} must contain trimmed non-blank values")
    if len(values) != len(set(values)):
        raise ValueError(f"{field_name} must not contain duplicates")


def _string(value: JsonValue | None) -> str | None:
    return value if isinstance(value, str) and value else None


def _sse(payload: dict[str, JsonValue]) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False, separators=(',', ':'))}\n\n"


async def _read_bounded_json(request: Any, max_bytes: int) -> object:
    declared_length = request.headers.get("content-length")
    if declared_length is not None:
        try:
            parsed_length = int(declared_length)
        except ValueError as exc:
            raise _request_error("REQUEST_LENGTH_INVALID", "Content-Length is invalid") from exc
        if parsed_length < 0:
            raise _request_error("REQUEST_LENGTH_INVALID", "Content-Length is invalid")
        if parsed_length > max_bytes:
            raise _request_error("REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > max_bytes:
            raise _request_error("REQUEST_TOO_LARGE", "request exceeds the configured byte limit")
    try:
        return json.loads(bytes(raw), parse_constant=_reject_json_constant)
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, RecursionError) as exc:
        raise _request_error("REQUEST_JSON_INVALID", "request body must be valid JSON") from exc


def _reject_json_constant(_value: str) -> None:
    raise ValueError("non-finite JSON numbers are not accepted")


def _request_error(code: str, message: str) -> ContractError:
    return ContractError(
        ErrorInfo(code=code, category=ErrorCategory.INVALID_REQUEST, message=message)
    )
