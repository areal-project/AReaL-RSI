"""Versioned canonical data-plane contracts.

The v1 ``RunEvent`` remains the compatibility/operational log.  Models in this
module are a typed, versioned projection used for cross-Harness query,
evaluation and training joins.  Unstructured vendor data is legal only inside
``RawEventObservation`` and is always labelled as such.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated, Literal

from pydantic import Field, JsonValue, StrictBool, StrictFloat, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel, require_optional_trimmed, require_trimmed
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.errors import ErrorInfo
from areal_agent_runtime.contracts.version import DATA_API_VERSION, DataApiVersion


class MessageCoverage(StrEnum):
    NONE = "none"
    FINAL = "final"
    FULL = "full"


class DetailCoverage(StrEnum):
    NONE = "none"
    AGGREGATE = "aggregate"
    FULL = "full"


class UsageCoverage(StrEnum):
    NONE = "none"
    NORMALIZED = "normalized"
    TOKEN_LEVEL = "token-level"


class CheckpointCoverage(StrEnum):
    NONE = "none"
    OPAQUE = "opaque"
    PORTABLE = "portable"


class RawEventCoverage(StrEnum):
    NONE = "none"
    REFERENCE = "reference"
    FULL = "full"


class TrainingSignalCoverage(StrEnum):
    NONE = "none"
    REWARD_ONLY = "reward-only"
    TOKEN_LEVEL = "token-level"


class CanonicalFinishReason(StrEnum):
    """Small cross-Harness finish taxonomy used by canonical views."""

    STOP = "stop"
    TOOL_CALL = "tool-call"
    LENGTH = "length"
    INTERACTION = "interaction"
    CANCELLED = "cancelled"
    ERROR = "error"
    UNKNOWN = "unknown"


class DataCoverage(ContractModel):
    """Machine-readable data fidelity promised by one Harness adapter."""

    messages: MessageCoverage = MessageCoverage.NONE
    model_calls: DetailCoverage = DetailCoverage.NONE
    tool_calls: DetailCoverage = DetailCoverage.NONE
    usage: UsageCoverage = UsageCoverage.NONE
    child_agents: DetailCoverage = DetailCoverage.NONE
    checkpoint: CheckpointCoverage = CheckpointCoverage.NONE
    raw_events: RawEventCoverage = RawEventCoverage.NONE
    training_signals: TrainingSignalCoverage = TrainingSignalCoverage.NONE


class RunIdentityContext(ContractModel):
    """Caller-owned identities which must not be inferred from ``runId``.

    The fields are optional so Product/Event v1 payloads remain source and wire
    compatible.  When omitted, only ``correlationId`` keeps the historical
    ``runId`` fallback in the compatibility event envelope.
    """

    tenant_id: str | None = None
    project_id: str | None = None
    correlation_id: str | None = None
    trace_id: str | None = None
    episode_id: str | None = None

    @field_validator(
        "tenant_id",
        "project_id",
        "correlation_id",
        "trace_id",
        "episode_id",
    )
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "run context identity")


class DataClassification(StrEnum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class RetentionClass(StrEnum):
    TRANSIENT = "transient"
    STANDARD = "standard"
    AUDIT = "audit"
    LEGAL_HOLD = "legal-hold"


class RedactionStatus(StrEnum):
    NOT_REQUIRED = "not-required"
    APPLIED = "applied"
    REQUIRED = "required"


class DataGovernance(ContractModel):
    classification: DataClassification = DataClassification.INTERNAL
    retention: RetentionClass = RetentionClass.STANDARD
    redaction: RedactionStatus = RedactionStatus.NOT_REQUIRED
    policy_id: str = "runtime-default/v1"

    @field_validator("policy_id")
    @classmethod
    def validate_policy_id(cls, value: str) -> str:
        return require_trimmed(value, "data governance policyId")


class SchemaReference(ContractModel):
    namespace: str = Field(min_length=1)
    version: str = Field(min_length=1)

    @field_validator("namespace", "version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "schema reference identity")


class ObservationLineage(ContractModel):
    tenant_id: str | None = None
    project_id: str | None = None
    session_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    execution_id: str | None = None
    agent_attempt_id: str | None = None
    agent_id: str | None = None
    parent_agent_id: str | None = None
    model_call_id: str | None = None
    message_id: str | None = None
    tool_call_id: str | None = None
    interaction_id: str | None = None
    correlation_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    episode_id: str | None = None
    environment_id: str | None = None
    agent_environment_id: str | None = None
    workspace_id: str | None = None

    @field_validator("session_id", "run_id")
    @classmethod
    def validate_required_identity(cls, value: str) -> str:
        return require_trimmed(value, "observation lineage identity")

    @field_validator(
        "tenant_id",
        "project_id",
        "execution_id",
        "agent_attempt_id",
        "agent_id",
        "parent_agent_id",
        "model_call_id",
        "message_id",
        "tool_call_id",
        "interaction_id",
        "correlation_id",
        "trace_id",
        "span_id",
        "episode_id",
        "environment_id",
        "agent_environment_id",
        "workspace_id",
    )
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "observation lineage identity")

    @model_validator(mode="after")
    def validate_hierarchy(self) -> ObservationLineage:
        execution_children = (
            self.agent_attempt_id,
            self.model_call_id,
            self.tool_call_id,
            self.interaction_id,
        )
        if self.execution_id is None and any(value is not None for value in execution_children):
            raise ValueError("attempt/model/tool/interaction lineage requires executionId")
        if self.parent_agent_id is not None and self.agent_id is None:
            raise ValueError("parentAgentId requires agentId")
        if self.parent_agent_id is not None and self.parent_agent_id == self.agent_id:
            raise ValueError("an agent cannot be its own parent")
        return self


class NormalizedUsage(ContractModel):
    input_tokens: StrictInt | None = Field(default=None, ge=0)
    output_tokens: StrictInt | None = Field(default=None, ge=0)
    total_tokens: StrictInt | None = Field(default=None, ge=0)
    cached_input_tokens: StrictInt | None = Field(default=None, ge=0)
    cache_write_tokens: StrictInt | None = Field(default=None, ge=0)
    reasoning_tokens: StrictInt | None = Field(default=None, ge=0)
    scope: Literal["model-call", "execution", "run"] = "model-call"
    cumulative: StrictBool = False

    @model_validator(mode="after")
    def require_a_measurement(self) -> NormalizedUsage:
        measurements = (
            self.input_tokens,
            self.output_tokens,
            self.total_tokens,
            self.cached_input_tokens,
            self.cache_write_tokens,
            self.reasoning_tokens,
        )
        if all(value is None for value in measurements):
            raise ValueError("normalized usage requires at least one token measurement")
        return self


class LifecycleObservation(ContractModel):
    kind: Literal["lifecycle"] = "lifecycle"
    event_type: str = Field(min_length=1)
    phase: Literal["started", "completed", "failed", "cancelled", "waiting", "updated"]
    finish_reason: CanonicalFinishReason | None = None
    error: ErrorInfo | None = None
    duration_seconds: StrictFloat | None = Field(default=None, ge=0)

    @field_validator("event_type")
    @classmethod
    def validate_event_type(cls, value: str) -> str:
        return require_trimmed(value, "lifecycle eventType")

class StreamingSignalObservation(ContractModel):
    kind: Literal["streaming-signal"] = "streaming-signal"
    signal_type: Literal["message-delta", "reasoning-delta", "tool-progress"]
    content: tuple[ContentBlock, ...] = ()
    text: str | None = None
    final: StrictBool = False
    durable_semantic_fact: Literal[False] = False


class MessageObservation(ContractModel):
    kind: Literal["message"] = "message"
    role: Literal["system", "user", "assistant", "tool"]
    content: tuple[ContentBlock, ...] = Field(min_length=1)
    final: Literal[True] = True
    identity_source: Literal["producer", "projection"] = "producer"


class ModelCallObservation(ContractModel):
    kind: Literal["model-call"] = "model-call"
    phase: Literal["started", "completed", "failed"]
    provider: str | None = None
    model: str | None = None
    provider_request_id: str | None = None
    finish_reason: CanonicalFinishReason | None = None
    error: ErrorInfo | None = None
    duration_seconds: StrictFloat | None = Field(default=None, ge=0)
    attempt: StrictInt = Field(default=1, ge=1)

    @field_validator("provider", "model", "provider_request_id")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "model call identity")

    @model_validator(mode="after")
    def validate_phase(self) -> ModelCallObservation:
        if self.phase == "failed" and self.error is None:
            raise ValueError("failed model call requires error")
        if self.phase != "failed" and self.error is not None:
            raise ValueError("model call error is only valid for failed phase")
        return self


class UsageObservation(ContractModel):
    kind: Literal["usage"] = "usage"
    usage: NormalizedUsage


class ToolCallObservation(ContractModel):
    kind: Literal["tool-call"] = "tool-call"
    phase: Literal["requested", "started", "completed", "failed"]
    name: str = Field(min_length=1)
    arguments: dict[str, JsonValue] | None = None
    content: tuple[ContentBlock, ...] = ()
    value: JsonValue = None
    error: ErrorInfo | None = None
    duration_seconds: StrictFloat | None = Field(default=None, ge=0)

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        return require_trimmed(value, "tool call name")

    @model_validator(mode="after")
    def validate_phase(self) -> ToolCallObservation:
        if self.phase == "failed" and self.error is None:
            raise ValueError("failed tool call requires error")
        if self.phase != "failed" and self.error is not None:
            raise ValueError("tool call error is only valid for failed phase")
        return self


class InteractionObservation(ContractModel):
    kind: Literal["interaction"] = "interaction"
    phase: Literal["required", "resolved"]
    interaction_kind: str | None = None
    request: JsonValue = None
    terminal: StrictBool = False
    commit_barrier: StrictBool = False
    pending_interactions: StrictInt | None = Field(default=None, ge=0)

    @field_validator("interaction_kind")
    @classmethod
    def validate_kind(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "interaction kind")


class RawEventObservation(ContractModel):
    """Governed escape hatch.  Arbitrary JSON is never presented as canonical semantics."""

    kind: Literal["raw-event"] = "raw-event"
    producer: str = Field(min_length=1)
    vendor_event_type: str = Field(min_length=1)
    reason: Literal["unknown-event", "unsupported-event", "canonicalization-failed"]
    storage: Literal["inline", "asset-ref"] = "inline"
    inline: JsonValue = None
    asset_id: str | None = None

    @field_validator("producer", "vendor_event_type")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "raw event identity")

    @field_validator("asset_id")
    @classmethod
    def validate_asset_id(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "raw event assetId")

    @model_validator(mode="after")
    def require_content(self) -> RawEventObservation:
        if self.storage == "asset-ref" and self.asset_id is None:
            raise ValueError("asset-ref raw event requires assetId")
        if self.storage == "inline" and self.asset_id is not None:
            raise ValueError("inline raw event cannot include assetId")
        if self.storage == "asset-ref" and self.inline is not None:
            raise ValueError("asset-ref raw event cannot also inline payload")
        return self


class RewardAnnotationPayload(ContractModel):
    kind: Literal["reward"] = "reward"
    value: float
    name: str = "reward"

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str) -> str:
        return require_trimmed(value, "reward name")


class EvaluationAnnotationPayload(ContractModel):
    kind: Literal["evaluation"] = "evaluation"
    label: str = Field(min_length=1)
    score: float | None = None
    passed: StrictBool | None = None

    @field_validator("label")
    @classmethod
    def validate_label(cls, value: str) -> str:
        return require_trimmed(value, "evaluation label")


AnnotationPayload = Annotated[
    RewardAnnotationPayload | EvaluationAnnotationPayload,
    Field(discriminator="kind"),
]


class DataAnnotation(ContractModel):
    api_version: DataApiVersion = DATA_API_VERSION
    annotation_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    created_at: datetime
    source: str = Field(min_length=1)
    payload: AnnotationPayload
    governance: DataGovernance = Field(default_factory=DataGovernance)
    execution_id: str | None = None
    model_call_id: str | None = None
    interaction_id: str | None = None

    @field_validator("annotation_id", "run_id", "source")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "annotation identity")

    @field_validator("execution_id", "model_call_id", "interaction_id")
    @classmethod
    def validate_optional_identity(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "annotation target identity")

    @field_validator("created_at")
    @classmethod
    def validate_created_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("annotation createdAt must include a timezone")
        return value

    @model_validator(mode="after")
    def require_target(self) -> DataAnnotation:
        if self.model_call_id is not None and self.execution_id is None:
            raise ValueError("annotation modelCallId requires executionId")
        if self.interaction_id is not None and self.execution_id is None:
            raise ValueError("annotation interactionId requires executionId")
        return self


class AnnotationObservation(ContractModel):
    kind: Literal["annotation"] = "annotation"
    annotation: DataAnnotation


ObservationPayload = Annotated[
    LifecycleObservation
    | StreamingSignalObservation
    | MessageObservation
    | ModelCallObservation
    | UsageObservation
    | ToolCallObservation
    | InteractionObservation
    | RawEventObservation
    | AnnotationObservation,
    Field(discriminator="kind"),
]


class CanonicalObservation(ContractModel):
    api_version: DataApiVersion = DATA_API_VERSION
    observation_id: str = Field(min_length=1)
    sequence: StrictInt = Field(ge=0)
    time: datetime
    source_event_id: str = Field(min_length=1)
    source_event_api_version: str = Field(min_length=1)
    # Additive metadata for Data API consumers. It remains optional so already
    # persisted/constructed data/v1 observations continue to validate.
    source_event_type: str | None = None
    schema_ref: SchemaReference = Field(
        validation_alias="schema",
        serialization_alias="schema",
    )
    lineage: ObservationLineage
    governance: DataGovernance
    payload: ObservationPayload

    @field_validator("observation_id", "source_event_id", "source_event_api_version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "canonical observation identity")

    @field_validator("source_event_type")
    @classmethod
    def validate_source_event_type(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "canonical observation source event type")

    @field_validator("time")
    @classmethod
    def validate_time(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("observation time must include a timezone")
        return value


class ObservationPage(ContractModel):
    observations: tuple[CanonicalObservation, ...]
    next_cursor: StrictInt | None = Field(default=None, ge=0)


class CoverageDimensionReport(ContractModel):
    dimension: Literal[
        "messages",
        "modelCalls",
        "toolCalls",
        "usage",
        "childAgents",
        "checkpoint",
        "rawEvents",
        "trainingSignals",
    ]
    declared: str
    observed: str
    exercised: StrictBool
    verified: StrictBool
    issues: tuple[str, ...] = ()


class DataCoverageReport(ContractModel):
    declared: DataCoverage
    dimensions: tuple[CoverageDimensionReport, ...]

    @property
    def valid(self) -> bool:
        return all(not item.issues for item in self.dimensions)

    @property
    def complete(self) -> bool:
        """Whether every non-``none`` declaration was exercised and verified."""

        return all(
            item.verified and (item.declared == "none" or item.exercised)
            for item in self.dimensions
        )


class CheckpointState(ContractModel):
    checkpoint_id: str
    kind: Literal["workspace", "runtime-opaque", "runtime-portable"]
    status: Literal["available", "unavailable"] = "available"
    digest: str | None = None
    locator: str | None = None

    @field_validator("checkpoint_id")
    @classmethod
    def validate_checkpoint_id(cls, value: str) -> str:
        return require_trimmed(value, "checkpoint identity")

    @field_validator("digest", "locator")
    @classmethod
    def validate_optional_value(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "checkpoint value")


class ToolCallState(ContractModel):
    tool_call_id: str
    execution_id: str
    name: str
    status: Literal["requested", "running", "completed", "failed"]
    model_call_id: str | None = None
    error: ErrorInfo | None = None


class InteractionState(ContractModel):
    interaction_id: str
    execution_id: str
    kind: str | None = None
    status: Literal["pending", "resolved"]
    terminal: StrictBool = False


class ModelCallState(ContractModel):
    model_call_id: str
    execution_id: str
    status: Literal["running", "completed", "failed"]
    provider: str | None = None
    model: str | None = None
    finish_reason: CanonicalFinishReason | None = None
    error: ErrorInfo | None = None


class AgentAttemptState(ContractModel):
    agent_attempt_id: str
    execution_id: str
    agent_id: str | None = None
    status: Literal["running", "completed", "failed", "cancelled"]


class ExecutionState(ContractModel):
    execution_id: str
    agent_attempt_id: str
    agent_id: str | None = None
    status: Literal["pending", "running", "waiting", "completed", "failed", "cancelled"]
    model_calls: tuple[ModelCallState, ...] = ()
    tool_calls: tuple[ToolCallState, ...] = ()
    interactions: tuple[InteractionState, ...] = ()
    checkpoints: tuple[CheckpointState, ...] = ()
    error: ErrorInfo | None = None


class DataRunState(ContractModel):
    run_id: str
    session_id: str
    status: Literal["queued", "running", "waiting", "completed", "failed", "cancelled"]
    revision: StrictInt = Field(ge=-1)
    context: RunIdentityContext = Field(default_factory=RunIdentityContext)
    environment_id: str | None = None
    workspace_id: str | None = None
    checkpoints: tuple[CheckpointState, ...] = ()
    agent_attempts: tuple[AgentAttemptState, ...] = ()
    executions: tuple[ExecutionState, ...] = ()


class SessionState(ContractModel):
    session_id: str
    revision: StrictInt = Field(ge=-1)
    run_ids: tuple[str, ...]
    active_run_ids: tuple[str, ...] = ()


class RunPage(ContractModel):
    runs: tuple[DataRunState, ...]
    next_cursor: StrictInt | None = Field(default=None, ge=0)


class CommandKind(StrEnum):
    CANCEL = "cancel"
    STEER = "steer"
    RESPOND = "respond"


class RuntimeCommand(ContractModel):
    """Durable control request; it is deliberately not an observation/event."""

    command_id: str
    kind: CommandKind
    run_id: str
    execution_id: str | None = None
    interaction_id: str | None = None
    expected_revision: StrictInt = Field(ge=-1)
    fencing_token: StrictInt = Field(ge=0)
    payload: JsonValue = None
    created_at: datetime

    @field_validator("command_id", "run_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "command identity")

    @field_validator("execution_id", "interaction_id")
    @classmethod
    def validate_optional_target(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "command target")

    @field_validator("created_at")
    @classmethod
    def validate_created_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("command createdAt must include a timezone")
        return value

    @model_validator(mode="after")
    def validate_target(self) -> RuntimeCommand:
        if self.kind == CommandKind.RESPOND and self.interaction_id is None:
            raise ValueError("respond command requires interactionId")
        return self


class CommandReceipt(ContractModel):
    command_id: str
    status: Literal["accepted", "applied", "rejected"]
    revision: StrictInt = Field(ge=-1)
    reason: str | None = None

    @field_validator("command_id")
    @classmethod
    def validate_command_id(cls, value: str) -> str:
        return require_trimmed(value, "command receipt identity")

    @field_validator("reason")
    @classmethod
    def validate_reason(cls, value: str | None) -> str | None:
        return require_optional_trimmed(value, "command receipt reason")


class TrajectoryPurpose(StrEnum):
    CONVERSATION = "conversation"
    AUDIT = "audit"
    EVALUATION = "evaluation"
    TRAINING = "training"


class TrajectoryView(ContractModel):
    api_version: DataApiVersion = DATA_API_VERSION
    run_id: str
    session_id: str
    purpose: TrajectoryPurpose
    observations: tuple[CanonicalObservation, ...]
    annotations: tuple[DataAnnotation, ...] = ()
    trainable: StrictBool = False


class ModelCallTrainingRecord(ContractModel):
    """Token-level facts supplied by AReaL/another instrumented inference plane."""

    model_call_id: str
    interaction_id: str
    input_token_ids: tuple[StrictInt, ...]
    output_token_ids: tuple[StrictInt, ...] = Field(min_length=1)
    output_logprobs: tuple[StrictFloat, ...] = Field(min_length=1)
    output_versions: tuple[StrictInt, ...] = Field(min_length=1)
    reward: float | None = None

    @field_validator("model_call_id", "interaction_id")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "training record identity")

    @model_validator(mode="after")
    def validate_token_alignment(self) -> ModelCallTrainingRecord:
        length = len(self.output_token_ids)
        if len(self.output_logprobs) != length or len(self.output_versions) != length:
            raise ValueError("output token ids, logprobs and versions must have equal lengths")
        if any(version < 0 for version in self.output_versions):
            raise ValueError("output versions must contain real non-negative policy versions")
        return self


class ARealModelResponseRecord(ContractModel):
    """Fields copied from AReaL ``ModelResponse`` without text reconstruction."""

    input_tokens: tuple[StrictInt, ...]
    output_tokens: tuple[StrictInt, ...] = Field(min_length=1)
    output_logprobs: tuple[StrictFloat, ...] = Field(min_length=1)
    output_versions: tuple[StrictInt, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_alignment(self) -> ARealModelResponseRecord:
        length = len(self.output_tokens)
        if len(self.output_logprobs) != length or len(self.output_versions) != length:
            raise ValueError("AReaL output tokens, logprobs and versions must have equal lengths")
        if any(version < 0 for version in self.output_versions):
            raise ValueError("AReaL output versions must be real non-negative policy versions")
        return self


class ARealTrainingSample(ContractModel):
    """Executable join fixture for AReaL's ModelResponse + interaction reward."""

    model_call_id: str
    interaction_id: str
    model_response: ARealModelResponseRecord
    reward: float
    lineage: ObservationLineage

    def to_areal_fixture(self) -> dict[str, object]:
        """Return snake_case values accepted by a thin AReaL integration shim."""

        return {
            "interaction_id": self.interaction_id,
            "model_call_id": self.model_call_id,
            "model_response": {
                "input_tokens": list(self.model_response.input_tokens),
                "output_tokens": list(self.model_response.output_tokens),
                "output_logprobs": list(self.model_response.output_logprobs),
                "output_versions": list(self.model_response.output_versions),
            },
            "reward": self.reward,
            "runtime_lineage": self.lineage.model_dump(mode="json", by_alias=True),
        }


class RewardOnlySample(ContractModel):
    model_call_id: str
    interaction_id: str | None = None
    reward: float
    lineage: ObservationLineage


class TrainingProjection(ContractModel):
    run_id: str
    mode: Literal["token-level", "reward-only"]
    trainable: StrictBool
    samples: tuple[ARealTrainingSample, ...] = ()
    reward_only: tuple[RewardOnlySample, ...] = ()
    rejected: tuple[str, ...] = ()

    def to_areal_fixtures(self) -> tuple[dict[str, object], ...]:
        if self.mode != "token-level" or not self.trainable:
            raise ValueError("only a validated token-level projection is AReaL trainable")
        return tuple(sample.to_areal_fixture() for sample in self.samples)
