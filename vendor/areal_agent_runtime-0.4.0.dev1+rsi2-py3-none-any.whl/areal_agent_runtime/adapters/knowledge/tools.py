"""Request-scoped knowledge catalog exposed through the generic ToolProvider port."""

from __future__ import annotations

import asyncio
import hashlib
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from areal_agent_runtime.contracts.content import TextBlock
from areal_agent_runtime.contracts.errors import ErrorCategory, ErrorInfo
from areal_agent_runtime.contracts.knowledge import KnowledgeRef
from areal_agent_runtime.contracts.runtime import HealthStatus, ToolCall, ToolResult, ToolSpec

KNOWLEDGE_TOOL_NAMES = ("knowledge.list", "knowledge.read")
_ALLOWED_SUFFIXES = frozenset({".md", ".txt", ".json", ".yaml", ".yml", ".csv", ".tsv"})
_KNOWLEDGE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_DIRECTORY_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
_FILE_OPEN_FLAGS = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)


@dataclass(frozen=True, slots=True)
class LocalKnowledgeConfig:
    roots: dict[str, Path]
    max_file_bytes: int = 256 * 1024
    max_selected_bundles: int = 32

    def __post_init__(self) -> None:
        if not isinstance(self.roots, dict) or not self.roots or any(
            not isinstance(source, str)
            or _KNOWLEDGE_NAME_RE.fullmatch(source) is None
            or not isinstance(root, Path)
            for source, root in self.roots.items()
        ):
            raise ValueError("roots must map non-empty source names to Path values")
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 1
            for value in (self.max_file_bytes, self.max_selected_bundles)
        ):
            raise ValueError("knowledge limits must be positive integers")


class LocalKnowledgeToolProvider:
    def __init__(self, config: LocalKnowledgeConfig) -> None:
        self._config = config
        self._roots = {source: root.expanduser().resolve() for source, root in config.roots.items()}

    async def list_tools(self) -> tuple[ToolSpec, ...]:
        return (
            ToolSpec(
                name="knowledge.list",
                description="List the request-authorized knowledge bundles and their SKILL.md summaries.",
                input_schema={"type": "object", "properties": {}, "additionalProperties": False},
                permissions=("knowledge.read",),
            ),
            ToolSpec(
                name="knowledge.read",
                description=(
                    "Read one bounded UTF-8 file from a request-authorized knowledge bundle. "
                    "Use path=SKILL.md first, then read only references it explicitly requires."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "source": {"type": "string", "minLength": 1},
                        "name": {"type": "string", "minLength": 1, "maxLength": 64},
                        "path": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 4096,
                            "default": "SKILL.md",
                        },
                    },
                    "required": ["source", "name"],
                    "additionalProperties": False,
                },
                permissions=("knowledge.read",),
            ),
        )

    async def invoke(self, call: ToolCall) -> ToolResult:
        try:
            self._validate_selection_count(call.knowledge)
            if call.name == "knowledge.list":
                value = await self._list(call.knowledge)
                return ToolResult(call_id=call.call_id, value=value)
            if call.name == "knowledge.read":
                value, text = await self._read(call)
                return ToolResult(call_id=call.call_id, content=(TextBlock(text=text),), value=value)
            return self._error(call.call_id, "KNOWLEDGE_TOOL_UNKNOWN", ErrorCategory.NOT_FOUND, call.name)
        except _KnowledgeError as exc:
            return self._error(call.call_id, exc.code, exc.category, exc.message)

    async def health(self) -> HealthStatus:
        missing = [source for source, root in self._roots.items() if not root.is_dir()]
        return HealthStatus(
            status="degraded" if missing else "healthy",
            details={"sources": sorted(self._roots), "missingSources": sorted(missing)},
        )

    async def _list(self, selected: tuple[KnowledgeRef, ...]) -> dict[str, object]:
        bundles = []
        for ref in selected:
            text = await asyncio.to_thread(self._read_ref, ref, "SKILL.md")
            bundles.append(
                {
                    "source": ref.source,
                    "name": ref.name,
                    "revision": ref.revision,
                    "description": self._frontmatter_description(text),
                    "skillSha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                }
            )
        return {"bundles": bundles}

    async def _read(self, call: ToolCall) -> tuple[dict[str, object], str]:
        source = self._argument(call, "source")
        name = self._argument(call, "name")
        relative = call.arguments.get("path", "SKILL.md")
        if not isinstance(relative, str) or not relative:
            raise _KnowledgeError("KNOWLEDGE_PATH_INVALID", ErrorCategory.INVALID_REQUEST, "path must be a string")
        selected = next(
            (ref for ref in call.knowledge if ref.source == source and ref.name == name),
            None,
        )
        if selected is None:
            raise _KnowledgeError(
                "KNOWLEDGE_NOT_AUTHORIZED",
                ErrorCategory.PERMISSION,
                f"Knowledge bundle was not selected for this Run: {source}/{name}",
            )
        text = await asyncio.to_thread(self._read_ref, selected, relative)
        return (
            {
                "source": source,
                "name": name,
                "revision": selected.revision,
                "path": relative,
                "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                "characters": len(text),
            },
            text,
        )

    def _resolve_relative(self, ref: KnowledgeRef, relative: str) -> tuple[Path, PurePosixPath]:
        root = self._roots.get(ref.source)
        if root is None:
            raise _KnowledgeError(
                "KNOWLEDGE_SOURCE_UNKNOWN",
                ErrorCategory.INVALID_REQUEST,
                f"Unknown knowledge source: {ref.source}",
            )
        candidate = PurePosixPath(relative)
        if (
            len(relative) > 4096
            or "\x00" in relative
            or candidate.is_absolute()
            or not candidate.parts
            or candidate.as_posix() != relative
            or any(part in {"", ".", ".."} for part in candidate.parts)
        ):
            raise _KnowledgeError(
                "KNOWLEDGE_PATH_INVALID",
                ErrorCategory.INVALID_REQUEST,
                "Knowledge path must be a normalized relative path",
            )
        if candidate.suffix.lower() not in _ALLOWED_SUFFIXES:
            raise _KnowledgeError(
                "KNOWLEDGE_FILE_TYPE_UNSUPPORTED",
                ErrorCategory.INVALID_REQUEST,
                f"Unsupported knowledge file type: {candidate.suffix or '<none>'}",
            )
        return root, PurePosixPath(ref.name) / candidate

    def _read_ref(self, ref: KnowledgeRef, relative: str) -> str:
        root, path = self._resolve_relative(ref, relative)
        current_descriptor: int | None = None
        file_descriptor: int | None = None
        try:
            current_descriptor = os.open(root, _DIRECTORY_OPEN_FLAGS)
            for part in path.parts[:-1]:
                next_descriptor = os.open(part, _DIRECTORY_OPEN_FLAGS, dir_fd=current_descriptor)
                os.close(current_descriptor)
                current_descriptor = next_descriptor
            file_descriptor = os.open(path.name, _FILE_OPEN_FLAGS, dir_fd=current_descriptor)
            before = os.fstat(file_descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise _KnowledgeError(
                    "KNOWLEDGE_PATH_INVALID",
                    ErrorCategory.PERMISSION,
                    "Knowledge path must identify a regular file",
                )
            if before.st_size > self._config.max_file_bytes:
                raise _KnowledgeError(
                    "KNOWLEDGE_TOO_LARGE",
                    ErrorCategory.INVALID_REQUEST,
                    f"Knowledge file exceeds {self._config.max_file_bytes} bytes",
                )
            payload = bytearray()
            while chunk := os.read(file_descriptor, min(64 * 1024, self._config.max_file_bytes + 1)):
                payload.extend(chunk)
                if len(payload) > self._config.max_file_bytes:
                    raise _KnowledgeError(
                        "KNOWLEDGE_TOO_LARGE",
                        ErrorCategory.INVALID_REQUEST,
                        f"Knowledge file exceeds {self._config.max_file_bytes} bytes",
                    )
            after = os.fstat(file_descriptor)
            if len(payload) != before.st_size or self._file_identity(before) != self._file_identity(after):
                raise _KnowledgeError(
                    "KNOWLEDGE_READ_CONFLICT",
                    ErrorCategory.CONFLICT,
                    "Knowledge file changed while it was read",
                )
            return bytes(payload).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise _KnowledgeError(
                "KNOWLEDGE_ENCODING_INVALID",
                ErrorCategory.INVALID_REQUEST,
                "Knowledge files must be UTF-8 text",
            ) from exc
        except FileNotFoundError as exc:
            raise _KnowledgeError(
                "KNOWLEDGE_NOT_FOUND",
                ErrorCategory.NOT_FOUND,
                f"Knowledge file not found: {ref.source}/{ref.name}/{relative}",
            ) from exc
        except _KnowledgeError:
            raise
        except OSError as exc:
            raise _KnowledgeError(
                "KNOWLEDGE_PATH_INVALID",
                ErrorCategory.PERMISSION,
                f"Knowledge path cannot be opened safely: {ref.source}/{ref.name}/{relative}",
            ) from exc
        finally:
            if file_descriptor is not None:
                os.close(file_descriptor)
            if current_descriptor is not None:
                os.close(current_descriptor)

    @staticmethod
    def _file_identity(metadata: os.stat_result) -> tuple[int, int, int, int, int, int]:
        return (
            metadata.st_dev,
            metadata.st_ino,
            metadata.st_mode,
            metadata.st_size,
            metadata.st_mtime_ns,
            metadata.st_ctime_ns,
        )

    def _validate_selection_count(self, selected: tuple[KnowledgeRef, ...]) -> None:
        if len(selected) > self._config.max_selected_bundles:
            raise _KnowledgeError(
                "KNOWLEDGE_SELECTION_TOO_LARGE",
                ErrorCategory.INVALID_REQUEST,
                f"At most {self._config.max_selected_bundles} knowledge bundles are allowed",
            )

    @staticmethod
    def _argument(call: ToolCall, name: str) -> str:
        value = call.arguments.get(name)
        if not isinstance(value, str) or _KNOWLEDGE_NAME_RE.fullmatch(value) is None:
            raise _KnowledgeError(
                "KNOWLEDGE_ARGUMENT_INVALID",
                ErrorCategory.INVALID_REQUEST,
                f"{name} must be a normalized knowledge identifier",
            )
        return value

    @staticmethod
    def _frontmatter_description(text: str) -> str:
        lines = text.splitlines()
        if not lines or lines[0].strip() != "---":
            return ""
        for line in lines[1:]:
            if line.strip() == "---":
                break
            key, separator, value = line.partition(":")
            if separator and key.strip() == "description":
                return value.strip().strip("'\"")
        return ""

    @staticmethod
    def _error(call_id: str, code: str, category: ErrorCategory, message: str) -> ToolResult:
        return ToolResult(call_id=call_id, error=ErrorInfo(code=code, category=category, message=message))


class _KnowledgeError(RuntimeError):
    def __init__(self, code: str, category: ErrorCategory, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.category = category
        self.message = message
