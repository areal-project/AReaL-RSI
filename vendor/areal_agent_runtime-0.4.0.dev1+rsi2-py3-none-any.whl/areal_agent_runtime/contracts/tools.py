"""Vendor-neutral tool definitions shared by environment snapshots and Runtime DTOs."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, JsonValue, StrictBool, field_validator

from areal_agent_runtime.contracts.base import ContractModel, require_trimmed, require_unique_trimmed


class ToolExecution(StrEnum):
    APPLICATION = "application"
    RUNTIME = "runtime"
    REMOTE = "remote"


class ToolRepeatPolicy(StrEnum):
    ALLOW = "allow"
    CACHE_THEN_BLOCK = "cache_then_block"


class ToolSpec(ContractModel):
    name: str = Field(min_length=1)
    description: str
    input_schema: dict[str, JsonValue]
    version: str = Field(default="1.0.0", min_length=1)
    execution: ToolExecution = ToolExecution.APPLICATION
    permissions: tuple[str, ...] = ()
    terminal_on_success: StrictBool = False
    repeat_policy: ToolRepeatPolicy = ToolRepeatPolicy.ALLOW

    @field_validator("name", "version")
    @classmethod
    def validate_identity(cls, value: str) -> str:
        return require_trimmed(value, "ToolSpec identity")

    @field_validator("permissions")
    @classmethod
    def validate_permissions(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return require_unique_trimmed(value, "ToolSpec permissions")
