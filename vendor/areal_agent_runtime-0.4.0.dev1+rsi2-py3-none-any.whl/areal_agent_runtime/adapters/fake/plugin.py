"""Plugin packaging for the deterministic development Runtime."""

from __future__ import annotations

from pydantic import JsonValue

from areal_agent_runtime.adapters.fake.runtime import FakeRuntimeAdapter
from areal_agent_runtime.contracts.runtime import HealthStatus
from areal_agent_runtime.plugin_sdk.contracts import PluginContext, PluginEntrypoints, PluginManifest, PortKey


class FakeRuntimePlugin:
    manifest = PluginManifest(
        name="fake-runtime",
        version="1.0.0",
        implements=(PortKey.AGENT_RUNTIME,),
        entrypoints=PluginEntrypoints(local="areal_agent_runtime.adapters.fake.plugin:create_plugin"),
        config_schema="config.schema.json",
    )

    def __init__(self) -> None:
        self.runtime: FakeRuntimeAdapter | None = None

    async def configure(self, context: PluginContext, config: dict[str, JsonValue]) -> None:
        del config
        self.runtime = FakeRuntimeAdapter()
        context.provide(PortKey.AGENT_RUNTIME, self.runtime)

    async def start(self) -> None:
        if self.runtime is None:
            raise RuntimeError("Fake Runtime plugin is not configured")

    async def health(self) -> HealthStatus:
        if self.runtime is None:
            return HealthStatus(status="unhealthy", details={"reason": "not_configured"})
        return await self.runtime.health()

    async def stop(self) -> None:
        if self.runtime is not None:
            await self.runtime.close()


def create_plugin() -> FakeRuntimePlugin:
    return FakeRuntimePlugin()
