"""Runtime-neutral workflow graph contracts and validation."""

from __future__ import annotations

import math
from enum import StrEnum

from pydantic import Field, StrictBool, StrictInt, field_validator, model_validator

from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import ContentBlock
from areal_agent_runtime.contracts.environment import AgentEnvironmentLayer
from areal_agent_runtime.contracts.runtime import Modality


class WorkspaceAccess(StrEnum):
    READ = "read"
    WRITE = "write"
    OVERLAY = "overlay"


class MultiAgentOwnership(StrEnum):
    """The one layer that owns scheduling for a graph scope."""

    APPLICATION = "application"
    RUNTIME_NATIVE = "runtime-native"
    HYBRID = "hybrid"


class JoinMode(StrEnum):
    ALL = "all"
    ANY = "any"
    FIRST_SUCCESS = "first-success"
    QUORUM = "quorum"
    COLLECT = "collect"
    REDUCE = "reduce"


class FailurePolicy(StrEnum):
    FAIL_FAST = "fail-fast"
    WAIT_ALL = "wait-all"
    CONTINUE = "continue"


class TimeoutPolicy(StrEnum):
    FAIL = "fail"
    PARTIAL = "partial"


class CancelPolicy(StrEnum):
    CANCEL_REMAINING = "cancel-remaining"
    LET_FINISH = "let-finish"


class JoinPolicy(ContractModel):
    mode: JoinMode = JoinMode.ALL
    quorum: StrictInt | None = Field(default=None, ge=1)
    timeout_seconds: float | None = Field(default=None, gt=0)
    failure: FailurePolicy = FailurePolicy.FAIL_FAST
    timeout: TimeoutPolicy = TimeoutPolicy.FAIL
    cancel: CancelPolicy = CancelPolicy.CANCEL_REMAINING

    @field_validator("timeout_seconds", mode="before")
    @classmethod
    def validate_timeout_type(cls, value: object) -> object:
        return _finite_number_or_none(value, "join timeoutSeconds")

    @model_validator(mode="after")
    def validate_join(self) -> JoinPolicy:
        if self.timeout_seconds is not None and not math.isfinite(self.timeout_seconds):
            raise ValueError("join timeoutSeconds must be finite")
        if self.timeout_seconds is not None and self.cancel == CancelPolicy.LET_FINISH:
            raise ValueError(
                "join timeoutSeconds requires cancel=cancel-remaining; structured group branches cannot outlive the Run"
            )
        if self.mode == JoinMode.QUORUM and self.quorum is None:
            raise ValueError("quorum join requires quorum")
        if self.mode != JoinMode.QUORUM and self.quorum is not None:
            raise ValueError("quorum is only valid for quorum join")
        return self


class ParallelGroup(ContractModel):
    group_id: str = Field(min_length=1)
    agent_ids: tuple[str, ...] = Field(min_length=2)
    join: JoinPolicy = Field(default_factory=JoinPolicy)

    @field_validator("group_id")
    @classmethod
    def validate_group_id(cls, value: str) -> str:
        return _trimmed(value, "parallel groupId")

    @field_validator("agent_ids")
    @classmethod
    def validate_agent_ids(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return _unique_trimmed(value, "parallel group agentIds")


class AgentInputMode(StrEnum):
    ORIGINAL = "original"
    DEPENDENCIES = "dependencies"
    ORIGINAL_AND_DEPENDENCIES = "original_and_dependencies"


class AgentSpec(ContractModel):
    """Fully resolved, immutable specification consumed by the scheduler.

    Static workflow nodes and accepted dynamic nodes use this exact model.  A
    dynamic planner never authors an ``AgentSpec`` directly; the trusted
    orchestrator resolves one from an ``AgentProfile`` catalog entry.
    """

    agent_id: str = Field(min_length=1)
    agent_profile_id: str | None = None
    agent_profile_version: str | None = None
    role: str = Field(min_length=1)
    depends_on: tuple[str, ...] = ()
    system: tuple[ContentBlock, ...] = ()
    agent_environment: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    runtime_selector: str | None = None
    workspace_access: WorkspaceAccess = WorkspaceAccess.READ
    input_mode: AgentInputMode = AgentInputMode.ORIGINAL_AND_DEPENDENCIES
    required_input_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    required_features: tuple[str, ...] = ()
    tool_names: tuple[str, ...] = ()
    timeout_seconds: float | None = Field(default=None, gt=0)
    max_attempts: StrictInt = Field(default=1, ge=1)
    retry_backoff_seconds: float = Field(default=0, ge=0)
    merge_overlays: tuple[str, ...] = ()
    allow_runtime_subagents: StrictBool = False
    budget_units: StrictInt = Field(default=1, ge=1)

    @field_validator(
        "agent_id",
        "agent_profile_id",
        "agent_profile_version",
        "role",
        "runtime_selector",
    )
    @classmethod
    def validate_identifiers(cls, value: str | None, info) -> str | None:  # type: ignore[no-untyped-def]
        if value is None:
            return None
        return _trimmed(value, f"agent {info.field_name}")

    @field_validator("depends_on", "required_features", "tool_names", "merge_overlays")
    @classmethod
    def validate_string_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return _unique_trimmed(value, f"agent {info.field_name}")

    @field_validator("required_input_modalities")
    @classmethod
    def validate_modalities(cls, value: tuple[Modality, ...]) -> tuple[Modality, ...]:
        if len(value) != len(set(value)):
            raise ValueError("agent requiredInputModalities must not contain duplicates")
        return value

    @field_validator("timeout_seconds", mode="before")
    @classmethod
    def validate_timeout_type(cls, value: object) -> object:
        return _finite_number_or_none(value, "agent timeoutSeconds")

    @field_validator("retry_backoff_seconds", mode="before")
    @classmethod
    def validate_backoff_type(cls, value: object) -> object:
        return _finite_number(value, "agent retryBackoffSeconds")

    @model_validator(mode="after")
    def validate_workspace_policy(self) -> AgentSpec:
        if self.timeout_seconds is not None and not math.isfinite(self.timeout_seconds):
            raise ValueError("agent timeoutSeconds must be finite")
        if not math.isfinite(self.retry_backoff_seconds):
            raise ValueError("agent retryBackoffSeconds must be finite")
        if self.merge_overlays and self.workspace_access != WorkspaceAccess.WRITE:
            raise ValueError("mergeOverlays requires exclusive write workspace access")
        return self


class AgentProfile(ContractModel):
    """Trusted reusable agent definition installed by the application owner."""

    agent_profile_id: str = Field(min_length=1)
    version: str = Field(default="1.0.0", min_length=1)
    role: str = Field(min_length=1)
    system: tuple[ContentBlock, ...] = ()
    agent_environment: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    runtime_selector: str | None = None
    required_input_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    required_features: tuple[str, ...] = ()
    tool_names: tuple[str, ...] = ()
    workspace_access: WorkspaceAccess = WorkspaceAccess.READ
    timeout_seconds: float | None = Field(default=None, gt=0)
    max_attempts: StrictInt = Field(default=1, ge=1)
    retry_backoff_seconds: float = Field(default=0, ge=0)
    allow_runtime_subagents: StrictBool = False

    @field_validator("agent_profile_id", "version", "role", "runtime_selector")
    @classmethod
    def validate_identifiers(cls, value: str | None, info) -> str | None:  # type: ignore[no-untyped-def]
        if value is None:
            return None
        return _trimmed(value, f"agent profile {info.field_name}")

    @field_validator("required_features", "tool_names")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return _unique_trimmed(value, f"agent profile {info.field_name}")

    @field_validator("required_input_modalities")
    @classmethod
    def validate_modalities(cls, value: tuple[Modality, ...]) -> tuple[Modality, ...]:
        if not value:
            raise ValueError("agent profile requiredInputModalities must not be empty")
        if len(value) != len(set(value)):
            raise ValueError("agent profile requiredInputModalities must not contain duplicates")
        return value

    @field_validator("timeout_seconds", mode="before")
    @classmethod
    def validate_timeout_type(cls, value: object) -> object:
        return _finite_number_or_none(value, "agent profile timeoutSeconds")

    @field_validator("retry_backoff_seconds", mode="before")
    @classmethod
    def validate_backoff_type(cls, value: object) -> object:
        return _finite_number(value, "agent profile retryBackoffSeconds")


# Source compatibility inside the new repository while public documentation
# uses AgentSpec.  There is still one runtime model, not a second DTO.
WorkflowAgent = AgentSpec


class DynamicAgentPolicy(ContractModel):
    """Owner-controlled authority ceiling for Planner proposals."""

    planner_agent_id: str = Field(min_length=1)
    allowed_agent_profile_ids: tuple[str, ...] = ()
    allowed_roles: tuple[str, ...] = ()
    allowed_runtime_selectors: tuple[str, ...] = ()
    allowed_tool_names: tuple[str, ...] = ()
    allowed_features: tuple[str, ...] = ()
    allowed_skill_resource_ids: tuple[str, ...] = ()
    allowed_workspace_access: tuple[WorkspaceAccess, ...] = (WorkspaceAccess.READ,)
    allowed_override_fields: tuple[str, ...] = (
        "runtime_selector",
        "workspace_access",
        "input_mode",
        "required_features",
        "tool_names",
        "timeout_seconds",
        "max_attempts",
        "retry_backoff_seconds",
        "merge_overlays",
        "allow_runtime_subagents",
    )
    max_dynamic_agents: StrictInt = Field(default=8, ge=1)
    max_parallel_groups: StrictInt = Field(default=4, ge=0)
    max_concurrency: StrictInt = Field(default=4, ge=1)
    max_budget_units: StrictInt = Field(default=16, ge=1)
    max_agent_budget_units: StrictInt = Field(default=8, ge=1)
    max_attempts: StrictInt = Field(default=3, ge=1)
    max_timeout_seconds: float = Field(default=900.0, gt=0)

    @field_validator("planner_agent_id")
    @classmethod
    def validate_planner(cls, value: str) -> str:
        return _trimmed(value, "dynamic plannerAgentId")

    @field_validator(
        "allowed_roles",
        "allowed_agent_profile_ids",
        "allowed_runtime_selectors",
        "allowed_tool_names",
        "allowed_features",
        "allowed_skill_resource_ids",
        "allowed_override_fields",
    )
    @classmethod
    def validate_allowlists(cls, value: tuple[str, ...], info) -> tuple[str, ...]:  # type: ignore[no-untyped-def]
        return _unique_trimmed(value, f"dynamic policy {info.field_name}")

    @field_validator("allowed_workspace_access")
    @classmethod
    def validate_workspace_access(cls, value: tuple[WorkspaceAccess, ...]) -> tuple[WorkspaceAccess, ...]:
        if not value:
            raise ValueError("dynamic policy allowedWorkspaceAccess must not be empty")
        if len(value) != len(set(value)):
            raise ValueError("dynamic policy allowedWorkspaceAccess must not contain duplicates")
        return value

    @field_validator("max_timeout_seconds", mode="before")
    @classmethod
    def validate_max_timeout(cls, value: object) -> object:
        return _finite_number(value, "dynamic policy maxTimeoutSeconds")

    @model_validator(mode="after")
    def validate_limits(self) -> DynamicAgentPolicy:
        if self.max_agent_budget_units > self.max_budget_units:
            raise ValueError("maxAgentBudgetUnits cannot exceed maxBudgetUnits")
        known_overrides = {
            "runtime_selector",
            "workspace_access",
            "input_mode",
            "required_features",
            "tool_names",
            "timeout_seconds",
            "max_attempts",
            "retry_backoff_seconds",
            "merge_overlays",
            "allow_runtime_subagents",
        }
        unknown = sorted(set(self.allowed_override_fields).difference(known_overrides))
        if unknown:
            raise ValueError("dynamic policy contains unknown override fields: " + ", ".join(unknown))
        return self


class AgentGraph(ContractModel):
    """A validated DAG executed by the Application Kernel."""

    agents: tuple[AgentSpec, ...] = Field(min_length=1)
    parallel_groups: tuple[ParallelGroup, ...] = ()
    coordinator_agent_id: str = Field(default="agent_root", min_length=1)
    max_concurrency: StrictInt = Field(default=4, ge=1)
    ownership: MultiAgentOwnership = MultiAgentOwnership.APPLICATION
    dynamic_policy: DynamicAgentPolicy | None = None

    @field_validator("coordinator_agent_id")
    @classmethod
    def validate_coordinator(cls, value: str) -> str:
        return _trimmed(value, "coordinatorAgentId")

    @model_validator(mode="after")
    def validate_graph(self) -> AgentGraph:
        by_id = {agent.agent_id: agent for agent in self.agents}
        if len(by_id) != len(self.agents):
            raise ValueError("AgentGraph agentId values must be unique")
        if self.coordinator_agent_id in by_id:
            raise ValueError("coordinatorAgentId must not collide with an executing agent")

        groups = {group.group_id: group for group in self.parallel_groups}
        if len(groups) != len(self.parallel_groups):
            raise ValueError("AgentGraph parallel groupId values must be unique")
        collisions = sorted(set(groups).intersection(by_id))
        if collisions:
            raise ValueError(f"Parallel group IDs collide with agents: {', '.join(collisions)}")

        membership: dict[str, str] = {}
        for group in self.parallel_groups:
            if len(group.agent_ids) != len(set(group.agent_ids)):
                raise ValueError(f"Parallel group {group.group_id} repeats an agent")
            unknown_members = sorted(set(group.agent_ids).difference(by_id))
            if unknown_members:
                raise ValueError(f"Parallel group {group.group_id} has unknown agents: {', '.join(unknown_members)}")
            if group.join.quorum is not None and group.join.quorum > len(group.agent_ids):
                raise ValueError(f"Parallel group {group.group_id} quorum exceeds its member count")
            for agent_id in group.agent_ids:
                previous = membership.setdefault(agent_id, group.group_id)
                if previous != group.group_id:
                    raise ValueError(f"Agent {agent_id} belongs to multiple parallel groups")

        dependency_ids = set(by_id).union(groups)
        for agent in self.agents:
            unknown = sorted(set(agent.depends_on).difference(dependency_ids))
            if unknown:
                raise ValueError(f"Agent {agent.agent_id} has unknown dependencies: {', '.join(unknown)}")
            if agent.agent_id in agent.depends_on:
                raise ValueError(f"Agent {agent.agent_id} cannot depend on itself")
            if agent.merge_overlays:
                missing_dependencies = sorted(set(agent.merge_overlays).difference(agent.depends_on))
                if missing_dependencies:
                    raise ValueError(
                        f"Agent {agent.agent_id} must depend on every merged overlay: {', '.join(missing_dependencies)}"
                    )
                non_overlays = sorted(
                    source
                    for source in agent.merge_overlays
                    if source not in by_id or by_id[source].workspace_access != WorkspaceAccess.OVERLAY
                )
                if non_overlays:
                    raise ValueError(f"Agent {agent.agent_id} can only merge overlay agents: {', '.join(non_overlays)}")
            own_group = membership.get(agent.agent_id)
            if own_group is not None:
                if own_group in agent.depends_on:
                    raise ValueError(f"Agent {agent.agent_id} cannot depend on its own parallel group")
                peer_dependencies = sorted(set(agent.depends_on).intersection(groups[own_group].agent_ids))
                if peer_dependencies:
                    raise ValueError(
                        f"Parallel group member {agent.agent_id} cannot depend on peer(s): "
                        f"{', '.join(peer_dependencies)}"
                    )

        for group in self.parallel_groups:
            if group.join.mode not in {JoinMode.ALL, JoinMode.COLLECT, JoinMode.REDUCE} or (
                group.join.timeout_seconds is not None and group.join.timeout == TimeoutPolicy.PARTIAL
            ):
                direct_consumers = sorted(
                    agent.agent_id
                    for agent in self.agents
                    if set(agent.depends_on).intersection(group.agent_ids) and agent.agent_id not in group.agent_ids
                )
                if direct_consumers:
                    raise ValueError(
                        f"Consumers of partial join group {group.group_id} must depend on the groupId, "
                        f"not individual members: {', '.join(direct_consumers)}"
                    )

        if self.dynamic_policy is not None and self.dynamic_policy.planner_agent_id not in by_id:
            raise ValueError("dynamicPolicy plannerAgentId must name a static workflow agent")
        if self.ownership != MultiAgentOwnership.HYBRID:
            hybrid_agents = sorted(agent.agent_id for agent in self.agents if agent.allow_runtime_subagents)
            if hybrid_agents:
                raise ValueError(
                    "allowRuntimeSubagents is only valid for hybrid ownership: " + ", ".join(hybrid_agents)
                )

        visiting: set[str] = set()
        visited: set[str] = set()

        def dependencies(node_id: str) -> tuple[str, ...]:
            if node_id in groups:
                return groups[node_id].agent_ids
            return by_id[node_id].depends_on

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError(f"AgentGraph contains a dependency cycle at {node_id}")
            if node_id in visited:
                return
            visiting.add(node_id)
            for dependency in dependencies(node_id):
                visit(dependency)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in dependency_ids:
            visit(node_id)

        # The scheduler starts a parallel group as one unit after *all* of
        # its members' prerequisites complete. Contracting member identities
        # can create a cycle even when the node-level DAG above is acyclic.
        unit_dependencies: dict[str, set[str]] = {}
        for agent in self.agents:
            unit = membership.get(agent.agent_id, agent.agent_id)
            unit_dependencies.setdefault(unit, set()).update(
                membership.get(dependency, dependency) for dependency in agent.depends_on
            )
        remaining = set(unit_dependencies)
        while remaining:
            ready = {unit for unit in remaining if not unit_dependencies[unit].intersection(remaining)}
            if not ready:
                raise ValueError(
                    "AgentGraph scheduling unit dependency cycle: " + ", ".join(sorted(remaining))
                )
            remaining.difference_update(ready)
        return self


def _trimmed(value: str, name: str) -> str:
    if not value.strip() or value != value.strip():
        raise ValueError(f"{name} must be non-blank and trimmed")
    return value


def _unique_trimmed(values: tuple[str, ...], name: str) -> tuple[str, ...]:
    for value in values:
        _trimmed(value, name)
    if len(values) != len(set(values)):
        raise ValueError(f"{name} must not contain duplicates")
    return values


def _finite_number(value: object, name: str) -> object:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    return value


def _finite_number_or_none(value: object, name: str) -> object:
    if value is None:
        return None
    return _finite_number(value, name)
