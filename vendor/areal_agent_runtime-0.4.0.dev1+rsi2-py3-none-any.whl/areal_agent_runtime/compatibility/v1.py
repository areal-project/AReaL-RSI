"""Non-lossy internal models projected onto the frozen pre-data-plane v1 wire.

The canonical models deliberately contain richer lineage and governance.  Old
v1 consumers, however, were generated from ``additionalProperties=false``
schemas.  Sending additive fields to those consumers is therefore breaking,
even when every new field is optional for a new reader.

Public v1 Hosts use these projections for their legacy endpoints.  Runtime
Wire peers advertise data/v1 awareness through the already-existing opaque
``clientName`` value; peers using the historical name receive this projection.
No compatibility field is removed from the authoritative EventLog.
"""

from __future__ import annotations

import hashlib
import json
from typing import Final

from pydantic import JsonValue

from areal_agent_runtime.contracts.events import EventType, RunEvent
from areal_agent_runtime.contracts.product import RunSnapshot
from areal_agent_runtime.contracts.runtime import RuntimeDescriptor, RuntimeEvent
from areal_agent_runtime.contracts.wire import (
    DATA_AWARE_RUNTIME_CLIENT_NAME as DATA_AWARE_RUNTIME_CLIENT_NAME,
)
from areal_agent_runtime.contracts.wire import (
    LEGACY_RUNTIME_CLIENT_NAME as LEGACY_RUNTIME_CLIENT_NAME,
)

# Event API v1 values published before the data-plane extension.  New internal
# facts are represented as ignorable runtime.status entries on the old Host
# stream so sequence cursors remain monotonic without leaking ungoverned data.
LEGACY_EVENT_TYPE_VALUES: Final = frozenset(
    {
        "run.queued",
        "run.started",
        "run.resumed",
        "run.completed",
        "run.failed",
        "run.cancelled",
        "execution.started",
        "execution.completed",
        "execution.failed",
        "message.delta",
        "message.completed",
        "reasoning.delta",
        "asset.created",
        "asset.attached",
        "tool.requested",
        "tool.started",
        "tool.progress",
        "tool.completed",
        "tool.failed",
        "interaction.required",
        "interaction.resolved",
        "agent.started",
        "agent.scheduled",
        "agent.retry.scheduled",
        "agent.environment.resolved",
        "agent.message",
        "agent.completed",
        "agent.failed",
        "agent.cancelled",
        "orchestrator.decided",
        "runtime_graph.snapshotted",
        "parallel_group.started",
        "parallel_group.joined",
        "parallel_group.failed",
        "parallel_group.cancelled",
        "workspace.checkpointed",
        "session.committed",
        "usage.updated",
        "runtime.status",
        "warning.raised",
    }
)

_RUN_EVENT_V1_FIELDS: Final = (
    "apiVersion",
    "eventId",
    "sequence",
    "time",
    "runId",
    "sessionId",
    "executionId",
    "agentId",
    "parentAgentId",
    "causationId",
    "correlationId",
    "type",
    "data",
    "ignorable",
)
_RUN_SNAPSHOT_V1_FIELDS: Final = (
    "apiVersion",
    "runId",
    "sessionId",
    "profile",
    "status",
    "lastSequence",
    "error",
)

# Stable event types whose payloads had extra=forbid typed models before the
# data-plane extension.  Fields added for message/model lineage must not cross
# an old Runtime Wire connection.
_LEGACY_RUNTIME_DATA_FIELDS: Final[dict[str, frozenset[str]]] = {
    "message.delta": frozenset({"parentExecutionId", "groupId", "delta"}),
    "message.completed": frozenset({"parentExecutionId", "groupId", "content"}),
    "agent.message": frozenset({"parentExecutionId", "groupId", "content"}),
    "reasoning.delta": frozenset({"parentExecutionId", "groupId", "text", "final"}),
    "tool.requested": frozenset(
        {
            "parentExecutionId",
            "groupId",
            "callId",
            "name",
            "arguments",
            "rawArguments",
            "execution",
            "context",
        }
    ),
    "tool.started": frozenset(
        {
            "parentExecutionId",
            "groupId",
            "callId",
            "name",
            "arguments",
            "rawArguments",
            "execution",
            "context",
        }
    ),
    "tool.completed": frozenset(
        {
            "parentExecutionId",
            "groupId",
            "callId",
            "name",
            "arguments",
            "content",
            "value",
            "result",
            "summary",
            "error",
            "durationSeconds",
        }
    ),
    "tool.failed": frozenset(
        {
            "parentExecutionId",
            "groupId",
            "callId",
            "name",
            "arguments",
            "content",
            "value",
            "result",
            "summary",
            "error",
            "durationSeconds",
        }
    ),
    "interaction.required": frozenset(
        {
            "parentExecutionId",
            "groupId",
            "interactionId",
            "kind",
            "request",
            "terminal",
            "commitBarrier",
        }
    ),
    "interaction.resolved": frozenset(
        {"parentExecutionId", "groupId", "interactionId", "kind"}
    ),
}


def runtime_client_supports_data_v1(client_name: str) -> bool:
    """Return true only for the explicit data-aware Runtime Wire identity."""

    return client_name == DATA_AWARE_RUNTIME_CLIENT_NAME


def dump_event_api_v1(event: RunEvent) -> dict[str, JsonValue]:
    """Serialize one canonical RunEvent for the frozen legacy Event API v1."""

    payload = event.model_dump(mode="json", by_alias=True)
    if event.type == EventType.RUNTIME_GRAPH_SNAPSHOTTED:
        _project_runtime_graph_v1(payload.get("data"))
    if event.type.value not in LEGACY_EVENT_TYPE_VALUES:
        payload["type"] = EventType.RUNTIME_STATUS.value
        payload["data"] = {
            "compatibilityEventType": event.type.value,
            "omittedFromLegacyV1": True,
        }
        payload["ignorable"] = True
    return _select(payload, _RUN_EVENT_V1_FIELDS)


def dump_product_run_snapshot_v1(snapshot: RunSnapshot) -> dict[str, JsonValue]:
    """Serialize a RunSnapshot without post-baseline data-plane fields."""

    return _select(
        snapshot.model_dump(mode="json", by_alias=True),
        _RUN_SNAPSHOT_V1_FIELDS,
    )


def dump_runtime_descriptor_v1(descriptor: RuntimeDescriptor) -> dict[str, JsonValue]:
    """Serialize a Runtime descriptor accepted by pre-data-plane v1 peers."""

    payload = descriptor.model_dump(mode="json", by_alias=True)
    capabilities = payload.get("capabilities")
    if isinstance(capabilities, dict):
        capabilities.pop("dataCoverage", None)
    return payload


def dump_runtime_event_v1(event: RuntimeEvent) -> dict[str, JsonValue]:
    """Down-project a Runtime event for a pre-data-plane Runtime Wire peer."""

    payload = event.model_dump(mode="json", by_alias=True)
    event_type = event.type.value if isinstance(event.type, EventType) else event.type
    if event_type not in LEGACY_EVENT_TYPE_VALUES:
        # Old RuntimeEvent readers explicitly permit unknown names only when
        # ignorable=true. Keep the source type but omit payload details that the
        # old application cannot govern or canonicalize.
        payload["type"] = f"areal.agent-runtime.compatibility.omitted/{event_type}"
        payload["data"] = {"sourceType": event_type}
        payload["ignorable"] = True
        return payload
    allowed = _LEGACY_RUNTIME_DATA_FIELDS.get(event_type)
    if allowed is not None:
        data = payload.get("data")
        if isinstance(data, dict):
            payload["data"] = {key: value for key, value in data.items() if key in allowed}
    return payload


def _project_runtime_graph_v1(data: JsonValue) -> None:
    """Keep the old strict node shape and its corresponding snapshot digest."""
    if not isinstance(data, dict) or not isinstance(data.get("agents"), list):
        return
    changed = False
    for node in data["agents"]:
        if isinstance(node, dict) and "completionSequence" in node:
            node.pop("completionSequence")
            changed = True
    if changed and "snapshotDigest" in data:
        canonical = json.dumps(
            {key: value for key, value in data.items() if key != "snapshotDigest"},
            ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        )
        data["snapshotDigest"] = hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _select(
    payload: dict[str, JsonValue],
    fields: tuple[str, ...],
) -> dict[str, JsonValue]:
    return {field: payload[field] for field in fields if field in payload}
