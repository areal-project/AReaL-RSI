"""Runtime-neutral release profiles and trusted dynamic-agent catalogs."""

from __future__ import annotations

from pydantic import Field, StrictInt, field_validator, model_validator

from areal_agent_runtime.application.workflow import (
    AgentGraph,
    AgentInputMode,
    AgentProfile,
    AgentSpec,
    WorkspaceAccess,
)
from areal_agent_runtime.contracts.base import ContractModel
from areal_agent_runtime.contracts.content import ContentBlock, TextBlock
from areal_agent_runtime.contracts.environment import AgentEnvironmentLayer
from areal_agent_runtime.contracts.runtime import Modality


class WorkflowProfile(ContractModel):
    """One user-selectable release surface.

    agent_profiles is the trusted catalog available to this workflow's
    dynamic planner. It is distribution-owned configuration, never planner
    output.
    """

    profile_id: str = Field(min_length=1)
    version: str = Field(default="1.0.0", min_length=1)
    role: str = Field(min_length=1)
    system: tuple[ContentBlock, ...] = ()
    agent_environment: AgentEnvironmentLayer = Field(default_factory=AgentEnvironmentLayer)
    required_input_modalities: tuple[Modality, ...] = (Modality.TEXT,)
    required_features: tuple[str, ...] = ()
    max_stalled_actions: StrictInt | None = Field(default=None, ge=2, le=30)
    tool_names: tuple[str, ...] = ()
    agent_graph: AgentGraph | None = None
    agent_profiles: tuple[AgentProfile, ...] = ()

    @field_validator("profile_id", "version", "role")
    @classmethod
    def validate_text(cls, value: str) -> str:
        if not value.strip() or value != value.strip():
            raise ValueError("workflow profile identifiers must be non-blank and trimmed")
        return value

    @field_validator("required_input_modalities")
    @classmethod
    def validate_modalities(cls, value: tuple[Modality, ...]) -> tuple[Modality, ...]:
        if not value:
            raise ValueError("requiredInputModalities must not be empty")
        if len(value) != len(set(value)):
            raise ValueError("requiredInputModalities must not contain duplicates")
        return value

    @field_validator("required_features", "tool_names")
    @classmethod
    def validate_named_sets(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any(not item.strip() or item != item.strip() for item in value):
            raise ValueError("workflow profile feature/tool names must be non-blank and trimmed")
        if len(value) != len(set(value)):
            raise ValueError("workflow profile feature/tool names must not contain duplicates")
        return value

    @model_validator(mode="after")
    def validate_agent_catalog(self) -> WorkflowProfile:
        profile_ids = [profile.agent_profile_id for profile in self.agent_profiles]
        if len(profile_ids) != len(set(profile_ids)):
            raise ValueError("workflow profile AgentProfile catalog contains duplicate IDs")
        if self.agent_graph is None or self.agent_graph.dynamic_policy is None:
            if self.agent_profiles:
                raise ValueError("agentProfiles requires a graph with dynamicPolicy")
            return self
        policy = self.agent_graph.dynamic_policy
        missing = sorted(set(policy.allowed_agent_profile_ids).difference(profile_ids))
        if missing:
            raise ValueError("dynamicPolicy allows profiles absent from the catalog: " + ", ".join(missing))
        return self


def default_profiles() -> dict[str, WorkflowProfile]:
    """Vendor-neutral starter profiles for common interaction shapes."""

    base_system = (
        TextBlock(
            text=(
                "Complete the user's request using only the tools and workspace authority "
                "granted for this invocation. Report the result and material limitations."
            )
        ),
    )
    profiles = (
        WorkflowProfile(
            profile_id="general.default",
            role="general_agent",
            system=base_system,
            max_stalled_actions=3,
        ),
        WorkflowProfile(
            profile_id="general.interactive",
            role="interactive_agent",
            system=base_system,
            required_features=("interaction",),
        ),
        WorkflowProfile(
            profile_id="general.vision",
            role="vision_agent",
            system=base_system,
            required_input_modalities=(Modality.TEXT, Modality.IMAGE),
        ),
        WorkflowProfile(
            profile_id="general.pipeline",
            role="pipeline_coordinator",
            system=base_system,
            agent_graph=AgentGraph(
                max_concurrency=1,
                agents=(
                    AgentSpec(
                        agent_id="agent_requirements",
                        role="requirements_analyst",
                        workspace_access=WorkspaceAccess.WRITE,
                        input_mode=AgentInputMode.ORIGINAL,
                    ),
                    AgentSpec(
                        agent_id="agent_implementation",
                        role="implementation_engineer",
                        depends_on=("agent_requirements",),
                        workspace_access=WorkspaceAccess.WRITE,
                    ),
                    AgentSpec(
                        agent_id="agent_validation",
                        role="validation_engineer",
                        depends_on=("agent_implementation",),
                        workspace_access=WorkspaceAccess.WRITE,
                    ),
                ),
            ),
        ),
    )
    return {profile.profile_id: profile for profile in profiles}


__all__ = ["WorkflowProfile", "default_profiles"]
